# Future REST Structure for Backend API

This doc aims to document the base route structure functions we will use in the near future.

It is, however, subject to changes over time, especially during the fist implementation. Consider this an overall guide and not a final definition.

## Basic functions & versioning

```
https://<env-url>/api/v<api-version>/<endpoint>
```

#### Example: get all projects

```
GET https://<env-url>/api/v1/projects
```

## Direct project functions

There functions affect the project directly

### Create project

```
POST /projects
```

NOTE: POST body will be defined later but won't differ much from the current implementation.

### Get all projects

```
GET /projects
```

## Get specific project

```
GET /projects/<project-id>
```

# Delete project

```
DELETE /projects/<project-id>
```

## Project sub functions

These functions affect project fields

### Get project field

```
GET /projects/<project-id>/<field>
```

#### Example: Get members

```
GET /projects/<project-id>/members
```

### Update project property

```
PUT /projects/<project-id>/<property>
```

#### Example: Add members

```
PUT /projects/<project-id>/members
```

#### Example: Add repo

```
PUT /projects/<project-id>/repository
```

#### Example: Set accessibility level

```
PUT /projects/<project-id>/accessibility
```

NOTE: body will be defined later

### Delete project property

```
PUT /projects/<project-id>/<property>/<value-to-delete>
```

#### Example: Delete member

```
DELETE /projects/<project-id>/members/<member-id>
```

#### Example: Delete repository

```
DELETE /projects/<project-id>/repository
```

## Accessibility functions

### GET project access

Returns `200` if a user can access a project, `401` if they can't and `404` if the project does not exist

```
GET /access/projects/<project-id>
```

### Request project access

```
POST /access/projects/<project-id>
```
