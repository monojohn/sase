# Virtual Lab

[![pipeline status](https://gitlab.sofa.dev/virtual-lab/azure-functions/virtual-lab/badges/next/pipeline.svg)](https://gitlab.sofa.dev/virtual-lab/azure-functions/virtual-lab/-/commits/next)
[![Quality Gate Status](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=alert_status&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)
[![Reliability Rating](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=reliability_rating&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)
[![Security Rating](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=security_rating&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)
[![Vulnerabilities](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=vulnerabilities&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)
[![Maintainability Rating](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=sqale_rating&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)
[![Bugs](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=bugs&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)
[![Coverage](https://sonarqube.sofa.dev/api/project_badges/measure?project=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5&metric=coverage&token=2371c5525f44e93213ee3b3d52dced14b41b3477)](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5)

Check [SonarQube](https://sonarqube.sofa.dev/dashboard?id=virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5) for more info

# Overview

This is the main Back-end repository which owns the majority of functions the Front-end uses for Virtual Lab.

Azure Functions act as the code runner and are configured through the [Terraform](https://gitlab.sofa.dev/cloud/azure/iac/product-teams/vl) repositories.

We have a custom webpack build which consumes our typescript code and outputs javascript in the format Azure Functions expect.

For more details, checkout the [/webpack](https://gitlab.sofa.dev/virtual-lab/azure-functions/virtual-lab/-/tree/next/webpack) folder.

The other important repository is the [Project Template Assign](https://gitlab.sofa.dev/virtual-lab/azure-functions/project-template-assign). This is used in the project creation flow. You can check out the project creation's README.md for more details.

## Creating a new function

Go over the [/src/functions](https://gitlab.sofa.dev/virtual-lab/azure-functions/virtual-lab/-/tree/next/src/functions) for step by step instructions on how to create new functions and endpoints

## Accessing execution logs

Functions logs can only be seen via the Azure Storage Explorer only via one of the Windows VMs. Additionally, logs can be checked in Datadog or the errors direcly in the Slack channels.

## Accessing database

Database access can only be done via the VMs. We recommend using Mongo Compass. The connection URLs can be found as env vars.

## Running scripts

Some scrips are available in [/scripts](https://gitlab.sofa.dev/virtual-lab/azure-functions/virtual-lab/-/tree/next/scripts). More details can be found in that folder's README.md file.

## Cron jobs

We have a few active cron jobs, more details can be found in [/src/functions/virtuallab-cron](https://gitlab.sofa.dev/virtual-lab/azure-functions/virtual-lab/-/tree/next/src/functions/virtuallab-cron). More details can be found in that folder's README.md file.

## Local development

### Building

Run the following command to build all functions locally:

```
yarn build:dev
```

Run the following command to build 1 functions locally:

```
yarn build:dev --env func=<function-directory-name>
```

Example:

```
yarn build:dev --env func=virtuallab
```

### Running function

```
func start --javascript  --script-root <path to function>
```

Example:

```
func start --javascript  --script-root ./dist/virtuallab
```

### Running tests

Run the following command to run a specific test file

```
yarn test:int --testRegex <file name>
```

Example:

```
yarn test:int --testRegex my-feedback.test.ts
```

### Coverage

To run integration tests with coverage, use the following command inside the VM:

```
yarn test:cov
```

Or run the integration tests step in the pipeline. This will run the tests with coverage and push the new coverage back to the branch.

To run unit tests with coverage, use the following command:

```
yarn test:unitcov
```

Then push the new coverage to the branch and check SonarQube.

## Release & branching

### Branch structure

The structure of the branches is the following:

- `main` is the code that is stable, the one deployed already to production
- `next` is the newely developed stable code that can be deployed to dev or staging, in which we push feature branches.

As a standard, we use `sutec-xxxx-short-description` where SUTEC xxxx is the number of the ticket in Jira. Merge requests are then created from the feature branch to the next branch with squash commits.

After developing, the feature is deployed to dev, tested and the code is reviewed by someone else in the project. Also pay attention to the static checks (runs automatically in the pipeline) and SonarQube. The SonarQube step has to be run manually and then the overall status of the changes have to be checked: coverage should be above 80% and there should be no open issues.

Then it is merged to `next` and can be deployed to staging to be tested for business approval.

Additionally, other branches can be created as `bug-..` or `chore-..` when there is no story / task behind it.

### Hotfix

Steps for hotfix preparation:

- create hotfix branch from `main` with name `hotfix--short-description`
- work on hotfix branch itself and create merge request to `main`
- during hotfix, deploy directly from `hotfix` branch to prod, running `PRD Deploy all`
- the next day, after confirming everything worked correctly, merge the hotfix MR to main with squash commit (we want just one commit as the hotfix usually represents one specific fix)
- rebase to next

### Release

Steps for release preparation:

- create and deploy (to dev) release branch from `next` with name `release--dd-mm-yyyy`
- create draft merge request to main so the changes can be reviewed
- if bugs are found during testing, create merge requests directly to the release branch
- during the release, deploy from the release branch, running `PRD Deploy all`
- the next day, after confirming everything worked correctly, merge the release MR to main without squash commit (we want each feature to reflect a commit so the history can be easily tracked)
- rebase to next

Additionally, for both release and hotfix, scripts to migrate or update things may need to be run. Usually, this is done after deployment is finished and the change has been tested on a new project to make sure it is working.

In case of anything going wrong, a script that updates existing projects may be harder to revert, but for the deployment itself, it is enough to deploy again from the main branch which is the stable code version.

## Maintenance activities

### Certificates renewal

We have certain accounts in place which use certificates or access tokens. Those certificates and tokens need to be updated on a regular basis as they have a set expiration date. Tickets are created in Jira in the maintenance epic with expiration dates for all of these expirations.

Instructions on how to request the change and what to do with them afterwords can be found [here](https://europeancentralbank.atlassian.net/wiki/spaces/SUPTEC/pages/58799501/Certificates+passwords+and+secrets+renewal). Action has to be taken usually a couple of weeks before the actual expiration as there might be approvals in place which require time. Updating values in production require a release like procedure, in which the `main` branch is redeployed after the new values are put in place (unless the change happens to coincide with an actual release).

Steps to follow on a renewal:

- follow the steps in the link above to:
  - request the new value
  - update the new value
  - deploy
- validate the update worked - a single action is enough. for example, if the Graph certificate has been updated, a test to check if users can be loaded would cover it
- update the new expiration date [here](https://europeancentralbank.atlassian.net/wiki/spaces/SUPTEC/pages/58798985/Secrets+Certificates+Passwords)
- create a new Jira ticket with the next expiration date in the maintenance epic so it can be tracked in the future

### Slack messages

Warnings and errors are currently sent as notifications to our Slack channels. We have 3 channels, `vl-errors-tst`, `vl-errors-stg`, `vl-errors-prd`. On every message that is being posted, there is the option to check the detailed logs in DataDog.
There are different types of messages that are being sent. Some are just informative (like the messages for backups being created and old backups being deleted), the others may require additional attention.

There are scheduled cron jobs that post messages like the ones for the monthly and weekly cleanups. These return a list of projects with the number of times that were found meeting that condition (e.g., project x found inactive 2 times) and a flag on whether they should be deleted or not. Currently, this action is not automated as the users may have contacted us directly through our mailbox asking for exceptions or something else.

Everything else needs to be paid attention too. There can be issues with IGAM / IAM, in which case the teams need to be contacted to be made aware of the issue. Or there can be changes in API responses, broken projects, issues with user accounts etc. Each issue may be unique and it has to be investigated and potentially fixed.

### VL Admin team list

On top of the Sharepoint pages, we use the Portal Customizer to hide certain elements from the users (settings wheel, banners, menus). Until the move to the new UI which involved switching from using public functions to private functions, the portal customizer was calling the Graph API function to get data about the user (like email, groups etc.).

With the move to private function, the Sharepoint page would not be able to call this private functions so a workaround had to be set in place. Now, the general info about the user like email and upn are retrieved from the /currentUser API call which is made to the Sharepoint site and the info about the groups was reduced to just knowing if user is VL admin or not.

Instead of using a call to Graph API which would imply keeping the function public, extra cost and exception from architecture and security, the workaround in place is to use a Sharepoint list. The list is called VLAdmins and it contains the display name of the account which is VL admin and the oid. The oid is then compared with the oid of the logged in user, thus knowing if the user is admin or not and showing extra options in case it is.

The maintenance activity behind this is that the list should be maintained on the dev, staging and prod environment in case of team members joining or leaving the team. It is a low effort manual action.
