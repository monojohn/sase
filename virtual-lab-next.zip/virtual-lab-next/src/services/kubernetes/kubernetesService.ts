import { CoreV1Api, KubeConfig } from "@kubernetes/client-node";
import { KUBECONFIG } from "../../utils/config";

let kc: CoreV1Api;

const namespace = (namespaceName: string) => ({
  metadata: {
    name: namespaceName,
  },
});

const connect = () => {
  if (!kc) {
    const kubConfig = new KubeConfig();
    const buff = Buffer.from(KUBECONFIG, "base64");
    const kube = buff.toString("ascii");
    kubConfig.loadFromString(kube);
    kc = kubConfig.makeApiClient(CoreV1Api);
  }

  return kc;
};

const KubernetesService = {
  async listPod() {
    const k8sApi = connect();
    return k8sApi.listNamespacedPod({ namespace: "default" });
  },

  async createNamespace(namespaceName: string) {
    const k8sApi = connect();
    return k8sApi.createNamespace({ body: namespace(namespaceName) });
  },

  async deleteNamespace(namespaceName: string) {
    const k8sApi = connect();
    return k8sApi.deleteNamespace({ name: namespaceName });
  },
};

export default KubernetesService;
