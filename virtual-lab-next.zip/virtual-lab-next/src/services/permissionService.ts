import { Context } from "@azure/functions";
import { VL_ADMINS_GROUP_ID, VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../utils/config";
import { AccessibilityLevel } from "./dbConnector/enums";
import SharePointService from "./sharepointService/sharepointService";

const PermissionService = {
  /**
   * Set Site Pages permissions to read for members
   */
  async setPermissions(ctx: Context, type: AccessibilityLevel, site: string) {
    ctx.log(`Setting permissions for ${type} ${site}`);
    const updates = [
      SharePointService.setSitePagesPermissions(ctx, site),
      SharePointService.addOwnerGroups(ctx, site, [VL_ADMINS_GROUP_ID]),
    ];

    if (type === AccessibilityLevel.Public) {
      ctx.log(`Public project detected, adding VL groups to visitors`);
      updates.push(
        SharePointService.addVisitorGroups(ctx, site, [VL_MEMBERS_GROUP_ID, VL_GUESTS_GROUP_ID]),
      );
    }

    return Promise.all(updates);
  },
};

export default PermissionService;
