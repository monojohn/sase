export type IamUser = {
  country: string; // 'DE',
  lastName: string; // 'WERNER'
  organizationPath: string; // 'Top:Users:ESCB:Deutsche Bundesbank (DE)'
  gender: null;
  mobileNumber: null;
  jobTitle: null;
  otherPhoneNumber: null;
  adminCapability: []; // always empty so far
  personalEmail: string; // firstname.lastname@bank.country
  accountValidityDate: string; // '31-10-3088'
  secretary: null;
  BICCode: null;
  userCategory: string; // 'Standard'
  contactLanguage: string; // 'English'
  tcsIconPosition: null;
  department: null;
  domesticUserID: string; // 'BA598WN'
  iamOrganizationID: string; // 'BBk'
  functionalEmail: string; // "testDarwin@bdf.local";
  tcsExtensionNumber: null;
  fullName: string; //   "Christian WERNER";
  userKey: number; // 6011
  userLogin: string; // DEBA598WN;
  firstName: string; // Christian;
  phoneNumber: null;
  identityStatus: string; // Active;
  rsaTokenID: null;
  faxNumber: null;
  location: null;
  middleName: null;
  tcsTelephoneNumber: null;
  orgKey: number; // 18
};

/**
 * Returned by the /getRoles endpoint
 */
export type IamFullRole = {
  listRoleExclusion: [];
  workflow: string; // "Application"
  displayName: string; // "Non-ESCB-Users"
  description: string; // "Role dedicated to non ESCB users"
  listRoleInclusion: [];
  listApprovers1: [];
  AAA_Group2: string; // ""
  AAA_Group1: string; // ""
  listApprovers2: [];
  name: string; // "VLAB_Non-ESCB-Users"
  disabled: boolean; // false
  key: string; // "7118"
  applicationName: string; // "VLAD"
};

/**
 * Data type used internally
 */
export type IamRole = {
  displayName: string; // "Non-ESCB-Users"
  roleName: string; // "VLAB_Non-ESCB-Users"
  key: string; // "7118"
};

export type GetRolesResponse = {
  Roles: IamFullRole[];
  Info: {
    backUri: string; // ?offset=0&limit=15
    nextUrl: string; // ?offset=15&limit=15
    itemsReturned: number; // 1
  };
};

/**
 * IAM types are inconsistent so we standardise them
 */
export type GetAllRolesResponse = {
  displayName: string; // 'ESCB-Employee',
  name: string; // 'VLAB_ESCB-Employee',
  key: string; // '7117'
  // new params
  roleName: string; // 'VLAB_ESCB-Employee',
  roleKey: string; // '7117'
};

/**
 * IAM types are inconsistent so we standardise them
 */
export type GetAllUserRolesByUserLoginResponse = {
  displayName: string; // 'ESCB-Employee',
  roleName: string; // 'VLAB_ESCB-Employee',
  key: number; // 7117
  // new param
  roleKey: string; // '7117'
};
