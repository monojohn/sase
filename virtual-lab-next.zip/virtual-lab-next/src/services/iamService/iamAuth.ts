import axios from "axios";
import URL from "node:url";
import { IAM_AUTH_URL, IAM_CLIENT_ID, IAM_CLIENT_SECRET } from "../../utils/config";
import { IamTokenResponse } from "./iamAuth.types";

const tokenUrl = `${IAM_AUTH_URL}/oauth2/rest/token`;
const IamAuth = {
  async getToken() {
    const params = new URL.URLSearchParams({
      grant_type: "CLIENT_CREDENTIALS",
      scope: ["IAMRestAPI.useapi"],
    });

    const base64Auth = Buffer.from(`${IAM_CLIENT_ID}:${IAM_CLIENT_SECRET}`).toString("base64");

    const rsp = await axios.post<IamTokenResponse>(tokenUrl, params, {
      headers: {
        Authorization: `Basic ${base64Auth}`,
        // "X-OAUTH-IDENTITY-DOMAIN-NAME": "domain", // NOTE: docs say it's needed but it's not
      },
    });

    return rsp.data;
  },
};

export default IamAuth;
