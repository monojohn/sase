import { Context } from "@azure/functions";
import axios, { AxiosError } from "axios";
import { IAM_BASE_URL } from "../../utils/config";
import IamAuth from "./iamAuth";
import { IamError, IamTokenResponse } from "./iamAuth.types";

let tokenExpirationTime = 0;
let iamToken: IamTokenResponse | null = null;

/**
 * Creates a new axios instance with custom interceptors.
 * One instance must be created per call since Azure Functions are stateful and the `cxt` logging stops working between calls
 *
 * @param ctx
 * @returns AxiosInstance
 */
export const getInstance = (ctx: Context) => {
  const instance = axios.create({ baseURL: IAM_BASE_URL });
  ctx.log(`Creating IAM instance in ${IAM_BASE_URL}`);

  // add interceptor to add token to all requests
  instance.interceptors.request.use(async (config) => {
    // if token does not exist or is expired, fetch a new one.
    if (!iamToken || Date.now() > tokenExpirationTime) {
      ctx.log(`Getting token `);
      iamToken = await IamAuth.getToken();
      ctx.log(`Received IAM token`, {
        ...iamToken,
        // hide access token from logs
        access_token: "REDACTED",
      });
      // remove 60 seconds to account for delays
      tokenExpirationTime = Date.now() + (iamToken.expires_in - 60) * 1000;
      ctx.log(`Setting expiration date to ${new Date(tokenExpirationTime).toISOString()}`);
    }

    // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-unsafe-member-access -- this is from axios doc's
    config.headers.Authorization = `Bearer ${iamToken.access_token}`;
    return config;
  });

  instance.interceptors.response.use(undefined, (err: Error) => {
    let errorText = err?.name;
    const errorData = err?.message;

    const axiosError = err as AxiosError<IamError>;
    if (axios.isAxiosError(err) && axiosError.response?.data) {
      const { response } = axiosError;
      const { data, status, statusText } = response;
      // response is present
      errorText = `${status} - ${statusText}: ${data.Exception}`;
    }
    const error = `IAM error: ${errorText}: ${errorText}`;
    ctx.log(err);
    ctx.log(error);
    ctx.log(errorData);
    throw new Error(error);
  });

  return instance;
};
