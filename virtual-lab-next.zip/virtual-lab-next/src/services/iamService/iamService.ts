import { Context } from "@azure/functions";
import { IAM_SPLIT_TERM } from "../../utils/config";
import { getInstance } from "./helpers";
import {
  GetAllRolesResponse,
  GetAllUserRolesByUserLoginResponse,
  IamRole,
  IamUser,
} from "./iamService.types";
import { GraphUser } from "../graphService/types";

type SimplifiedUser = Pick<GraphUser, "userPrincipalName" | "mail">;

/**
 * Gets a lowercase IAM user name from Graphs's UPN or their email for B2B users
 *
 * @param user upn and mail
 * @returns
 */
const getIamUserName = (user: SimplifiedUser) => {
  if (user.userPrincipalName.includes(IAM_SPLIT_TERM)) {
    // user in IAM
    return user.userPrincipalName.split(IAM_SPLIT_TERM)[0].toLocaleLowerCase();
  }
  // user with bank email
  return user.mail.toLocaleLowerCase();
};

const IamService = {
  async getUsers(ctx: Context, users: SimplifiedUser[]) {
    ctx.log(`Fetching ${users.length} IAM users`);
    return Promise.all(users.map((user) => IamService.getUser(ctx, user)));
  },

  async getUser(ctx: Context, user: SimplifiedUser) {
    const name = getIamUserName(user);

    const url = `/getUsers/${name}?limit=10&offset=0`;
    ctx.log({ url });
    const { data } = await getInstance(ctx).get<{ Users: IamUser[] }>(url);
    return data.Users.find(
      ({ userLogin, personalEmail }) =>
        name === userLogin?.toLocaleLowerCase() || name === personalEmail?.toLocaleLowerCase(),
    );
  },

  async getRoles(ctx: Context, roleName: string): Promise<IamRole[]> {
    const { data } = await getInstance(ctx).get<{ Roles: GetAllRolesResponse[] }>(
      `/getAllRoles/${roleName}?limit=15&offset=0`,
    );
    return data.Roles
      ? data.Roles.map((role) => ({
          displayName: role.displayName,
          roleName: role.roleName ?? role.name,
          key: `${role.roleKey ?? role.key}`,
        }))
      : [];
  },

  async getRole(ctx: Context, name: string) {
    const lowercaseName = name.toLocaleLowerCase();
    const roles = await IamService.getRoles(ctx, name);
    return roles.find(({ roleName }) => roleName.toLocaleLowerCase() === lowercaseName);
  },

  async getUserRoles(ctx: Context, user: SimplifiedUser): Promise<IamRole[]> {
    let name: string;
    // verify where the user is coming from in case we don't need the extra request
    if (user.userPrincipalName.includes(IAM_SPLIT_TERM)) {
      // user is IAM
      name = getIamUserName(user);
    } else {
      // get the user's userLogin as we can't send their email address or UPN
      const iamUser = await this.getUser(ctx, user);
      name = iamUser?.userLogin ?? "";
    }
    const url = `/getAllUserRolesByUserLogin/${name}`;
    ctx.log({ url });
    const { data } = await getInstance(ctx).get<GetAllUserRolesByUserLoginResponse[] | string>(url);

    if (!Array.isArray(data)) {
      // IAM returns '' when the user is missing
      ctx.log(`Empty response from IAM `);
      return [];
    }

    return data.map((iamRole) => ({
      displayName: iamRole.displayName,
      roleName: iamRole.roleName,
      key: `${iamRole.key ?? iamRole.roleKey}`,
    }));
  },
};

export default IamService;
