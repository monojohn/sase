export type IamTokenResponse = {
  access_token: string; // 'eyJraWQiOiJLZXlQYW3.......iqlre3fjpnYz6K4sWBuw',
  token_type: "Bearer";
  expires_in: number; // 3600
};

export type IamError = {
  Exception: string; // API Gateway encountered an error
};
