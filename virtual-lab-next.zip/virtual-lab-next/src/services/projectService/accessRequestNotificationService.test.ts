import { jest } from "@jest/globals";
import NotificationService from "./accessRequestNotificationService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Access Request NotificationService", () => {
  it("sendAccessRequestEmail works", async () => {
    await NotificationService.sendAccessRequestEmail(ctx, [userEmail], {
      message: "message",
      projectName: "test",
      ctaUrl: "url",
      senderName: "Unit test",
    });
  });

  it("sendAccessDeniedEmail works", async () => {
    await NotificationService.sendAccessDeniedEmail(ctx, userEmail, {
      message: "message",
      projectName: "Test project",
      senderName: "Unit test",
    });
  });

  it("sendAccessApprovedEmail works", async () => {
    await NotificationService.sendAccessApprovedEmail(ctx, userEmail, "email", "test project");
  });
});
