import { Context } from "@azure/functions";
import EmailService from "../emailService/emailService";
import { TEMPLATE_ID } from "../emailService/flowmailer";
import { InformationWithMessageEmail } from "../emailService/types";

type AccessRequestProps = {
  projectName: string;
  senderName: string;
  message: string;
  ctaUrl: string;
};

const AccessRequestNotificationService = {
  async sendAccessRequestEmail(ctx: Context, emails: string[], props: AccessRequestProps) {
    const { projectName, senderName, message, ctaUrl } = props;
    const subject = `[Action required] Membership request for project ${projectName}`;
    const preHeadline = "Membership request for project";
    const postHeadline = `${props.senderName} wants member access, with the following message.`;
    const postMessage =
      "As an owner, this request can be either accepted or rejected from the project site.";
    const ctaLabel = "Review Membership";

    // https://dashboard.flowmailer.net/design/templates/edit.html?id=67695
    await EmailService.sendEmail(ctx, TEMPLATE_ID.INFORMATION_WITH_MESSAGE_CTA, {
      subject,
      bcc: emails,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        postMessage,
        senderName: `${senderName}:`,
        message: `"${message}"`,
        ctaLabel,
        ctaUrl,
      },
    });
  },

  async sendAccessDeniedEmail(
    ctx: Context,
    email: string,
    {
      projectName,
      senderName,
      message,
    }: Pick<InformationWithMessageEmail, "projectName" | "senderName" | "message">,
  ) {
    const subject = `[Notification] Request for project access rejected`;
    const preHeadline = `Your membership request for the project`;
    const postHeadline = `has been rejected by ${senderName} as project owner with the message "${message}". In case you believe this is an error, please reach out to the project owner.`;

    // https://dashboard.flowmailer.net/design/templates/edit.html?id=67455
    await EmailService.sendInformationWithMessageEmail(ctx, {
      subject,
      bcc: email,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        senderName: "",
        message: "",
      },
    });
  },

  async sendAccessApprovedEmail(
    ctx: Context,
    email: string,
    projectUrl: string,
    projectName: string,
  ) {
    const subject = `[Notification] Membership request approved for project ${projectName}`;
    const headline = `Your membership request has been approved. You can now access the project.`;

    return EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc: email,
      templateData: {
        projectName,
        ctaUrl: projectUrl,
        ctaLabel: "View project board",
        headline,
      },
    });
  },

  async sendSuccessEmail(
    ctx: Context,
    projectName: string,
    userName: string,
    accessRights: string,
    ctaUrl: string,
    emails: string[],
  ) {
    const subject = `[Action required] Request for project access`;
    const preHeadline = `Request for project access`;
    const headline = `${userName} wants ${accessRights} access. As an owner, this request can be either accepted or rejected from the project site.`;

    await EmailService.sendInfoCtaEmail(ctx, {
      subject,
      bcc: emails,
      templateData: {
        projectName,
        preHeadline,
        headline,
        ctaLabel: "Review Access",
        ctaUrl,
      },
    });
  },
};

export default AccessRequestNotificationService;
