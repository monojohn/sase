import { Context } from "@azure/functions";
import { UI_DOMAIN } from "../../utils/config";
import { DataSensitivityLevel, RequestStatus } from "../dbConnector/enums";
import EmailService from "../emailService/emailService";

type SendOwnershipInvitationEmailProps = {
  bcc: string;
  projectName: string;
  requiresApproval: boolean;
};

type SendDataSensitivityChangeEmailProps = {
  projectName: string;
  bcc: string[];
  dataSensitivityLevel: DataSensitivityLevel;
  ctaUrl: string;
};

type FailedStatuses = RequestStatus.CLOSED | RequestStatus.EXPIRED | RequestStatus.REJECTED;

const contactBaOrg =
  "We recommend reaching out to your relevant BA Org contacts to ensure they are aware of your request. It may be helpful to discuss any additional information that might be required for approval in the future. This way, you can address any potential issues and resubmit your request with confidence.";
const partialRejection =
  "We suggest contacting your BA Org representatives to understand the reasons for the rejection. By doing so, you can address any concerns and resubmit your request with greater confidence.";
const rejection = `has been rejected by the relevant Business Area Organization (BA Org). ${partialRejection}`;

const NotificationService = {
  async sendOwnershipInvitationEmail(ctx: Context, data: SendOwnershipInvitationEmailProps) {
    let headline = `
  <div style="padding:0px 0px 18px 0px; line-height:22px; text-align:justify;">
    If you want to accept the project owner role, please click on see invitations below or go to the invitations tab on the Virtual Lab landing page.
    <br />
    Before accepting this role, please make sure to read the <a style="color: #00858c;" href="${UI_DOMAIN}/help">list of responsibilities</a> that this role entails.
  </div>
`;
    if (data.requiresApproval) {
      headline += `
      <div style="padding:0px 0px 18px 0px; line-height:22px; text-align:justify;">
   Please be aware that you must first accept this request in Virtual Lab before it can be forwarded to IGAM for approval by the Business Area Organization (BA Org). Once you accept the request, it will be sent to IGAM, initiating the approval process with the relevant BA Org.
  </div>
      `;
    }

    const preHeadline = `You have been invited as project owner to the`;
    const subject = `[Action required] You have been invited to join as project owner to the ${data.projectName} project`;

    return EmailService.sendInfoCtaEmail(ctx, {
      subject,
      bcc: data.bcc,
      templateData: {
        projectName: data.projectName,
        preHeadline,
        headline,
        ctaLabel: "See invitations",
        ctaUrl: `${UI_DOMAIN}/projects`,
      },
    });
  },

  async sendDataSensitivityChangeEmail(ctx: Context, props: SendDataSensitivityChangeEmailProps) {
    const { projectName, bcc, ctaUrl, dataSensitivityLevel } = props;

    const subject = `[Notification] CSI data permissions changed for ${projectName} project`;
    let headline = `Dear Virtual Lab user, please note that CSI data permissions have been changed for your Virtual Lab project named ${projectName}. The project has been reclassified and is currently <b>${
      dataSensitivityLevel === DataSensitivityLevel.CSI ? "allowed" : "not allowed"
    } to use CSI data.</b>`;

    if (dataSensitivityLevel === DataSensitivityLevel.CSI) {
      headline += ` Please follow the <a style="color: #00858c;" href="https://darwin.escb.eu/livelink/livelink/app/nodes/1792308987">guide on handling CSI data</a>. Find here <a style="color: #00858c;" href="https://darwin.escb.eu/livelink/livelink/app/nodes/1792277733">an overview of datasets considered to contain CSI data</a>.`;
    }

    await EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "View project",
        ctaUrl,
      },
    });
  },

  sendProjectCreationRejectionEmail(
    ctx: Context,
    name: string,
    bcc: string,
    status: FailedStatuses,
  ) {
    const preHeadline = "Your request to create the project";
    const messageMap = {
      [RequestStatus.EXPIRED]: {
        subject: `[Action required] Expiration of Project Request for ${name} project`,
        postHeadline: `has expired because it was not approved by the relevant Business Area Organization (BA Org) within the required timeframe.<br>${contactBaOrg}`,
      },
      [RequestStatus.CLOSED]: {
        subject: `[Action required] Closure of Project Request for ${name} project`,
        postHeadline: `has been closed because it was not approved by the relevant Business Area Organization (BA Org) within the required timeframe.<br>${contactBaOrg}`,
      },
      [RequestStatus.REJECTED]: {
        subject: `[Action required] Rejection of Project ${name}`,
        postHeadline: rejection,
      },
    };

    const message = messageMap[status];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject: message.subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline: message.postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  sendConfidentialityPendingApprovalEmail(
    ctx: Context,
    name: string,
    bcc: string[],
    requestId: string,
    org: string,
    approvers: string[],
  ) {
    const subject = `[Notification] Approval Pending for Project Confidentiality Request for ${name} project`;

    const preHeadline = `Your request ${requestId} to increase the confidentiality of your project`;
    const postHeadline = [
      `has been submitted to the relevant Business Area Organization (${org}) in IGAM for approval. Please be aware that the approval process can take some time, as the BA Org ${org} has 15 days to review your request. Below you can find the list of approvers.`,
      '<ul style="text-align: left;">',
      ...approvers.map((approver) => `<li>${approver}</li>`),
      "</ul>",
      `To ensure smooth communication and efficiency, please reach out to your approvers only in cases where there are delays in approval. You will receive a notification once your request has been approved.`,
    ];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline: postHeadline.join(""),
        senderName: ``,
        message: ``,
      },
    });
  },

  sendConfidentialityUpdateRejectionEmail(
    ctx: Context,
    name: string,
    bcc: string[],
    status: FailedStatuses,
  ) {
    const preHeadline = `Your request to increase the confidentiality level of your project ${name}`;
    const messageMap = {
      [RequestStatus.EXPIRED]: {
        subject: `[Action required] Expiration of Project Confidentiality Request for ${name} project`,
        postHeadline: `has expired, as it was not approved by the relevant Business Area Organization (BA Org) in time.<br>${contactBaOrg}`,
      },
      [RequestStatus.REJECTED]: {
        subject: `[Notification] Rejection of Project Confidentiality Request for ${name} project`,
        postHeadline: rejection,
      },
      [RequestStatus.CLOSED]: {
        subject: `[Action required] Closure of Project Confidentiality Request for ${name} project`,
        postHeadline: `has been closed, as it was not approved by the relevant Business Area Organization (BA Org) in time.<br>${contactBaOrg}`,
      },
    };

    const { subject, postHeadline } = messageMap[status];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  async sendConfidentialityUpdatedEmail(
    ctx: Context,
    bcc: string[],
    projectName: string,
    ctaUrl: string,
  ) {
    const subject = `[Notification] Approval of Project Confidentiality Request for ${projectName} project`;

    const headline = `Your request to increase the confidentiality of your project ${projectName} has been approved by the relevant Business Area Organization (BA Org) in IGAM. You can now begin uploading content in accordance with the updated confidentiality level.<br>Please ensure that all project members are authorized to access this content under the new confidentiality settings. Note that all project members will be granted access to these documents, so it's important to verify that all members are still valid participants of your project. Be sure to remove any outdated members to ensure that only relevant users have access to this sensitive information.<br>Thank you for paying attention to these details, and we hope you have a productive collaboration using Virtual Lab.`;

    return EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "View project",
        ctaUrl,
      },
    });
  },

  async sendOrgUpdateRequestedEmail(
    ctx: Context,
    name: string,
    bcc: string[],
    requestId: string,
    org: string,
    approvers: string[],
  ) {
    const subject = `[Notification] Approval Pending for BA Org Reassignment Request for ${name} project`;

    const preHeadline = `Your request ${requestId} to reassign the appropriate Business Area Organization (BA Org) for your project`;
    const postHeadline = [
      `has been forwarded to the relevant BA Org (${org}) in IGAM for approval. Please be aware that the approval process can take some time, as the BA Org ${org} has 15 days to review your request. Below you can find the list of approvers.`,
      '<ul style="text-align: left;">',
      ...approvers.map((approver) => `<li>${approver}</li>`),
      "</ul>",
      `To ensure smooth communication and efficiency, please reach out to your approvers only in cases where there are delays in approval. You will receive a notification once your request has been approved.`,
    ];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline: postHeadline.join(""),
        senderName: ``,
        message: ``,
      },
    });
  },

  async sendOrgUpdateRejectedEmail(
    ctx: Context,
    name: string,
    bcc: string[],
    status: FailedStatuses,
    org: string,
  ) {
    const preHeadline =
      "Your request to update the relevant Business Area Organization (BA Org) of project ";
    const messageMap = {
      [RequestStatus.EXPIRED]: {
        subject: `[Action required] Expiration of BA Org Update Request for ${name} project`,
        postHeadline: `has expired because it was not approved by the relevant Business Area Organization (BA Org) ${org} within the required timeframe.<br>${contactBaOrg}`,
      },
      [RequestStatus.REJECTED]: {
        subject: `[Action required] Rejection of BA Org Update Request for ${name} project`,
        postHeadline: `has been rejected by the relevant BA Org in IGAM (${org}). ${partialRejection}`,
      },
      [RequestStatus.CLOSED]: {
        subject: `[Action required] Closure of BA Org Update Request for ${name} project`,
        postHeadline: `has been closed because it was not approved by the relevant Business Area Organization (BA Org) ${org} within the required timeframe.<br>${contactBaOrg}`,
      },
    };

    const { subject, postHeadline } = messageMap[status];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  async sendOrgUpdatedEmail(
    ctx: Context,
    bcc: string[],
    org: string,
    projectName: string,
    ctaUrl: string,
  ) {
    const subject = `[Notification] Approval of BA Org Update Request ${projectName}`;

    const headline = `Your request to reassign the appropriate Business Area Organization (BA Org) for your project ${projectName} has been approved. Please be aware that the new BA Org ${org} is now responsible for reviewing project-related requests incl. the yearly user recertification.`;

    return EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "View project",
        ctaUrl,
      },
    });
  },

  async sendAddingOwnerApprovedEmail(
    ctx: Context,
    bcc: string[],
    user: string,
    projectName: string,
    ctaUrl: string,
  ) {
    const subject = `[Notification] Approval of Project Owner Request for ${projectName} project`;

    const headline = `Your request to add an additional Project Owner ${user} for ${projectName} has been approved by the relevant Business Area Organization (BA Org). Please note that the new Project Owner will soon receive the updated status in the Virtual Lab Project, allowing him or her to proceed with their Project Owner responsibilities.`;

    return EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "View project",
        ctaUrl,
      },
    });
  },

  sendAddingOwnerRejectionEmail(
    ctx: Context,
    name: string,
    bcc: string[],
    status: FailedStatuses,
    invitedOwner: string,
  ) {
    const preHeadline = `Your request to add an additional Project Owner ${invitedOwner} to your project`;
    const messageMap = {
      [RequestStatus.REJECTED]: {
        subject: `[Notification] Rejection of Project Owner Request for ${name} project`,
        postHeadline: rejection,
      },
      [RequestStatus.EXPIRED]: {
        subject: `[Action required] Expiration of Project Owner Request for ${name} project`,
        postHeadline: `has expired because it was not approved by the relevant Business Area Organization (BA Org) within the allowed time. ${contactBaOrg}`,
      },
      [RequestStatus.CLOSED]: {
        subject: `[Action required] Closure of Project Owner Request for ${name} project`,
        postHeadline: `has been closed because it was not approved by the relevant Business Area Organization (BA Org) within the allowed time. ${contactBaOrg}`,
      },
    };

    const { subject, postHeadline } = messageMap[status];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  sendPendingRequestEmail(ctx: Context, name: string, bcc: string[]) {
    const subject = `[Notification] IGAM Queue Information for ${name} project`;

    const preHeadline = `We are writing to inform you that there is already a pending request for your project`;
    const postHeadline = `in your Business Area Organization's (BA Org) IGAM queue. Therefore, we cannot submit your new request until the existing one has been addressed. Please note that we will place your request in the queue and automatically submit it once the current request is resolved. No further action is required from you at this time. We will send you a separate email once your request has been submitted.`;

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  sendProjectCreationApprovedEmail(ctx: Context, name: string, bcc: string) {
    const subject = `[Notification] Approval of Project ${name}`;

    const preHeadline = `Your request to create the following project`;
    const postHeadline = `has been approved by the relevant Business Area Organization (BA Org). Please be aware that the new project will soon be created in the Virtual Lab, allowing you to begin fulfilling <a style="color: #00858c;" href="${UI_DOMAIN}/help>your responsibilities</a> as Project Owner.`;

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName: name,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  sendOwnerAwaitingApprovalEmail(
    ctx: Context,
    bcc: string[],
    projectName: string,
    userName: string,
    requestId: string,
    org: string,
    approvers: string[],
  ) {
    const subject = `[Notification] Approval Pending for Project Owner Request for ${projectName} project`;
    const preHeadline = `Your request ${requestId} to add an additional Project Owner ${userName} for`;
    const postHeadline = [
      `has been submitted to the relevant Business Area Organization (${org}) in IGAM for approval. Please be aware that the approval process can take some time, as the BA Org ${org} has 15 days to review your request. Below you can find the list of approvers.`,
      '<ul style="text-align: left;">',
      ...approvers.map((approver) => `<li>${approver}</li>`),
      "</ul>",
      `To ensure smooth communication and efficiency, please reach out to your approvers only in cases where there are delays in approval. You will receive a notification once your request has been approved.`,
    ];

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName,
        preHeadline,
        postHeadline: postHeadline.join(""),
        senderName: ``,
        message: ``,
      },
    });
  },
};

export default NotificationService;
