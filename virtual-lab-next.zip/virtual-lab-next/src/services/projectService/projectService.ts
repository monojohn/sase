import { Context } from "@azure/functions";
import NotificationService from "../../features/projectAccessibilityModification/notificationService";
import { createSofaRepository } from "../../features/repositoryCreation";
import { Session } from "../../middleware/withHttpSession";
import {
  arraysAreEquivalent,
  getEmailOfUser,
  getMembersGroupName,
  getOwnersGroupName,
  getRolesAndEntitlementsNames,
  isConfidentialityHigher,
  requiresManagerApproval,
} from "../../utils/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  ProjectStatus,
  RequestStatus,
  RequestType,
  UpdateStatus,
} from "../dbConnector/enums";
import JoinProjectRequestModel from "../dbConnector/models/joinProjectRequestModel";
import OwnershipInviteModel from "../dbConnector/models/ownershipInviteModel";
import { PickRole, Project, RolesAndEntitlements } from "../dbConnector/models/project";
import ProjectModel from "../dbConnector/models/projectModel";
import { ProjectRequest } from "../dbConnector/models/projectRequest";
import GraphService from "../graphService/graphService";
import { GraphUser } from "../graphService/types.d";
import IamService from "../iamService/iamService";
import { IamRole, IamUser } from "../iamService/iamService.types.d";
import EntitlementsService from "../igamService/entitlementsService";
import { IgamUser } from "../igamService/types";
import RepositoryService from "../repositoryService/repositoryService";
import FavoritesService from "../sharepointService/favoritesServices";
import AccessRequestNotificationService from "./accessRequestNotificationService";
import ProjectNotificationService from "./notificationService";
import projectAccessLevelService from "./projectAccessLevelService";
import { IgamRequest } from "../dbConnector/models/igamRequest";
import { Analysis, MissingRolesOrEntitlements } from "./types";
import { WorkspaceType } from "../sharepointService/enums";
import IgamRequestModel from "../dbConnector/models/igamRequestModel";
import { CreateProjectProps } from "../../features/projectCreation/types";
import { ProjectCreationType } from "./enums";
import QueueService, { QUEUE } from "../queueService";
import { activeRequestsExist, buildJustification } from "../igamService/helpers";
import { UI_DOMAIN, VL_TEAM_ORG } from "../../utils/config";
import UserNotificationService from "../userNotificationService/userNotificationService";
import LlmNotificationService from "../../features/openAIUseCase/notificationService";
import MembersNotificationService from "../../features/projectMembers/emails";
import OrgService from "../igamService/orgService";
import { ActionStatus, ActionType } from "../../features/userActions/enums";
import UserActionModel from "../dbConnector/models/userActionModel";

type SendAccessRequestNotification = {
  senderName: string;
  message?: string;
  ownersGroupId: string;
  project: {
    name: string;
    url: string;
    _id: string;
  };
};

const ProjectService = {
  async getTrendingProjects(ctx: Context, count: number) {
    ctx.log("Fetching all project and all favorites");
    const favorites = await FavoritesService.getMostFavorited(ctx);
    const maxResults = Math.min(favorites.length, count);
    const pids = favorites.slice(0, maxResults).map(([pid]) => pid);

    const projects = await ProjectModel.find({
      $and: [
        { _id: { $in: pids } },
        {
          $or: [{ accessibilityLevel: "Public" }, { accessibilityLevel: "Protected" }],
        },
      ],
    });

    ctx.log(`Found ${projects.length} projects and ${pids.length} favorites`);
    return (
      projects
        .reduce((acc, project) => {
          const pid = project._id.toString();
          const index = pids.indexOf(pid);
          ctx.log(`Adding project ${project.name} to index ${index}`);
          if (index < 0) {
            const error = `Project ${pid} not in indexed favorites`;
            ctx.log(error, { pids });
            throw new Error(error);
          }

          acc[index] = project;
          return acc;
        }, [] as Project[])
        // Filter out highly favorited private projects
        .filter((project) => !!project)
    );
  },

  /**
   * Adds a member / owner to a project
   * Does NOT send notification
   *
   * @param ctx
   * @param project
   * @param oid
   * @param isAddingOwner
   */
  async addUser(
    ctx: Context,
    project: Project,
    oid: string,
    isAddingOwner: boolean,
    postApproval?: boolean,
  ) {
    const { _id: pid, name } = project;
    ctx.log("Getting graph user");
    const user = await GraphService.getUserProps(ctx, oid, [
      "id",
      "userType",
      "userPrincipalName",
      "otherMails",
      "mail",
      "identities",
      "department",
    ]);
    const upn = user.userPrincipalName;
    const email = getEmailOfUser(user);

    const groupName = isAddingOwner ? getOwnersGroupName(name) : getMembersGroupName(name);

    const oppositeGroupName = isAddingOwner ? getMembersGroupName(name) : getOwnersGroupName(name);

    ctx.log(`Adding user to ${groupName} and removing them from ${oppositeGroupName}`);

    // Add user to repository
    ctx.log("Adding user to repository");
    await RepositoryService.addUser(ctx, name, email, isAddingOwner);

    // add user to igam groups
    ctx.log("Adding user to IGAM groups");
    const groups = postApproval ? [project.teamGroupName] : [groupName, project.teamGroupName];
    await EntitlementsService.addUser(ctx, groups, upn, false);

    if (isAddingOwner && user.userType === "Member") {
      const [projectOrgIsVlOrg, department] = await Promise.all([
        EntitlementsService.isProjectOrgVlOrg(ctx, project.ownersGroupName),
        GraphService.getUserDepartment(ctx, user),
      ]);
      if (projectOrgIsVlOrg && department !== VL_TEAM_ORG) {
        // update org only when new department isn't VL team's org
        await EntitlementsService.updateOrg(
          ctx,
          [project.ownersGroupName, project.membersGroupName, project.teamGroupName],
          department,
          false,
        );
        await ProjectModel.updateOne({ _id: project._id }, { $set: { org: department } });
      }
    }

    ctx.log(`Getting entitlement Id of opposite group: ${oppositeGroupName}`);
    const id = await EntitlementsService.getEntitlementsId(ctx, oppositeGroupName);

    // remove user from Owners group in case they're there
    ctx.log(`Removing user from opposite group in case they're present`);
    await EntitlementsService.removeUser(ctx, upn, id!);

    // remove user from join request list
    ctx.log(`Removing user's Join Requests for ${name}`);
    await JoinProjectRequestModel.deleteMany({ oid, pid }).lean();

    // remove user from awaiting owners list for when admins add them in
    ctx.log(`Removing user's Awaiting Owners entries for ${name}`);
    await OwnershipInviteModel.deleteMany({ invitee: oid, pid }).lean();

    const groupToPush = isAddingOwner ? "owners" : "members";
    const groupToPull = isAddingOwner ? "members" : "owners";
    ctx.log(`Adding user to ${groupToPush} group of project ${name}`);

    await ProjectModel.updateOne(
      { _id: pid },
      {
        $push: { [groupToPush]: oid }, // add user to new group
        $pull: { [groupToPull]: oid }, // remove from previous group if present
      },
    );
  },

  async setDataSensitivityLevel(
    ctx: Context,
    project: Project,
    dataSensitivityLevel: DataSensitivityLevel,
  ) {
    const { accessibilityLevel, confidentialityLevel } = project;
    if (
      !ProjectService.isConfidentialityValid(
        accessibilityLevel,
        confidentialityLevel,
        dataSensitivityLevel,
      )
    ) {
      throw new Error(`${dataSensitivityLevel} is invalid for a ${confidentialityLevel} project`);
    }

    if (
      project.workspaceType === WorkspaceType.EXPLORATORY &&
      dataSensitivityLevel === DataSensitivityLevel.CSI
    ) {
      throw new Error(
        `${dataSensitivityLevel} is invalid for a ${WorkspaceType.EXPLORATORY} ML workspace`,
      );
    }

    const groupId = await GraphService.getGroupIdByName(ctx, project.teamGroupName);

    const bcc = await GraphService.getGroupUsersEmails(ctx, groupId);

    // notify owners
    await ProjectNotificationService.sendDataSensitivityChangeEmail(ctx, {
      projectName: project.name,
      bcc,
      dataSensitivityLevel,
      ctaUrl: ProjectService.getProjectUrl(project),
    });

    // update project
    return ProjectModel.updateOne({ _id: project._id }, { $set: { dataSensitivityLevel } });
  },

  isConfidentialityValid(
    accessLevel: AccessibilityLevel,
    confLevel: ConfidentialityLevel,
    dataSensitivityLevel: DataSensitivityLevel,
  ) {
    const accessibilityLevels: Record<AccessibilityLevel, ConfidentialityLevel[]> = {
      [AccessibilityLevel.Public]: [ConfidentialityLevel.PUBLIC, ConfidentialityLevel.UNRESTRICTED],
      [AccessibilityLevel.Private]: [
        ConfidentialityLevel.PUBLIC,
        ConfidentialityLevel.UNRESTRICTED,
        ConfidentialityLevel.RESTRICTED,
        ConfidentialityLevel.CONFIDENTIAL,
        ConfidentialityLevel.SECRET,
      ],
      [AccessibilityLevel.Protected]: [
        ConfidentialityLevel.PUBLIC,
        ConfidentialityLevel.UNRESTRICTED,
        ConfidentialityLevel.RESTRICTED,
        ConfidentialityLevel.CONFIDENTIAL,
        ConfidentialityLevel.SECRET,
      ],
    };

    const dataSensitivityLevels: Record<DataSensitivityLevel, ConfidentialityLevel[]> = {
      [DataSensitivityLevel.CSI]: [ConfidentialityLevel.CONFIDENTIAL],
      [DataSensitivityLevel.No]: [
        ConfidentialityLevel.PUBLIC,
        ConfidentialityLevel.UNRESTRICTED,
        ConfidentialityLevel.RESTRICTED,
        ConfidentialityLevel.CONFIDENTIAL,
        ConfidentialityLevel.SECRET,
      ],
    };

    return (
      accessibilityLevels[accessLevel].includes(confLevel) &&
      dataSensitivityLevels[dataSensitivityLevel].includes(confLevel)
    );
  },

  async setConfidentialityLevel(
    ctx: Context,
    project: Project,
    oid: string,
    requester: string,
    newConfidentialityLevel: ConfidentialityLevel,
    newDataSensitivityLevel?: DataSensitivityLevel,
  ) {
    const {
      accessibilityLevel,
      dataSensitivityLevel,
      confidentialityLevel,
      ownersGroupName,
      membersGroupName,
      teamGroupName,
      org,
    } = project;
    if (
      !ProjectService.isConfidentialityValid(
        accessibilityLevel,
        newConfidentialityLevel,
        newDataSensitivityLevel ?? dataSensitivityLevel,
      )
    ) {
      throw new Error(
        `${newConfidentialityLevel} is invalid for a ${accessibilityLevel} project with ${newDataSensitivityLevel ?? dataSensitivityLevel} data sensitivity level`,
      );
    }

    // check if it needs igam approval
    const owners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
      "id",
      "userType",
      "identities",
      "otherMails",
      "mail",
    ]);
    const ecbOwners = owners.filter(({ userType }) => userType === "Member");
    const userType = ecbOwners.length ? "Member" : "Guest";
    const ownersEmails = owners.map((owner) => getEmailOfUser(owner));

    // it only needs approval if new conf is higher then current one
    if (
      isConfidentialityHigher(newConfidentialityLevel, confidentialityLevel) &&
      requiresManagerApproval(newConfidentialityLevel, userType)
    ) {
      // check if other requests are currently active
      const requestExists = await activeRequestsExist(project._id);
      if (requestExists) {
        // create pending request and notify owners
        const body: Partial<IgamRequest> = {
          requestType: RequestType.UPDATE_CONFIDENTIALITY,
          requestStatus: RequestStatus.PENDING,
          pid: project._id,
          requesterId: oid,
          confidentialityLevel: newConfidentialityLevel,
        };
        if (newDataSensitivityLevel) {
          body.dataSensitivityLevel = newDataSensitivityLevel;
        }
        await IgamRequestModel.create(body);
        await ProjectNotificationService.sendPendingRequestEmail(ctx, project.name, ownersEmails);
        return UpdateStatus.PENDING_REQUEST_CREATION;
      }

      const [{ requestId }] = await EntitlementsService.updateConfidentiality(
        ctx,
        [ownersGroupName],
        newConfidentialityLevel,
        true,
        buildJustification(project, requester),
      );
      if (!requestId) {
        throw new Error(`Missing requestId for updating conf in project ${project.name}`);
      }

      const body: Partial<IgamRequest> = {
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        pid: project._id,
        requesterId: oid,
        confidentialityLevel: newConfidentialityLevel,
        requestId,
      };
      if (newDataSensitivityLevel) {
        body.dataSensitivityLevel = newDataSensitivityLevel;
      }
      await IgamRequestModel.create(body);
      const orgApprovers = await OrgService.getApproversEmails(ctx, org);
      await ProjectNotificationService.sendConfidentialityPendingApprovalEmail(
        ctx,
        project.name,
        ownersEmails,
        requestId,
        org,
        orgApprovers,
      );
      return UpdateStatus.PENDING_APPROVAL;
    }

    // update confidentiality of all entitlements
    await EntitlementsService.updateConfidentiality(
      ctx,
      [ownersGroupName, membersGroupName, teamGroupName],
      newConfidentialityLevel,
      false,
    );

    // update project
    await ProjectModel.updateOne(
      { _id: project._id },
      { $set: { confidentialityLevel: newConfidentialityLevel } },
    );

    return UpdateStatus.DONE;
  },

  async finishConfidentialityUpdate(
    ctx: Context,
    project: Project,
    newConfidentialityLevel: ConfidentialityLevel,
    dataSensitivityLevel?: DataSensitivityLevel,
  ) {
    // update the other 2 groups
    ctx.log(`New confidentiality: ${newConfidentialityLevel}`);
    const { teamGroupName, membersGroupName } = project;
    await EntitlementsService.updateConfidentiality(
      ctx,
      [teamGroupName, membersGroupName],
      newConfidentialityLevel,
      false,
    );

    // update project
    const [ownersEmails] = await Promise.all([
      GraphService.getGroupUsersEmails(ctx, project.ownersGroupId),
      ProjectModel.updateOne(
        { _id: project._id },
        { $set: { confidentialityLevel: newConfidentialityLevel } },
      ),
    ]);
    if (dataSensitivityLevel) {
      await ProjectModel.updateOne({ _id: project._id }, { $set: { dataSensitivityLevel } });
      const bcc = await GraphService.getGroupUsersEmails(ctx, project.teamGroupId);

      // notify owners
      await ProjectNotificationService.sendDataSensitivityChangeEmail(ctx, {
        projectName: project.name,
        bcc,
        dataSensitivityLevel,
        ctaUrl: ProjectService.getProjectUrl(project),
      });
    }
    return ProjectNotificationService.sendConfidentialityUpdatedEmail(
      ctx,
      ownersEmails,
      project.name,
      ProjectService.getProjectUrl(project),
    );
  },

  async setAccessibilityLevel(ctx: Context, project: Project, level: AccessibilityLevel) {
    ctx.log(`Updating accessibility of project ${project.name} to ${level}`);
    if (level === AccessibilityLevel.Public) {
      ctx.log("Allowing visitors");
      await projectAccessLevelService.allowVisitors(ctx, project);
    } else {
      ctx.log("Disallowing visitors");
      await projectAccessLevelService.disallowVisitors(ctx, project);
    }

    // email owners
    await NotificationService.sendSuccessEmail(
      ctx,
      project.name,
      level,
      ProjectService.getProjectUrl(project),
    );

    // update project
    await ProjectModel.updateOne({ _id: project._id }, { $set: { accessibilityLevel: level } });
  },

  async sendAccessRequestNotification(ctx: Context, props: SendAccessRequestNotification) {
    const { senderName, message, ownersGroupId, project } = props;

    ctx.log("Getting projects owners");
    const emails = await GraphService.getGroupUsersEmails(ctx, ownersGroupId);
    if (message) {
      ctx.log("Message present, sending custom email");
      await AccessRequestNotificationService.sendAccessRequestEmail(ctx, emails, {
        senderName,
        message,
        projectName: project.name,
        ctaUrl: ProjectService.getProjectUrl(project),
      });
    } else {
      ctx.log("Message not present, sending default email");
      await AccessRequestNotificationService.sendSuccessEmail(
        ctx,
        project.name,
        senderName,
        "Member",
        ProjectService.getProjectUrl(project),
        emails,
      );
    }
  },

  /**
   * Deletes the access request and notifies users
   *
   * @param ctx
   * @param request
   * @param projectName
   * @param session
   * @param message
   */
  async rejectAccessRequest(
    ctx: Context,
    request: ProjectRequest,
    projectName: string,
    session: Session,
    message: string,
  ) {
    await JoinProjectRequestModel.deleteOne({ _id: request._id }).lean();

    // get email of user
    const email = await GraphService.getUserEmail(ctx, request.oid);

    // email user
    await AccessRequestNotificationService.sendAccessDeniedEmail(ctx, email, {
      senderName: session.name,
      projectName,
      message,
    });
  },

  async createSofaRepository(ctx: Context, project: Project) {
    try {
      return await createSofaRepository(ctx, project);
    } catch (e) {
      // rollback repo creation
      ctx.log(`Repository creation failed, attempting rollback`);

      ctx.log(`Deleting repository`);
      await RepositoryService.markRepositoryGroupForDeletion(ctx, project.name);

      ctx.log(`Rollback successful, throwing error`);
      throw e;
    }
  },

  async checkIamRoles(
    ctx: Context,
    graphIamUsers: Pick<GraphUser, "id" | "userPrincipalName" | "mail">[],
    roles: IamRole[],
  ): Promise<MissingRolesOrEntitlements> {
    const analysis: MissingRolesOrEntitlements = {};

    for (let index = 0; index < graphIamUsers.length; index++) {
      const graphUser = graphIamUsers[index];
      const iamUserRoles = await IamService.getUserRoles(ctx, graphUser);

      if (!graphUser) {
        // eslint-disable-next-line no-continue
        continue;
      }

      const { userPrincipalName: upn } = graphUser;
      const missingRoles = ProjectService.getMissingIamRoles(iamUserRoles, roles);

      if (missingRoles.length > 0) {
        analysis[upn] = missingRoles;
      }
    }

    return analysis;
  },

  checkIgamRolesAndEntitlements(
    upns: string[],
    users: IgamUser[],
    roles: PickRole[],
    entitlements: string[],
  ): [MissingRolesOrEntitlements, MissingRolesOrEntitlements] {
    const entitlementAnalysis: MissingRolesOrEntitlements = {};
    const rolesAnalysis: MissingRolesOrEntitlements = {};

    for (let index = 0; index < users.length; index++) {
      const user = users[index];

      if (!user) {
        // eslint-disable-next-line no-continue
        continue;
      }

      const upn = upns[index];
      const [missingEntitlements, missingRoles] = [
        ProjectService.getMissingEntitlements(user, entitlements),
        ProjectService.getMissingRoles(user, roles),
      ];

      if (missingEntitlements.length > 0) {
        entitlementAnalysis[upn] = missingEntitlements;
      }

      if (missingRoles.length > 0) {
        rolesAnalysis[upn] = missingRoles;
      }
    }

    return [entitlementAnalysis, rolesAnalysis];
  },

  checkMissingUsers(ctx: Context, upns: string[], allUsers: (IgamUser | IamUser | undefined)[]) {
    const messages: string[] = [];
    const missingUsers: string[] = [];
    // check for missing users
    const missingUsersToCheck = upns.filter((_, index) => !allUsers[index]);
    if (missingUsersToCheck.length > 0) {
      const message = `Users ${missingUsersToCheck.join(", ")} are missing`;
      messages.push(message);
      ctx.log(message);
      missingUsers.push(...missingUsersToCheck);
    }
    return { messages, missingUsers };
  },

  checkCondition(
    ctx: Context,
    rolesAndEntitlements: RolesAndEntitlements[],
    igamRolesAnalysis: MissingRolesOrEntitlements,
    igamEntitlementsAnalysis: MissingRolesOrEntitlements,
    iamAnalysis: MissingRolesOrEntitlements,
  ) {
    const missingRolesAndEntitlements: { [upn: string]: RolesAndEntitlements[] } = {};
    const messages: string[] = [];
    // for each and condition
    for (const { roles, entitlements, iamRoles } of rolesAndEntitlements) {
      // get the UPNs of ECB users with possible missing roles or entitlements
      const igamUpnsWithPossibleMissingRoles = [
        ...new Set(Object.keys(igamRolesAnalysis).concat(Object.keys(igamEntitlementsAnalysis))),
      ];
      for (const upn of igamUpnsWithPossibleMissingRoles) {
        // if every role and every entitlement of condition is missing
        if (
          roles.every((role) => igamRolesAnalysis[upn]?.includes(role.roleName)) &&
          entitlements.every((entitlement) => igamEntitlementsAnalysis[upn]?.includes(entitlement))
        ) {
          // add user
          missingRolesAndEntitlements[upn] ??= [];
          missingRolesAndEntitlements[upn].push({
            roles,
            entitlements,
            iamRoles: [],
          });
          const entitlementMessages = entitlements.map((ent) => `${ent} entitlement`);
          const rolesMessages = roles.map((role) => `${role.roleName} role`);
          const message = `${upn} is missing ${[...entitlementMessages, ...rolesMessages].join(", ")}.`;
          messages.push(message);
          ctx.log(message, { roles, entitlements });
        }
      }

      // get UPNs of IAM users with possible missing roles
      const iamUpnsWithPossibleMissingRoles = Object.keys(iamAnalysis);
      for (const upn of iamUpnsWithPossibleMissingRoles) {
        // if user is missing every role of condition
        if (iamRoles.every((role) => iamAnalysis[upn].includes(role.displayName))) {
          // add user
          missingRolesAndEntitlements[upn] ??= [];
          missingRolesAndEntitlements[upn].push({
            roles: [],
            entitlements: [],
            iamRoles,
          });
          const rolesMessages = iamRoles.map((role) => `${role.roleName} role`);
          const message = `${upn} is missing ${rolesMessages.join(", ")}.`;
          messages.push(message);
          ctx.log(message, { iamRoles });
        }
      }
    }
    return { messages, missingRolesAndEntitlements };
  },

  async checkRolesAndEntitlements(
    ctx: Context,
    users: Pick<GraphUser, "id" | "userPrincipalName" | "userType" | "mail">[],
    { rolesAndEntitlements }: Pick<Project, "rolesAndEntitlements">,
  ) {
    const analysis: Analysis = {
      missingUsers: [],
      missingRolesAndEntitlements: {},
      missingConditions: {
        Guest: [],
        Member: [],
      },
      errors: [],
      errorUsers: [],
    };

    const errorUsers: string[] = [];

    const [graphIgamUsers, graphIamUsers] = [
      users.filter(({ userType }) => userType === "Member"),
      users.filter(({ userType }) => userType === "Guest"),
    ];
    const anonymisedUsers = users.map(({ id, userType }) => ({ id, userType }));
    ctx.log(
      `${graphIgamUsers.length} IGAM and ${graphIamUsers.length} IAM users to check`,
      anonymisedUsers,
    );

    const igamUpns = graphIgamUsers.map((user) => user.userPrincipalName);
    const iamUpns = graphIamUsers.map((user) => user.userPrincipalName);
    const [allIgamUsers, allIamUsers] = await Promise.all([
      ProjectService.getIgamUsers(ctx, igamUpns),
      IamService.getUsers(ctx, graphIamUsers),
    ]);

    const missingIgamUsersCheck = this.checkMissingUsers(ctx, igamUpns, allIgamUsers);
    analysis.missingUsers.push(...missingIgamUsersCheck.missingUsers);
    analysis.errors.push(...missingIgamUsersCheck.messages);
    errorUsers.push(...missingIgamUsersCheck.missingUsers);

    const missingIamUsersCheck = this.checkMissingUsers(ctx, iamUpns, allIamUsers);
    analysis.missingUsers.push(...missingIamUsersCheck.missingUsers);
    analysis.errors.push(...missingIamUsersCheck.messages);
    errorUsers.push(...missingIamUsersCheck.missingUsers);

    const igamUsers = igamUpns.filter((_, index) => allIgamUsers[index]);
    // if there are any IGAM users, check how many role and entitlement conditions do not have at least one IGAM entitlement / role
    if (
      igamUsers.length > 0 &&
      rolesAndEntitlements.some(
        ({ roles, entitlements }) => roles.length === 0 && entitlements.length === 0,
      )
    ) {
      analysis.missingConditions.Member = rolesAndEntitlements.filter(
        ({ roles, entitlements }) => roles.length === 0 && entitlements.length === 0,
      );
      errorUsers.push(...igamUsers);
      const message = `ECB users are missing roles / entitlements in conditions: ${getRolesAndEntitlementsNames(
        analysis.missingConditions.Member,
      ).join(", ")}`;
      analysis.errors.push(message);
      ctx.log(message);
    }

    const iamUsers = iamUpns.filter((_, index) => allIamUsers[index]);
    // if there are any IAM users, check how many role and entitlement conditions do not have at least one IAM role
    if (iamUsers.length > 0 && rolesAndEntitlements.some(({ iamRoles }) => iamRoles.length === 0)) {
      analysis.missingConditions.Guest = rolesAndEntitlements.filter(
        ({ iamRoles }) => iamRoles.length === 0,
      );
      errorUsers.push(...iamUsers);
      const message = `IAM users are missing roles in conditions: ${getRolesAndEntitlementsNames(
        analysis.missingConditions.Guest,
      ).join(", ")}`;
      analysis.errors.push(message);
      ctx.log(message);
    }

    const [igamEntitlementsAnalysis, igamRolesAnalysis] =
      ProjectService.checkIgamRolesAndEntitlements(
        igamUpns,
        allIgamUsers,
        rolesAndEntitlements.flatMap(({ roles }) => roles),
        rolesAndEntitlements.flatMap(({ entitlements }) => entitlements),
      );

    const iamAnalysis = await ProjectService.checkIamRoles(
      ctx,
      graphIamUsers,
      rolesAndEntitlements.flatMap(({ iamRoles }) => iamRoles),
    );

    const missingRolesAndEntitlementsCheck = this.checkCondition(
      ctx,
      rolesAndEntitlements,
      igamRolesAnalysis,
      igamEntitlementsAnalysis,
      iamAnalysis,
    );
    analysis.errors.push(...missingRolesAndEntitlementsCheck.messages);
    analysis.missingRolesAndEntitlements =
      missingRolesAndEntitlementsCheck.missingRolesAndEntitlements;
    errorUsers.push(...Object.keys(analysis.missingRolesAndEntitlements));

    const passed = analysis.errors.length === 0;
    const missingRolesAndEntitlementCount = Object.keys(
      analysis.missingRolesAndEntitlements,
    ).length;

    const graphErrorUsers = await GraphService.getUsersProps(ctx, errorUsers, [
      "id",
      "mail",
      "otherMails",
      "identities",
      "displayName",
    ]);
    analysis.errorUsers = graphErrorUsers.map((user) => ({
      displayName: user.displayName,
      email: getEmailOfUser(user),
      oid: user.id,
    }));

    ctx.log({
      passed,
      missingConditionsCount:
        analysis.missingConditions.Member.length + analysis.missingConditions.Guest.length,
      missingRolesAndEntitlementCount: `${missingRolesAndEntitlementCount} users with missing roles / entitlements conditions`,
      error: analysis.errors.join(". "),
    });

    return { passed, analysis };
  },

  /**
   * Checks if alls oids have requested roles and entitlements
   */
  async checkProjectRolesAndEntitlementsByOid(
    ctx: Context,
    oids: string[],
    project: Pick<Project, "name" | "rolesAndEntitlements">,
  ) {
    const users = await Promise.all(
      oids.map((oid) =>
        GraphService.getUserProps(ctx, oid, ["id", "userPrincipalName", "userType", "mail"]),
      ),
    );

    return ProjectService.checkRolesAndEntitlements(ctx, users, project);
  },

  /**
   * Get user's missing roles display name
   * @param userRoles the roles a user has
   * @param requiredRoles the roles a project requires
   * @returns missing roles display name
   */
  getMissingIamRoles(userRoles: IamRole[], requiredRoles: IamRole[]) {
    const userRoleKeys = userRoles?.map((role) => role.key) ?? [];
    return requiredRoles
      .filter(({ key }) => !userRoleKeys.includes(key))
      .map((role) => role.roleName);
  },

  getMissingEntitlements(user: IgamUser, entitlements: string[]) {
    const userEnts = user?.entitlements?.map((ent) => ent.displayName) ?? [];
    return entitlements.filter((entName) => !userEnts.includes(entName));
  },

  /**
   * Get user's missing roles display name
   * @param user
   * @param roles
   * @returns missing roles display name
   */
  getMissingRoles(user: IgamUser, roles: PickRole[]) {
    const userRoles = user?.roles?.map((role) => role.roleName) ?? [];
    return roles.map((role) => role.roleName).filter((roleName) => !userRoles.includes(roleName));
  },

  async getIgamUsers(ctx: Context, upns: string[]) {
    ctx.log(`Fetching ${upns.length} IGAM users`);
    return Promise.all(upns.map((upn) => EntitlementsService.getUser(ctx, upn)));
  },

  async cleanupRejectedProject(ctx: Context, project: Project, request: IgamRequest) {
    ctx.log(`Setting status of project ${request.pid} to ${request.requestStatus}`);

    await ProjectModel.updateOne(
      { _id: request.pid },
      {
        $set: {
          status: request.requestStatus,
          name: `${project.name} - ${request.requestId} ${request.requestStatus}`,
        },
      },
    );

    ctx.log("Delete onwer group entitlement");
    const ownerGroupName = getOwnersGroupName(project.name);
    const entitlementId = await EntitlementsService.getEntitlementsId(ctx, ownerGroupName);
    if (entitlementId) {
      await EntitlementsService.delete(ctx, entitlementId);
      ctx.log(`Entitlement for owner group deleted`);
    } else {
      ctx.log(`Entitlement for owner group already deleted`);
    }
  },

  async finishProjectCreation(ctx: Context, project: Project, requesterId: string) {
    const ownerEmail = await GraphService.getUserEmail(ctx, requesterId);
    await ProjectModel.findOneAndUpdate(
      { _id: project._id },
      {
        $set: {
          status: ProjectStatus.BeingCreated,
        },
      },
    );
    const message: CreateProjectProps = {
      owner: requesterId,
      project,
      projectCreationType: ProjectCreationType.APPROVAL_GRANTED,
    };
    ctx.log(`Adding message to project creation queue`, message);
    await QueueService.put(QUEUE.CREATE_PROJECT, message);

    await ProjectNotificationService.sendProjectCreationApprovedEmail(
      ctx,
      project.name,
      ownerEmail,
    );
  },

  async finishOrgUpdate(ctx: Context, project: Project, org: string) {
    // update the other 2 groups
    const { teamGroupName, membersGroupName } = project;
    await EntitlementsService.updateOrg(ctx, [teamGroupName, membersGroupName], org, false);
    await ProjectModel.updateOne({ _id: project._id }, { $set: { org } });

    // notify owners
    const emails = await GraphService.getGroupUsersEmails(ctx, project.ownersGroupId);
    return ProjectNotificationService.sendOrgUpdatedEmail(
      ctx,
      emails,
      org,
      project.name,
      ProjectService.getProjectUrl(project),
    );
  },

  async addOwnerWithApproval(ctx: Context, project: Project, oid: string, requester: string) {
    // if it requires approval and curent org is VL org, it's a project with just guest users where an ECB owner is being added -> add update of ent owner on the same request
    const [user, projectOrgVlOrg] = await Promise.all([
      GraphService.getUserProps(ctx, oid, [
        "userPrincipalName",
        "department",
        "displayName",
        "userType",
        "id",
      ]),
      EntitlementsService.isProjectOrgVlOrg(ctx, project.ownersGroupName),
    ]);
    const department = await GraphService.getUserDepartment(ctx, user);
    if (projectOrgVlOrg && department !== VL_TEAM_ORG) {
      // update org only when new department isn't VL team's org
      // trigger request in IGAM to update org so new org has to approve it, but also include the fatc that a new owner will be added
      const [{ requestId }] = await EntitlementsService.updateOrg(
        ctx,
        [project.ownersGroupName],
        department,
        true,
        buildJustification(project, requester, user.displayName),
      );
      return {
        requestId,
        requestType: RequestType.ADD_OWNER_WITH_ORG_UPDATE,
        org: department,
      };
    }
    const [data] = await EntitlementsService.addUser(
      ctx,
      [project.ownersGroupName],
      user.userPrincipalName,
      true,
      buildJustification(project, requester),
    );
    return { requestId: data?.[0]?.requestId, requestType: RequestType.ADD_OWNER };
  },

  async addOwnerAsAdmin(
    ctx: Context,
    users: Pick<
      GraphUser,
      "displayName" | "mail" | "userPrincipalName" | "id" | "otherMails" | "userType" | "identities"
    >[],
    project: Project,
    oid: string,
    name: string,
  ) {
    await Promise.all(
      users.map(async (user) => {
        await ProjectService.addUser(ctx, project, user.id, true);
        await UserNotificationService.notifyGroup(ctx, project.ownersGroupId, {
          type: ActionType.ADD_OWNER,
          target: { id: user.id, name: user.displayName },
          project: { id: project._id, name: project.name },
          triggerer: { id: oid, displayName: name },
        });
      }),
    );

    // Wait for previous one to finish before sending this
    if (project.aiUsage) {
      // Filter out new owners which were members and map to emails
      const nonPreviouslyMembersEmails = users
        .filter((user) => !project.members.includes(user.id))
        .map((user) => getEmailOfUser(user));

      if (nonPreviouslyMembersEmails.length) {
        void LlmNotificationService.sendLlmAwarenessInfoToUsers(ctx, {
          projectName: project.name,
          projectUrl: ProjectService.getProjectUrl(project),
          confidentialityLevel: project.confidentialityLevel,
          emails: nonPreviouslyMembersEmails,
          created: false,
        });
      }
    }
  },

  async addMember(
    ctx: Context,
    oidArray: string[],
    project: Project,
    inviteeOid: string | string[],
    users: Pick<
      GraphUser,
      "displayName" | "mail" | "userPrincipalName" | "id" | "otherMails" | "userType" | "identities"
    >[],
    oid: string,
    name: string,
  ) {
    const { _id: pid, name: projectName } = project;
    await Promise.all(
      oidArray.map((memberOid) => ProjectService.addUser(ctx, project, memberOid, false)),
    );

    const useBulkAdd = Array.isArray(inviteeOid);
    const notificationType = useBulkAdd ? ActionType.BULK_ADD_MEMBER : ActionType.ADD_MEMBER;

    const targetId = useBulkAdd ? oidArray.join() : inviteeOid;
    const targetName = useBulkAdd
      ? JSON.stringify(users.map(({ displayName }) => displayName))
      : users[0].displayName;

    // notify the added members and the user taking action
    const usersToNotify = [...oidArray, oid].map((id) => ({ id }));
    // send email to added members
    const addedMembersEmails = users.map((user) => getEmailOfUser(user));

    await Promise.all([
      UserNotificationService.notifyUsers(ctx, usersToNotify, {
        type: notificationType,
        target: { id: targetId, name: targetName },
        project: { id: pid, name: projectName },
        triggerer: { id: oid, displayName: name },
      }),

      MembersNotificationService.sendAddMemberEmail(ctx, {
        ctaUrl: ProjectService.getProjectUrl(project),
        bcc: addedMembersEmails,
        projectName,
      }),
    ]);

    // Wait for previous one to finish before sending this
    if (project.aiUsage) {
      // Filter out new members which were owners and map to emails
      const nonPreviouslyOwnersEmails = users
        .filter((user) => !project.owners.includes(user.id))
        .map((user) => getEmailOfUser(user));

      if (nonPreviouslyOwnersEmails.length) {
        void LlmNotificationService.sendLlmAwarenessInfoToUsers(ctx, {
          projectName,
          projectUrl: ProjectService.getProjectUrl(project),
          confidentialityLevel: project.confidentialityLevel,
          emails: nonPreviouslyOwnersEmails,
          created: false,
        });
      }
    }
  },

  async isConfidentialityPending(pid: string) {
    return IgamRequestModel.find({
      pid,
      requestType: RequestType.UPDATE_CONFIDENTIALITY,
      requestStatus: { $in: [RequestStatus.AWAITING_APPROVAL, RequestStatus.PENDING] },
    });
  },

  async saveUpdateProjectUserActions(
    ctx: Context,
    oid: string,
    updates: Partial<Project>,
    project: Project,
  ) {
    const userAction = {
      pid: project._id,
      oid,
      status: ActionStatus.DONE,
      invocationId: ctx.invocationId,
    };

    // create user actions if values are different
    if (updates.description && updates.description !== project.description) {
      await UserActionModel.create({ ...userAction, action: ActionType.UPDATE_DESCRIPTION });
    }
    if (updates.icon && updates.icon !== project.icon) {
      await UserActionModel.create({ ...userAction, action: ActionType.UPDATE_ICON });
    }
    if (updates.tags && !arraysAreEquivalent(updates.tags, project.tags)) {
      await UserActionModel.create({ ...userAction, action: ActionType.UPDATE_TAGS });
    }

    if (
      updates.confidentialityLevel &&
      updates.confidentialityLevel !== project.confidentialityLevel
    ) {
      await UserActionModel.create({
        ...userAction,
        action: ActionType.UPDATE_CONFIDENTIALITY,
      });
    }
    if (updates.accessibilityLevel && updates.accessibilityLevel !== project.accessibilityLevel) {
      await UserActionModel.create({ ...userAction, action: ActionType.UPDATE_ACCESSIBILITY });
    }
    if (
      updates.dataSensitivityLevel &&
      updates.dataSensitivityLevel !== project.dataSensitivityLevel
    ) {
      await UserActionModel.create({
        ...userAction,
        action: ActionType.UPDATE_DATA_SENSITIVITY,
      });
    }
  },

  getProjectUrl(project: Pick<Project, "_id">) {
    return `${UI_DOMAIN}/projects/${project._id}`;
  },
};

export default ProjectService;
