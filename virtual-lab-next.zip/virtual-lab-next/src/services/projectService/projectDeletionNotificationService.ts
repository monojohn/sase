import { Context } from "@azure/functions";
import moment from "moment";
import EmailService from "../emailService/emailService";

type SuccessEmailProps = {
  projectName: string;
  bcc: string[];
};

const ProjectDeletionNotificationService = {
  sendSuccessEmail(ctx: Context, { projectName, bcc }: SuccessEmailProps) {
    const subject = `[Notification] Your project ${projectName} has been deleted `;
    const headline = `Your project has been deleted`;

    return EmailService.sendSuccessEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
      },
    });
  },

  sendErrorEmail(ctx: Context, name: string, emails: string[], upn: string) {
    const headline = `Your attempt to delete a project was unsuccessful`;
    const subject = `[Failure] ${headline}`;
    const actionName = "Delete project";

    return EmailService.sendErrorEmail(ctx, {
      subject,
      bcc: emails,
      templateData: {
        headline,
        actionName,
        userEmail: upn,
        projectId: name,
        projectName: name,
        time: moment.utc().format("dddd, MMMM Do YYYY, h:mm:ss A z"),
      },
    });
  },
};

export default ProjectDeletionNotificationService;
