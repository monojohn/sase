import { jest } from "@jest/globals";
import NotificationService from "./notificationService";
import { DataSensitivityLevel, RequestStatus } from "../dbConnector/enums";
import GraphService from "../graphService/graphService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("project service NotificationService", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getGroupIdByName").mockImplementation(async () => "id");
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupIdByName").mockRestore();
  });
  it("sendOwnershipRejectionEmail works", async () => {
    await NotificationService.sendOwnershipInvitationEmail(ctx, {
      projectName: "Unit test",
      requiresApproval: true,
      bcc: userEmail,
    });
  });

  it("sendDataSensitivityChangeEmail works", async () => {
    await NotificationService.sendDataSensitivityChangeEmail(ctx, {
      projectName: "Unit test",
      bcc: [userEmail],
      dataSensitivityLevel: DataSensitivityLevel.CSI,
      ctaUrl: "url",
    });
  });

  it("sendProjectCreationRejectionEmail works", async () => {
    await NotificationService.sendProjectCreationRejectionEmail(
      ctx,
      "unit test",
      userEmail,
      RequestStatus.CLOSED,
    );
  });

  it("sendConfidentialityPendingApprovalEmail works", async () => {
    await NotificationService.sendConfidentialityPendingApprovalEmail(
      ctx,
      "unit test",
      [userEmail],
      "1234",
      "org",
      ["manager"],
    );
  });

  it("sendConfidentialityUpdateRejectionEmail works", async () => {
    await NotificationService.sendConfidentialityUpdateRejectionEmail(
      ctx,
      "unit test",
      [userEmail],
      RequestStatus.CLOSED,
    );
  });
  it("sendConfidentialityUpdatedEmail works", async () => {
    await NotificationService.sendConfidentialityUpdatedEmail(ctx, [userEmail], "unit test", "url");
  });

  it("sendOrgUpdateRequestedEmail works", async () => {
    await NotificationService.sendOrgUpdateRequestedEmail(
      ctx,
      "unit test",
      [userEmail],
      "123",
      "org",
      ["manager"],
    );
  });

  it("sendOrgUpdateRejectedEmail works", async () => {
    await NotificationService.sendOrgUpdateRejectedEmail(
      ctx,
      "unit test",
      [userEmail],
      RequestStatus.EXPIRED,
      "org",
    );
  });

  it("sendOrgUpdatedEmail works", async () => {
    await NotificationService.sendOrgUpdatedEmail(ctx, [userEmail], "org", "unit test", "url");
  });

  it("sendAddingOwnerApprovedEmail works", async () => {
    await NotificationService.sendAddingOwnerApprovedEmail(
      ctx,
      [userEmail],
      "user",
      "unit test",
      "url",
    );
  });

  it("sendAddingOwnerRejectionEmail works", async () => {
    await NotificationService.sendAddingOwnerRejectionEmail(
      ctx,
      "unit test",
      [userEmail],
      RequestStatus.REJECTED,
      "user",
    );
  });

  it("sendPendingRequestEmail works", async () => {
    await NotificationService.sendPendingRequestEmail(ctx, "unit test", [userEmail]);
  });

  it("sendProjectCreationApprovedEmail works", async () => {
    await NotificationService.sendProjectCreationApprovedEmail(ctx, "unit test", userEmail);
  });

  it("sendOwnerAwaitingApprovalEmail works", async () => {
    await NotificationService.sendOwnerAwaitingApprovalEmail(
      ctx,
      [userEmail],
      "project",
      "user",
      "1234",
      "org",
      ["manager"],
    );
  });
});
