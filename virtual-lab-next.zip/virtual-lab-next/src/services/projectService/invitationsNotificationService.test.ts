import { jest } from "@jest/globals";
import NotificationService from "../../features/projectInvitations/emails";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("project service NotificationService", () => {
  it("sendOwnershipRejectionEmail works", async () => {
    await NotificationService.sendOwnershipRejectionEmail(ctx, {
      projectName: "Unit test",
      userName: "username",
      bcc: [userEmail],
    });
  });

  it("sendOwnerAddedPostApprovalEmail works", async () => {
    await NotificationService.sendOwnerAddedPostApprovalEmail(ctx, {
      projectName: "Unit test",
      ctaUrl: "url",
      bcc: [userEmail],
    });
  });
});
