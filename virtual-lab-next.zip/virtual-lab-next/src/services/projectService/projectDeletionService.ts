import { Context } from "@azure/functions";
import WorkspaceDeletionService from "../../features/machineLearningDeletion/index";
import { deleteRepository } from "../../features/repositoryDeletion";
import {
  getMembersGroupName,
  getOwnersGroupName,
  getTeamGroupName,
  withRetry,
} from "../../utils/helpers";
import FavoriteProjectModel from "../dbConnector/models/favoriteProjectModel";
import JoinProjectRequestModel from "../dbConnector/models/joinProjectRequestModel";
import LeaveProjectRequestModel from "../dbConnector/models/leaveProjectRequestModel";
import OwnershipInviteModel from "../dbConnector/models/ownershipInviteModel";
import { Project } from "../dbConnector/models/project.d";
import ProjectModel from "../dbConnector/models/projectModel";
import EntitlementsService from "../igamService/entitlementsService";
import IgamRequestModel from "../dbConnector/models/igamRequestModel";
import FileExpirationModel from "../dbConnector/models/fileExpirationModel";
import SlackService from "../slackService";

const getProjectEntitlements = (ctx: Context, projectTitle: string) => {
  const groupNames = [
    getMembersGroupName(projectTitle),
    getOwnersGroupName(projectTitle),
    getTeamGroupName(projectTitle),
  ];

  ctx.log(`Getting ${projectTitle} entitlements`, groupNames);

  return Promise.all(groupNames.map((name) => EntitlementsService.getEntitlementsId(ctx, name)));
};

const deleteEntitlements = async (ctx: Context, entitlementIds: (string | undefined)[]) => {
  ctx.log(`Deleting all entitlements`, { entitlementIds });
  for (let index = 0; index < entitlementIds.length; index++) {
    const id = entitlementIds[index];
    if (id) {
      // NOTE: Too many requests make the server start throwing errors
      await EntitlementsService.delete(ctx, id);
    } else {
      ctx.log(`Skipping deletion of group ${entitlementIds[index]}: falsy id '${id}'`);
    }
  }
};

type CreationFailureProps = {
  id: number | string;
  name: string;
};

const ProjectDeletionService = {
  async handleCreationFailure(ctx: Context, props: CreationFailureProps) {
    const entitlementIds = await getProjectEntitlements(ctx, props.name);

    await Promise.all([
      getProjectEntitlements(ctx, props.name),
      deleteEntitlements(ctx, entitlementIds),
      ProjectModel.deleteOne({ name: props.name }).lean(),
    ]);

    ctx.log(`Cleanup for project ${props.name} with id ${props.id} finished`);
  },

  async deleteProject(ctx: Context, project: Project) {
    const { _id, name, workspaceUrl, repositoryUrl } = project;
    const entitlementIds = await getProjectEntitlements(ctx, name);

    // First delete ML and repository because we need the groups
    if (workspaceUrl) {
      await WorkspaceDeletionService.delete(ctx, project);
    }

    if (repositoryUrl) {
      await deleteRepository(ctx, project);
    }

    ctx.log(`Deleting groups of project ${name}`);
    try {
      await deleteEntitlements(ctx, entitlementIds);
    } catch (e) {
      const err = e as Error;
      ctx.log(err);
      await SlackService.logInfo(ctx, {
        message: `Deleting of entitlements failed with error ${err.message}`,
      });
    }

    ctx.log(`Deleting DB entries for project ${name}`);
    const promises = [
      ProjectModel.deleteOne({ _id }).lean(),
      OwnershipInviteModel.deleteMany({ pid: _id }).lean(),
      FavoriteProjectModel.deleteMany({ pid: _id }).lean(),
      JoinProjectRequestModel.deleteMany({ pid: _id }).lean(),
      LeaveProjectRequestModel.deleteMany({ pid: _id }).lean(),
      IgamRequestModel.deleteMany({ pid: _id }).lean(),
      FileExpirationModel.deleteMany({ pid: _id }).lean(),
    ];

    ctx.log("awaiting completion");
    await withRetry(
      async () => {
        await Promise.all(promises);
      },
      ctx,
      5,
    );
  },
};

export default ProjectDeletionService;
