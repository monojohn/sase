import type { Context } from "@azure/functions";
import {
  getMembersGroupName,
  getOwnersGroupName,
  getTeamGroupName,
  wait,
} from "../../utils/helpers";
import EntitlementsService from "../igamService/entitlementsService";
import { AddIgamUser, CreateEntitlementsResponse } from "../igamService/types";
import { CreateProjectProps } from "./types";
import { ProjectCreationType } from "./enums";
import IgamRequestModel from "../dbConnector/models/igamRequestModel";
import { RequestStatus, RequestType } from "../dbConnector/enums";
import { buildJustification } from "../igamService/helpers";

const MAX_ERRORS = 20;

// query status for all groups
const statusFn = async (
  ctx: Context,
  names: string[],
  urls: string[],
  maxRetries = 30,
  delay = 30,
) =>
  Promise.all(
    names.map(async (name, index) => {
      let retries = 0;
      let errorCount = 0;
      while (retries <= maxRetries) {
        ctx.log(`Attempt #${retries} of fetching status of ${name}`);

        const [response, entitlements] = await Promise.all([
          EntitlementsService.getEntitlementsByPermalink(ctx, urls[index]),
          EntitlementsService.get(ctx, name),
        ]);

        // if there's a creation error
        if (response?.entitlements?.[0]?.status === "ERROR") {
          const trace = response?.entitlements?.[0]?.stacktrace ?? "Z";
          // IGAM sometimes  throws 404's during creation
          const is404Error = trace.includes("Service returned status:404");
          const isSkipableError = trace.includes("At least one item failed");
          const isIgamError = true;

          if (is404Error || isSkipableError || isIgamError) {
            ctx.log(`Detected error in stacktrace`, {
              errorCount,
              MAX_ERRORS,
              is404Error,
              isSkipableError,
              isIgamError,
            });

            errorCount += 1;
            if (errorCount <= MAX_ERRORS) {
              ctx.log(`Retrying`);
              // IGAM waits for 2 min between retries, no point calling earlier
              await wait(60);
              // if it's a 404 error and we haven't ran out of retries, try again
              continue;
            }
          }

          // we don't know what type of error we got
          ctx.log(`Group creation failed for ${name}`, trace, { is404Error, errorCount });
          ctx.log({ response });

          // throw it and stop execution
          const err = `IGAM Error | ${response.entitlements[0].stacktrace?.substring(0, 50)}`;
          ctx.log(err);
          throw new Error(err);
        }

        if (entitlements?.length === 0) {
          // increment retry count
          retries += 1;

          // wait a bit
          await wait(delay);

          // continue the cycle
          continue;
        }

        ctx.log(`Group creation succeeded for ${name}`);
        return entitlements;
      }

      ctx.log(`Max retries exceeded for ${name}`);
      throw new Error(`IGAM Error | Max retries exceeded for ${name}`);
    }),
  );

const ProjectCreationService = {
  async createGroups(ctx: Context, props: CreateProjectProps) {
    const { project, owner, projectCreationType, department } = props;
    ctx.log(`Start creation of project ${project.name} groups`);

    const title = project.name;

    const igamOwner: AddIgamUser = {
      action: "add",
      accountName: owner.userPrincipalName,
    };

    const teamGroupName = getTeamGroupName(title);
    const ownersGroupName = getOwnersGroupName(title);
    const membersGroupName = getMembersGroupName(title);

    ctx.log({ teamGroupName, ownersGroupName, membersGroupName });

    // description has a limit of 200 characters
    const entitlementDescription = `Project name: ${title}`;

    ctx.log(`Entitlement owner will be ${department}`);

    const commonEntitlementProps = {
      owner: department,
      description: entitlementDescription,
      classification: project.confidentialityLevel,
    };

    // 3 entitlements are needed: owners group, members group and team
    const ownerGroupProps = {
      displayName: ownersGroupName,
      members: [igamOwner],
      entType: "AAD-Group",
      ...commonEntitlementProps,
    };
    const memberGroupProps = {
      displayName: membersGroupName,
      members: [],
      entType: "AAD-Group",
      ...commonEntitlementProps,
    };
    const teamGroupProps = {
      displayName: teamGroupName,
      members: [igamOwner],
      entType: "AAD-Team",
      persistent: true,
      ...commonEntitlementProps,
    };

    if (projectCreationType === ProjectCreationType.APPROVAL_REQUIRED) {
      // just create owner group, waiting for approval from org
      const { requestId, url } = await EntitlementsService.create(ctx, {
        request: true,
        justification: buildJustification(project, owner.displayName),
        ...ownerGroupProps,
      });

      if (!requestId) {
        throw new Error(`Missing requestId for owner entitlement creation for ${title}`);
      }

      await IgamRequestModel.create({
        requestType: RequestType.PROJECT_CREATION,
        requestId,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        pid: project._id,
        requesterId: owner.id,
        entitlementUrl: url,
      });
      return [];
    }

    const promises: Promise<CreateEntitlementsResponse>[] = [];
    promises.push(
      EntitlementsService.create(ctx, teamGroupProps),
      EntitlementsService.create(ctx, memberGroupProps),
    );

    if (projectCreationType === ProjectCreationType.NO_APPROVAL) {
      // create all groups in case approval is not needed
      promises.push(EntitlementsService.create(ctx, ownerGroupProps));
    }

    const response = await Promise.all(promises);
    const urls = response.map(({ url }) => url);

    if (projectCreationType === ProjectCreationType.APPROVAL_GRANTED) {
      const request = await IgamRequestModel.findOne({
        pid: project._id,
        requestType: RequestType.PROJECT_CREATION,
      });
      if (!request?.entitlementUrl) {
        throw new Error(`Missing entitlement url for owner group for ${title}`);
      }
      urls.push(request.entitlementUrl);
    }

    ctx.log(`Group creation request sent`);
    return statusFn(ctx, [teamGroupName, membersGroupName, ownersGroupName], urls);
  },
};

export default ProjectCreationService;
