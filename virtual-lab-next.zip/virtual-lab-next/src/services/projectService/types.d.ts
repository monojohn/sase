import { Project, RolesAndEntitlements } from "../dbConnector/models/project";
import { GraphUser, UserType } from "../graphService/types";
import { ProjectCreationType } from "./enums";

export type SortOrder = "asc" | "desc";

export type MissingRolesOrEntitlements = { [upn: string]: string[] };

export type Analysis = {
  errors: string[];
  missingUsers: string[];
  missingRolesAndEntitlements: { [upn: string]: RolesAndEntitlements[] };
  missingConditions: { [type in UserType]: RolesAndEntitlements[] };
  errorUsers: { email: string; displayName: string; oid: string }[];
};

export type CreateProjectProps = {
  project: Project;
  owner: Pick<GraphUser, "id" | "userPrincipalName" | "userType" | "displayName" | "department">;
  projectCreationType: ProjectCreationType;
  department: string;
};
