import { Context } from "@azure/functions";
import { VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../../utils/config";
import { Project } from "../dbConnector/models/project.d";
import SharePointService from "../sharepointService/sharepointService";

/**
 * Extracts the siteId from the siteUrl.
 * In most cases the SiteId is the same as the siteUrl but in some edge cases it's not.
 *
 * @param siteUrl string in the format "https://ecbdevenv.sharepoint.com/sites/TEAM_VLB-INTEGRATION_PROJECT_39"
 */
export const getSiteIdFromUrl = (siteUrl = "") => {
  const siteUrlSplit = siteUrl.split("/");
  return siteUrlSplit.at(-1)!;
};

const projectAccessLevelService = {
  async allowVisitors(ctx: Context, project: Project) {
    const groups = [VL_MEMBERS_GROUP_ID, VL_GUESTS_GROUP_ID];

    const siteId = getSiteIdFromUrl(project.url);

    // Add VL groups under Visitors
    ctx.log(`Adding VL groups as visitors of ${siteId}`, groups);
    await SharePointService.addVisitorGroups(ctx, siteId, groups);
  },

  async disallowVisitors(ctx: Context, project: Project) {
    const groups = [VL_MEMBERS_GROUP_ID, VL_GUESTS_GROUP_ID];

    const siteId = getSiteIdFromUrl(project.url);

    ctx.log(`Removing VL groups as visitors of ${siteId}`, groups);
    await SharePointService.removeVisitorGroups(siteId, groups);
  },
};

export default projectAccessLevelService;
