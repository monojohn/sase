export enum ProjectCreationType {
  APPROVAL_REQUIRED = "Managerial approval required",
  APPROVAL_GRANTED = "Managerial approval granted",
  NO_APPROVAL = "No approval required",
}
