import { Context } from "@azure/functions";
import { getEmailOfUser } from "../../../utils/helpers";
import { AccessibilityLevel } from "../../dbConnector/enums";
import FavoriteProjectModel from "../../dbConnector/models/favoriteProjectModel";
import LeaveProjectRequestModel from "../../dbConnector/models/leaveProjectRequestModel";
import OwnershipInviteModel from "../../dbConnector/models/ownershipInviteModel";
import { Project } from "../../dbConnector/models/project";
import ProjectModel from "../../dbConnector/models/projectModel";
import GraphService from "../../graphService/graphService";
import EntitlementsService from "../../igamService/entitlementsService";
import RepositoryService from "../../repositoryService/repositoryService";

/**
 * Removes a user from a project
 *
 * @param ctx
 * @param project
 * @param userId user oid or UPN
 */
export const removeUserFromProject = async (ctx: Context, project: Project, userId: string) => {
  const {
    _id: pid,
    name: projectName,
    ownersGroupId,
    membersGroupId,
    teamGroupName,
    teamGroupId,
    ownersGroupName,
    membersGroupName,
  } = project;

  const [teamEntitlementId, ownersEntitlementId, membersEntitlementId, user] = await Promise.all([
    EntitlementsService.getEntitlementsId(ctx, project.teamGroupName),
    EntitlementsService.getEntitlementsId(ctx, project.ownersGroupName),
    EntitlementsService.getEntitlementsId(ctx, project.membersGroupName),
    GraphService.getUserProps(ctx, userId, [
      "id",
      "displayName",
      "userType",
      "userPrincipalName",
      "otherMails",
      "mail",
      "identities",
    ]),
  ]);

  if (!teamGroupName || !ownersGroupName || !membersGroupName) {
    const error = `IGAM Entitlement IDs not found project ${projectName}`;
    ctx.log(error, {
      teamGroupName,
      teamGroupId,
      ownersGroupName,
      ownersGroupId,
      membersGroupId,
      membersGroupName,
    });
    throw new Error(error);
  }
  const oid = user.id;
  const upn = user.userPrincipalName;
  const email = getEmailOfUser(user);
  const isOwner = project.owners.includes(oid);
  ctx.log({ isOwner, userType: user.userType });

  await Promise.all([
    // remove user from repository
    RepositoryService.removeUser(ctx, projectName, email),

    // remove user from all AD groups
    EntitlementsService.removeUser(ctx, upn, ownersEntitlementId!),
    EntitlementsService.removeUser(ctx, upn, membersEntitlementId!),
    EntitlementsService.removeUser(ctx, upn, teamEntitlementId!),
  ]);

  // update DB after removing from groups
  const promises: Promise<unknown>[] = [
    // Remove pending ownership invitations
    OwnershipInviteModel.deleteMany({ pid, invitee: oid }).lean(),
    // Remove pending leave requests
    LeaveProjectRequestModel.deleteMany({ pid, oid }).lean(),
    // remove user from owners and members
    ProjectModel.updateOne({ _id: pid }, { $pull: { owners: oid, members: oid } }).lean(),
  ];

  if (project.accessibilityLevel === AccessibilityLevel.Private) {
    // remove favorite when project is private
    promises.push(FavoriteProjectModel.deleteMany({ oid, pid }).lean());
  }

  await Promise.all(promises);
};
