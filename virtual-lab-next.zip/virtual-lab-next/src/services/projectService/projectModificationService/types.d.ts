import { WithSession } from "../../../../@types/types";

type ProjectModificationAction =
  | "addMember"
  | "addOwner"
  | "removeMember"
  | "removeOwner"
  | "toMember"
  | "toOwner"
  | "alreadyOwner"
  | "proposeOwnership"
  | "ownershipAccept"
  | "rejectOwnership"
  | "cantOwn";

export type ProjectModificationProps = WithSession<{
  action: ProjectModificationAction;
  email: string;
  groupId: string;
  memberId: string; // User principal BUT NOT FOR ownershipAccept || ownershipReject
  projectName: string;

  // only present in ownershipAccept || ownershipReject
  userName: string;
  userEmail: string; // User principal
}>;

export type UserAccessRights = "Member" | "Owner";
