import { jest } from "@jest/globals";
import NotificationService from "./projectDeletionNotificationService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Project deletion NotificationService", () => {
  it("sendSuccessEmail works", async () => {
    await NotificationService.sendSuccessEmail(ctx, { projectName: "Unit test", bcc: [userEmail] });
  });

  it("sendErrorEmail works", async () => {
    await NotificationService.sendErrorEmail(ctx, "Unit test", [userEmail], userEmail);
  });
});
