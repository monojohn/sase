import { Context } from "@azure/functions";
import { BlobItem } from "@azure/storage-blob";
import { WithId, Document } from "mongodb";
import {
  BACKUP_PERSISTENCY,
  BACKUP_PREFIX,
  BACKUP_STORAGE_ACCOUNT,
  BACKUP_STORAGE_CONTAINER,
} from "../../utils/config";
import BlobStorageService from "../blobStorageService/blobStorageService";
import MongoConnector from "../dbConnector/mongoDb";
import SlackService from "../slackService";
import { Uint8ArrayToString, stringToUint8Array } from "./helpers";
import { wait } from "../../utils/helpers";

let blobStorage: BlobStorageService | null = null;
const getBlobStorage = () => {
  blobStorage ??= new BlobStorageService({
    storageAccountName: BACKUP_STORAGE_ACCOUNT,
    storageContainerName: BACKUP_STORAGE_CONTAINER,
  });

  return blobStorage;
};

const BackupService = {
  async backupDb(ctx: Context) {
    ctx.log("Backup started");

    const storage = getBlobStorage();

    const today = new Date();
    const fullYear = today.getFullYear();
    const month = `0${today.getMonth() + 1}`.slice(-2); // zero-padded month
    const date = `0${today.getDate()}`.slice(-2); // zero-padded date;
    const dateString = `${fullYear}-${month}-${date}`;
    const timestamp = today.getTime();

    const mongoose = await MongoConnector.connect();
    const models = await mongoose.connection.db.collections();
    const backedUpCollections: string[] = [];
    const chunkSize = 5000;

    // get all records per model
    for (let index = 0; index < models.length; index++) {
      const model = models[index]; // cast to prevent type false positives in the .find
      const modelName = model.collectionName;

      ctx.log(`Backing up ${modelName}`);
      try {
        // fetch records by chunks because fetching all of them throws 429 errors for some collections
        ctx.log(`Fetching records by chunks`);

        const allRecords: WithId<Document>[] = [];
        let done = false;
        let lastId = null;

        do {
          // build query based on lastId
          const query = lastId ? { _id: { $gt: lastId } } : {};

          await wait(1);
          const records: WithId<Document>[] = await model
            .find(query)
            .sort({ _id: 1 })
            .limit(chunkSize)
            .toArray();

          // push retrieved records
          allRecords.push(...records);

          // get last record's id for next query
          if (records.length > 0) {
            lastId = records.at(-1)!._id;
          }

          // in case less records were retrieved than the chunkSize, we are at the end
          if (records.length < chunkSize) {
            done = true;
          }
        } while (!done);

        ctx.log(`Converting ${allRecords.length} records to byte array`);
        // covert data to byte array
        const byteArrData = stringToUint8Array(JSON.stringify(allRecords));

        // update json file to azure
        const fileName = `${BACKUP_PREFIX}${dateString}-${modelName}-${timestamp}`;

        ctx.log(`Uploading file "${fileName}"`);
        await storage.upload(byteArrData, fileName);

        backedUpCollections.push(model.collectionName);
      } catch (e) {
        const errorMsg = `Failed to backup ${modelName}`;
        const error = new Error(errorMsg);

        ctx.log(errorMsg, e);

        await SlackService.logError(ctx, error);
      }
    }

    // return names of backed up collections
    return backedUpCollections;
  },

  async backupDevoFile(ctx: Context, file: Uint8Array<ArrayBuffer>, fileName: string) {
    ctx.log(`Uploading ${fileName} to storage account`);
    const storage = getBlobStorage();
    await storage.upload(file, fileName);
  },

  /**
   * Downloads a file from Azure Storage account as a string
   *
   * @param fileName name of file to download should be YYYY-MM-DD-collectionName-timestamp
   * i.e. "2024-01-19-userFeedbacks-1705676760482" (the dates are 0-padded)
   */
  async getFile(ctx: Context, fileName: string) {
    const storage = getBlobStorage();
    ctx.log(`Downloading ${fileName}`);

    // download file
    const fileBuffer = await storage.download(fileName);

    // convert to a JSON array
    ctx.log(`Converting Uint8Array to string`);
    return Uint8ArrayToString(fileBuffer);
  },

  /**
   * Lists all files available in the backup system
   *
   * @param prefix an optional prefix the files must have
   * @returns
   */
  listFiles(prefix?: string) {
    return getBlobStorage().list({ prefix });
  },

  /**
   * Returns a list of backups older than "timeInDays"
   *
   * @param prefix
   * @param timeInDays
   * @returns
   */
  async listOldBackups(prefix?: string, timeInDays = BACKUP_PERSISTENCY) {
    const minAgeTimestamp = Date.now() - timeInDays * 24 * 60 * 60 * 1000;
    const files = await BackupService.listFiles(prefix);

    const oldBackups: BlobItem[] = [];

    for (let index = 0; index < files.length; index++) {
      const file = files[index];
      if (!file.properties.createdOn) {
        throw new Error("createdOn date not defined");
      }
      const fileAge = new Date(file.properties.createdOn).getTime();
      if (fileAge < minAgeTimestamp) {
        oldBackups.push(file);
      }
    }

    return oldBackups;
  },

  /**
   * Deletes files from Azure Storage account
   *
   * @param files names of files to delete
   */
  async delete(files: string[]) {
    return getBlobStorage().delete(files);
  },
};

export default BackupService;
