export const stringToUint8Array = (str: string) => {
  const base64String = Buffer.from(encodeURIComponent(str), "binary").toString("base64");
  return new TextEncoder().encode(base64String);
};

export const Uint8ArrayToString = (byteArray: Uint8Array | Buffer) => {
  const decodedString = new TextDecoder().decode(byteArray);
  return decodeURIComponent(Buffer.from(decodedString, "base64").toString("binary"));
};
