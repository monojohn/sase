import { Uint8ArrayToString, stringToUint8Array } from "./helpers";

describe("BackupService helpers", () => {
  const testString = "testéßtring€";
  const testUint8 = [
    100, 71, 86, 122, 100, 67, 86, 68, 77, 121, 86, 66, 79, 83, 86, 68, 77, 121, 85, 53, 82, 110,
    82, 121, 97, 87, 53, 110, 74, 85, 85, 121, 74, 84, 103, 121, 74, 85, 70, 68,
  ];

  describe("stringToByteArray", () => {
    it("Converts to expected format", () => {
      const output = stringToUint8Array(testString);
      expect(output.toLocaleString()).toBe(testUint8.toLocaleString());
    });
  });

  describe("byteArrayToString", () => {
    it("Converts to expected format", () => {
      const input = stringToUint8Array(testString);
      const output = Uint8ArrayToString(input);
      expect(output).toEqual(testString);
    });
  });
});
