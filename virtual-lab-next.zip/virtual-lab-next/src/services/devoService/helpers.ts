import {
  ProjectLog,
  ProjectToUser,
  UserLog,
  UserMetadata,
  TokenConsumption,
} from "../../features/export/types";

export const createSchema = (
  obj: UserLog | ProjectLog | UserMetadata | ProjectToUser | TokenConsumption,
) => {
  const fields: Record<string, { type: string; logicalType?: string }> = {};
  for (const [key, value] of Object.entries(obj)) {
    let type = { type: "UTF8" };
    if (typeof value === "number") {
      type = { type: "DOUBLE" };
    }
    if (typeof value === "boolean") {
      type = { type: "BOOLEAN" };
    }
    if (value instanceof Date) {
      type = { type: "TIMESTAMP_MILLIS" };
    }
    fields[key] = type;
  }
  return fields;
};
