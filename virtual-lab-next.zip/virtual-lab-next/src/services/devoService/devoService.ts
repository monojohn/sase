import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { AssumeRoleCommand, STSClient } from "@aws-sdk/client-sts";
import { Context } from "@azure/functions";
import { createReadStream, createWriteStream, unlinkSync } from "node:fs";
import parquet from "parquetjs";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import os from "node:os";
import path from "node:path";
import {
  DEVO_ACCESS_KEY_ID,
  DEVO_BUCKET,
  DEVO_ENDPOINT,
  DEVO_REGION,
  DEVO_ROLE_ARN,
  DEVO_SECRET_ACCESS_KEY,
  IS_PROD,
  ENV,
} from "../../utils/config";
import SlackService from "../slackService";
import { createSchema } from "./helpers";
import {
  ProjectLog,
  ProjectToUser,
  TokenConsumption,
  UserLog,
  UserMetadata,
} from "../../features/export/types";
import BackupService from "../backupService/backupService";
import { stringToUint8Array } from "../backupService/helpers";

const DevoService = {
  async uploadData(
    ctx: Context,
    data: (UserLog | ProjectLog | UserMetadata | ProjectToUser | TokenConsumption)[],
    tableName: string,
  ) {
    if (!data[0]) {
      const message = `No data received, nothing to upload`;
      ctx.log(message);
      await SlackService.logWarning(ctx, new Error(message));
      return;
    }
    const schema = new parquet.ParquetSchema(createSchema(data[0]));

    const tempDir = os.tmpdir();
    const location = path.join(tempDir, `${tableName}.parquet`);
    const stream = createWriteStream(location);
    const writer = await parquet.ParquetWriter.openStream(schema, stream);
    for (const row of data) {
      await writer.appendRow(row);
    }
    await writer.close();
    const file = createReadStream(location);

    // sts client
    const stsClient = new STSClient({
      region: DEVO_REGION,
      endpoint: DEVO_ENDPOINT,
      credentials: { accessKeyId: DEVO_ACCESS_KEY_ID, secretAccessKey: DEVO_SECRET_ACCESS_KEY },
    });
    const assumeRole = await stsClient.send(
      new AssumeRoleCommand({
        RoleArn: DEVO_ROLE_ARN,
        RoleSessionName: uuidv4(),
        DurationSeconds: 3600,
      }),
    );

    const creds = assumeRole.Credentials;
    if (!creds?.AccessKeyId || !creds?.SecretAccessKey) {
      const message = "Missing credentials from assuming role";
      ctx.log(message);
      throw new Error(message);
    }

    // s3 client
    const s3 = new S3Client({
      region: DEVO_REGION,
      credentials: {
        accessKeyId: creds.AccessKeyId,
        secretAccessKey: creds.SecretAccessKey,
        sessionToken: creds.SessionToken,
      },
    });

    const tableNamePrefix = IS_PROD ? "" : `${ENV.toLowerCase()}_`;

    // upload data
    const uploadCommand = new PutObjectCommand({
      Bucket: DEVO_BUCKET,
      Key: `prj_vlab/db/${tableNamePrefix}${tableName}/${moment().toISOString()}.parquet`,
      Body: file,
    });

    try {
      await s3.send(uploadCommand);
      await BackupService.backupDevoFile(
        ctx,
        stringToUint8Array(JSON.stringify(data)),
        `${tableName}-${moment().toISOString()}.json`,
      );
    } catch (e) {
      const message = `Could not upload file for ${tableName}`;
      ctx.log(message, e);
      await SlackService.logWarning(ctx, new Error(message));
    }

    unlinkSync(location);
  },
};

export default DevoService;
