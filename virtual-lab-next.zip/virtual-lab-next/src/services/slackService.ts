import { Context, HttpRequestHeaders } from "@azure/functions";
import { IncomingWebhook } from "@slack/webhook";
import moment from "moment";
import { AZURE_TENANT, DISABLE_SLACK, IS_JEST, SLACK_WEBHOOK_URL } from "../utils/config";

const isDev = AZURE_TENANT !== "ecbprod";
let webhook: IncomingWebhook;

/**
 * Get webhook when fn is called to avoid adding more moving parts
 *
 * @returns IncomingWebhook
 */
const getWebhook = () => {
  webhook ??= new IncomingWebhook(SLACK_WEBHOOK_URL);
  return webhook;
};

const getDataDogLinks = (ctx: Context) => {
  const { invocationId } = ctx;
  const query = [
    encodeURIComponent(`@invocationId:${invocationId}`),
    `stream_sort=${encodeURIComponent("time,asc")}`,
    `from_ts=${Date.now() - 15 * 50 * 1000}`, // 15 minutes int the past
    `to_ts=${Date.now() + 15 * 50 * 1000}`, // 15 min in the future
  ];
  const queryUrl = `https://app.datadoghq.eu/logs?query=${query.join("&")}`;
  const loginUrl = "https://app.datadoghq.eu/account/login/id/408d5d80-097b-11ec-bd24-da7ad0900005";

  return {
    queryUrl,
    loginUrl,
  };
};

const getSlackCodeSnippet = (ctx: Context, data: Record<string, unknown>) => {
  try {
    return `\`\`\`\n${JSON.stringify(data, null, 2)}\n\`\`\``;
  } catch (error) {
    const err = error as Error;
    ctx.log(`Error getting slack code snippet: ${err.message}`);
    return `\`\`\`Unable to decode data\`\`\``;
  }
};

const isPostman = (headers?: HttpRequestHeaders) => {
  const userAgent = headers?.["User-Agent"] ?? headers?.["user-agent"];
  return userAgent?.toLocaleLowerCase?.().includes("postman");
};

type LogLevel = "Error" | "Warning" | "Info";

type LogObject = Error | { message: string; stack?: string };

const getLogMessage = (log: LogObject) => log?.message ?? log?.stack ?? "No error data received";

const IconMap: Record<LogLevel, string> = {
  Error: ":fire:",
  Warning: ":warning:",
  Info: ":information_source:",
};

const SlackService = {
  log(ctx: Context, msg: LogObject, level: LogLevel) {
    if (isDev && isPostman(ctx.req?.headers)) {
      return ctx.log(`Postman request detected, not sending log to slack`);
    }

    // start off with basic error data
    const message = [
      `${IconMap[level]} *${level}* ${IconMap[level]} in function \`${
        ctx.executionContext?.functionName
      }\` on ${moment.utc().format("lll")}`,
      `Request id: \`${ctx.invocationId}\``,
    ];

    // ctx.req only exists in HTTP function - cron and queues don't have it
    if (ctx.req) {
      message.push(
        `\`${ctx.req.method} ${ctx.req.url}\``,
        `FE build-version: \`${ctx.req?.headers?.["build-version"]}\``,
      );
    }

    // add query params if present
    // the query property defaults to an empty object so we must check if any keys are present
    if (ctx.req?.query && Object.keys(ctx.req.query).length > 0) {
      message.push(`Request query: ${getSlackCodeSnippet(ctx, ctx.req.query)}`);
    }

    // add log message
    message.push(`\`\`\`\n${getLogMessage(msg)}\n\`\`\``);

    const { loginUrl, queryUrl } = getDataDogLinks(ctx);
    message.push(`Datadog <${queryUrl}|*logs*>. Datadog <${loginUrl}|*login*>`);

    return SlackService.send(message.join("\n"));
  },

  logError(ctx: Context, err: Error) {
    return SlackService.log(ctx, err, "Error");
  },

  logWarning(ctx: Context, msg: Error) {
    return SlackService.log(ctx, msg, "Warning");
  },

  logInfo(ctx: Context, msg: LogObject) {
    return SlackService.log(ctx, msg, "Info");
  },

  async send(message: string) {
    if (IS_JEST) {
      // don't log when running tests
      return;
    }

    if (DISABLE_SLACK) {
      // eslint-disable-next-line no-console
      console.log(message);
      return;
    }

    await getWebhook().send(message);
  },
};

export default SlackService;
