import { formatName } from "./helpers";

describe("Repositroy service helpers", () => {
  describe("formatName", () => {
    it("Should not modify name", () => {
      expect(formatName("a-b-c")).toEqual("a-b-c");
    });

    it("Should replace spaces with dashes", () => {
      expect(formatName("a b c")).toEqual("a-b-c");
    });

    it("Should replace underscores with dashes", () => {
      expect(formatName("a_b_c")).toEqual("a-b-c");
    });

    it("Should replace multiple spaces, dashes or underscores with dashes", () => {
      expect(formatName("a - b - c")).toEqual("a-b-c");
      expect(formatName("a _ b _ c")).toEqual("a-b-c");
      expect(formatName("a _ b - c")).toEqual("a-b-c");
      expect(formatName("a _ - ---- ---- ___ _ _ b - - - - _ _ - _  _     - c")).toEqual("a-b-c");
    });
  });
});
