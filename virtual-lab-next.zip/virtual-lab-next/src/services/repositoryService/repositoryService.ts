import { AxiosError } from "axios";
import { Context } from "@azure/functions";
import { Project } from "../dbConnector/models/project";
import ProjectModel from "../dbConnector/models/projectModel";
import NotificationService from "./notificationService";
import {
  addMember,
  createGroup,
  createProject,
  deleteGroup,
  formatName,
  getCommits,
  getGroup,
  getGroups,
  getInvitations,
  getMembers,
  getProjects,
  getUser,
  removeInvitation,
  removeMember,
  searchGroup,
  sendInvitation,
  updateInvitation,
  updateMember,
  updateProject,
} from "./helpers";
import { Commit, Group } from "./types";
import { generateRandomString } from "../../utils/helpers";
import { AccessLevel } from "./enums";

// documentation on deletion process in Sofa: https://gitlab.sofa.dev/sofa/for-users/on-boarding/-/wikis/1-SOFA-How-to/Delete-a-Gitlab-project
const deletionPhrases = [
  "Delete this project",
  "to be deleted",
  "to_be_deleted",
  "delete please",
  "delete_please",
];

const RepositoryService = {
  /**
   * Create a new Sofa repository group and project
   */
  async createRepositoryGroup(ctx: Context, projectName: string, description: string) {
    ctx.log(`Create repository group for ${projectName}, description ${description}`);
    const name = this.formatName(projectName);
    const { id, web_url: groupUrl } = await this.createGroup(name, description);
    await this.createRepository(name, id);
    return groupUrl;
  },

  async createGroup(name: string, description: string) {
    try {
      const group = await createGroup(name, description);
      return group;
    } catch (err) {
      const error = err as AxiosError<{ message: string }>;
      if (error.response?.data?.message.includes("has already been taken")) {
        const suffix = generateRandomString(2);
        return createGroup(`${name}_${suffix}`, description);
      }
      throw err;
    }
  },

  /**
   * Get repository group
   */
  async getRepositoryGroup(ctx: Context, projectName: string) {
    const project = await ProjectModel.findOne({ name: projectName, repositoryUrl: /^http/ });
    if (!project) {
      return null;
    }
    // example of URL: https://gitlab.sofa.dev/groups/virtual-lab-dev/test-release-ro-2604_f2
    const repositoryUrlSplit = project?.repositoryUrl.split("/");
    const groupName = repositoryUrlSplit.at(-1)!;

    ctx.log(`Searching repository group ${groupName}`);
    const groups = await searchGroup(groupName);

    return groups.find(({ path }) => path === groupName);
  },

  /**
   * Add user to repository group
   */
  async addUser(ctx: Context, projectName: string, email: string, isAddingOwner: boolean) {
    ctx.log(`Adding user to ${projectName} repository group`);
    ctx.log(`Checking if "${projectName}" has a Sofa repository group`);
    const repositoryGroup = await this.getRepositoryGroup(ctx, projectName);

    if (!repositoryGroup) {
      ctx.log(`"${projectName}" has no repository group.`);
      return;
    }

    const user = await getUser(email);
    const accessLevel = isAddingOwner ? AccessLevel.Maintainer : AccessLevel.Developer;

    if (user) {
      await this.addUserToGroup(repositoryGroup.id, user.id, accessLevel);
      return;
    }
    // user doesn't exist in Sofa -> invite user
    const invitations = await getInvitations(repositoryGroup.id);
    const inviteEmail = email.toLowerCase();
    const invitation = invitations.find(({ invite_email }) => invite_email === inviteEmail);
    if (invitation) {
      await updateInvitation(repositoryGroup.id, accessLevel, inviteEmail);
      return;
    }
    await sendInvitation(repositoryGroup.id, accessLevel, inviteEmail);
    await NotificationService.sendInvitationEmail(ctx, projectName, repositoryGroup.web_url, [
      email,
    ]);
  },

  async addUserToGroup(repositoryGroupId: number, userId: number, accessLevel: number) {
    const members = await getMembers(repositoryGroupId);
    // check if user is part of the group
    const existingMember = members.find(({ id }) => id === userId);

    if (existingMember) {
      // if user is an owner, skip (VL team = owners)
      if (existingMember.access_level === AccessLevel.Owner) {
        return;
      }
      // modify user access
      await updateMember(repositoryGroupId, userId, accessLevel);
      return;
    }
    // add user
    await addMember(repositoryGroupId, userId, accessLevel);
  },

  /**
   * Remove user from group
   */
  async removeUser(ctx: Context, projectName: string, email: string) {
    ctx.log(`Removing user ${email} from ${projectName} repository`);

    const repositoryGroup = await this.getRepositoryGroup(ctx, projectName);
    if (!repositoryGroup) {
      ctx.log(`"${projectName}" has no repository group.`);
      return;
    }

    const user = await getUser(email);

    if (user) {
      const members = await getMembers(repositoryGroup.id);
      const member = members.find(({ id }) => id === user.id);
      if (!member) {
        // user no longer in group, maybe removed manually
        return;
      }
      if (member.access_level === AccessLevel.Owner) {
        // if user is an owner, skip (VL team = owners)
        return;
      }
      await removeMember(repositoryGroup.id, user.id);
      return;
    }

    const invitations = await getInvitations(repositoryGroup.id);
    const inviteEmail = email.toLowerCase();
    const invitation = invitations.find(({ invite_email }) => invite_email === inviteEmail);
    if (!invitation) {
      // user is no longer invited, maybe removed manually
      return;
    }
    await removeInvitation(repositoryGroup.id, inviteEmail);
  },

  /**
   * Mark group for deletion
   */
  async markRepositoryGroupForDeletion(ctx: Context, projectName: string) {
    const repositoryGroup = await this.getRepositoryGroup(ctx, projectName);
    if (!repositoryGroup) {
      ctx.log(`"${projectName}" has no repository group`);
      return;
    }

    const repositories = await this.getRepositories(repositoryGroup.id);
    await Promise.all(
      repositories.map(({ id, name }) => updateProject(id, `${name} ${deletionPhrases[0]}`)),
    );
  },

  async permanentlyRemoveGroup(ctx: Context, repositoryGroup: Group) {
    const repositories = await this.getRepositories(repositoryGroup.id);
    if (repositories.length) {
      ctx.log(
        `Repository group ${repositoryGroup.name} still has repositories, group cannot be deleted`,
      );
      return;
    }
    ctx.log(`Repository group ${repositoryGroup.name} will be deleted`);

    // if it has not been marked for deletion, it can't be permanently removed
    if (!repositoryGroup.marked_for_deletion_on) {
      await deleteGroup(repositoryGroup.id);
      const repositoryGroupUpdated = await getGroup(repositoryGroup.id);
      if (!repositoryGroupUpdated) {
        ctx.log(`Repository group ${repositoryGroup.name} not found anymore`);
        return;
      }
      await deleteGroup(repositoryGroupUpdated.id, repositoryGroupUpdated.full_path);
      return;
    }
    await deleteGroup(repositoryGroup.id, repositoryGroup.full_path);
  },

  async getRepositoryGroupCount() {
    const groups = await this.getAllRepositoryGroups();
    return groups.length;
  },

  async getCommitsForAllRepos(ctx: Context, project: Project) {
    const repositoryGroup = await this.getRepositoryGroup(ctx, project.name);
    if (!repositoryGroup?.id) {
      throw new Error(`Repository group for ${project.name} has missing id`);
    }

    const repositories = await this.getRepositories(repositoryGroup.id);
    const promises: Promise<Commit[]>[] = [];
    for (const repository of repositories) {
      if (!repository.id) {
        throw new Error(`Repository for ${project.name} has missing id`);
      }
      promises.push(getCommits(repository.id));
    }

    const commitDetails = await Promise.all(promises);
    return { commitDetails, repositories };
  },

  async getAllRepositoryGroups() {
    const allGroups: Group[] = [];
    let done = false;
    let page = 1;
    do {
      const groups = await getGroups(page);
      page += 1;
      allGroups.push(...groups);
      if (!groups.length) {
        done = true;
      }
    } while (!done);
    return allGroups;
  },

  createRepository: createProject,
  getUser,
  getRepositories: getProjects,
  getCommits,
  deletionPhrases,
  formatName,
};

export default RepositoryService;
