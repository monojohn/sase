import { AccessLevel } from "./enums";

export type User = {
  id: number;
  username: string;
};

export type Group = {
  id: number;
  name: string;
  path: string;
  full_path: string;
  web_url: string;
  marked_for_deletion_on?: string;
};

export type Repository = {
  id: number;
  name: string;
  last_activity_at: string;
};

export type Member = {
  id: number;
  access_level: AccessLevel;
};

export type Invitation = {
  invite_email: string;
};

export type Commit = {
  id: string;
  author_email: string; // 'roberta.popescu.external@tadnet.eu'
  authored_date: string; //  '2025-05-30T07:20:00.000+00:00'
};
