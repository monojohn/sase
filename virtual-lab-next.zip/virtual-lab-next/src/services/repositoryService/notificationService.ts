import { Context } from "@azure/functions";
import EmailService from "../emailService/emailService";

const NotificationService = {
  async sendInvitationEmail(
    ctx: Context,
    projectName: string,
    repositoryUrl: string,
    bcc: string[],
  ) {
    const subject = `[Action required] You have been invited to join ${projectName}'s Git project`;
    const headline = `You have been invited to join a Git project. In order to gain access, you need to request the SOFA_Developers role in IGAM / IAM. Once the role has been granted, you need to access <a href="https://gitlab.sofa.dev">Sofa Gitlab</a> for the license to be granted.`;

    await EmailService.sendSuccessCtaLeftAlignEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "Access Git project",
        ctaUrl: repositoryUrl,
      },
    });
  },
};

export default NotificationService;
