import axios from "axios";
import { GIT_REPOSITORY_TOKEN, SOFA_HOST, SOFA_NAMESPACE_ID } from "../../utils/config";
import { User, Group, Member, Invitation, Repository, Commit } from "./types";

const headers = {
  headers: {
    "PRIVATE-TOKEN": GIT_REPOSITORY_TOKEN,
  },
};

const urlBase = `${SOFA_HOST}/api/v4`;

export const getGroups = async (page: number) => {
  const url = `${urlBase}/groups/${SOFA_NAMESPACE_ID}/descendant_groups?page=${page}`;
  const { data: groups } = await axios.get<Group[]>(url, headers);
  return groups;
};

export const searchGroup = async (name: string) => {
  const url = `${urlBase}/groups?search=${name}`;
  const { data: groups } = await axios.get<Group[]>(url, headers);
  return groups;
};

export const createGroup = async (name: string, description: string) => {
  const url = `${urlBase}/groups`;
  const body = {
    name,
    path: name,
    parent_id: SOFA_NAMESPACE_ID,
    description,
    emails_enabled: false,
    visibility: "private",
  };

  const { data: group } = await axios.post<Group>(url, body, headers);
  return group;
};

export const deleteGroup = async (groupId: number, fullPath?: string) => {
  let url = `${urlBase}/groups/${groupId}`;
  if (fullPath) {
    url += `?permanently_remove=true&full_path=${fullPath}`;
  }

  await axios.delete(url, headers);
};

export const getGroup = async (groupId: number) => {
  const url = `${urlBase}/groups/${groupId}`;
  const { data: group } = await axios.get<Group>(url, headers);
  return group;
};

export const getProjects = async (repositoryGroupId: number) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/projects?simple=no`;
  const { data: projects } = await axios.get<Repository[]>(url, headers);
  return projects;
};

export const createProject = async (name: string, namespaceId: number, importUrl?: string) => {
  const url = `${urlBase}/projects`;
  const body: Record<string, string | number> = {
    name,
    namespace_id: namespaceId,
  };
  if (importUrl) {
    body.import_url = importUrl;
  }

  const { data: project } = await axios.post<Repository>(url, body, headers);
  return project;
};

export const updateProject = async (repositoryId: number, name: string) => {
  const url = `${urlBase}/projects/${repositoryId}`;
  const body = {
    name,
  };
  await axios.put(url, body, headers);
};

export const getUser = async (email: string) => {
  const possibleUsername = email.split("@")[0];
  const url = `${urlBase}/users?username=${possibleUsername}`;
  const { data: users } = await axios.get<User[]>(url, headers);
  return users.find(
    ({ username }) => username.toLocaleLowerCase() === possibleUsername.toLocaleLowerCase(),
  );
};

export const getMembers = async (repositoryGroupId: number) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/members/all`;
  const { data: members } = await axios.get<Member[]>(url, headers);
  return members;
};

export const addMember = async (repositoryGroupId: number, userId: number, accessLevel: number) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/members`;
  const body = {
    user_id: userId,
    access_level: accessLevel,
  };
  await axios.post(url, body, headers);
};

export const updateMember = async (
  repositoryGroupId: number,
  userId: number,
  accessLevel: number,
) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/members/${userId}`;
  const body = {
    access_level: accessLevel,
  };
  await axios.put(url, body, headers);
};

export const removeMember = async (repositoryGroupId: number, userId: number) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/members/${userId}`;
  await axios.delete(url, headers);
};

export const getInvitations = async (repositoryGroupId: number) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/invitations`;
  const { data: invitations } = await axios.get<Invitation[]>(url, headers);
  return invitations;
};

export const sendInvitation = async (
  repositoryGroupId: number,
  accessLevel: number,
  email: string,
) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/invitations`;
  const body: Record<string, string | number> = {
    access_level: accessLevel,
    email,
  };

  await axios.post(url, body, headers);
};

export const updateInvitation = async (
  repositoryGroupId: number,
  accessLevel: number,
  email: string,
) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/invitations/${email}`;
  const body: Record<string, string | number> = {
    access_level: accessLevel,
  };

  await axios.put(url, body, headers);
};

export const removeInvitation = async (repositoryGroupId: number, email: string) => {
  const url = `${urlBase}/groups/${repositoryGroupId}/invitations/${email}`;
  await axios.delete(url, headers);
};

export const getCommits = async (repositoryId: number) => {
  const url = `${urlBase}/projects/${repositoryId}/repository/commits`;
  const { data: commits } = await axios.get<Commit[]>(url, headers);
  return commits;
};

// all spaces and underscores are replaced by dashes, then multiple dashes are replaced by a single one, then remove trailing dash
export const formatName = (name: string) =>
  name.toLowerCase().replace(/[ _]/g, "-").replace(/-+/g, "-").replace(/-$/, ""); // NOSONAR - it wants to use replaceAll but that doesn't work with replacing multiple dashes by a single one for example
