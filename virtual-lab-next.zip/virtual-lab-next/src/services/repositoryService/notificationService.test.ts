import { jest } from "@jest/globals";
import NotificationService from "./notificationService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("repository service NotificationService", () => {
  it("sendInvitationEmail works", async () => {
    await NotificationService.sendInvitationEmail(ctx, "project name", "url", [userEmail]);
  });
});
