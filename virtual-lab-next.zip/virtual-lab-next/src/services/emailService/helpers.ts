export const transformText = (template: string, data: Record<string, string | number | string[]>) =>
  Object.entries(data ?? {}).reduce(
    (acc, [key, value]) =>
      acc
        .replaceAll(`{{${key}}}`, `${value.toString()}`)
        .replaceAll(`$\{${key}}`, `${value.toString()}`),
    template,
  );
