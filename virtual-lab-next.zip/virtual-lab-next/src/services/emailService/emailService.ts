import {
  FLOWMAILER_ACCOUNT_ID,
  FLOWMAILER_CLIENT_ID,
  FLOWMAILER_CLIENT_SECRET,
  FLOWMAILER_EMAIL_REPLY_TO,
  FLOWMAILER_EMAIL_SENDER,
  FLOWMAILER_SMTP_PASS,
  FLOWMAILER_SMTP_USER,
} from "../../utils/config";
import Flowmailer from "./flowmailer";

const EmailService = new Flowmailer({
  clientId: FLOWMAILER_CLIENT_ID,
  clientSecret: FLOWMAILER_CLIENT_SECRET,
  accountId: +FLOWMAILER_ACCOUNT_ID,
  transport: {
    host: "smtp.flowmailer.net",
    auth: {
      user: FLOWMAILER_SMTP_USER,
      pass: FLOWMAILER_SMTP_PASS,
    },
  },
  from: FLOWMAILER_EMAIL_SENDER,
  replyTo: FLOWMAILER_EMAIL_REPLY_TO,
});

export default EmailService;
