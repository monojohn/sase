import SMTPTransport from "nodemailer/lib/smtp-transport";

export type FlowmailerConfig = Partial<Request> & {
  clientId: string;
  clientSecret: string;
};

export type FlowmailerAuthResponse = {
  token: string;
};

export type FlowmailerProps = {
  from: string;
  replyTo: string;
};

export type FlowmailerConstructorProps = FlowmailerProps & {
  clientId: string;
  accountId: number;
  clientSecret: string;
  transport: SMTPTransport.Options;
  defaults?: SMTPTransport.Options;
};

export type FlowmailerToken = {
  access_token: string;
  token_type: "bearer";
  expires_at: number;
  expires_in: number; // starts at 60s
  scope: "api";
};

export type FlowmailerTemplateResponse = {
  id: string;
  data: string;
  mimeType: string;
  description: string;
  templateEngine: string;
};

export type SuccessEmail = {
  headline: string;
  projectName: string;
};

export type CtaTemplateData = SuccessEmail & {
  ctaUrl: string;
  ctaLabel: string;
};

export type InfoEmail = Omit<SuccessEmail, "headline"> & {
  preHeadline: string;
};

export type InfoEmailWithCta = CtaTemplateData & InfoEmail;
export type SuccessEmailWithCta = SuccessEmail & CtaTemplateData;

export type ErrorEmail = SuccessEmail & {
  headline: string;
  projectId: string;
  actionName: string;
  time: string;
  userEmail: string;
};

export type InformationWithMessageEmail = {
  projectName: string;
  preHeadline: string;
  postHeadline: string;
  senderName: string;
  message: string;
};
