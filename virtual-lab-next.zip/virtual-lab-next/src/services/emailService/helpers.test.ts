import { transformText } from "./helpers";

describe("helpers", () => {
  describe("transformText", () => {
    it("Should replace keys wrapped in {{}}", () => {
      const needle = "needle1";
      const template = "pre text {{needle}} post text {{needle}}";
      const data = {
        needle,
      };

      expect(transformText(template, data)).toEqual(`pre text ${needle} post text ${needle}`);
    });

    it("Should replace keys wrapped in ${}", () => {
      const needle = "needle2";
      // eslint-disable-next-line no-template-curly-in-string
      const template = "pre text ${needle} post text ${needle}";
      const data = {
        needle,
      };

      expect(transformText(template, data)).toEqual(`pre text ${needle} post text ${needle}`);
    });
  });
});
