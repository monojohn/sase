import { Context } from "@azure/functions";
import fetch from "cross-fetch";
import * as nodemailer from "nodemailer";
import type { Options } from "nodemailer/lib/mailer";
import SMTPTransport from "nodemailer/lib/smtp-transport";
import { ENV, IS_PROD } from "../../utils/config";
import SlackService from "../slackService";
import { transformText } from "./helpers";
import {
  ErrorEmail,
  FlowmailerConstructorProps,
  FlowmailerProps,
  FlowmailerTemplateResponse,
  FlowmailerToken,
  InfoEmail,
  InfoEmailWithCta,
  InformationWithMessageEmail,
  SuccessEmail,
  SuccessEmailWithCta,
} from "./types";

// eslint-disable-next-line @typescript-eslint/naming-convention
export const TEMPLATE_ID = {
  ERROR: IS_PROD ? 151884 : 59751,
  INFO: IS_PROD ? 151888 : 59943,
  INFO_CTA: IS_PROD ? 151890 : 59869,
  SUCCESS: IS_PROD ? 151904 : 59805,
  SUCCESS_CTA: IS_PROD ? 151882 : 59819,
  SUCCESS_CTA_LEFT_ALIGN: IS_PROD ? 151906 : 64923,
  INFORMATION_WITH_MESSAGE: IS_PROD ? 151892 : 67455,
  INFORMATION_WITH_MESSAGE_CTA: IS_PROD ? 151894 : 67695,
  INFORMATION_NO_PROJECT_NAME: IS_PROD ? 151896 : 91175,
  PROJECT_WITHOUT_USERS: IS_PROD ? 151902 : 115467,
  FILE_DELETION: IS_PROD ? 151886 : 68182,
  ML_COMPUTE_DELETION: IS_PROD ? 151898 : 95116,
  ML_COMPUTE_RECREATION_REMINDER: IS_PROD ? 151900 : 113702,
};

export type MailOptions = Options & {
  bcc: string | string[];
  subject: string;
  templateData: Record<string, string | string[] | number>;
  priority?: "high" | "normal" | "low";
};

export type InfoMailOptions = MailOptions & {
  templateData: InfoEmail;
};

export type InfoCtaMailOptions = MailOptions & {
  templateData: InfoEmailWithCta;
};

export type SimpleMailOptions = MailOptions & {
  templateData: {
    headline: string;
    ctaLabel: string;
    ctaUrl: string;
  };
};

export type SuccessMailOptions = MailOptions & {
  templateData: SuccessEmail;
};

export type SuccessCtaMailOptions = MailOptions & {
  templateData: SuccessEmailWithCta;
};

export type ErrorMailOptions = MailOptions & {
  templateData: ErrorEmail;
};

export type InformationWithMessageMailOptions = MailOptions & {
  templateData: InformationWithMessageEmail;
};

class Flowmailer {
  private readonly accountId: number;
  private readonly clientId: string;
  private readonly clientSecret: string;
  private fetchTokenPromise: Promise<FlowmailerToken> | null = null;
  private token?: FlowmailerToken;
  // sonar complains it should be readonly because it's not reassigned but we do that in our tests
  private transport: nodemailer.Transporter<SMTPTransport.SentMessageInfo>; // NOSONAR
  private readonly config: FlowmailerProps;

  constructor(props: FlowmailerConstructorProps) {
    this.clientId = props.clientId;
    this.accountId = props.accountId;
    this.clientSecret = props.clientSecret;

    this.transport = nodemailer.createTransport(
      { ...props.transport, secure: true },
      props.defaults,
    );

    this.config = {
      from: props.from,
      replyTo: props.replyTo,
    };
  }

  public async getTemplateById(id: number) {
    const response = await fetch(`https://api.flowmailer.net/${this.accountId}/templates/${id}`, {
      headers: {
        Authorization: `Bearer ${await this.getToken()}`,
      },
    });

    if (response.status !== 200) {
      throw new Error(
        `Failed to fetch template "${id}": ${response.status}: ${response.statusText}`,
      );
    }

    const template = (await response.json()) as FlowmailerTemplateResponse;
    return template.data;
  }

  public async sendEmail(ctx: Context, templateId: number, opt: MailOptions) {
    const options = { ...opt };

    // prevent errors when no recipients are defined
    if (!options.bcc || options.bcc.length < 1) {
      const message = `No recipients defined for email with subject '${options.subject}'`;
      ctx.log(message);
      return SlackService.logWarning(ctx, new Error(message));
    }

    try {
      if (templateId && options.templateData) {
        options.html = transformText(await this.getTemplateById(templateId), options.templateData);
      }

      if (options.templateData) {
        options.subject = transformText(options.subject, options.templateData);
      }

      if (!IS_PROD) {
        // Let's add [DEV]: or [STG]: prefix to the subject for all emails coming from DEV env for easier lookup in mail inbox
        options.subject = `[${ENV.toUpperCase()}]: ${options.subject}`;
      }

      return await this.transport.sendMail({ ...this.config, ...options });
    } catch (e) {
      const message = "Email sending failed";
      ctx.log(message, e);
      return SlackService.logWarning(ctx, new Error(message));
    }
  }

  public async sendInfoEmail(ctx: Context, options: InfoMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.INFO, options);
  }

  public async sendInfoCtaEmail(ctx: Context, options: InfoCtaMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.INFO_CTA, options);
  }

  public async sendSuccessEmail(ctx: Context, options: SuccessMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.SUCCESS, options);
  }

  public async sendSuccessCtaEmail(ctx: Context, options: SuccessCtaMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.SUCCESS_CTA, options);
  }

  public async sendSimpleEmail(ctx: Context, options: SimpleMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.INFORMATION_NO_PROJECT_NAME, options);
  }

  public async sendSuccessCtaLeftAlignEmail(ctx: Context, options: SuccessCtaMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.SUCCESS_CTA_LEFT_ALIGN, options);
  }

  public async sendErrorEmail(ctx: Context, options: ErrorMailOptions) {
    return this.sendEmail(ctx, TEMPLATE_ID.ERROR, options);
  }

  public async sendInformationWithMessageEmail(
    ctx: Context,
    options: InformationWithMessageMailOptions,
  ) {
    return this.sendEmail(ctx, TEMPLATE_ID.INFORMATION_WITH_MESSAGE, options);
  }

  public async getToken(force = false) {
    // +3000 to pretend we're 3s in the future
    // to account for server time discrepancies
    const now = Date.now() + 3000;

    // ensure token exists and is not too close to expiration
    if (!force && this.token && this.token.expires_at > now) {
      return this.token.access_token;
    }

    this.fetchTokenPromise ??= this.fetchToken();

    // wait for fetch
    await this.fetchTokenPromise;

    // nullify promise for next run
    this.fetchTokenPromise = null;

    // return access token
    return this.token!.access_token;
  }

  private async fetchToken() {
    const body = new URLSearchParams();
    body.append("client_id", this.clientId);
    body.append("client_secret", this.clientSecret);
    body.append("grant_type", "client_credentials");

    const response = await fetch(`https://login.flowmailer.net/oauth/token`, {
      method: "POST",
      body,
    });

    if (response.status === 200) {
      this.token = (await response.json()) as FlowmailerToken;
      this.token.expires_at = Date.now() + this.token.expires_in * 1000;
    } else {
      throw new Error(
        `Flowmailer: Failed to fetch API token with status "${response?.status}: ${response.statusText}"`,
      );
    }
    return this.token;
  }
}

export default Flowmailer;
