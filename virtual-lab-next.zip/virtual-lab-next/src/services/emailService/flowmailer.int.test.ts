import { jest } from "@jest/globals";
import {
  FLOWMAILER_ACCOUNT_ID,
  FLOWMAILER_CLIENT_ID,
  FLOWMAILER_CLIENT_SECRET,
  FLOWMAILER_EMAIL_REPLY_TO,
  FLOWMAILER_EMAIL_SENDER,
  FLOWMAILER_SMTP_PASS,
  FLOWMAILER_SMTP_USER,
} from "../../utils/config";
import Flowmailer, { MailOptions, TEMPLATE_ID } from "./flowmailer";
import { FlowmailerConstructorProps } from "./types";

const { TEST_EMAIL = "" } = process.env;

const ctx = {
  log: jest.fn(),
} as any;

const credentials: FlowmailerConstructorProps = {
  accountId: +FLOWMAILER_ACCOUNT_ID,
  clientId: FLOWMAILER_CLIENT_ID,
  clientSecret: FLOWMAILER_CLIENT_SECRET,
  transport: {
    host: "smtp.flowmailer.net",
    auth: {
      user: FLOWMAILER_SMTP_USER,
      pass: FLOWMAILER_SMTP_PASS,
    },
  },
  from: FLOWMAILER_EMAIL_SENDER,
  replyTo: FLOWMAILER_EMAIL_REPLY_TO,
};

describe("Flowmailer", () => {
  describe("getToken", () => {
    it("Fetches token", async () => {
      const transport = new Flowmailer(credentials);
      const token = await transport.getToken();
      expect(token?.length).toBeGreaterThan(5);
    });

    it("Re-uses token when needed", async () => {
      const transport = new Flowmailer(credentials);

      const token1 = await transport.getToken();
      const token2 = await transport.getToken();

      expect(token1).toBe(token2);
    });

    it("Forcefully gets new token", async () => {
      const transport = new Flowmailer(credentials);

      const token1 = await transport.getToken();
      const token2 = await transport.getToken(true);

      expect(token1).not.toBe(token2);
    });

    it("Fetches new token after timeout", async () => {
      const transport = new Flowmailer(credentials);

      // get token
      const token1 = await transport.getToken();

      // eslint-disable-next-line @typescript-eslint/dot-notation
      if (transport["token"] === undefined) {
        throw new Error(`Transport is not defined`);
      }

      // eslint-disable-next-line @typescript-eslint/dot-notation -- expire token
      transport["token"].expires_at = Date.now();

      // refetch token
      const token2 = await transport.getToken();

      expect(token1).not.toBe(token2);
    });
  });

  describe("sendMail", () => {
    it("Updates subject when data is available", async () => {
      let output: MailOptions = {} as any;
      const sendMail: any = (data: MailOptions) => {
        output = data;
      };

      const EmailerService = new Flowmailer(credentials);

      // eslint-disable-next-line object-shorthand,@typescript-eslint/dot-notation -- overwride value
      EmailerService["transport"] = { sendMail } as any;

      const templateData = { exampleField: "exampleValue" };

      await EmailerService.sendEmail(ctx, TEMPLATE_ID.INFO_CTA, {
        bcc: "bcc",
        subject: "Subject with {{exampleField}}",
        templateData,
      });

      expect(output.subject).toBe("[DEV]: Subject with exampleValue");
    });

    test("sendInfoEmail", async () => {
      const EmailerService = new Flowmailer(credentials);

      await EmailerService.sendInfoEmail(ctx, {
        bcc: TEST_EMAIL,
        subject: "info email unit test",
        templateData: {
          preHeadline: "pre headline",
          projectName: "unit test",
        },
      });
    });

    test("sendInfoCtaEmail", async () => {
      const EmailerService = new Flowmailer(credentials);

      await EmailerService.sendInfoCtaEmail(ctx, {
        bcc: TEST_EMAIL,
        subject: "info CTA email unit test",
        templateData: {
          preHeadline: "pre headline",
          projectName: "unit test",
          ctaLabel: "label",
          ctaUrl: "url",
          headline: "headline",
        },
      });
    });

    test("sendSuccessEmail", async () => {
      const EmailerService = new Flowmailer(credentials);

      await EmailerService.sendSuccessEmail(ctx, {
        bcc: TEST_EMAIL,
        subject: "Success email unit test",
        templateData: {
          projectName: "unit test",
          headline: "headline",
        },
      });
    });
    test("sendSuccessCtaEmail", async () => {
      const EmailerService = new Flowmailer(credentials);

      await EmailerService.sendSuccessCtaEmail(ctx, {
        bcc: TEST_EMAIL,
        subject: "Success CTA email unit test",
        templateData: {
          projectName: "unit test",
          headline: "headline",
          ctaLabel: "label",
          ctaUrl: "url",
        },
      });
    });
    test("sendErrorEmail", async () => {
      const EmailerService = new Flowmailer(credentials);

      await EmailerService.sendErrorEmail(ctx, {
        bcc: TEST_EMAIL,
        subject: "Error email unit test",
        templateData: {
          projectName: "unit test",
          headline: "headline",
          actionName: "unit test action",
          projectId: "mock id",
          time: "now-ish",
          userEmail: TEST_EMAIL,
        },
      });
    });
  });
});
