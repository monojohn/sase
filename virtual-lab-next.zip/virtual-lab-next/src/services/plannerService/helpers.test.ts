import { teamsTabBody } from "./helpers";

describe("Planner Service Helpers", () => {
  describe("teamsTabBody", () => {
    it("Creates the body", () => {
      expect(() => {
        teamsTabBody("", "");
      }).not.toThrow();
    });
  });
});
