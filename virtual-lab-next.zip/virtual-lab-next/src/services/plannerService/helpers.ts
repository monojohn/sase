import { Context } from "@azure/functions";
import GraphClient from "../../utils/graphClient";
import { CreatePlannerResponse } from "./types";
import SlackService from "../slackService";

/**
 * Creation of the body for the Microsoft Teams 'Planner' tab
 *
 * @param {string} channelId Channel Id
 * @param {string} plannerId PlannerId
 */
export const teamsTabBody = (channelId: string, plannerId: string) => ({
  displayName: "Planner",
  "teamsApp@odata.bind":
    "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps/com.microsoft.teamspace.tab.planner",
  configuration: {
    entityId: `tt.c_${channelId}_p_${plannerId}`,
    contentUrl: `https://tasks.teams.microsoft.com/teamsui/{tid}/Home/PlannerFrame?page=7&auth_pvr=OrgId&auth_upn={userPrincipalName}&groupId={groupId}&planId=${plannerId}&channelId={channelId}&entityId={entityId}&tid={tid}&userObjectId={userObjectId}&subEntityId={subEntityId}&sessionId={sessionId}&theme={theme}&mkt={locale}&ringId={ringId}&PlannerRouteHint={tid}&tabVersion=20200228.1_s`,
  },
});

export const createTeamsTab = async (
  ctx: Context,
  groupId: string,
  channelId: string,
  plannerId: string,
) => {
  ctx.log(`Creating Teams tab`);

  const client = await GraphClient.get(ctx);
  const plannerTabUri = `teams/${groupId}/channels/${channelId}/tabs?$expand=teamsApp`;
  try {
    (await client
      .api(plannerTabUri)
      .post(JSON.stringify(teamsTabBody(channelId, plannerId)))) as Promise<CreatePlannerResponse>;
  } catch (err) {
    ctx.log(err, "Microsoft Teams planner tab failed to create");
    await SlackService.logWarning(
      ctx,
      new Error(`Failed to create planner tab in Teams but continuing creation`),
    );
  }
};
