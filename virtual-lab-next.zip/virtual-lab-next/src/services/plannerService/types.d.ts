export type CreatePlannerResponse = {
  id: string;
};

export type GetPlannerResponse = {
  id: string;
};

type UserDetails = {
  user: {
    id: string;
  };
};

export type TaskResponse = {
  id: string;
  planId: string;
  title: string;
  createdDateTime: string;
  completedDateTime: string;
  dueDateTime: string;
  percentComplete: number;
  createdBy: UserDetails;
  assignments: {
    [id: string]: {
      assignedBy?: UserDetails;
      assignedDateTime: string;
    };
  };
};
