import { Context } from "@azure/functions";
import { createTeamsTab } from "./helpers";
import { CreatePlannerResponse, GetPlannerResponse, TaskResponse } from "./types";
import GraphClient from "../../utils/graphClient";

const PlannerService = {
  async createPlanner(ctx: Context, groupId: string, title: string, channelId: string) {
    const client = await GraphClient.get(ctx);
    const body = {
      owner: groupId,
      title,
    };
    const value = (await client.api(`/planner/plans`).post(body)) as CreatePlannerResponse;
    await createTeamsTab(ctx, groupId, channelId, value.id);
    return value;
  },

  async getPlanners(ctx: Context, groupId: string) {
    const client = await GraphClient.get(ctx);
    const { value: planners } = (await client.api(`/groups/${groupId}/planner/plans`).get()) as {
      value: GetPlannerResponse[];
    };
    return planners;
  },

  async getTasks(ctx: Context, id: string) {
    const client = await GraphClient.get(ctx);
    const { value: tasks } = (await client.api(`/planner/plans/${id}/tasks`).get()) as {
      value: TaskResponse[];
    };
    return tasks;
  },

  async getAllPlannerTasks(ctx: Context, teamGroupId: string) {
    const planners: GetPlannerResponse[] = await PlannerService.getPlanners(ctx, teamGroupId);
    const promises: Promise<TaskResponse[]>[] = [];
    for (const { id } of planners) {
      promises.push(PlannerService.getTasks(ctx, id));
    }

    return Promise.all(promises);
  },
};

export default PlannerService;
