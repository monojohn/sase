export type Team = {
  webUrl: string;
};

export type Metrics = {
  replyMessages: { value: number };
  postMessages: { value: number };
  meetingsOrganized: { value: number };
  channelMessages: { value: number };
  reactions: { value: number };
  mentions: { value: number };
};

export type MetricsDetails = {
  teams: {
    id: string;
    metrics: Metrics;
  };
};

export type ReportEntry = {
  "Report Refresh Date": string; //  '2025-05-04'
  "Team Id": string; // '2d33fd79-9af2-4517-87b9-153b2f1ac412'
  "Team Name": string; // 'Demo Bidirectional sync'
  "Last Activity Date": string; // '2024-10-29'
  "Team Type": string; // 'Private'
  "Is Deleted": string; // 'False'
  "Report Period": string; // '90'
  "Active Users": string; // '0'
  "Active Channels": string; // '0'
  "Channel Messages": string; // '0'
  Reactions: string; // '0'
  "Meetings Organized": string; // '0'
  "Post Messages": string; // '0'
  "Reply Messages": string; // '0'
  "Urgent Messages": string; // '0'
  Mentions: string; // '0'
  Guests: string; // '0'
  "Active Shared Channels": string; // '0'
  "Active External Users": string; // '0'
};

export type TeamTabsResponse = {
  value: {
    id: string;
  }[];
};
