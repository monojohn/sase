import { Context } from "@azure/functions";
import GraphClient from "../../utils/graphClient";
import { ReportEntry, Team, TeamTabsResponse } from "./types";

const TeamsService = {
  async getChannelId(ctx: Context, teamId: string) {
    ctx.log(`Querying for ${teamId}`);
    try {
      const client = await GraphClient.get(ctx);
      const { value } = (await client.api(`/teams/${teamId}/channels`).get()) as TeamTabsResponse;
      return value[0]?.id;
    } catch (e) {
      ctx.log(`Error querying for ${teamId}`, e);
      throw e;
    }
  },

  async getChannelCount(ctx: Context, teamId: string) {
    try {
      const client = await GraphClient.get(ctx);
      const { value } = (await client.api(`/teams/${teamId}/channels`).get()) as TeamTabsResponse;
      return value.length;
    } catch (e) {
      ctx.log(`Error querying for ${teamId}`, e);
      throw e;
    }
  },

  async getTeam(ctx: Context, teamId: string) {
    const client = await GraphClient.get(ctx);
    return client.api(`/teams/${teamId}`).get() as Promise<Team>;
  },

  /**
   * get report from Teams activity for all teams for the provided period
   * @param ctx context
   * @param period can be 30 or 90 days
   * @returns ReportEntry[]
   */
  async getReport(ctx: Context, period: number) {
    const timePeriod: string = period === 30 ? "D30" : "D90";
    const client = await GraphClient.get(ctx);
    const data = (await client
      .api(`/reports/getTeamsTeamActivityDetail(period='${timePeriod}')`)
      .header("Accept", "text/csv")
      .get()) as ReadableStream;
    const stream = data;
    const reader = stream.getReader();
    const decoder = new TextDecoder("utf-8");

    // read stream
    let csvText = "";
    let done = false;
    while (!done) {
      const result: ReadableStreamReadResult<Uint8Array> = await reader.read();
      const { value, done: readerDone } = result;
      if (value) {
        csvText += decoder.decode(value, { stream: !readerDone });
      }
      done = readerDone;
    }

    // build object from csv
    const [header, ...rows] = csvText.split("\r\n");
    const columnNames = header.split(",");
    return rows.map((row) => {
      const values = row.split(",");
      const entry: { [key: string]: string } = {};

      for (const [index, column] of columnNames.entries()) {
        entry[column] = values[index];
      }
      return entry as ReportEntry;
    });
  },

  isTeamActive(report: ReportEntry[], teamId: string) {
    const teamReport = report.find((entry) => entry["Team Id"] === teamId);
    if (!teamReport) {
      return false;
    }

    return Number(teamReport["Active Channels"]) > 0;
  },
};

export default TeamsService;
