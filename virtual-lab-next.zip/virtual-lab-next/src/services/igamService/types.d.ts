import type { RolesAndEntitlements } from "../dbConnector/models/project";
import type { GraphUser } from "../graphService/types";
import { ApprovalModel, IgamRequestStatus } from "./enums";

export type OrgDeputy = {
  userLogin: string; // "T01-ENGDIV2";
  firstName: string; // "Dirk";
  lastName: string; // "EngDiv2Manager";
  id: string; // "1015";
  email: string; // "Dirk@ecb.europa.eu";
  employeeNumber: string; // "TST202-01";
};

export type Org = {
  orgName: string; // "Testing org(CI-Virtual-Lab)";
  manager: {
    userLogin: string; // "T01-ENGMANA",
    firstName: string; // "Mary",
    lastName: string; // "EngManager",
    id: string; // "1007",
    email: string; // "t01-engmana@ecb.europa.eu",
    employeeNumber: string; // "TST200-01"
  };
  deputies: OrgDeputy[];
  id: string; // "867"
  parentOrgName: string;
};

export type IgamToken = {
  access_token: string; // "eyJraWQiOiJJR0FNLUFQSSIsIng1dCI6InQyR1QwUFg4VXhYQml0ZTJLNUtrblRxN2tDWSIsImFsZyI6IlJTMjU2In0.eyJpc3MiOiJodHRwczovL2QtaWdhbS50YWRuZXQuZXU6NDQzL29hdXRoMiIsImF1ZCI6WyJJR0FNLUlNIiwiaHR0cHM6Ly9kLWlnYW0udGFkbmV0LmV1OjQ0My9vYXV0aDIiXSwiZXhwIjoxNjY4NTM3MTQ0LCJqdGkiOiJlaWRlX2FiYnA2elN1M0o5MzZ0N0N3IiwiaWF0IjoxNjY4NTMzNTQ0LCJzdWIiOiJkMDEtYnVsa29wcy1ydW50aW1lIiwiY2xpZW50IjoiZDAxLWJ1bGtvcHMtcnVudGltZSIsInNjb3BlIjpbIklHQU0tSU0uYWRtaW4iXSwiZG9tYWluIjoiSUdBTS1BUEkiLCJncm91cHMiOlsiRUNCVEVTVC1QU08tUHJpdmlsZWdlZC1BY2NvdW50Il0sIkFwcF9BY3RpdmVDbGllbnQiOiJ0cnVlIiwiZGlzcGxheW5hbWUiOiJPcGVyYXRpb25zIEFkbWluaXN0cmF0b3IiLCJBcHBfQWN0aXZlIjoidHJ1ZSIsInNlc3Npb25pZCI6IjlmYjdlNTkzNTlmYTc4MzVlMmNkODExYTQxYWQ2Mjc2NmQ0YzgxMDM0ZmU5OWJjNmM4Njk5ZTMxOTM1NzMzOWMiLCJBcHBfU3RhdHVzIjoidHJ1ZSJ9.iuFCFl-xrgrTmCpuaLr59l6tURxvAexH40Tl9X97ndrtqMEKul6gK5IDtRmN-BZvYxnzsNjjT-MBEjF990nC73SYaQR3PE8SPW3u067FKYTjfBmAna-FlKzgD-KRdLJYfTbc4Soum0ZePOIyWUEtIK1qyIErbqoYLHi9wWcIYXXtglxvrdyxHnDg0ilLTGQK96U0Gt4VKxOUTgUfJ2S7IwpSxwsw5zI3-bQVJlcujZ81aJcMjqA6f7ByOIf5_C9h5uSAZoLQzZ12rt764tn_vUZ2tUQNhCDyZnev4504-lo3uW1vt8xYtjqi6HOeAwqLQEDZYMgG7xpMC0WlPvRFAQ";
  token_type: "Bearer";
  expires_in: 3600;
  scope: "IGAM.ENTITLEMENT.READ IGAM.ENTITLEMENT.WRITE IGAM.ORG.READ IGAM.ORG.WRITE";
};

export type IgamMUserActions = "add" | "remove";
export type AddIgamUser = {
  action: IgamMUserActions;
  accountName: string;
  request?: boolean;
  justification?: string;
};

export type IgamGroupStatus = "RUNNING" | "ERROR";
export type EntitlementMember = {
  userLogin: string; // i.e. 'JDOE';
  firstName: string; // i.e. 'John';
  lastName: string; // i.e. 'Doe';
  id: string; // i.e. '33086';
  email: string; // i.e. 'john.doe@ecb.europa.eu';
  employeeNumber: string; // i.e. '123651'
};

export type PermalinkResponse = {
  entitlements: {
    apiRequestId: string; // "56009";
    stacktrace: string;
    status: "READY" | "ERROR";
  }[];
};

export type UserEntitlement = {
  owner: string; //  "CI11656";
  entCode: string; // "21~A-Darwin";
  displayName: string; // "A-Darwin";
  members: EntitlementMember[]; // [Array];
  criticality: string; //  "Low";
  description: string; //  "Application Group - Darwin Users";
  id: string; // "2375";
  requestable: boolean;
  accountName: string; // <=== upn
};

type RoleMember = {
  userLogin: string; // 'SANTOSI',
  firstName: string; // 'Martinho',
  lastName: string; // 'Santos',
  id: string; // '1141015',
  email: string; // 'Martinho.Santos.external@ecb.europa.eu',
  employeeNumber: string; // '124958'
};

type RoleEntitlement = {
  ntCode: string; // '102~759b3d65-ff4a-4072-9b3e-482f21087b62',
  displayName: string; // 'ECBPROD-DSS-USG-SEC-CA-P-Consultants',
  id: string; // '71830'
};

export type Role = {
  entitlements: RoleEntitlement[];
  displayName: string; // 'DGE/FIP (50000036) Delegated Approvers',
  members: RoleMember[];
  roleName: string; // '50000036 Delegated Approvers',
  description: string; // 'This role grants the ability to act on behalf of the management of DGE/FIP for all IGAM tasks. This includes e.g. approving IGAM requests, reporting on team access and reporting on membership of roles owned by DGE/FIP.',
  id: string; // '18893'
};

export type IgamUser = {
  entitlements: UserEntitlement[]; // [Array],
  FirstName: string; // 'Martinho',
  roles: Role[]; // [],
  EmployeeNumber: string; // '124958',
  id: string; // '1141015',
  LastName: string; // 'Santos',
  UserLogin: string; // 'SANTOSI'
};

export type Entitlement = {
  id: string; // i.e. "1"
  appInstance: "AADproduction";
  entType: "AAD-Team";
  owner: string; // name of org
  entCode: string; // i.e. '03be707e-eb9e-4b2b-a9ac-1cfe68232f96';
  approvalModel: string; // '3'
  displayName: string; // i.e. 'group-name';
  members: EntitlementMember[];
  criticality: "Low";
  description: string;
  requestable: true;
  requestableBy: string;
  // only present on error
  stacktrace?: string;

  // only present when status is RUNNING or ERROR
  apiRequestId?: string; // i.e. '1614';

  status?: IgamGroupStatus;
};

export type IgamGroupResponse = {
  entitlements?: Entitlement[];
  nextPageURL?: string; // present when there are > 100 results
};

export type IgamRequestResponse = {
  id: string;
  status: IgamRequestStatus;
};

export type CreateEntitlementsResponse = {
  requestId?: string;
  url: string;
};

export type UpdateEntitlementResponse = {
  requestId?: string;
  members?: [
    {
      requestId?: string;
    },
  ];
};

export type CreateEntitlementProps = {
  owner: string; // will be added to the owner field
  displayName: string;
  description: string;
  members: AddIgamUser[];
  entType: string;
  classification?: string;
  technicalOwner?: string;
  risk?: "5"; // 3 - low risk, 5 - medium risk, 7 - high risk -- also called criticallity
  approvalModel?: ApprovalModel;
  persistent?: boolean; // if true, it is excluded from recertification
  request?: boolean; // whether API request should be approved by ECB approval workflow or directly created
  justification?: string; // justification for API request displayed for approvers
};

export type EntitlementRequest = CreateEntitlementProps & {
  persistent: boolean;
};

export type MissingEntAndRoles = {
  upns: string[];
  projectName: string;
  missingRolesAndEntitlements: { [key: string]: RolesAndEntitlements[] };
  owners: Pick<GraphUser, "mail" | "userPrincipalName" | "otherMails" | "identities">[];
};
