import { jest } from "@jest/globals";
import { getOrgName } from "../../utils/helpers";
import OrgService from "./orgService";
import { genString, getCtx } from "../../../jest/helpers";

const managerUpn = process.env.TEST_USER_VIDMANTE ?? "";
const deputy = process.env.TEST_USER_ROBERTA ?? "";

jest.setTimeout(5 * 60 * 1000);
const ctx = getCtx({ name: "OrgService" });

describe("OrgService", () => {
  const orgName = getOrgName(`Test org ${Date.now()}`);

  it(`Creates an org with name ${orgName}`, async () => {
    // create org
    const org = await OrgService.create(ctx, {
      orgName,
      deputiesUpn: ["roberta.popescu.external@tadnet.eu"],
      // managerUpn,
    });

    // check it exists
    expect(org).not.toBe(undefined);
    expect(org.orgName).toContain(orgName);
  });

  it(`Creates an org with name over 50 chars`, async () => {
    const name = getOrgName(`UT org name length test ${genString(17)}`);
    // create org
    const org = await OrgService.create(ctx, {
      orgName: name,
      deputiesUpn: [],
      managerUpn,
    });

    // check it exists
    expect(org).not.toBe(undefined);
    expect(org.orgName).toContain(name);

    // cleanup
    await OrgService.delete(ctx, org.id);
  });

  it("Finds the org by name", async () => {
    const org = await OrgService.getOrgByName(ctx, orgName);
    expect(org).not.toBe(undefined);
    expect(org.orgName).toContain(orgName);
  });

  it("Searching for an unexisting org returns empty", async () => {
    const org = await OrgService.getOrgByName(ctx, `Fake org ${Date.now()}`);
    expect(org).toBe(undefined);
  });

  it("Updates the org", async () => {
    const org = await OrgService.getOrgByName(ctx, orgName);
    expect(org).not.toBe(undefined);

    await OrgService.addDeputies(ctx, org.id, [deputy]);
    const orgWithDeputy = await OrgService.getOrgByName(ctx, orgName);

    await OrgService.removeDeputies(ctx, org.id, [deputy]);
    const orgWithoutDeputy = await OrgService.getOrgByName(ctx, orgName);

    expect(orgWithDeputy.deputies.length).toBe(1);
    expect(orgWithoutDeputy.deputies.length).toBe(0);
  });

  it("Deletes the org", async () => {
    const org = await OrgService.getOrgByName(ctx, orgName);
    expect(org).not.toBe(undefined);

    const rsp = await OrgService.delete(ctx, org.id);
    expect(rsp).toBe(undefined);
  });

  it("Doesn't throw when deleteing an unexisting org", async () => {
    const rsp = await OrgService.deleteByName(ctx, `Fake org ${Date.now()}`);
    expect(rsp).toBe(undefined);
  });
});
