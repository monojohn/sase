import { Context } from "@azure/functions";
import { AxiosError } from "axios";
import {
  APP_INSTANCE,
  GROUP_ACCOUNT_TYPE,
  GROUP_SERVICE,
  VL_ORG,
  VL_TEAM_ORG,
} from "../../utils/config";
import { getMembersGroupName, getOwnersGroupName, getTeamGroupName } from "../../utils/helpers";
import { getInstance } from "./helpers";
import {
  CreateEntitlementProps,
  CreateEntitlementsResponse,
  Entitlement,
  EntitlementRequest,
  IgamGroupResponse,
  IgamUser,
  PermalinkResponse,
  UpdateEntitlementResponse,
} from "./types";
import { ApprovalModel } from "./enums";
import { ConfidentialityLevel } from "../dbConnector/enums";

// docs: https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Create+Entitlement
const fixedData = {
  appInstance: APP_INSTANCE,
  service: GROUP_SERVICE,
  approvalModel: ApprovalModel.OWNER_APPROVAL,
  risk: "5",
  requestable: false,
  accountType: GROUP_ACCOUNT_TYPE,
};

/**
 * Interacts with IGAM to CRUD entitlements
 *
 * Some info can be found here:
 * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Create+AD+Group
 */
const EntitlementsService = {
  async get(ctx: Context, id: string) {
    const ents: Entitlement[] = [];
    const instance = getInstance(ctx);
    let nextUrl = `/entitlements?filter=${encodeURIComponent(
      `appInstance eq ${APP_INSTANCE} and displayName eq "${id}"`,
    )}`;

    do {
      const {
        data: { entitlements = [], nextPageURL: url = "" },
      } = await instance.get<IgamGroupResponse>(nextUrl);

      if (entitlements.length > 0) {
        ents.push(...entitlements);
      }
      // eslint-disable-next-line prefer-destructuring -- not sure how to use destructuring here
      nextUrl = url.split("services")[1];
    } while (nextUrl);

    return ents;
  },

  async searchByName(ctx: Context, name: string) {
    const {
      data = {
        entitlements: [],
      },
    } = await getInstance(ctx).get<IgamGroupResponse>(
      `/entitlements?filter=${encodeURIComponent(
        `appInstance eq "AD ECB01" and displayName eq "${name}"`,
      )}`,
    );
    return data?.entitlements ?? [];
  },

  async getEntitlementsByPermalink(ctx: Context, url: string) {
    const { data } = await getInstance(ctx).get<PermalinkResponse>(url);
    return data;
  },

  async getEntitlementsId(ctx: Context, groupName: string): Promise<string | undefined> {
    const entitlements = await EntitlementsService.get(ctx, groupName);
    return entitlements?.[0]?.id;
  },

  async create(ctx: Context, data: CreateEntitlementProps) {
    // replace orgId with owner prop
    const props = { ...data, owner: data.owner };
    try {
      const rsp = await getInstance(ctx).post<CreateEntitlementsResponse>(`/create/entitlements`, {
        ...props,
        ...fixedData,
      });
      return rsp.data;
    } catch (err: unknown) {
      const error = err as AxiosError<{ errors: string[] }>;
      const prettyError = error?.response?.data?.errors?.join("\n");
      ctx.log(error.response?.data);
      ctx.log(prettyError);
      ctx.log(`Failed to create entitlements\n`, prettyError ?? err);
      throw prettyError ? new Error(prettyError) : err;
    }
  },

  async delete(ctx: Context, entitlementId: string) {
    return getInstance(ctx).delete<void>(`/delete/entitlements/${entitlementId}`);
  },

  /**
   * Allows updating entitlements
   * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Modify+Organisation
   *
   * @param id entitlement id to update
   */
  update(ctx: Context, id: string, props: Partial<EntitlementRequest>) {
    return getInstance(ctx).post<UpdateEntitlementResponse>(`/update/entitlements/${id}`, props);
  },

  async addUser(
    ctx: Context,
    groupNames: string[],
    accountName: string,
    request: boolean,
    justification?: string,
  ) {
    const entitlementIds = await Promise.all(
      groupNames.map((groupName) => EntitlementsService.getEntitlementsId(ctx, groupName)),
    );

    const responses = await Promise.all(
      entitlementIds.map((id) =>
        EntitlementsService.update(ctx, id!, {
          members: [{ action: "add", accountName, request, justification }],
        }),
      ),
    );
    return responses.map(({ data }) => data.members);
  },

  /**
   *
   * @param ctx
   * @param upn must be the UPN
   * @param entitlementId
   * @returns
   */
  async removeUser(ctx: Context, upn: string, entitlementId: string) {
    return EntitlementsService.update(ctx, entitlementId, {
      members: [{ action: "remove", accountName: upn }],
    });
  },

  /**
   * Fetches a user from IGAM
   *
   * @param ctx
   * @param upn MUST be the upn, oids don't work
   * @returns
   */
  async getUser(ctx: Context, upn: string) {
    const rsp = await getInstance(ctx).get<{
      users: IgamUser[];
    }>(
      `/users?filter=${encodeURIComponent(
        `appInstance eq ${APP_INSTANCE} and accountName eq ${upn}`,
      )}`,
    );
    return rsp.data?.users?.[0];
  },

  async getUserEntitlements(ctx: Context, upn: string) {
    const user = await EntitlementsService.getUser(ctx, upn);
    return user?.entitlements ?? [];
  },

  async getProjectEntitlements(ctx: Context, projectName: string) {
    const [team, owners, members] = await Promise.all([
      EntitlementsService.get(ctx, getTeamGroupName(projectName)),
      EntitlementsService.get(ctx, getOwnersGroupName(projectName)),
      EntitlementsService.get(ctx, getMembersGroupName(projectName)),
    ]);

    return {
      team: team.find((t) => t.displayName.includes(projectName)) ?? team[0],
      owners: owners.find((o) => o.displayName.includes(projectName)) ?? owners[0],
      members: members.find((m) => m.displayName.includes(projectName)) ?? members[0],
    };
  },

  async updateConfidentiality(
    ctx: Context,
    groupNames: string[],
    confidentiality: ConfidentialityLevel,
    request: boolean,
    justification?: string,
  ) {
    const entitlementIds = await Promise.all(
      groupNames.map((groupName) => EntitlementsService.getEntitlementsId(ctx, groupName)),
    );
    const responses = await Promise.all(
      entitlementIds.map((id) =>
        EntitlementsService.update(ctx, id!, {
          classification: confidentiality,
          justification,
          request,
        }),
      ),
    );
    return responses.map(({ data }) => data);
  },

  async updateOrg(
    ctx: Context,
    groupNames: string[],
    org: string,
    request: boolean,
    justification?: string,
  ) {
    const entitlementIds = await Promise.all(
      groupNames.map((groupName) => EntitlementsService.getEntitlementsId(ctx, groupName)),
    );
    const responses = await Promise.all(
      entitlementIds.map((id) =>
        EntitlementsService.update(ctx, id!, {
          owner: org,
          justification,
          request,
        }),
      ),
    );
    return responses.map(({ data }) => data);
  },

  /**
   * Check if project's org is VL or VL team
   *
   * @param ctx Context
   * @param groupName groupName
   * @returns boolean
   */
  async isProjectOrgVlOrg(ctx: Context, groupName: string) {
    const entitlement = await EntitlementsService.get(ctx, groupName);
    const { owner } = entitlement[0];
    return owner === VL_ORG || owner === VL_TEAM_ORG;
  },

  async getProjectOrg(ctx: Context, projectName: string) {
    const owners = await EntitlementsService.get(ctx, getTeamGroupName(projectName));

    return (owners.find((o) => o.displayName.includes(projectName)) ?? owners[0]).owner;
  },
};

export default EntitlementsService;
