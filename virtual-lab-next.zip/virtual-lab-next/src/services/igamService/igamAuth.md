# Below is all the info we received on how to use IGAM's OAuth2 system

## Sample Request:

```bash
curl --location --request POST 'https://igam.ecb.europa.eu/oauth2/rest/token/ECBOIDCDomainA2A' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=JWT_BEARER' \
--data-urlencode 'scope= IGAM.ENTITLEMENT.READ IGAM.ENTITLEMENT.WRITE IGAM.ORG.READ IGAM.ORG.WRITE' \
--data-urlencode 'client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer' \
--data-urlencode 'client_assertion=<ASSERTION_VALUE>' \
--data-urlencode 'assertion=<ASSERTION_VALUE>'
```

\<ASSERTION_VALUE> should be passed as encoded value. Decode value structure should be like:

## HEADER: ALGORITHM & TOKEN TYPE

```json
{
  "x5t": "<Base64-encoded SHA1 fingerprint of X.509 Certificate>",
  "typ": "JWT",
  "alg": "RS256"
}
```

To manually generate the x5t, run the following command:

```bash
echo $(openssl x509 -in <cert-name>.pem -fingerprint -noout) | sed 's/SHA1 Fingerprint=//g' | sed 's/://g' | xxd -r -ps | base64
```

The output of this command will look something like `4O/XnGPzxWelh96cO2jqtfrOvPY=` which must then be formatted according to [RFC7515 Appendix-C](https://datatracker.ietf.org/doc/html/rfc7515#appendix-C) by:

1. Replacing `/` with `_`
2. Replacing `+` with `-`
3. Removing the `=` character

This means `4O/XnGPzxWelh96cO2jqtfrOvPY=` should be sent as `4O_XnGPzxWelh96cO2jqtfrOvPY`

More info on the x5t can be found [here](https://redthunder.blog/2017/06/08/jwts-jwks-kids-x5ts-oh-my/).

### PAYLOAD:DATA

```json
{
       "jti": "<JWT ID>",
       "aud": "https://igam.ecb.europa.eu:443/oauth2",
       "exp": <Expiration Time>,
       "iat": <Issued At>,
       "iss": "ap-virtual-lab",
       "sub": "ap-virtual-lab"
}
```

## SIGNATURE

Signed by private key of certificate vlbigam-p01.ecb01.ecb.de

Encoded \<ASSERTION_VALUE> will look like (3 parts divided by `.`):

```
eyJ4NXQiOiJwZlJPQ05wZGtsMjhLU3JYczd0QlpiZDNxeDQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJqdGkiOiIxNjYzODYwNDcyODIyIiwiYXVkIjoiaHR0cHM6Ly9kLWlnYW0udGFkbmV0LmV1OjQ0My9vYXV0aDIvcmVzdC90b2tlbiIsImV4cCI6MTY5OTEwOTExOCwiaWF0IjoxNjYzOTQ1MzI2LCJpc3MiOiJkMDEtYnVsa29wcy1ydW50aW1lIiwic3ViIjoiZDAxLWJ1bGtvcHMtcnVudGltZSJ9.SnOdhjdsGJqoEvMvb2HsIH5RvVggbG5fb343WiezqW_F-SZGTySG9zKmtuFcspROD0qSGNk7gIAr7rDpcTQrPoW52gk3oUnT-f6syOOurLycWFFSyqNupA8HiQCbb63cLSz9q7lgrEDF8j6BozDFBpTAIJEWaz_RSUctqKnusfzwMKcl_3v9TmUPQXTEBFkUgI87QKwC7tl4kjJ7GsgsjGg8W5Jw9_udFXIiXWoSPoTYlZytSG3uill6ENEl1TxK4dXBysMAsyVrVF5QiBO7Mnpp4L5jstIUaDO8YMElypNHSYyNQI0HQGZSIBp6vHcqvLNs9jTCNA3IfGYUkRYMpQ
```

## RESPONSE:

```json
{
  "access_token": "eyJraWQiOiJJR0FNLUFQSSIsIng1dCI6InQyR1QwUFg4VXhYQml0ZTJLNUtrblRxN2tDWSIsImFsZyI6IlJTMjU2In0.eyJpc3MiOiJodHRwczovL2QtaWdhbS50YWRuZXQuZXU6NDQzL29hdXRoMiIsImF1ZCI6WyJJR0FNLUlNIiwiaHR0cHM6Ly9kLWlnYW0udGFkbmV0LmV1OjQ0My9vYXV0aDIiXSwiZXhwIjoxNjY4NTM3MTQ0LCJqdGkiOiJlaWRlX2FiYnA2elN1M0o5MzZ0N0N3IiwiaWF0IjoxNjY4NTMzNTQ0LCJzdWIiOiJkMDEtYnVsa29wcy1ydW50aW1lIiwiY2xpZW50IjoiZDAxLWJ1bGtvcHMtcnVudGltZSIsInNjb3BlIjpbIklHQU0tSU0uYWRtaW4iXSwiZG9tYWluIjoiSUdBTS1BUEkiLCJncm91cHMiOlsiRUNCVEVTVC1QU08tUHJpdmlsZWdlZC1BY2NvdW50Il0sIkFwcF9BY3RpdmVDbGllbnQiOiJ0cnVlIiwiZGlzcGxheW5hbWUiOiJPcGVyYXRpb25zIEFkbWluaXN0cmF0b3IiLCJBcHBfQWN0aXZlIjoidHJ1ZSIsInNlc3Npb25pZCI6IjlmYjdlNTkzNTlmYTc4MzVlMmNkODExYTQxYWQ2Mjc2NmQ0YzgxMDM0ZmU5OWJjNmM4Njk5ZTMxOTM1NzMzOWMiLCJBcHBfU3RhdHVzIjoidHJ1ZSJ9.iuFCFl-xrgrTmCpuaLr59l6tURxvAexH40Tl9X97ndrtqMEKul6gK5IDtRmN-BZvYxnzsNjjT-MBEjF990nC73SYaQR3PE8SPW3u067FKYTjfBmAna-FlKzgD-KRdLJYfTbc4Soum0ZePOIyWUEtIK1qyIErbqoYLHi9wWcIYXXtglxvrdyxHnDg0ilLTGQK96U0Gt4VKxOUTgUfJ2S7IwpSxwsw5zI3-bQVJlcujZ81aJcMjqA6f7ByOIf5_C9h5uSAZoLQzZ12rt764tn_vUZ2tUQNhCDyZnev4504-lo3uW1vt8xYtjqi6HOeAwqLQEDZYMgG7xpMC0WlPvRFAQ",
  "token_type": "Bearer",
  "expires_in": 3600,
  "scope": "IGAM.ENTITLEMENT.READ IGAM.ENTITLEMENT.WRITE IGAM.ORG.READ IGAM.ORG.WRITE"
}
```

#### Call IGAM API with recieved access token:

```bash
curl --location --request POST 'https://igam-login.ecb01.ecb.de/oim-bulk-exec-ui/rest/jersey/bulk/services/oauth
/*' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer eyJraWQiOiJJR0FNLUFQSSIsIng1dCI6InQyR1QwUFg4VXhYQml0ZTJLNUtrblRxN2tDWSIsImFsZyI6IlJTMjU2In0.eyJpc3MiOiJodHRwczovL2QtaWdhbS50YWRuZXQuZXU6NDQzL29hdXRoMiIsImF1ZCI6WyJJR0FNLUlNIiwiaHR0cHM6Ly9kLWlnYW0udGFkbmV0LmV1OjQ0My9vYXV0aDIiXSwiZXhwIjoxNjY4NTM3MTQ0LCJqdGkiOiJlaWRlX2FiYnA2elN1M0o5MzZ0N0N3IiwiaWF0IjoxNjY4NTMzNTQ0LCJzdWIiOiJkMDEtYnVsa29wcy1ydW50aW1lIiwiY2xpZW50IjoiZDAxLWJ1bGtvcHMtcnVudGltZSIsInNjb3BlIjpbIklHQU0tSU0uYWRtaW4iXSwiZG9tYWluIjoiSUdBTS1BUEkiLCJncm91cHMiOlsiRUNCVEVTVC1QU08tUHJpdmlsZWdlZC1BY2NvdW50Il0sIkFwcF9BY3RpdmVDbGllbnQiOiJ0cnVlIiwiZGlzcGxheW5hbWUiOiJPcGVyYXRpb25zIEFkbWluaXN0cmF0b3IiLCJBcHBfQWN0aXZlIjoidHJ1ZSIsInNlc3Npb25pZCI6IjlmYjdlNTkzNTlmYTc4MzVlMmNkODExYTQxYWQ2Mjc2NmQ0YzgxMDM0ZmU5OWJjNmM4Njk5ZTMxOTM1NzMzOWMiLCJBcHBfU3RhdHVzIjoidHJ1ZSJ9.iuFCFl-xrgrTmCpuaLr59l6tURxvAexH40Tl9X97ndrtqMEKul6gK5IDtRmN-BZvYxnzsNjjT-MBEjF990nC73SYaQR3PE8SPW3u067FKYTjfBmAna-FlKzgD-KRdLJYfTbc4Soum0ZePOIyWUEtIK1qyIErbqoYLHi9wWcIYXXtglxvrdyxHnDg0ilLTGQK96U0Gt4VKxOUTgUfJ2S7IwpSxwsw5zI3-bQVJlcujZ81aJcMjqA6f7ByOIf5_C9h5uSAZoLQzZ12rt764tn_vUZ2tUQNhCDyZnev4504-lo3uW1vt8xYtjqi6HOeAwqLQEDZYMgG7xpMC0WlPvRFAQ' \
--data-raw '{
  ………………
}'
```
