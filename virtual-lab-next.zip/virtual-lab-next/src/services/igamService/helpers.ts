import { Context } from "@azure/functions";
import axios, { AxiosError } from "axios";
import { IGAM_BASE_URL } from "../../utils/config";
import IgamAuth from "./igamAuth";
import { IgamToken } from "./types";
import IgamRequestModel from "../dbConnector/models/igamRequestModel";
import { RequestStatus } from "../dbConnector/enums";
import { Project } from "../dbConnector/models/project";

// igam cert is self signed
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

let tokenExpirationTime = 0;
let igamToken: IgamToken | null = null;

/**
 * Creates a new axios instance with custom interceptors.
 * One instance must be created per call since Azure Functions are stateful and the `cxt` logging stops working between calls
 *
 * @param ctx
 * @returns AxiosInstance
 */
export const getInstance = (ctx: Context) => {
  const instance = axios.create({ baseURL: IGAM_BASE_URL });
  ctx.log(`Creating instance`);

  // add interceptor to add token to all requests
  instance.interceptors.request.use(async (config) => {
    // if token does not exist or is expired, fetch a new one.
    if (!igamToken?.access_token || Date.now() > tokenExpirationTime) {
      ctx.log(`Getting token `);
      igamToken = await IgamAuth.getToken();
      ctx.log(`Received Igam token`, {
        ...igamToken,
        // hide access token from logs
        access_token: "REDACTED",
      });
      // remove 60 seconds to account for delays
      tokenExpirationTime = Date.now() + (igamToken.expires_in - 60) * 1000;
      ctx.log(`Setting expiration date to ${new Date(tokenExpirationTime).toISOString()}`);
    }

    // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-unsafe-member-access -- this is from axios doc's
    config.headers.Authorization = `Bearer ${igamToken.access_token}`;
    return config;
  });

  instance.interceptors.response.use(undefined, (err: Error) => {
    let errorText = err?.name;
    let errorData = err?.message;

    if (axios.isAxiosError(err) && err.response) {
      const { response } = err as AxiosError<{ errors?: string[] }>;

      // response is present
      errorText = `${response?.status} - ${response?.statusText}`;
      errorData =
        response?.data?.errors?.join?.("") ??
        (response?.data as string) ??
        "No response data received";
    }
    const error = `IGAM error: ${errorText}: ${errorData}`;
    ctx.log(err);
    ctx.log(error);
    ctx.log(errorData);
    throw new Error(error);
  });

  return instance;
};

export const activeRequestsExist = async (pid: string) => {
  const requests = await IgamRequestModel.find({
    pid,
    requestStatus: RequestStatus.AWAITING_APPROVAL,
  });
  return requests.length > 0;
};

/**
 * Build justification for IGAM request
 *
 * @param project Project
 * @param requester person who requested the update
 * @param newOwner optional, only needed when adding owner with org update
 * @returns
 */
export const buildJustification = (project: Project, requester: string, newOwner?: string) => {
  const messages = [
    `Project name: ${project.name}`,
    `Project confidentiality: ${project.confidentialityLevel}`,
    `Requester: ${requester}`,
    `Project purpose: ${project.description}`,
  ];
  if (newOwner) {
    messages.splice(3, 0, `New owner to be added to project: ${newOwner}`);
  }
  return messages.join(". ");
};
