import axios from "axios";
import { X509Certificate } from "node:crypto";
import jwt from "jsonwebtoken";
import moment from "moment";
import url from "node:url";
import { IGAM_CERT, IGAM_ENDPOINT, IGAM_KEY } from "../../utils/config";
import { IgamToken } from "./types";

/**
 * Uses the IGAM_CERT env variable to generate the x5t fingerprint for
 * IGAM calls.
 * More info can be found here: https://datatracker.ietf.org/doc/html/rfc7515#appendix-C
 *
 * @returns
 */
const getCertFingerprint = () => {
  if (!IGAM_CERT) {
    throw new Error(`IGAM_CERT env variable not defined.`);
  }

  // get fingerprint, should look like AE:61:3F:39:A2:A7:7E:D0:73...
  const certString = IGAM_CERT?.replaceAll(String.raw`\n`, "\n");
  const x509cert = new X509Certificate(certString);
  const shaSig = x509cert.fingerprint;

  const sigOctets = shaSig.split(":");
  const sigBuffer = Buffer.alloc(sigOctets.length);
  for (let i = 0; i < sigOctets.length; i++) {
    // Convert fingerprint to HEX and hash it
    sigBuffer.writeUInt8(Number.parseInt(sigOctets[i], 16), i);
  }

  // base64url-encode and replace required chars to match the RFC7515's spec
  return sigBuffer.toString("base64").replaceAll("=", "").replaceAll("+", "-").replaceAll("/", "_");
};

export const createJwt = () => {
  const issueDate = Date.now();
  const expirationDate = moment(issueDate).add(5, "days").valueOf();

  return jwt.sign(
    {
      jti: "16638604728212",
      aud: `https://${IGAM_ENDPOINT}/oauth2/rest/token`,
      iat: Math.round(issueDate / 1000),
      exp: Math.round(expirationDate / 1000),
      iss: "ap-virtual-lab",
      sub: "ap-virtual-lab",
    },
    IGAM_KEY?.replaceAll(String.raw`\n`, "\n"),
    {
      header: {
        alg: "RS256",
        x5t: getCertFingerprint(),
      },
    },
  );
};

const IgamAuth = {
  async getToken() {
    const token = createJwt();
    const params = new url.URLSearchParams({
      grant_type: "JWT_BEARER",
      scope: "IGAM.ENTITLEMENT.READ IGAM.ENTITLEMENT.WRITE IGAM.ORG.READ IGAM.ORG.WRITE",
      client_assertion_type: "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
      client_assertion: token,
      assertion: token,
    });

    const rsp = await axios.post<IgamToken>(
      `https://${IGAM_ENDPOINT}/oauth2/rest/token/ECBOIDCDomainA2A`,
      params,
    );

    return rsp.data;
  },
};

export default IgamAuth;
