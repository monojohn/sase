import { Context } from "@azure/functions";
import { APP_INSTANCE } from "../../utils/config";
import { wait } from "../../utils/helpers";
import { getInstance } from "./helpers";
import { Org } from "./types";

type CreateOrgProps = {
  orgName: string;
  managerUpn?: string; // upn
  deputiesUpn: string[]; // upn[]
};

enum Action {
  "add" = "add",
  "remove" = "remove",
}

type DeputyBase = {
  action: Action;
  appInstance: string;
};
type DeputyVariants = { accountName: string } | { userLogin: string };
type OrgRequest = {
  orgName: string;
  parentOrgName: string;
  skipApproval?: boolean;
  manager?: {
    action: Action;
    accountName: string;
    appInstance: string;
  };
  deputies: (DeputyBase & DeputyVariants)[];
};

type GetOrgsResponse = {
  organizations: Org[];
};

/**
 * More info and API spec on the URl below
 *
 * https://confluence.ecb.europa.eu/pages/viewpage.action?spaceKey=IGAMUSER&title=IGAM+-+API+for+Identity+Management
 */
const OrgService = {
  /**
   * Create org
   * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Create+Organisation
   *
   * @param props
   */
  async create(ctx: Context, props: CreateOrgProps) {
    const data: OrgRequest = {
      orgName: props.orgName,
      parentOrgName: "", // should be empty
      skipApproval: true,
      manager: props.managerUpn
        ? {
            action: Action.add,
            appInstance: APP_INSTANCE,
            accountName: props.managerUpn,
          }
        : undefined,
      deputies: props.deputiesUpn.map((upn) => ({
        action: Action.add,
        accountName: upn,
        appInstance: APP_INSTANCE,
      })),
    };

    // Creation returns empty
    try {
      const existingOrg = await OrgService.getOrgByName(ctx, props.orgName);
      // if an org already exists
      if (existingOrg) {
        ctx.log(`Org with name ${props.orgName} already exists, deleting it`);
        // delete it before continuing
        await OrgService.delete(ctx, existingOrg.id);
        ctx.log("org deleted, waiting");
        // wait a few seconds before continuing
        await wait(5);
      }

      ctx.log(`Creating org ${props.orgName} with ${props.deputiesUpn.length} deputies`, data);
      await getInstance(ctx).post<void>("/create/organizations/", data);
    } catch (e) {
      const message = `IGAM error: ORG creation failed`;
      ctx.log(e, message);
      throw new Error(message);
    }

    ctx.log(`Creation done, awaiting fetch`);
    // Get recently created org - sometimes it's not available immediately
    let org: Org | undefined;
    for (let index = 0; index < 50; index++) {
      try {
        org = await OrgService.getOrgByName(ctx, props.orgName);
        if (org) {
          return org;
        }
        ctx.log(`Org not found at attempt ${index + 1}`);
        // eslint-disable-next-line sonarjs/no-ignored-exceptions
      } catch (e) /* NOSONAR */ {
        // this will be removed later with the governance changes as we will not be creating orgs anymore
        ctx.log(`Error when fetching org ${props.orgName}`);
      }
      // wait a bit on error and 404
      await wait(5);
    }
    ctx.log(`Org not found after all attempt, assuming creation failed`);
    throw new Error(`Failed to crate org ${props.orgName}`);
  },

  async getOrgByName(ctx: Context, orgName: string) {
    const [org] = await OrgService.search(ctx, `orgName eq "${orgName}"`);
    return org;
  },

  /**
   * Convenience function, gets all orgs.
   * Should be used sparingly
   */
  getAll(ctx: Context) {
    return OrgService.search(ctx, "orgName eq *");
  },

  /**
   * Search orgs
   * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Search+Organisations
   *
   * @param filter query string i.e. "orgName eq <name>"
   */
  async search(ctx: Context, filter: string) {
    const { data } = await getInstance(ctx).get<GetOrgsResponse>(
      `/organizations/?include=managers,ecbTree&filter=${filter}`,
    );
    return data?.organizations ?? [];
  },

  /**
   * Delete org entitlements
   * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Delete+Organisation
   *
   * @param id entitlement id to delete
   */
  async delete(ctx: Context, id: string) {
    await getInstance(ctx).delete<void>(`/delete/organizations/${id}`);
  },

  async deleteByName(ctx: Context, name: string) {
    const org = await OrgService.getOrgByName(ctx, name);
    if (org) {
      await OrgService.delete(ctx, org.id);
    }

    ctx.log(`org with name "${name}" not found, nothing to delete`);
  },

  /**
   * Allows updating org entitlements
   * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Modify+Organisation
   *
   * @param id org id to update
   */
  update(ctx: Context, id: string, props: Partial<OrgRequest>) {
    return getInstance(ctx).post<void>(`/update/organizations/${id}`, props);
  },

  /**
   * Adds deputies to project
   * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Modify+Organisation
   *
   * @param id entitlement id to delete
   * @param upns MUST be UPNs
   */
  async addDeputies(ctx: Context, id: string, upns: string[]) {
    await OrgService.update(ctx, id, {
      deputies: upns.map((upn) => ({
        action: Action.add,
        accountName: upn,
        appInstance: APP_INSTANCE,
      })),
    });
  },

  /**
   * Removes deputies from project
   * https://europeancentralbank.atlassian.net/wiki/spaces/IGAMUSER/pages/65016823/API+-+Modify+Organisation
   *
   * @param id entitlement id to delete
   * @param upns string[] of upns of users to be removed
   */
  removeDeputies(ctx: Context, id: string, upns: string[]) {
    return OrgService.update(ctx, id, {
      deputies: upns.map((upn) => ({
        action: Action.remove,
        accountName: upn,
        appInstance: APP_INSTANCE,
      })),
    });
  },

  /**
   * Removes deputies from project by using user login
   *
   * @param id entitlement id to delete
   * @param userLogins string[] of userLogins of users to be removed
   */
  removeDeputiesByUserLogin(ctx: Context, id: string, userLogins: string[]) {
    return OrgService.update(ctx, id, {
      deputies: userLogins.map((userLogin) => ({
        action: Action.remove,
        userLogin,
        appInstance: APP_INSTANCE,
      })),
    });
  },
  setManager(ctx: Context, id: string, upn: string) {
    return OrgService.update(ctx, id, {
      manager: {
        action: Action.add,
        accountName: upn,
        appInstance: APP_INSTANCE,
      },
    });
  },

  async getApproversEmails(ctx: Context, orgName: string) {
    const org = await this.getOrgByName(ctx, orgName);
    const emails: string[] = [];
    if (org.manager) {
      emails.push(org.manager.email);
    }
    for (const deputy of org.deputies) {
      if (emails.length < 3) {
        emails.push(deputy.email);
      }
    }
    return emails;
  },
};

export default OrgService;
