import { Context } from "@azure/functions";
import { buildJustification, getInstance } from "./helpers";
import { IgamRequestResponse } from "./types";
import { IgamRequest } from "../dbConnector/models/igamRequest";
import IgamRequestModel from "../dbConnector/models/igamRequestModel";
import ProjectService from "../projectService/projectService";
import SlackService from "../slackService";
import ProjectModel from "../dbConnector/models/projectModel";
import { Project } from "../dbConnector/models/project";
import { RequestStatus, RequestType } from "../dbConnector/enums";
import { IgamRequestStatus } from "./enums";
import NotificationService from "../projectService/notificationService";
import EntitlementsNotificationService from "../../features/notificationEntitlements/notificationService";
import GraphService from "../graphService/graphService";
import EntitlementsService from "./entitlementsService";
import { acceptProjectInvitation } from "../../features/projectInvitations/acceptProjectInvitation";
import OwnershipInviteModel from "../dbConnector/models/ownershipInviteModel";
import OrgService from "./orgService";
import { getEmailOfUser } from "../../utils/helpers";
import { EmailType } from "../../features/notificationEntitlements/enums";
import { removeUserFromProject } from "../projectService/projectModificationService/removeUser";

const RequestsService = {
  // https://europeancentralbank.atlassian.net/wiki/spaces/IGAMUSER/pages/65015894/API+-+Get+Request+Info
  async getRequestInfo(ctx: Context, requestId: string) {
    const { data } = await getInstance(ctx).get<IgamRequestResponse>(
      `/requests/request/${requestId}`,
    );
    return data;
  },

  async checkRequestsStatus(ctx: Context, requests: IgamRequest[]) {
    const settled = await Promise.allSettled(
      requests.map((request) => this.checkRequest(ctx, request)),
    );
    const errors = settled
      .filter((promiseResult) => promiseResult.status === "rejected")
      .map((_, ind) => `Failed checking status of IGAM request ${requests[ind].requestId}`);
    if (errors.length) {
      await SlackService.logWarning(ctx, new Error(errors.join("\n")));
    }
  },

  async checkRequest(ctx: Context, request: IgamRequest) {
    if (!request.requestId) {
      ctx.log(`Request does not have a request id`);
      return null;
    }
    const requestInfo = await this.getRequestInfo(ctx, request.requestId);
    if (
      ![
        IgamRequestStatus.CLOSED,
        IgamRequestStatus.EXPIRED,
        IgamRequestStatus.REJECTED,
        IgamRequestStatus.COMPLETED,
      ].includes(requestInfo.status)
    ) {
      ctx.log(`Request has status ${requestInfo.status}, will be tried again`);
      return null;
    }
    ctx.log(`Request status has been updated to ${requestInfo.status}`);
    // update status of request in DB
    const [updatedRequest, project] = await Promise.all([
      IgamRequestModel.findOneAndUpdate(
        { _id: request._id },
        {
          $set: {
            requestStatus: requestInfo.status,
          },
        },
        { new: true },
      ),
      ProjectModel.findById(request.pid),
    ]);
    if (!updatedRequest || !project) {
      throw new Error(`Request ${request._id} or project ${request.pid} missing`);
    }

    // define owner emails
    const ownersEmails: string[] = [];
    // if request is of type project creation, the ownersGroupId is not defined yet, so just the requester's email is to be used
    if (request.requestType === RequestType.PROJECT_CREATION) {
      ownersEmails.push(await GraphService.getUserEmail(ctx, request.requesterId));
    } else {
      ownersEmails.push(...(await GraphService.getGroupUsersEmails(ctx, project.ownersGroupId)));
    }

    // handle pending request if any exist
    const pendingRequests = await IgamRequestModel.find({
      pid: request.pid,
      requestStatus: RequestStatus.PENDING,
    }).sort({ createdAt: 1 });
    if (pendingRequests.length) {
      await this.handleRequestCreation(ctx, project, pendingRequests[0], ownersEmails);
    }

    if (requestInfo.status === IgamRequestStatus.COMPLETED) {
      return this.handleRequestApproval(ctx, project, updatedRequest, ownersEmails);
    }
    return this.handleRequestRejection(ctx, project, updatedRequest, ownersEmails);
  },

  /**
   * handles finishing up actions when approval is granted
   * @param ctx
   * @param project
   * @param request request details
   * @returns
   */
  async handleRequestApproval(
    ctx: Context,
    project: Project,
    request: IgamRequest,
    ownersEmails: string[],
  ) {
    const { requestType, requesterId, oid, pid } = request;
    ctx.log(`Handling request approval for ${pid}, request type ${requestType}`);

    if (requestType === RequestType.UPDATE_CONFIDENTIALITY) {
      return ProjectService.finishConfidentialityUpdate(
        ctx,
        project,
        request.confidentialityLevel!,
        request.dataSensitivityLevel,
      );
    }

    if (requestType === RequestType.UPDATE_ORG) {
      if (!request.org) {
        throw new Error(`Missing org for request ${request._id}`);
      }
      return ProjectService.finishOrgUpdate(ctx, project, request.org);
    }

    if (requestType === RequestType.PROJECT_CREATION) {
      return ProjectService.finishProjectCreation(ctx, project, requesterId);
    }

    if (requestType === RequestType.ADD_OWNER_WITH_ORG_UPDATE) {
      // the owner entitlement has been updated
      // have to update the other 2 entitlements with the new org and add the owner
      const invitation = await OwnershipInviteModel.findOne({ invitee: oid, pid });
      if (!invitation || !request.org) {
        throw new Error(
          `Missing invitation for oid ${oid}, project ${pid} or org on request ${request._id}`,
        );
      }
      return Promise.all([
        EntitlementsService.updateOrg(
          ctx,
          [project.teamGroupName, project.membersGroupName],
          request.org,
          false,
        ),
        ProjectModel.updateOne({ _id: project._id }, { $set: { org: request.org } }),
        acceptProjectInvitation(ctx, invitation, project, false),
      ]);
    }

    const [invitation, invitedOwner] = await Promise.all([
      OwnershipInviteModel.findOne({ pid, invitee: oid }),
      GraphService.getUserProps(ctx, oid!, [
        "displayName",
        "identities",
        "otherMails",
        "mail",
        "id",
        "userPrincipalName",
        "userType",
      ]),
    ]);
    if (!invitation) {
      throw new Error(`Missing invitation for oid ${oid}, pid ${pid}`);
    }

    // check if the roles and entitlements of the project are covered, if any
    if (project.rolesAndEntitlements?.length) {
      // only check if there is something to check
      const { analysis, passed } = await ProjectService.checkRolesAndEntitlements(
        ctx,
        [invitedOwner],
        project,
      );

      if (!passed) {
        // user would already be added in the owners group from the IAM request, so they need to be removed
        await removeUserFromProject(ctx, project, invitedOwner.id);

        // send notifications according to the analysis
        return EntitlementsNotificationService.notifyUsers(
          ctx,
          [invitedOwner],
          analysis,
          EmailType.NEW_USERS,
          project,
        );
      }
    }

    // notify owner that request has been approved and invited owner will be added soon
    await NotificationService.sendAddingOwnerApprovedEmail(
      ctx,
      [...ownersEmails, getEmailOfUser(invitedOwner)],
      invitedOwner.displayName,
      project.name,
      ProjectService.getProjectUrl(project),
    );
    return acceptProjectInvitation(ctx, invitation, project, true);
  },

  /**
   * handles cleaning up actions when approval is not granted (request is rejected / expired etc.)
   * @param ctx
   * @param project
   * @param request request details
   * @returns
   */
  async handleRequestRejection(
    ctx: Context,
    project: Project,
    request: IgamRequest,
    ownersEmails: string[],
  ) {
    const { requestType, requesterId } = request;
    ctx.log(`Handling request rejecttion for ${request.pid}, request type ${requestType}`);
    const requestStatus = request.requestStatus as
      | RequestStatus.CLOSED
      | RequestStatus.EXPIRED
      | RequestStatus.REJECTED;
    const requesterEmail = await GraphService.getUserEmail(ctx, requesterId);
    if (
      requestType === RequestType.ADD_OWNER ||
      requestType === RequestType.ADD_OWNER_WITH_ORG_UPDATE
    ) {
      await OwnershipInviteModel.findOneAndUpdate(
        { pid: request.pid, oid: request.oid },
        { $set: { status: requestStatus } },
      );
      const invitedOwner = await GraphService.getUserProps(ctx, request.oid!, [
        "displayName",
        "identities",
        "otherMails",
        "mail",
      ]);
      return NotificationService.sendAddingOwnerRejectionEmail(
        ctx,
        project.name,
        [...ownersEmails, getEmailOfUser(invitedOwner)],
        requestStatus,
        invitedOwner.displayName,
      );
    }

    if (requestType === RequestType.UPDATE_CONFIDENTIALITY) {
      return NotificationService.sendConfidentialityUpdateRejectionEmail(
        ctx,
        project.name,
        ownersEmails,
        requestStatus,
      );
    }

    if (requestType === RequestType.UPDATE_ORG) {
      if (!request.org) {
        throw new Error(`Missing org in request ${request.requestId} for ${project.name}`);
      }
      const org = await OrgService.getOrgByName(ctx, request.org);
      const emails: string[] = ["virtuallab@ecb.europa.eu"];
      if (org.manager) {
        emails.push(org.manager.email);
      }
      emails.push(...org.deputies.map(({ email }) => email));
      return NotificationService.sendOrgUpdateRejectedEmail(
        ctx,
        project.name,
        emails,
        requestStatus,
        request.org,
      );
    }

    if (requestType === RequestType.PROJECT_CREATION) {
      return Promise.all([
        NotificationService.sendProjectCreationRejectionEmail(
          ctx,
          project.name,
          requesterEmail,
          requestStatus,
        ),
        ProjectService.cleanupRejectedProject(ctx, project, request),
      ]);
    }
    return null;
  },

  /**
   * handles creating the next pending request for a project in IGAM. due to IGAM limitations, we can only have one active request at a time
   * so we can't add for example 2 owners, or add an owner and update confidentiality
   * @param ctx
   * @param project
   * @param request
   * @returns
   */
  async handleRequestCreation(
    ctx: Context,
    project: Project,
    request: IgamRequest,
    ownersEmails: string[],
  ) {
    const { requestType } = request;
    const { ownersGroupName, org } = project;
    ctx.log(`Handling request creation for ${project._id}, request type ${requestType}`);

    const requester = await GraphService.getUserProps(ctx, request.requesterId, ["displayName"]);
    const orgApprovers = await OrgService.getApproversEmails(ctx, org);
    const justification = buildJustification(project, requester.displayName);
    let requestId: string = "";

    if (requestType === RequestType.ADD_OWNER) {
      const invitedOwner = await GraphService.getUserProps(ctx, request.oid!, [
        "displayName",
        "identities",
        "otherMails",
        "mail",
      ]);
      const data = await ProjectService.addOwnerWithApproval(
        ctx,
        project,
        request.oid!,
        requester.displayName,
      );
      requestId = data.requestId ?? "";
      if (data.requestType === RequestType.ADD_OWNER_WITH_ORG_UPDATE) {
        if (!data.org) {
          throw new Error(
            `Missing org for request to add owner with org update for ${project.name}`,
          );
        }
        await IgamRequestModel.findOneAndUpdate(
          { _id: request._id },
          {
            $set: {
              requestType: data.requestType,
              org: data.org,
            },
          },
        );
        const updatedOrg = data.org;
        const approvers = await OrgService.getApproversEmails(ctx, updatedOrg);
        await NotificationService.sendOwnerAwaitingApprovalEmail(
          ctx,
          [...ownersEmails, getEmailOfUser(invitedOwner)],
          project.name,
          invitedOwner.displayName,
          requestId,
          updatedOrg,
          approvers,
        );
      } else {
        await NotificationService.sendOwnerAwaitingApprovalEmail(
          ctx,
          [...ownersEmails, getEmailOfUser(invitedOwner)],
          project.name,
          invitedOwner.displayName,
          requestId,
          org,
          orgApprovers,
        );
      }
    } else if (requestType === RequestType.UPDATE_CONFIDENTIALITY) {
      const [data] = await EntitlementsService.updateConfidentiality(
        ctx,
        [ownersGroupName],
        request.confidentialityLevel!,
        true,
        justification,
      );
      requestId = data.requestId ?? "";
      if (!requestId) {
        throw new Error(`Missing requestId for ${requestType} project ${project.name}`);
      }
      await NotificationService.sendConfidentialityPendingApprovalEmail(
        ctx,
        project.name,
        ownersEmails,
        requestId,
        org,
        orgApprovers,
      );
    } else if (requestType === RequestType.UPDATE_ORG) {
      if (!request.org) {
        throw new Error(`Missing org for request ${request._id}`);
      }
      const [data] = await EntitlementsService.updateOrg(
        ctx,
        [ownersGroupName],
        request.org,
        true,
        justification,
      );
      requestId = data.requestId ?? "";

      const approvers = await OrgService.getApproversEmails(ctx, request.org);
      await NotificationService.sendOrgUpdateRequestedEmail(
        ctx,
        project.name,
        ownersEmails,
        requestId,
        request.org,
        approvers,
      );
    }

    return IgamRequestModel.findOneAndUpdate(
      { _id: request._id },
      {
        $set: {
          requestStatus: RequestStatus.AWAITING_APPROVAL,
          requestId,
        },
      },
    );
  },
};

export default RequestsService;
