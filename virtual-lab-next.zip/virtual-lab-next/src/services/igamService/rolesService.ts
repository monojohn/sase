import { Context } from "@azure/functions";
import { getInstance } from "./helpers";
import { Role } from "./types";

/**
 * Interacts with IGAM to read roles
 *
 * Some info can be found here:
 * https://confluence.ecb.europa.eu/display/IGAMUSER/API+-+Search+Roles
 */
const RolesService = {
  async searchByName(ctx: Context, name: string) {
    const role = `roleName eq "${name}"`;
    ctx.log(`Searching for '${role}'`);
    const rsp = await getInstance(ctx).get<{
      roles: Role[];
    }>(`/roles?filter=${encodeURIComponent(role)}`);
    return rsp.data?.roles;
  },
};

export default RolesService;
