export enum IgamRequestStatus {
  AWAITING_APPROVAL = "Request Awaiting Approval", // waiting for action by approver
  COMPLETED = "Request Completed", // approved and implemented
  CLOSED = "Request Closed", // withdrawn, will not be implemented
  EXPIRED = "Request Expired", // not approved in time, will not be implemented
  REJECTED = "Request Rejected", // not approved, will not be implemented
}

export enum ApprovalModel {
  NO_APPROVAL = "0",
  MANAGER_APPROVAL = "1",
  MANAGER_AND_OWNER_APPROVAL = "2",
  OWNER_APPROVAL = "3",
}
