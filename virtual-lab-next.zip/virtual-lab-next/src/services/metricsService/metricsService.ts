import { Workspace } from "@azure/arm-machinelearning";
import { Context } from "@azure/functions";
import moment from "moment";
import ProjectModel from "../dbConnector/models/projectModel";
import GraphService from "../graphService/graphService";
import { GraphUser, UserType } from "../graphService/types";
import MachineLearningService from "../machineLearningService/machineLearningService";
import SpFolderService from "../sharepointService/spFolderService";
import { VL_TEAM_GROUP_ID } from "../../utils/config";
import { getEmailOfUser, getTeamGroupName, wait } from "../../utils/helpers";
import { Project } from "../dbConnector/models/project";
import { MetricsGraphUser } from "./types";
import { ProjectStatus } from "../dbConnector/enums";
import PlannerService from "../plannerService/plannerService";

const MetricsService = {
  async getAllVlUsers(ctx: Context) {
    if (!VL_TEAM_GROUP_ID) {
      throw new Error("VL_TEAM_GROUP_ID is not defined");
    }

    return GraphService.getGroupUsers(ctx, VL_TEAM_GROUP_ID, [
      "id",
      "displayName",
      "otherMails",
      "mail",
      "userType",
      "identities",
      "department",
    ]);
  },

  async getUsersByGroups<K extends keyof Partial<GraphUser>>(
    ctx: Context,
    prefix: string,
    fields: K[],
    filterByGroupNames = false,
  ) {
    let groups = await GraphService.searchGroups(ctx, prefix);

    if (filterByGroupNames) {
      const projects = await ProjectModel.find({ status: ProjectStatus.Active });
      const groupNames = new Set(projects.map(({ name }) => getTeamGroupName(name)));
      groups = groups.filter((group) => groupNames.has(group.displayName));
    }
    ctx.log(`Getting users from ${groups.length} groups`);

    const chunkSize = 40;
    const groupsUsers: Pick<GraphUser, K>[][] = [];
    // batch requests so we don't get 429'd
    for (let index = 0; index < groups.length; index += chunkSize) {
      const promises: Promise<Pick<GraphUser, K>[]>[] = [];

      for (
        let innerIndex = 0;
        innerIndex < chunkSize && innerIndex + index < groups.length;
        innerIndex++
      ) {
        const actualIndex = innerIndex + index;

        promises.push(GraphService.getGroupUsers(ctx, groups[actualIndex].id, fields));
      }
      // we get disconnected when sending too many requests
      await wait(1);

      groupsUsers.push(...(await Promise.all(promises)));
    }
    return groupsUsers;
  },

  filterUsersByType(userList: MetricsGraphUser[], type: UserType) {
    return userList.filter(({ userType }) => userType === type);
  },

  getUserTypes(userList: MetricsGraphUser[]) {
    return userList.reduce((acc, { userType }) => {
      if (!acc.includes(userType)) {
        acc.push(userType);
      }
      return acc;
    }, [] as UserType[]);
  },

  getUniqueDomains(userList: MetricsGraphUser[]) {
    return userList.reduce((acc, user) => {
      const email = getEmailOfUser(user);
      const domain = email?.split("@")[1]?.toLocaleLowerCase();

      if (!acc.includes(domain)) {
        acc.push(domain);
      }

      return acc;
    }, [] as string[]);
  },

  async areFilesActive(ctx: Context, project: Project, start: moment.Moment, end: moment.Moment) {
    const files = await SpFolderService.getProjectFiles(ctx, project.url.split("/sites/")[1]);
    return files.some((file) => moment(file.TimeLastModified).isBetween(start, end, null, "[]"));
  },

  async isMachineLearningWorkspaceActive(
    ctx: Context,
    workspace: Workspace,
    userMails: string[],
    start: moment.Moment,
    end: moment.Moment,
  ) {
    // check last modified at date
    if (moment(workspace.systemData?.lastModifiedAt).isBetween(start, end, null, "[]")) {
      return true;
    }
    const workspaceName = workspace.name!;
    if (!workspace.id) {
      throw new Error(`Missing workspace id for ${workspaceName}`);
    }

    // check activtiy log for workspace
    return MachineLearningService.hasUserActivityLogs(
      ctx,
      workspace.id,
      userMails,
      start.format(),
      end.format(),
    );
  },

  async isPlannerActive(
    ctx: Context,
    teamGroupId: string,
    start: moment.Moment,
    end: moment.Moment,
  ) {
    const plannerTasks = await PlannerService.getAllPlannerTasks(ctx, teamGroupId);
    return plannerTasks.some((tasks) =>
      tasks.some(
        (task) =>
          moment(task.createdDateTime).isBetween(start, end, null, "[]") || // NOSONAR - complains about using ?? instead of ||
          moment(task.completedDateTime).isBetween(start, end, null, "[]"),
      ),
    );
  },
};

export default MetricsService;
