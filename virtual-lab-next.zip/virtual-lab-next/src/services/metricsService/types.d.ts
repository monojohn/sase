import type { SimpleGraphUser, UserType } from "../graphService/types";

export type MetricsGraphUser = SimpleGraphUser & {
  userType: UserType;
};
