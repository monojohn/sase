import { ActionType } from "../../features/userActions/enums";

export type Notification = {
  type: ActionType;
  oid: string; // identifies user to be notified
  triggeredBy: string; // oid of user who triggered notification
  triggeredByName: string; // name of user who triggered notification

  // project identification
  pid: string | number;
  projectName: string;

  read: boolean;
  target?: string;
  targetName?: string;

  // auto generated fields
  Id: number;
  Created: string;
  Modified: string;
};

export type CreateNotification = Omit<Notification, "read" | "Created" | "Modified"> & {
  read?: boolean;
};
