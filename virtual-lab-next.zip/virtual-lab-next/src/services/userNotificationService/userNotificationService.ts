import { Context } from "@azure/functions";
import UserNotificationModel from "../dbConnector/models/userNotificationModel";
import GraphService from "../graphService/graphService";
import { GraphUser } from "../graphService/types";
import { withRetry } from "../../utils/helpers";
import { ActionType } from "../../features/userActions/enums";

type Triggerer = Pick<GraphUser, "id" | "displayName">;
type Target = { id: string; name?: string };

export type NotifyUserProps = {
  type: ActionType;
  oid: string;
  project: { id: string | number; name: string };
  target?: Target;
  triggerer: Triggerer;
  read?: boolean;
};

type NotifyUsersProps = Omit<NotifyUserProps, "oid">;
type UserId = Pick<GraphUser, "id">;

export type NotifyGroupProps = Omit<NotifyUserProps, "oid" | "read">;

const UserNotificationService = {
  /**
   * Send the same notification to all group users
   *
   * @param ctx
   * @param users users to notify
   * @param props
   * @returns
   */
  async notifyGroup(ctx: Context, groupId: string, props: NotifyGroupProps) {
    const users = await GraphService.getGroupUsers(ctx, groupId, ["id"]);
    return UserNotificationService.notifyUsers(ctx, users, props);
  },

  /**
   * Send the same notification to all users
   *
   * @param ctx
   * @param users users to notify
   * @param props
   * @returns
   */
  async notifyUsers(ctx: Context, users: UserId[], props: NotifyUsersProps) {
    const { project, type, target, triggerer } = props;
    for (const user of users) {
      const { id: oid } = user;

      // 'read' is set to "true" when triggerer is being notified
      const read = triggerer.id === oid;

      await withRetry(
        async () => {
          await UserNotificationModel.create({
            // 'read' is set to "true" when triggerer is being notified

            oid,
            pid: project.id,
            read,
            projectName: project.name,
            triggeredBy: triggerer.id,
            triggeredByName: triggerer.displayName,
            targetId: target?.id,
            targetName: target?.name,
            type,
          });
        },
        ctx,
        10,
      );
    }
  },
};

export default UserNotificationService;
