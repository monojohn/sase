import { Context } from "@azure/functions";
import { GraphError } from "@microsoft/microsoft-graph-client";
import { AxiosError } from "axios";
import {
  ENV,
  IS_PROD,
  NON_ESCB_GUEST_GROUP,
  VL_ADMINS_GROUP_ID,
  VL_GUESTS_GROUP_ID,
  VL_INBOX_GROUP,
  VL_MEMBERS_GROUP_ID,
  VL_ORG,
  VL_TEAM_ORG,
} from "../../utils/config";
import GraphClient from "../../utils/graphClient";
import {
  getEmailOfUser,
  getMembersGroupName,
  getOwnersGroupName,
  getTeamGroupName,
} from "../../utils/helpers";
import { isTechnicalAccount } from "../../utils/isTechnicalAccount";
import { InstitutionsMap } from "./enums";
import { formatUser, getAllEntries } from "./helpers";
import {
  AllTimeUsage,
  DefaultGraphUser,
  GraphDrive,
  GraphDriveItem,
  GraphDriveItemResponse,
  GraphGroup,
  GraphSearchResponse,
  GraphUser,
  GroupSite,
  PageActivity,
} from "./types";

const GraphService = {
  async getSiteById(context: Context, id: string) {
    const client = await GraphClient.get(context);
    return client.api(`/groups/${id}/sites/root`).get() as Promise<GroupSite>;
  },

  async getSiteId(context: Context, teamGroupId: string) {
    return GraphService.getIdOfSite(await GraphService.getSiteById(context, teamGroupId));
  },

  getIdOfSite(site: GroupSite) {
    return site.id.split(",")[1];
  },

  async getSiteUrl(context: Context, teamGroupId: string): Promise<string> {
    const client = await GraphClient.get(context);
    const { value } = (await client.api(`/groups/${teamGroupId}/sites/root/weburl`).get()) as {
      value: string;
    };

    return value;
  },

  async getGroupByName(ctx: Context, name: string) {
    const client = await GraphClient.get(ctx);
    const groupUrl = `/groups?$filter=displayName eq '${name}'`;
    try {
      const { value } = (await client.api(groupUrl).get()) as {
        value: GraphGroup[];
      };
      return value;
    } catch (err) {
      ctx.log(err, "Group was not found");
    }
    return [];
  },

  async getGroupIdByName(context: Context, groupName: string) {
    const [group] = await GraphService.getGroupByName(context, groupName);
    return group?.id;
  },

  async getAllGroupUserEmails(context: Context, projectName: string) {
    const teamName = getTeamGroupName(projectName);
    const groupId = await GraphService.getGroupIdByName(context, teamName);

    if (!groupId) {
      throw new Error(`Group not found ${teamName}`);
    }

    return GraphService.getGroupUsersEmails(context, groupId);
  },

  async getGroupMembersEmails(context: Context, projectName: string) {
    const groupId = await GraphService.getGroupIdByName(context, getMembersGroupName(projectName));

    return GraphService.getGroupUsersEmails(context, groupId);
  },

  async getGroupOwnersEmails(context: Context, projectName: string) {
    const groupId = await GraphService.getGroupIdByName(context, getOwnersGroupName(projectName));

    return GraphService.getGroupUsersEmails(context, groupId);
  },

  async getGroupUsersEmails(context: Context, groupId: string) {
    const users = await GraphService.getGroupUsers(context, groupId, [
      "otherMails",
      "mail",
      "identities",
    ]);

    return (
      users
        .map(getEmailOfUser)
        // filter out technical accounts (i.e. Planner) as they show up in the Team group but should not receive emails
        .filter((email) => !isTechnicalAccount(email))
    );
  },

  async getProjectUsersMails(context: Context, projectName: string) {
    const teamName = getTeamGroupName(projectName);
    const groupId = await GraphService.getGroupIdByName(context, teamName);

    if (!groupId) {
      throw new Error(`Group not found ${teamName}`);
    }

    const users = await GraphService.getGroupUsers(context, groupId, ["mail"]);

    return users
      .filter(({ mail }) => !isTechnicalAccount(mail))
      .map(({ mail }) => mail.toLocaleLowerCase());
  },

  async getGroupUsers<K extends keyof Partial<GraphUser>>(
    ctx: Context,
    groupId: string,
    select: K[] = [],
  ) {
    // ignore tech accounts when fetching groups
    const techAccountPrefixes = ["ECBDEVENV-", "ECBPROD-", "AP-"];
    const query = techAccountPrefixes
      .map((prefix) => `not(startsWith(displayName, '${prefix}'))`)
      .join(" and ");

    const selectParam = select.length > 0 ? `$select=${select.join(", ")}` : "";
    return getAllEntries<Pick<GraphUser, K>>(
      ctx,
      `/groups/${groupId}/members?${selectParam}&$filter=${query}`,
    );
  },

  async getAllGroupUsers<K extends keyof Partial<GraphUser>>(
    ctx: Context,
    groupId: string,
    select: K[],
  ) {
    return getAllEntries<Pick<GraphUser, K>>(
      ctx,
      `/groups/${groupId}/members?$select=${select.join(", ")}`,
    );
  },

  /**
   * Returns the required fields for Member (meaning non-guest) users
   *
   * @param ctx
   * @param groupId
   * @param select fields to select
   * @returns
   */
  async getGroupMemberUsers<K extends keyof Partial<GraphUser>>(
    ctx: Context,
    groupId: string,
    select: K[],
  ) {
    return getAllEntries<Pick<GraphUser, K>>(
      ctx,
      // NOTE: Member must be between single quotes for query to work
      `/groups/${groupId}/members?$filter=userType eq 'Member'&$select=${select.join(", ")}`,
    );
  },

  /**
   * Verifies if a user is a member of an AAD group
   *
   * @param context
   * @param userId can be the object Id or UPN
   * @param groupId id of the group to check
   * @returns custom user
   */
  async isUserInGroup(ctx: Context, userId: string, groupId: string) {
    const client = await GraphClient.get(ctx);
    const cleanPrincipal = encodeURIComponent(userId);

    try {
      const response = (await client
        .api(`/users/${cleanPrincipal}/memberOf?$filter=id eq '${groupId}'`)
        .get()) as {
        value: GraphGroup[];
      };
      return response.value[0]?.id === groupId;
    } catch (e) {
      // 404's throw errors and must be caught
      const err = e as GraphError;
      if (err?.statusCode === 404) {
        return false;
      }
      ctx.log(`Failed to check if user was in group`, {
        code: err?.statusCode,
      });

      // non 404's throw
      throw e;
    }
  },

  /**
   * Get groups info for a user like isAdmin, isNonEscb and isVlUser
   *
   * @param context
   * @param userId can be the object Id or UPN
   * @returns custom user
   */
  async getUserGroupsInfo(ctx: Context, userId: string) {
    const [isAdmin, isNonEscb, isGuest, isMember] = await Promise.all([
      GraphService.isUserInGroup(ctx, userId, VL_ADMINS_GROUP_ID),
      GraphService.isUserInGroup(ctx, userId, NON_ESCB_GUEST_GROUP),
      GraphService.isUserInGroup(ctx, userId, VL_GUESTS_GROUP_ID),
      GraphService.isUserInGroup(ctx, userId, VL_MEMBERS_GROUP_ID),
    ]);
    return {
      isAdmin,
      isNonEscb,
      isVlUser: isAdmin || isNonEscb || isGuest || isMember,
    };
  },

  async searchGroups(ctx: Context, text: string) {
    return getAllEntries<GraphGroup>(ctx, `/groups/?$filter=startswith(displayName, '${text}')`);
  },

  async getSimpleUser(context: Context, userPrincipalName: string) {
    return GraphService.getUserProps(context, userPrincipalName, [
      "id",
      "otherMails",
      "mail",
      "displayName",
      "identities",
    ]);
  },

  /**
   * Get user by ObjectId or UPN with field selector
   *
   * @param context
   * @param userId can be the object Id or UPN
   * @param select
   * @returns custom user
   */
  async getUserProps<K extends keyof Partial<GraphUser>>(
    context: Context,
    userId: string,
    select: K[],
  ) {
    try {
      const client = await GraphClient.get(context);
      return (await client
        .api(`/users/${encodeURIComponent(userId)}?$select=${select.join(", ")}`)
        .get()) as Pick<GraphUser, K>;
    } catch (err) {
      const error = err as AxiosError<string | { errors: string[] }>;
      const data = error?.response?.data;
      const errorText = typeof data === "string" ? data : data?.errors?.join("\n");

      const prettyError = `Graph error | failed to get user: ${errorText ?? (err as string)}`;
      throw new Error(prettyError);
    }
  },

  /**
   * Get a list of users by ObjectId or UPN with field selector
   *
   * @param context
   * @param userIds an array of object Id or UPN
   * @param select
   * @returns list of custom user
   */
  async getUsersProps<K extends keyof Partial<GraphUser>>(
    context: Context,
    userIds: string[],
    select: K[],
  ) {
    return Promise.all(userIds.map((id) => GraphService.getUserProps(context, id, select)));
  },

  /**
   * Get user by ObjectId or UPN
   *
   * @param context
   * @param userId can be the object Id or UPN
   * @returns
   */
  async getUser(context: Context, userId: string) {
    const client = await GraphClient.get(context);

    try {
      return (await client.api(`/users/${encodeURIComponent(userId)}`).get()) as DefaultGraphUser;
    } catch (err) {
      const error = err as AxiosError<{ errors: string[] }>;
      const prettyError = error?.response?.data?.errors?.join("\n");
      context.log(`Failed to get user\n`, prettyError ?? err);
      throw prettyError ? new Error(prettyError) : err;
    }
  },

  /**
   * Searches for 'needle' inside the 'groupId'
   *
   * if 'needle' is not provided, all users are returned
   *
   * [graph docs](https://learn.microsoft.com/en-us/graph/api/group-list-members?view=graph-rest-1.0&tabs=javascript#example-4-use-searchand-odata-cast-to-get-user-membership-in-groups-with-display-names-that-contain-the-letters-pr-including-a-count-of-returned-objects)
   *
   * @param ctx
   * @param groupId
   * @param needle (optional) the string to search for
   * @returns
   */
  async searchGroupUsers(ctx: Context, groupId: string, needle: string = "") {
    const client = await GraphClient.get(ctx);

    const query = client
      .api(`/groups/${groupId}/members`)
      .header("ConsistencyLevel", "eventual")
      .select(["id", "mail", "displayName", "userType", "otherMails", "identities"]);

    if (needle) {
      query.search(`"userPrincipalName:${needle}" OR "displayName:${needle}" OR "mail:${needle}"`);
    }

    const { value } = (await query.orderby("displayName").count().get()) as GraphSearchResponse;

    return value;
  },

  /**
   * Searches users inside VL_GUESTS_GROUP_ID for 'needle'
   *
   * @param ctx
   * @param needle the string to search for
   */
  async searchGuestUsers(ctx: Context, needle: string) {
    return GraphService.searchGroupUsers(ctx, VL_GUESTS_GROUP_ID, needle);
  },

  /**
   * Searches users inside VL_MEMBERS_GROUP_ID for 'needle'
   *
   * @param ctx
   * @param needle the string to search for
   */
  async searchMemberUsers(ctx: Context, needle: string) {
    return GraphService.searchGroupUsers(ctx, VL_MEMBERS_GROUP_ID, needle);
  },

  /**
   * Searches users inside NON_ESCB_GUEST_GROUP for 'needle'
   *
   * @param ctx
   * @param needle the string to search for
   */
  async searchNonEscbUsers(ctx: Context, needle: string) {
    return GraphService.searchGroupUsers(ctx, NON_ESCB_GUEST_GROUP, needle);
  },

  /**
   * Searches the displayName, mail and userPrincipalName fields for the needle
   *
   * The [docs](https://learn.microsoft.com/en-us/graph/api/user-list?view=graph-rest-1.0&tabs=javascript#example-6-use-search-to-get-users-with-display-names-that-contain-the-letters-wa-including-a-count-of-returned-objects)
   * are partially incorrect in the `.search` example. It requires the full string to be within quotes, i.e. `.search('"displayName:value"')`
   *
   * @param ctx
   * @param needle the string to search for
   * @returns
   */
  async searchUsers(ctx: Context, needle: string, searchNonEscbUsers: boolean) {
    const promises = [
      GraphService.searchGuestUsers(ctx, needle),
      GraphService.searchMemberUsers(ctx, needle),
    ];
    if (searchNonEscbUsers) {
      promises.push(GraphService.searchNonEscbUsers(ctx, needle));
    }
    const result = await Promise.all(promises);

    // sort results by displayName
    return result
      .flat(1)
      .sort((a, b) => a.displayName.localeCompare(b.displayName))
      .map((user) => formatUser(user));
  },

  async getUserByAltEmail(context: Context, email: string) {
    const client = await GraphClient.get(context);
    const { value } = (await client
      .api("/users")
      .filter(`otherMails/any(c:c eq '${email}')`)
      .get()) as {
      value: DefaultGraphUser[];
    };

    return value;
  },

  async getUserEmail(context: Context, userId: string) {
    const user = await GraphService.getUserProps(context, userId, [
      "otherMails",
      "mail",
      "identities",
    ]);
    return getEmailOfUser(user);
  },

  getInstitutionOfUser(otherMails: string[]) {
    const mail =
      // use the email address that is not IAM
      otherMails.find((otherMail) => !otherMail.includes("@iam.escb.eu")) ||
      // if that is not found, use IAM
      otherMails.find((otherMail) => otherMail.includes("@iam.escb.eu"));

    if (!mail) {
      return null;
    }

    const institutionValue = mail.split("@")[1].toLowerCase() as keyof typeof InstitutionsMap;
    return (InstitutionsMap[institutionValue] as string)
      ? (InstitutionsMap[institutionValue] as string)
      : institutionValue;
  },

  async getGroupProperty<T>(ctx: Context, groupId: string, property: string) {
    const client = await GraphClient.get(ctx);
    return client.api(`/groups/${groupId}/${property}`).get() as Promise<{
      value: T[];
    }>;
  },

  async getPageViews(ctx: Context, siteId: string, startDate: string, endDate: string) {
    const client = await GraphClient.get(ctx);
    const { value: analytics } = (await client
      .api(
        `/sites/${siteId}/getActivitiesByInterval(startDateTime='${startDate}',endDateTime='${endDate}',interval='week')`,
      )
      .get()) as { value: PageActivity[] };
    const viewsCount = analytics.reduce((acc, { access }) => acc + access.actionCount, 0);
    return viewsCount;
  },

  /**
   *
   * @param ctx
   * @param siteId site Id string
   * @returns AllTimeUsage - unique viewers and site visits
   */
  async getAllTimeUsage(ctx: Context, siteId: string) {
    const client = await GraphClient.get(ctx);
    return client.api(`/sites/${siteId}/analytics/allTime`).get() as Promise<AllTimeUsage>;
  },

  /**
   * Returns (only) files in folder of the specified site ID
   * @param ctx
   * @param siteId site ID of the project
   * @param folderId folder ID, will use root folder if `undefined` or `null`
   * @param select fields to select
   * @param recursive default is `false`, set to `true` to search recursively
   * @returns array of files in folder with properties based on `select`
   */
  async getFilesInFolder<K extends keyof Partial<GraphDriveItem>>(
    ctx: Context,
    siteId: string,
    folderId: string | null = null,
    select: K[] = [],
    recursive = false,
  ) {
    const client = await GraphClient.get(ctx);

    const drive = (await client.api(`/sites/${siteId}/drive`).get()) as GraphDrive;

    const rootOrFolder = folderId ? `items/${folderId}` : "root";

    const { value: items } = (await client
      .api(
        `/sites/${siteId}/drives/${drive.id}/${rootOrFolder}/children?$select=${select.join(", ")}`,
      )
      .get()) as GraphDriveItemResponse;

    const files = items.filter((item) => item.file);

    if (recursive) {
      // Only check folders with children
      const foldersToCheck = items.filter(
        (item) => item.folder?.childCount && item.folder.childCount > 0,
      );

      for (const folder of foldersToCheck) {
        const folderItems = await GraphService.getFilesInFolder(
          ctx,
          siteId,
          folder.id,
          select,
          recursive,
        );

        files.push(...folderItems.filter((item) => item.file));
      }
    }

    return files;
  },

  async getUserDepartment(ctx: Context, user: Pick<GraphUser, "id" | "department" | "userType">) {
    const { id, userType, department } = user;
    if (
      (ENV === "test" && id === "1d4a57dd-2c6c-4309-b9cb-d404d53476e0") ||
      ((ENV === "stg" || ENV === "prod") && id === "226d5de7-04a3-4acf-aaca-439e49ec8bd1")
    ) {
      // vidmante's normal account
      return "Virtual Lab Custom 2(CI587574)";
    }

    if (
      (ENV === "test" && id === "202eb6a9-e030-474c-ab26-5864a99b7a52") ||
      ((ENV === "stg" || ENV === "prod") && id === "4aa8b699-1345-45e6-8d2f-5a103637bfef")
    ) {
      // roberta's normal account
      return "Virtual Lab Custom 3(CI587574)";
    }

    // test & stg -> vl team org
    if (!IS_PROD) {
      return VL_TEAM_ORG;
    }

    // guest user -> VL org
    if (userType === "Guest") {
      return VL_ORG;
    }

    // VL team user -> vl team org
    const isUserVlTeam = await GraphService.isUserInGroup(ctx, id, VL_INBOX_GROUP);
    if (isUserVlTeam) {
      return VL_TEAM_ORG;
    }

    // otherwise, user's department
    return department;
  },
};

export default GraphService;
