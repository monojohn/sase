export type GraphResponse<T> = {
  value: T;
  "@odata.nextLink": string; // NOTE: only present when there are more results
  "@odata.context": string;
};

export type GroupMember = {
  "@odata.type": string; // "#microsoft.graph.user";
  mail: string; // "Sophia_Luisa_Luca.Janzen.external@tadnet.eu";
  otherMails: string[]; // [];
};

export type UserType = "Guest" | "Member";

export type Identity = {
  signInType: string; // "federated"
  issuer: string; // "ExternalAzureAD"
  issuerAssignedId?: string;
};

/**
 * Data received when no SELECT field is sent
 */
export type DefaultGraphUser = {
  "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#users/$entity";
  businessPhones: [];
  displayName: string; // '<surname>, <givenName> (External)',
  givenName: string;
  jobTitle: "Externals";
  mail: string; // '<givenName>.<surname>@tadnet.eu',
  mobilePhone: null;
  officeLocation: null;
  preferredLanguage: null;
  surname: string;
  userPrincipalName: string; // '<givenName>.<surname>.external@tadnet.eu'
  id: string; // '7cc64737-7c3f-47e5-b121-fe545c260ac0'
};

export type GraphUser = DefaultGraphUser & {
  otherMails: string[];
  userType: UserType;
  mailNickname: string; // 'TEAM_VLB-VLTESTEMAIL22624',
  department: string;
  identities: Identity[];
};

export type SimpleGraphUser = Pick<
  GraphUser,
  "id" | "mail" | "otherMails" | "displayName" | "userType" | "identities" | "department"
>;

// export type GraphError = {
//   message: string;
//   stack: string;
//   code: string; // 'Request_ResourceNotFound';
//   statusCode: 404; // 404,
//   requestId: string; // 'dee8c4c9-63a6-4038-b0c4-7143bc2bc2bf',
//   date: Date;
//   body: string; // `{"code":"Request_ResourceNotFound","message":"Resource 'Martinho.Santos@tadnet.eu' does not exist or one of its queried reference-property objects are not present.","innerError":{"date":"2022-03-17T14:14:21","request-id":"dee8c4c9-63a6-4038-b0c4-7143bc2bc2bf","client-request-id":"b9f4e055-050a-cd14-d19d-03ad06911604"}}`
// };

export type GraphGroup = {
  "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#groups/$entity";
  id: string; // 'c06b7475-95d4-406e-a83c-e148bc326ab6',
  deletedDateTime: null; // null,
  classification: string; // 'ECB-CONFIDENTIAL',
  createdDateTime: string; // '2021-12-06T16:10:46Z',
  creationOptions: string[]; // ['Team', 'ExchangeProvisioningFlags:3552'],
  description: string; // 'test description',
  displayName: string; // 'TEAM_VLB-VLTESTEMAIL22',
  expirationDateTime: null; // null,
  groupTypes: string[]; // ['Unified'],
  isAssignableToRole: null; // null,
  mail: string; // 'TEAM_VLB-VLTESTEMAIL22624@group.tadnet.eu',
  mailEnabled: boolean; // true,
  mailNickname: string; // 'TEAM_VLB-VLTESTEMAIL22624',
  membershipRule: null; // null,
  membershipRuleProcessingState: null; // null,
  onPremisesDomainName: null; // null,
  onPremisesLastSyncDateTime: null; // null,
  onPremisesNetBiosName: null; // null,
  onPremisesSamAccountName: null; // null,
  onPremisesSecurityIdentifier: null; // null,
  onPremisesSyncEnabled: null; // null,
  preferredDataLocation: null; // null,
  preferredLanguage: null; // null,
  proxyAddresses: string; // [    'SPO:SPO_5d4fb0b5-4029-4ce8-993c-039083547513@SPO_f4e69ed8-b558-4494-a61a-031b535160c5',    'SMTP:TEAM_VLB-VLTESTEMAIL22624@group.tadnet.eu',    'smtp:TEAM_VLB-VLTESTEMAIL22624@ecbdevenv.onmicrosoft.com', ],
  renewedDateTime: string; // '2021-12-06T16:10:46Z',
  resourceBehaviorOptions: string[]; // [    'HideGroupInOutlook',    'SubscribeMembersToCalendarEventsDisabled',    'WelcomeEmailDisabled', ],
  resourceProvisioningOptions: string[]; // ['Team'],
  securityEnabled: boolean; // false,
  securityIdentifier: string; // 'S-1-12-1-3228267637-1080989140-1222720680-3060413116',
  theme: null; // null,
  visibility: string; // 'Private',
  onPremisesProvisioningErrors: unknown[]; // [],
};

export type GroupSite = {
  "@odata.context": string; // "https://graph.microsoft.com/v1.0/$metadata#sites/$entity";
  createdDateTime: string; // "2021-12-06T16:10:48.277Z";
  description: string; // "test description";
  displayName: string; // "TEAM_VLB-VLTESTEMAIL22";
  id: string; // "ecbdevenv.sharepoint.com,5d4fb0b5-4029-4ce8-993c-039083547513,6e3bf0c2-5179-462a-b40d-ed61139938d5";
  lastModifiedDateTime: string; // "2022-01-25T13:31:04Z";
  name: string; // "TEAM_VLB-VLTESTEMAIL22624";
  root: unknown;
  siteCollection: { hostname: string }; // "ecbdevenv.sharepoint.com" };
  webUrl: string; // "https://ecbdevenv.sharepoint.com/sites/TEAM_VLB-VLTESTEMAIL22624";
};

type GraphDriveItemUser = {
  email: string; // "valter.vicente@tadnet.eu";
  id: string; // "2f68d409-9b18-4e3f-8f8f-0c47f3e4c709";
  displayName: string; // "Vicente, Valter (External)";
};

type GraphFileSensitivityLabel = {
  displayName: string; // "ECB-RESTRICTED" / "ECB-UNRESTRICTED \ Label" \ "ECB-CONFIDENTIAL \ Business"
  id: string; // "f31720b4-1edb-4628-9fc9-0d2c1e781e19"
  protectionEnabled: boolean; // false
};

export type GraphDrive = {
  id: string;
};

export type GraphDriveItem = {
  "@odata.etag"?: string; // "\"{2CF9C4DD-C34F-4706-9907-86B20B89BAF1},7\"",
  "@microsoft.graph.downloadUrl"?: string; // https://ecbdevenv.sharepoint.com/sites/TEAM_VLB-TESTING_SOFA/_layouts/15/download.aspx?UniqueId=2cf9c4dd-c34f-4706-9907-86b20b89baf1&Translate=false&tempauth=v1.eyJzaXRlaWQiOiI1ZWFiNGUyNC0xNzBjLTRmMjctOTQwZi00NzVjOWZlNTdjZjkiLCJhcHBfZGlzcGxheW5hbWUiOiJbVkxCXSBNMzY1IiwiYXVkIjoiMDAwMDAwMDMtMDAwMC0wZmYxLWNlMDAtMDAwMDAwMDAwMDAwL2VjYmRldmVudi5zaGFyZXBvaW50LmNvbUBmNGU2OWVkOC1iNTU4LTQ0OTQtYTYxYS0wMzFiNTM1MTYwYzUiLCJleHAiOiIxNzM0MDE5OTM5In0.CgoKBHNuaWQSAjY0EgsItO_j9ayyzT0QBRoMNDAuMTI2LjMyLjk5Kix0bXNJSWgrRlV2dVBKTmxHd0xoL3padGJseUxBR01tbnFZNDV0YkR1VjE4PTCUATgBQhChbNmmTbAAoL9KgXEYdewMShBoYXNoZWRwcm9vZnRva2VuegExugEwZ3JvdXAucmVhZCBhbGxzaXRlcy5mdWxsY29udHJvbCBhbGxwcm9maWxlcy5yZWFkwgFJYjhhNjA4YWMtNGFjNC00YmFlLTgzYjQtYTAyOTJjMGE2NTBmQGY0ZTY5ZWQ4LWI1NTgtNDQ5NC1hNjFhLTAzMWI1MzUxNjBjNcgBAQ.fDT5e3SyFn7ofGPTK82GEpMLRV1j6o-8G-qVd0jT9sg&ApiVersion=2.0";
  createdBy: GraphDriveItemUser;
  createdDateTime: string; // "2024-11-25T13:17:43Z"
  eTag: string; // '"{2CF9C4DD-C34F-4706-9907-86B20B89BAF1},7"'
  id: string; // "01SAFZ3365YT4SYT6DAZDZSB4GWIFYTOXR"
  lastModifiedBy: GraphDriveItemUser;
  lastModifiedDateTime: string; // "2024-12-12T13:41:06Z"
  name: string; // "Restricted.docx"
  parentReference: {
    driveType: string; // "documentLibrary"
    driveId: string; // "b!JE6rXgwXJ0-UD0dcn-V8-XNIblzeJcpDjhsAH1ahF1lAlN9-k6ayT6G_89hp44v3"
    id: string; // "01SAFZ3356Y2GOVW7725BZO354PWSELRRZ"
    name: string; // "Shared Documents"
    path: string; // "/drives/b!JE6rXgwXJ0-UD0dcn-V8-XNIblzeJcpDjhsAH1ahF1lAlN9-k6ayT6G_89hp44v3/root:"
    siteId: string; // "5eab4e24-170c-4f27-940f-475c9fe57cf9"
  };
  webUrl: string; // "https://ecbdevenv.sharepoint.com/sites/TEAM_VLB-TESTING_SOFA/_layouts/15/Doc.aspx?sourcedoc=%7B2CF9C4DD-C34F-4706-9907-86B20B89BAF1%7D&file=Restricted.docx&action=default&mobileredirect=true"
  cTag: string; // '"c:{2CF9C4DD-C34F-4706-9907-86B20B89BAF1},5"'
  fileSystemInfo: {
    createdDateTime: string; // "2024-11-25T13:17:43Z"
    lastModifiedDateTime: string; // "2024-12-12T13:41:06Z"
  };
  /** Included if item is `file` */
  file?: {
    hashes: {
      quickXorHash: string; // "qDMn/YecUdGfO428mtJYnktOQJ0="
    };
    mimeType: string; // "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  };
  /** Included if item is `folder` */
  folder?: {
    childCount: number; // 1
    decorator?: {
      iconColor: string; // "darkRed";
    };
  };
  shared: {
    scope: string; // "users"
  };
  size: number; // 32949
  /** Only displayed if included in Graph `$select` */
  sensitivityLabel?: GraphFileSensitivityLabel;
};

export type GraphDriveItemResponse = {
  "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#Collection(driveItem)";
  value: Partial<GraphDriveItem>[];
};

export type PageActivity = {
  access: {
    actionCount: number;
    actorCount: number;
  };
};

export type AllTimeUsage = {
  access: {
    actionCount: number;
    actorCount: number;
  };
};

export type GraphSearchResponse = {
  "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#users";
  "@odata.count": number;
  value: SimpleGraphUser[];
};

export type Institution =
  | "banque-france.fr"
  | "bancaditalia.it"
  | "fma.gv.at"
  | "bundesbank.de"
  | "externe-mitarbeiter.bundesbank.de"
  | "nbb.be"
  | "bof.fi"
  | "dnb.nl"
  | "bportugal.pt"
  | "externos.bportugal.pt"
  | "bde.es"
  | "cnb.cz"
  | "cssf.lu"
  | "finanssivalvonta.fi"
  | "centralbank.ie"
  | "bcl.lu"
  | "bankofgreece.gr"
  | "bafin.de"
  | "esterni.bancaditalia.it"
  | "ecb.europa.eu"
  | "hnb.hr"
  | "acpr.banque-france.fr"
  | "oenb.at"
  | "fi.ee"
  | "nbs.sk"
  | "centralbank.cy"
  | "mfsa.mt"
  | "bnbank.org"
  | "bank.lv"
  | "srb.europa.eu"
  | "bsi.si"
  | "bnro.ro"
  | "lb.lt"
  | "centralbankmalta.org"
  | "fktk.lv"
  | "ec.europa.eu"
  | "riksbank.se"
  | "nationalbanken.dk"
  | "mnb.hu"
  | "eestipank.ee"
  | "acor.banque-france.fr"
  | "eba.europa.eu"
  | "nbp.pl"
  | "cbm.local";
