import { Institution } from "./types";

export const institutionsToCountryMap: Record<
  Institution,
  { institutionAcronym: string; countryCode: string }
> = {
  "banque-france.fr": {
    institutionAcronym: "NCA",
    countryCode: "FR",
  },
  "bancaditalia.it": {
    institutionAcronym: "NCA",
    countryCode: "IT",
  },
  "fma.gv.at": {
    institutionAcronym: "NCA",
    countryCode: "AT",
  },
  "bundesbank.de": {
    institutionAcronym: "NCB",
    countryCode: "DE",
  },
  "externe-mitarbeiter.bundesbank.de": {
    institutionAcronym: "NCB",
    countryCode: "DE",
  },
  "nbb.be": {
    institutionAcronym: "NCA",
    countryCode: "BE",
  },
  "bof.fi": {
    institutionAcronym: "NCB",
    countryCode: "FI",
  },
  "dnb.nl": {
    institutionAcronym: "NCA",
    countryCode: "NL",
  },
  "bportugal.pt": {
    institutionAcronym: "NCB",
    countryCode: "PT",
  },
  "externos.bportugal.pt": {
    institutionAcronym: "NCB",
    countryCode: "PT",
  },
  "bde.es": {
    institutionAcronym: "NCA",
    countryCode: "ES",
  },
  "cnb.cz": {
    institutionAcronym: "NCA",
    countryCode: "CZ",
  },
  "cssf.lu": {
    institutionAcronym: "NCA",
    countryCode: "LU",
  },
  "finanssivalvonta.fi": {
    institutionAcronym: "NCA",
    countryCode: "FI",
  },
  "centralbank.ie": {
    institutionAcronym: "NCA",
    countryCode: "IE",
  },
  "bcl.lu": {
    institutionAcronym: "NCB",
    countryCode: "LU",
  },
  "bankofgreece.gr": {
    institutionAcronym: "NCA",
    countryCode: "GR",
  },
  "bafin.de": {
    institutionAcronym: "NCA",
    countryCode: "DE",
  },
  "esterni.bancaditalia.it": {
    institutionAcronym: "NCA",
    countryCode: "IT",
  },
  "ecb.europa.eu": {
    institutionAcronym: "ECB",
    countryCode: "EU",
  },
  "hnb.hr": {
    institutionAcronym: "NCB",
    countryCode: "HR",
  },
  "acpr.banque-france.fr": {
    institutionAcronym: "NCA",
    countryCode: "FR",
  },
  "oenb.at": {
    institutionAcronym: "NCB",
    countryCode: "AT",
  },
  "fi.ee": {
    institutionAcronym: "NCA",
    countryCode: "EE",
  },
  "nbs.sk": {
    institutionAcronym: "NCA",
    countryCode: "SK",
  },
  "centralbank.cy": {
    institutionAcronym: "NCA",
    countryCode: "CY",
  },
  "mfsa.mt": {
    institutionAcronym: "NCA",
    countryCode: "MT",
  },
  "bnbank.org": {
    institutionAcronym: "OTHER",
    countryCode: "OTHER",
  },
  "bank.lv": {
    institutionAcronym: "NCB",
    countryCode: "LV",
  },
  "srb.europa.eu": {
    institutionAcronym: "SRB",
    countryCode: "EU",
  },
  "bsi.si": {
    institutionAcronym: "NCA",
    countryCode: "SI",
  },
  "bnro.ro": {
    institutionAcronym: "NCA",
    countryCode: "RO",
  },
  "lb.lt": {
    institutionAcronym: "NCA",
    countryCode: "LT",
  },
  "centralbankmalta.org": {
    institutionAcronym: "NCB",
    countryCode: "MT",
  },
  "fktk.lv": {
    institutionAcronym: "NCA",
    countryCode: "LV",
  },
  "ec.europa.eu": {
    institutionAcronym: "EC",
    countryCode: "EU",
  },
  "riksbank.se": {
    institutionAcronym: "NCB",
    countryCode: "SE",
  },
  "nationalbanken.dk": {
    institutionAcronym: "NCB",
    countryCode: "DK",
  },
  "mnb.hu": {
    institutionAcronym: "NCA",
    countryCode: "HU",
  },
  "eestipank.ee": {
    institutionAcronym: "NCB",
    countryCode: "EE",
  },
  "acor.banque-france.fr": {
    institutionAcronym: "NCA",
    countryCode: "FR",
  },
  "eba.europa.eu": {
    institutionAcronym: "EBA",
    countryCode: "EU",
  },
  "nbp.pl": {
    institutionAcronym: "NCB",
    countryCode: "PL",
  },
  "cbm.local": {
    institutionAcronym: "NCB",
    countryCode: "MT",
  },
};
