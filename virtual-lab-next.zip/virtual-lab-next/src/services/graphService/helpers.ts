import { Context } from "@azure/functions";
import GraphClient from "../../utils/graphClient";
import { GraphResponse, SimpleGraphUser } from "./types";
import { getEmailOfUser } from "../../utils/helpers";

export const getAllEntries = async <T>(ctx: Context, query: string) => {
  const client = await GraphClient.get(ctx);

  let url = query;
  const value: T[] = [];

  do {
    const response = (await client
      .api(url)
      // ConsistencyLevel: "eventual" and .count are required for some queries
      // https://learn.microsoft.com/en-us/graph/api/group-list-members?view=graph-rest-1.0&tabs=http
      .headers({
        ConsistencyLevel: "eventual",
      })
      .count(true)
      .get()) as GraphResponse<T[]>;

    value.push(...response.value);
    url = response["@odata.nextLink"];
  } while (url);

  return value;
};

export const formatUser = (user: SimpleGraphUser) => ({
  displayName: user.displayName,
  userType: user.userType,
  email: getEmailOfUser(user),
  oid: user.id,
});
