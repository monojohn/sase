import { ClientCertificateCredential } from "@azure/identity";
import {
  BlobItem,
  BlobServiceClient,
  ContainerClient,
  ContainerListBlobsOptions,
} from "@azure/storage-blob";
import { AZURE_TENANT_ID, INFRA_CERTIFICATE, INFRA_CLIENT_ID } from "../../utils/config";

type BlobStorageConfig = {
  storageContainerName: string;
  storageAccountName: string;
};

class BlobStorageService {
  private readonly blobServiceClient: BlobServiceClient;
  private readonly containerClient: ContainerClient;
  storageContainerName: string;
  storageAccountName: string;

  constructor(config: BlobStorageConfig) {
    this.storageContainerName = config.storageContainerName;
    this.storageAccountName = config.storageAccountName;
    const accountName = this.storageAccountName;
    if (!accountName) throw new Error("Azure Storage accountName not found");
    const authorization = new ClientCertificateCredential(AZURE_TENANT_ID, INFRA_CLIENT_ID, {
      certificate: INFRA_CERTIFICATE,
    });

    this.blobServiceClient = new BlobServiceClient(
      `https://${accountName}.blob.core.windows.net`,
      authorization,
    );

    this.containerClient = this.blobServiceClient.getContainerClient(this.storageContainerName);
  }

  async upload(blob: ArrayBuffer | Uint8Array<ArrayBuffer>, name: string) {
    // Get a reference to a container
    const blobClient = this.containerClient.getBlockBlobClient(name);
    return blobClient.uploadData(blob);
  }

  async download(blobName: string) {
    const blobClient = this.containerClient.getBlobClient(blobName);
    return blobClient.downloadToBuffer();
  }

  async list(options?: ContainerListBlobsOptions) {
    const blobs = this.containerClient.listBlobsFlat(options);
    const blobItems: BlobItem[] = [];
    // eslint-disable-next-line no-restricted-syntax
    for await (const blob of blobs) {
      blobItems.push(blob);
    }
    return blobItems;
  }

  async delete(blobNames: string[]) {
    const blobDeleteBatch = blobNames.map((blobName) => {
      const blobClient = this.containerClient.getBlobClient(blobName);
      return blobClient.delete();
    });
    return Promise.allSettled(blobDeleteBatch);
  }
}

export default BlobStorageService;
