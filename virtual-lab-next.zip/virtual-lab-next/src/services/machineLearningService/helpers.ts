import { TableServiceClient } from "@azure/data-tables";
import { ClientCertificateCredential } from "@azure/identity";
import { BlobServiceClient } from "@azure/storage-blob";
import { QueueServiceClient } from "@azure/storage-queue";
import axios from "axios";
import { AZURE_TENANT_ID, INFRA_CERTIFICATE, INFRA_CLIENT_ID } from "../../utils/config";

const apiMap = {
  ["Microsoft.Insights/components".toLocaleLowerCase()]: "2020-02-02",
  ["Microsoft.KeyVault/vaults".toLocaleLowerCase()]: "2019-09-01",
  ["Microsoft.MachineLearningServices/workspaces".toLocaleLowerCase()]: "2021-04-01",
  ["Microsoft.Storage/storageAccounts".toLocaleLowerCase()]: "2021-04-01",
  ["Microsoft.Network/privateEndpoints".toLocaleLowerCase()]: "2022-05-01",
  ["Microsoft.ContainerRegistry/registries".toLocaleLowerCase()]: "2022-12-01",
  ["Microsoft.MachineLearningServices/workspaces/onlineEndpoints".toLocaleLowerCase()]:
    "2023-10-01",
};

export const getApiVersion = (apiName: string = ""): string => {
  const lowercaseVersion = apiName?.toLocaleLowerCase();
  const version = apiMap[lowercaseVersion];
  if (!version) {
    throw new Error(`${lowercaseVersion} does not exist in ${JSON.stringify(apiMap, null, 2)}`);
  }

  return version;
};

export const privateEndpointTemplate = (
  subscriptionId: string,
  resourceGroup: string,
  azureMlName: string,
  networkRG: string,
  vnetName: string,
  subnetName: string,
  infraName: string,
  tag: string,
  resourceGroupDNS: string,
  subscriptionIdDNS: string,
) => ({
  requests: [
    {
      content: {
        properties: {
          mode: "incremental",
          debugSetting: {
            detailLevel: "none",
          },
          parameters: {
            location: {
              value: "westeurope",
            },
            privateEndpointName: {
              value: `pe-${infraName}`,
            },
            privateLinkResource: {
              value: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.MachineLearningServices/workspaces/${azureMlName}`,
            },
            targetSubResource: {
              value: ["amlworkspace"],
            },
            requestMessage: {
              value: "",
            },
            subnet: {
              value: `/subscriptions/${subscriptionId}/resourceGroups/${networkRG}/providers/Microsoft.Network/virtualNetworks/${vnetName}/subnets/${subnetName}`,
            },
            virtualNetworkId: {
              value: `/subscriptions/${subscriptionId}/resourceGroups/${networkRG}/providers/Microsoft.Network/virtualNetworks/${vnetName}`,
            },
            subnetDeploymentName: {
              value: `UpdateSubnetDeployment-${infraName}`,
            },
            virtualNetworkResourceGroup: {
              value: networkRG,
            },
          },
          template: {
            $schema:
              "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
            // in Sonarqube it is marked as an IP address
            // eslint-disable-next-line sonarjs/no-hardcoded-ip
            contentVersion: "1.0.0.0", // NOSONAR
            parameters: {
              location: {
                type: "string",
              },
              privateEndpointName: {
                type: "string",
              },
              privateLinkResource: {
                type: "string",
              },
              targetSubResource: {
                type: "array",
              },
              requestMessage: {
                type: "string",
              },
              subnet: {
                type: "string",
              },
              virtualNetworkId: {
                type: "string",
              },
              virtualNetworkResourceGroup: {
                type: "string",
              },
              subnetDeploymentName: {
                type: "string",
              },
            },
            resources: [
              {
                location: "[parameters('location')]",
                name: "[parameters('privateEndpointName')]",
                type: "Microsoft.Network/privateEndpoints",
                apiVersion: "2021-05-01",
                properties: {
                  subnet: {
                    id: "[parameters('subnet')]",
                  },
                  customNetworkInterfaceName: `nic-${infraName}`,
                  privateLinkServiceConnections: [
                    {
                      name: "[parameters('privateEndpointName')]",
                      properties: {
                        privateLinkServiceId: "[parameters('privateLinkResource')]",
                        groupIds: "[parameters('targetSubResource')]",
                      },
                    },
                  ],
                },
                tags: {
                  project: tag,
                },
                dependsOn: [],
              },
              {
                apiVersion: "2017-05-10",
                name: `DNSZoneGroup-${infraName}`,
                type: "Microsoft.Resources/deployments",
                resourceGroup,
                dependsOn: ["[parameters('privateEndpointName')]"],
                properties: {
                  mode: "Incremental",
                  template: {
                    $schema:
                      "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
                    // in Sonarqube it is marked as an IP address
                    // eslint-disable-next-line sonarjs/no-hardcoded-ip
                    contentVersion: "1.0.0.0", // NOSONAR
                    resources: [
                      {
                        type: "Microsoft.Network/privateEndpoints/privateDnsZoneGroups",
                        apiVersion: "2021-05-01",
                        name: "[concat(parameters('privateEndpointName'), '/', 'default')]",
                        location: "[parameters('location')]",
                        properties: {
                          privateDnsZoneConfigs: [
                            {
                              name: "privatelink-api-azureml-ms",
                              properties: {
                                privateDnsZoneId: `/subscriptions/${subscriptionIdDNS}/resourceGroups/${resourceGroupDNS}/providers/Microsoft.Network/privateDnsZones/privatelink.api.azureml.ms`,
                              },
                            },
                            {
                              name: "privatelink-notebooks-azure-net",
                              properties: {
                                privateDnsZoneId: `/subscriptions/${subscriptionIdDNS}/resourceGroups/${resourceGroupDNS}/providers/Microsoft.Network/privateDnsZones/privatelink.notebooks.azure.net`,
                              },
                            },
                          ],
                        },
                      },
                    ],
                  },
                },
              },
            ],
          },
          validationLevel: "Template",
        },
        tags: {
          primaryResourceId: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Network/privateEndpoints/pe-${infraName}`,
          marketplaceItemId: "",
        },
      },
      httpMethod: "PUT",
      name: "e29467b7-47be-492c-9b76-4ffaefedf0e7",
      requestHeaderDetails: {
        commandName: "Microsoft_Azure_Network.Deploy.submitDeployment",
      },
      url: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Resources/deployments/Microsoft.PrivateEndpoint-${infraName}?api-version=2020-06-01`,
    },
  ],
});

type SpResponse = {
  nextLink: string;
};

export const getAllEntries = async <T extends SpResponse>(url: string, token: string) => {
  let nextLink = url;
  const value: T[] = [];

  while (nextLink) {
    const { data } = await axios.get<T>(nextLink, {
      headers: { Authorization: `Bearer ${token}` },
    });
    nextLink = data.nextLink;
    value.push(data);
  }

  return value;
};

export const enableStorageAccountLogging = async (accountName: string) => {
  const authorization = new ClientCertificateCredential(AZURE_TENANT_ID, INFRA_CLIENT_ID, {
    certificate: INFRA_CERTIFICATE,
  });
  const queueClient = new QueueServiceClient(
    `https://${accountName}.queue.core.windows.net`,
    authorization,
  );
  const tableClient = new TableServiceClient(
    `https://${accountName}.table.core.windows.net`,
    authorization,
  );
  const blobClient = new BlobServiceClient(
    `https://${accountName}.blob.core.windows.net`,
    authorization,
  );

  return Promise.all([
    queueClient.setProperties({
      queueAnalyticsLogging: {
        version: "1.0",
        deleteProperty: true,
        write: true,
        read: true,
        retentionPolicy: {
          enabled: true,
          days: 3,
        },
      },
    }),
    tableClient.setProperties({
      logging: {
        version: "1.0",
        delete: true,
        write: true,
        read: true,
        retentionPolicy: {
          enabled: true,
          days: 3,
        },
      },
    }),
    blobClient.setProperties({
      blobAnalyticsLogging: {
        version: "1.0",
        deleteProperty: true,
        write: true,
        read: true,
        retentionPolicy: {
          enabled: true,
          days: 3,
        },
      },
    }),
  ]);
};
