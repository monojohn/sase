import { ApplicationInsightsManagementClient } from "@azure/arm-appinsights";
import { Key, KeyVaultManagementClient, SkuName, Vault } from "@azure/arm-keyvault";
import {
  AzureMachineLearningServicesManagementClient,
  Workspace,
} from "@azure/arm-machinelearning";
import { ResourceManagementClient } from "@azure/arm-resources";
import { SecurityCenter } from "@azure/arm-security";
import { StorageAccountCreateParameters, StorageManagementClient } from "@azure/arm-storage";
import { PagedAsyncIterableIterator } from "@azure/core-paging";
import { Context } from "@azure/functions";
import { ClientCertificateCredential } from "@azure/identity";
import axios, { AxiosError } from "axios";
import { v4 as uuidv4 } from "uuid";
import ArmService from "../../utils/armService";
import {
  AKS_ML,
  AZURE_LOCATION,
  AZURE_RESOURCE_GROUP,
  AZURE_TENANT_ID,
  INFRA_CERTIFICATE,
  INFRA_CLIENT_ID,
  ML_COMPUTE_SUBNET,
  ML_NETWORK_RG,
  ML_SUBNET_NAME,
  ML_VNET_NAME,
  STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID,
  STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME,
  SUBSCRIPTION_ID,
} from "../../utils/config";
import { wait, withRetry } from "../../utils/helpers";
import GraphService from "../graphService/graphService";
import { getAllEntries, getApiVersion, privateEndpointTemplate } from "./helpers";
import {
  ActivityLog,
  Compute,
  Computes,
  Endpoint,
  EndpointMetrics,
  GeneralResource,
  OnlineResource,
} from "./types";

type Deployment = {
  properties: {
    provisioningState: string;
  };
};

type Resource = {
  id: string;
  type: string;
  name: string;
};

type RoleAssignment = {
  value: [{ name: string }];
};

type PrivateEndpointProps = {
  subscriptionId: string;
  resourceGroup: string;
  azureMlName: string;
  networkRg: string;
  vnetName: string;
  subnetName: string;
  infraName: string;
  tag: string;
  resourceGroupDns: string;
  subscriptionIdDns: string;
};

type Cost = {
  properties: {
    rows: (string | number)[][];
  };
};

type GpuSelector = {
  accelerator?: string;
  type?: string;
};

type WorkspaceProperties = {
  properties: {
    v1LegacyMode: boolean;
  };
};

type StorageAccountCreationProps = {
  subscriptionId: string;
  resourceGroupName: string;
  storageAccountName: string;
  keyVaultKey: Key;
  keyVault: Vault;
  tags: Record<string, string>;
};

type WorkspaceCreationProps = {
  subscriptionId: string;
  resourceGroup: string;
  storageAccountName: string;
  azureMlName: string;
  keyVaultName: string;
  appInsightsName: string;
  tags: Record<string, string>;
};

const MachineLearningService = {
  /**
   * Connects to Azure Resource Manager.
   * Used by modules that make use of Azure ARM library
   */
  connect() {
    return new ClientCertificateCredential(AZURE_TENANT_ID, INFRA_CLIENT_ID, {
      certificate: INFRA_CERTIFICATE,
    });
  },

  getWorkspaceUrlByName(workspaceName: string) {
    return `https://ml.azure.com/?tid=${AZURE_TENANT_ID}&wsid=/subscriptions/${SUBSCRIPTION_ID}/resourcegroups/${AZURE_RESOURCE_GROUP}/workspaces/${workspaceName}`;
  },

  isComputeInstanceGPU(computeInstance: Compute) {
    return computeInstance.properties.properties.vmSize.toLowerCase().startsWith("standard_n");
  },

  createStorageAccount(
    ctx: Context,
    credentials: ClientCertificateCredential,
    props: StorageAccountCreationProps,
  ) {
    const { subscriptionId, resourceGroupName, storageAccountName, keyVaultKey, keyVault, tags } =
      props;
    ctx.log(`Creating Storage account: ${storageAccountName}`);
    const client = new StorageManagementClient(credentials, subscriptionId);

    const identity = `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME}`;

    const config: StorageAccountCreateParameters = {
      location: AZURE_LOCATION,
      sku: { name: "Standard_ZRS" },
      kind: "StorageV2",
      tags,
      enableHttpsTrafficOnly: true,
      // NOTE: disabling publicNetworkAccess prevents datastores from being selectable
      publicNetworkAccess: "Enabled",
      allowBlobPublicAccess: false,
      minimumTlsVersion: "TLS1_2",

      identity: {
        type: "UserAssigned",
        userAssignedIdentities: {
          [`${identity}`]: {},
        },
      },
      encryption: {
        encryptionIdentity: {
          encryptionUserAssignedIdentity: identity,
        },
        keySource: "Microsoft.Keyvault",
        services: {
          file: {
            keyType: "Account",
            enabled: true,
          },
          blob: {
            keyType: "Account",
            enabled: true,
          },
          queue: {
            keyType: "Account",
            enabled: true,
          },
          table: {
            keyType: "Account",
            enabled: true,
          },
        },
        keyVaultProperties: {
          keyName: keyVaultKey.name,
          keyVaultUri: keyVault.properties.vaultUri,
        },
      },

      // NOTE: enable when private endpoints work
      // networkRuleSet: {
      //   defaultAction: "Deny",
      //   virtualNetworkRules: [
      //     {
      //       virtualNetworkResourceId: `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${ML_NETWORK_RG}/providers/Microsoft.Network/virtualNetworks/${ML_VNET_NAME}/subnets/${ML_SUBNET_NAME}`,
      //       action: "Allow",
      //     },
      //     {
      //       virtualNetworkResourceId: `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${ML_NETWORK_RG}/providers/Microsoft.Network/virtualNetworks/${ML_VNET_NAME}/subnets/${ML_COMPUTE_SUBNET}`,
      //       action: "Allow",
      //     },
      //   ],
      // },
    };

    ctx.log("config", JSON.stringify(config, null, 2));

    return client.storageAccounts.beginCreateAndWait(resourceGroupName, storageAccountName, config);
  },

  updateStorageAcc(
    ctx: Context,
    credentials: ClientCertificateCredential,
    storageAccountName: string,
    workspaceName: string,
  ) {
    ctx.log(`Updating Storage account: ${storageAccountName}`);
    const client = new StorageManagementClient(credentials, SUBSCRIPTION_ID);

    return client.storageAccounts.update(AZURE_RESOURCE_GROUP, storageAccountName, {
      networkRuleSet: {
        bypass: "AzureServices",

        defaultAction: "Deny",
        virtualNetworkRules: [
          {
            virtualNetworkResourceId: `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${ML_NETWORK_RG}/providers/Microsoft.Network/virtualNetworks/${ML_VNET_NAME}/subnets/${ML_SUBNET_NAME}`,
            action: "Allow",
          },
          {
            virtualNetworkResourceId: `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${ML_NETWORK_RG}/providers/Microsoft.Network/virtualNetworks/${ML_VNET_NAME}/subnets/${ML_COMPUTE_SUBNET}`,
            action: "Allow",
          },
        ],
        resourceAccessRules: [
          {
            tenantId: AZURE_TENANT_ID,
            resourceId: `/subscriptions/${SUBSCRIPTION_ID}/resourcegroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}`,
          },
        ],
      },
    });
  },

  updateBlobService(
    ctx: Context,
    credentials: ClientCertificateCredential,
    storageAccountName: string,
  ) {
    ctx.log(`Updating blob services for storage account: ${storageAccountName}`);
    const client = new StorageManagementClient(credentials, SUBSCRIPTION_ID);

    return client.blobServices.setServiceProperties(AZURE_RESOURCE_GROUP, storageAccountName, {
      deleteRetentionPolicy: {
        enabled: true,
        days: 7,
      },
    });
  },

  async createKeyVault(
    ctx: Context,
    credentials: ClientCertificateCredential,
    subscriptionId: string,
    tenantId: string,
    resourceGroup: string,
    keyVaultName: string,
    tags: Record<string, string>,
  ) {
    ctx.log(`Creating Key vault: ${keyVaultName}`);
    const sku = {
      name: "standard" as SkuName,
      family: "A",
    };

    const client = new KeyVaultManagementClient(credentials, subscriptionId);
    return client.vaults.beginCreateOrUpdateAndWait(resourceGroup, keyVaultName, {
      location: AZURE_LOCATION,
      tags,
      properties: {
        tenantId,
        sku,
        accessPolicies: [
          {
            tenantId,
            permissions: {
              keys: ["unwrapKey", "wrapKey", "get"],
            },
            objectId: STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID,
          },
        ],
        enableSoftDelete: true,
        enablePurgeProtection: true,
        // NOTE: disabling publicNetworkAccess prevents datastores from being selectable
        // publicNetworkAccess: "disabled",
        enabledForDiskEncryption: true,
      },
    });
  },

  async createKeyVaultKey(
    ctx: Context,
    credentials: ClientCertificateCredential,
    subscriptionId: string,
    resourceGroup: string,
    keyVaultName: string,
    keyVaultKeyName: string,
    tags: Record<string, string>,
  ) {
    ctx.log(`Creating Key vault key: ${keyVaultKeyName}`);

    const client = new KeyVaultManagementClient(credentials, subscriptionId);
    return client.keys.createIfNotExist(resourceGroup, keyVaultName, keyVaultKeyName, {
      tags,
      properties: {
        kty: "RSA",
        keySize: 2048,
        attributes: {
          enabled: true,
        },
      },
    });
  },

  createAppInsights(
    ctx: Context,
    credentials: ClientCertificateCredential,
    subscriptionId: string,
    resourceGroup: string,
    appInsightsName: string,
    tags: Record<string, string>,
  ) {
    ctx.log(`Creating Application Insights: ${appInsightsName}`);

    const params = {
      location: AZURE_LOCATION,
      kind: "other",
      // Note: applicationType has bad types, must be forced with "any"
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-explicit-any
      applicationType: "other" as any,
      tags,
    };
    const client = new ApplicationInsightsManagementClient(credentials, subscriptionId);
    return client.components.createOrUpdate(resourceGroup, appInsightsName, params);
  },

  createWorkspace(
    ctx: Context,
    credentials: ClientCertificateCredential,
    props: WorkspaceCreationProps,
  ) {
    const {
      subscriptionId,
      resourceGroup,
      storageAccountName,
      azureMlName,
      keyVaultName,
      appInsightsName,
      tags,
    } = props;
    ctx.log(`Creating AzureML workspace ${azureMlName}`);
    const params: Workspace = {
      location: AZURE_LOCATION,
      identity: { type: "SystemAssigned" },
      applicationInsights: `subscriptions/${subscriptionId}/resourcegroups/${resourceGroup}/providers/microsoft.insights/components/${appInsightsName}`,
      keyVault: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.KeyVault/vaults/${keyVaultName}`,
      storageAccount: `/subscriptions/${subscriptionId}/resourcegroups/${resourceGroup}/providers/Microsoft.Storage/storageAccounts/${storageAccountName}`,
      hbiWorkspace: false,
      friendlyName: tags?.project,
      tags,
    };

    const client = new AzureMachineLearningServicesManagementClient(credentials, subscriptionId);
    return client.workspaces.beginCreateOrUpdateAndWait(resourceGroup, azureMlName, params);
  },

  async getAllResources<T>(list: PagedAsyncIterableIterator<T>) {
    const resources: T[] = [];

    let done = false;
    do {
      const next = (await list.next()) as { value: T; done: boolean };
      done = next.done;
      const resource = next.value;

      if (resource) {
        resources.push(resource);
      }
    } while (!done);
    return resources;
  },

  async getUnhealthyAssessments(
    securityCenterClient: SecurityCenter,
    assessmentDisplayName: string,
  ) {
    const assessments = await this.getAllResources(
      securityCenterClient.assessments.list(`/subscriptions/${SUBSCRIPTION_ID}`),
    );
    return assessments.filter(
      ({ displayName, status }) =>
        status?.code === "Unhealthy" && displayName === assessmentDisplayName,
    );
  },

  async modifyAzureMLQuota(
    ctx: Context,
    credentials: ClientCertificateCredential,
    subscriptionId: string,
    location: string,
    resourceGroup: string,
    azureMlName: string,
  ) {
    const params = {
      value: [
        {
          id: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.MachineLearningServices/workspaces/${azureMlName}/quotas/Standard_DSv2_Family_Cluster_Dedicated_vCPUs`,
          type: "Microsoft.MachineLearningServices/workspaces/quotas",
          limit: 32,
          unit: "Count",
        },
        {
          id: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.MachineLearningServices/workspaces/${azureMlName}/quotas/Standard_NV_Family_Cluster_Dedicated_vCPUs`,
          type: "Microsoft.MachineLearningServices/workspaces/quotas",
          limit: 18,
          unit: "Count",
        },
        {
          id: `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.MachineLearningServices/workspaces/${azureMlName}/quotas/Standard_Dv2_Family_Cluster_Dedicated_vCPUs`,
          type: "Microsoft.MachineLearningServices/workspaces/quotas",
          limit: 8,
          unit: "Count",
        },
      ],
    };
    ctx.log("Updating AI | ML workspace vCPUs quotas");
    const client = new AzureMachineLearningServicesManagementClient(credentials, subscriptionId);

    return client.quotas.update(location, params);
  },
  /**
   * Main permissions function, used to call the groupId fetching function and createRoleAssignment
   */
  async createPermissions(
    ctx: Context,
    subscriptionId: string,
    resourceGroup: string,
    groupName: string,
    roleId: string,
    azureMlName: string,
  ) {
    ctx.log(`Creating permissions for ${groupName}`);
    const groupId = await GraphService.getGroupIdByName(ctx, groupName);

    const { token } = await ArmService.get(ctx);
    const scope = `subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.MachineLearningServices/workspaces/${azureMlName}`;
    const roleAssignmentId = uuidv4();
    const url = `https://management.azure.com/${scope}/providers/Microsoft.Authorization/roleAssignments/${roleAssignmentId}?api-version=2015-07-01`;

    try {
      const { data } = await axios.put<void>(
        url,
        {
          properties: {
            roleDefinitionId: `${scope}/providers/Microsoft.Authorization/roleDefinitions/${roleId}`,
            principalId: groupId,
          },
        },
        { headers: { Authorization: `Bearer ${token}` } },
      );
      return data;
    } catch (err: unknown) {
      const error = err as AxiosError<{ errors: string[]; error: string }>;
      const prettyError = error?.response?.data?.errors?.join("\n");
      ctx.log(
        `Failed to create permissions for ${groupName}\n`,
        prettyError ?? error?.response?.data.error ?? error,
      );
      throw prettyError ? new Error(prettyError) : err;
    }
  },

  async deleteWorkspaceEndpoints(
    ctx: Context,
    client: ResourceManagementClient,
    resource: Resource,
  ) {
    const { id, name, type } = resource;
    const endpoints = await this.getOnlineEndpoints(ctx, name);
    await Promise.all(
      endpoints.map(async (endpoint) => {
        ctx.log(`Deleting ${endpoint.type} ${endpoint.name}`);
        return client.resources.beginDeleteByIdAndWait(endpoint.id, getApiVersion(endpoint.type));
      }),
    );

    const apiVersion = getApiVersion(type);

    // needs to be retried because endpoints are not deleted right away and workspace deletion complains of nested resources
    return withRetry(
      async () => {
        if (endpoints.length) {
          await wait(30);
        }
        return client.resources.beginDeleteByIdAndWait(id, apiVersion);
      },
      ctx,
      5,
    );
  },

  async deleteWorkspace(ctx: Context, credentials: ClientCertificateCredential, groupName: string) {
    const client = new ResourceManagementClient(credentials, SUBSCRIPTION_ID);

    ctx.log(`Getting ML resources for ${groupName} by tag`);
    const resources = client.resources.list({
      filter: `tagname eq 'project' and tagvalue eq '${groupName}'`,
    });

    const promises: Promise<void>[] = [];

    // eslint-disable-next-line no-restricted-syntax -- for await of is the cleanest way to write async iterations
    for await (const resource of resources) {
      const { id, type, name } = resource;
      if (
        type === "Microsoft.Network/networkInterfaces" ||
        type === "microsoft.operationalinsights/workspaces"
      ) {
        continue;
      }

      const apiVersion = getApiVersion(type);
      ctx.log(`Deleting ${type}: ${name} | ${apiVersion}`);

      if (!name) {
        throw new Error(`Resource name not defined: '${name}`);
      }

      if (!id) {
        throw new Error(`Resource id not defined: '${id}`);
      }

      if (type === "Microsoft.MachineLearningServices/workspaces") {
        const workspaceProperties = await MachineLearningService.getWorkspaceProperties(ctx, name);
        // if legacy mode is true, getting the endpoints would fail
        if (workspaceProperties.properties.v1LegacyMode === true) {
          promises.push(client.resources.beginDeleteByIdAndWait(id, apiVersion));
        } else {
          promises.push(
            MachineLearningService.deleteWorkspaceEndpoints(ctx, client, {
              id,
              name,
              type,
            }),
          );
        }
      } else {
        promises.push(client.resources.beginDeleteByIdAndWait(id, apiVersion));
      }
    }

    return promises;
  },

  async getCosts(context: Context, from: string, to: string) {
    const { token } = await ArmService.get(context);
    context.log("Getting costs");
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/providers/Microsoft.CostManagement/query?api-version=2024-08-01`;
    const body = {
      type: "ActualCost",
      dataSet: {
        aggregation: {
          totalCost: {
            name: "Cost",
            function: "Sum",
          },
        },
        grouping: [
          {
            type: "TagKey",
            name: "project",
          },
        ],
      },
      timeframe: "Custom",
      timePeriod: {
        from,
        to,
      },
    };
    // costs will be an array with cost, tag name (project), project name, currency. e.g. [ 29.892992481217, 'project', 'cypress-09may2023-512', 'EUR' ]
    const { data } = await axios.post<Cost>(url, body, {
      headers: {
        Authorization: `Bearer ${token}`,
        Clienttype: "CostAnalysis",
        "Content-Type": "application/json",
      },
    });
    return data;
  },

  async getComputes(context: Context, workspaceName: string) {
    const { token } = await ArmService.get(context);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/computes?api-version=2021-03-01-preview`;
    const computeData = await axios.get<Computes>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return computeData.data.value;
  },

  async deleteCompute(context: Context, workspaceName: string, computeName: string) {
    const { token } = await ArmService.get(context);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/computes/${computeName}?api-version=2021-03-01-preview&underlyingResourceAction=Delete`;
    return axios.delete(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  },

  async updateComputeIdleSchedule(
    context: Context,
    workspaceName: string,
    computeName: string,
    idleTimeBeforeShutdown: string,
  ) {
    const { token } = await ArmService.get(context);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/computes/${computeName}/updateIdleShutdownSetting?api-version=2024-01-01-preview`;
    return axios.post<void>(
      url,
      { idleTimeBeforeShutdown },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  },

  async getActivityLog(ctx: Context, resourceId: string, startDate: string, endDate: string) {
    const filter = `eventTimestamp ge '${startDate}' and eventTimestamp le '${endDate}' and ResourceUri eq '${resourceId}'`;
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/providers/Microsoft.Insights/eventtypes/management/values?api-version=2015-04-01&$filter=${filter}`;

    ctx.log(`Getting all data for ${resourceId} `);
    const entries = await getAllEntries<{ value: ActivityLog[]; nextLink: string }>(url, token);

    return entries.reduce((acc, activity) => {
      acc.push(...activity.value);
      return acc;
    }, [] as ActivityLog[]);
  },

  async hasUserActivityLogs(
    ctx: Context,
    resourceId: string,
    userMails: string[],
    startDate: string,
    endDate: string,
  ) {
    const filter = `eventTimestamp ge '${startDate}' and eventTimestamp le '${endDate}' and ResourceUri eq '${resourceId}'`;
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/providers/Microsoft.Insights/eventtypes/management/values?api-version=2015-04-01&$filter=${filter}`;

    ctx.log(`Checking activity logs for ${resourceId} `);
    let nextLink = url;

    while (nextLink) {
      const { data } = await axios.get<{ value: ActivityLog[]; nextLink: string }>(nextLink, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (data.value.some(({ caller }) => userMails.includes(caller.toLocaleLowerCase()))) {
        return true;
      }
      nextLink = data.nextLink;
    }
    return false;
  },

  async getWorkspaceProperties(ctx: Context, workspaceName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}?api-version=2023-04-01`;
    const { data } = await axios.get<WorkspaceProperties>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return data;
  },

  async getOnlineEndpoints(ctx: Context, workspaceName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/onlineEndpoints?api-version=2023-04-01`;

    const { data } = await axios.get<{ value: OnlineResource[] }>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.value;
  },

  async getOnlineDeployments(ctx: Context, workspaceName: string, onlineEndpoint: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/onlineEndpoints/${onlineEndpoint}/deployments?api-version=2023-04-01`;

    const { data } = await axios.get<{ value: OnlineResource[] }>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.value;
  },

  async getBatchEndpoints(ctx: Context, workspaceName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/batchEndpoints?api-version=2024-04-01`;

    const { data } = await axios.get<{ value: OnlineResource[] }>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.value;
  },

  async getServerlessEndpoints(ctx: Context, workspaceName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/serverlessEndpoints?api-version=2024-04-01`;

    const { data } = await axios.get<{ value: OnlineResource[] }>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.value;
  },

  async getEndpointMetrics(
    ctx: Context,
    workspaceName: string,
    resourceId: string,
    deployments: string[],
    startTime: string,
    endTime: string,
  ) {
    const { token } = await ArmService.get(ctx);
    const url = `https://ml.azure.com/api/westeurope/metric/v2.0/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/azuremonitor/getsamples`;
    const metricIds = deployments.map((deployment) => ({
      name: "RequestsPerMinute",
      namespace: "System.Resource",
      derivedLabelValues: {
        deployment,
      },
    }));
    const body = {
      resourceId,
      startTime,
      endTime,
      type: "Average",
      metricIds,
    };
    const { data } = await axios.post<EndpointMetrics>(url, body, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.metricSamples;
  },

  async getResource<T>(context: Context, workspaceName: string, resourceName: string) {
    const { token } = await ArmService.get(context);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/${resourceName}?api-version=2022-10-01`;
    const { data } = await axios.get<{ value: T[] }>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.value;
  },

  async createNetworkPermission(
    ctx: Context,
    subscriptionId: string,
    vnetName: string,
    groupName: string,
    roleId: string,
    networkResourceGroup: string,
  ) {
    ctx.log(`Creating network permissions for ${groupName}`);
    const groupId = await GraphService.getGroupIdByName(ctx, groupName);

    const { token } = await ArmService.get(ctx);
    const scope = `subscriptions/${subscriptionId}/resourceGroups/${networkResourceGroup}/providers/Microsoft.Network/virtualNetworks/${vnetName}`;
    const roleAssignmentId = uuidv4();
    const url = `https://management.azure.com/${scope}/providers/Microsoft.Authorization/roleAssignments/${roleAssignmentId}?api-version=2015-07-01`;

    try {
      await axios.put<void>(
        url,
        {
          properties: {
            roleDefinitionId: `${scope}/providers/Microsoft.Authorization/roleDefinitions/${roleId}`,
            principalId: groupId,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );
    } catch (err: unknown) {
      const error = err as AxiosError<{
        errors: string[];
        error: { code: string; message: string };
      }>;

      if (error?.response?.data?.error?.code !== "RoleAssignmentExists") {
        // allow 'RoleAssignmentExists' error through
        const prettyError = error?.response?.data?.errors?.join("\n");
        ctx.log(
          `Failed to create network permissions for ${groupName}\n`,
          prettyError ?? error?.response?.data.error ?? error,
        );
        throw prettyError ? new Error(prettyError) : err;
      }
    }
  },

  async deleteNetworkPermission(
    ctx: Context,
    subscriptionId: string,
    vnetName: string,
    groupName: string,
    networkResourceGroup: string,
  ) {
    ctx.log(`Deleting network permissions for ${groupName}`);
    const groupId = await GraphService.getGroupIdByName(ctx, groupName);

    const { token } = await ArmService.get(ctx);
    const { data: roleAssignment } = await axios.get<RoleAssignment>(
      `https://management.azure.com/subscriptions/${subscriptionId}/resourceGroups/${networkResourceGroup}/providers/Microsoft.Network/virtualNetworks/${vnetName}/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01&$filter=principalId eq '${groupId}'`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
    const assignmentName = roleAssignment?.value?.[0]?.name;
    if (!assignmentName) {
      ctx.log(`No assignment to delete`);
      return;
    }

    try {
      const url = `https://management.azure.com/subscriptions/${subscriptionId}/resourceGroups/${networkResourceGroup}/providers/Microsoft.Network/virtualNetworks/${vnetName}/providers/Microsoft.Authorization/roleAssignments/${assignmentName}?api-version=2022-04-01`;
      const { data } = await axios.delete<void>(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      ctx.log("Management response", data);
    } catch (err: unknown) {
      const error = err as AxiosError<{ errors: string[]; error: string }>;
      const prettyError = error?.response?.data?.errors?.join("\n");
      ctx.log(
        `Failed to delete network permissions for ${groupName}\n`,
        prettyError ?? error?.response?.data.error ?? error,
      );
      throw prettyError ? new Error(prettyError) : err;
    }
  },

  async updateMlNetworkAccess(
    ctx: Context,
    subscriptionId: string,
    resourceGroup: string,
    azureMlName: string,
  ) {
    ctx.log("Switching workspace network access to public");
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.MachineLearningServices/workspaces/${azureMlName}?api-version=2022-10-01`;
    return axios.patch<void>(
      url,
      {
        properties: {
          publicNetworkAccess: "Enabled",
        },
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  },

  async verifyDeployment(
    ctx: Context,
    deploymentName: string,
    resourceGroup: string,
    subscriptionId: string,
  ) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Resources/deployments/${deploymentName}?api-version=2021-04-01`;
    const { data } = await axios.get<Deployment>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return data.properties.provisioningState;
  },

  async createMlPrivateEndpoint(ctx: Context, props: PrivateEndpointProps) {
    const {
      subscriptionId,
      resourceGroup,
      azureMlName,
      networkRg,
      vnetName,
      subnetName,
      infraName,
      tag,
      resourceGroupDns,
      subscriptionIdDns,
    } = props;

    ctx.log("Creating ML private endpoint");
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/batch?api-version=2020-06-01`;
    try {
      const { data } = await axios.post<void>(
        url,
        privateEndpointTemplate(
          subscriptionId,
          resourceGroup,
          azureMlName,
          networkRg,
          vnetName,
          subnetName,
          infraName,
          tag,
          resourceGroupDns,
          subscriptionIdDns,
        ),
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );
      ctx.log({ data: JSON.stringify(data, null, 2) });

      return data;
    } catch (err: unknown) {
      const error = err as AxiosError<{ errors: string[]; error: string }>;
      const prettyError = error?.response?.data?.errors?.join("\n");
      ctx.log(
        `Failed to create private endpoint\n`,
        prettyError ?? error?.response?.data.error ?? error,
      );
      throw prettyError ? new Error(prettyError) : err;
    }
  },

  getAllWorkspaces() {
    const credentials = MachineLearningService.connect();
    const client = new AzureMachineLearningServicesManagementClient(credentials, SUBSCRIPTION_ID);
    // get workspaces by resource group since there are other resource groups like AI PoC
    return client.workspaces.listByResourceGroup(AZURE_RESOURCE_GROUP);
  },

  /**
   * Returns all ML projects
   */
  async getAllProjects() {
    // get url of all ML Workspaces
    const workspaces: Workspace[] = [];
    const workspaceList = MachineLearningService.getAllWorkspaces() as {
      next: () => Promise<{ value: Workspace }>;
    };

    let { value: workspace } = await workspaceList.next();

    // for each workspace
    while (workspace) {
      // check the state because there are workspaces stuck in "Deleted" state
      if (workspace.provisioningState === "Succeeded") {
        // generate url from name
        workspaces.push(workspace);
      }
      // get next value and restarts
      const { value } = await workspaceList.next();
      workspace = value;
    }

    return workspaces;
  },

  async getWorkspaceCount() {
    const projects = await MachineLearningService.getAllProjects();
    return projects.length;
  },

  async getWorkspaceByProjectName(projectName: string): Promise<Workspace | null> {
    const workspaceList = MachineLearningService.getAllWorkspaces() as {
      next: () => Promise<{ value: Workspace }>;
    };

    let { value: workspace } = await workspaceList.next();

    // for each workspace
    while (workspace) {
      if (workspace.tags?.project === projectName && workspace.provisioningState === "Succeeded") {
        return workspace;
      }

      // get next value and restarts
      workspace = (await workspaceList.next()).value;
    }

    return null;
  },

  async getWorkspaceEndpoints(ctx: Context, workspaceName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://ml.azure.com/api/westeurope/modelmanagement/v1.0/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/services`;
    const { data } = await axios.get<{ value: Endpoint[] }>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return data.value;
  },

  async getPipelines(ctx: Context, workspaceName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://ml.azure.com/api/westeurope/index/v1.0/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/entities`;
    const { data } = await axios.post<{ value: GeneralResource[] }>(
      url,
      { filters: [{ field: "type", operator: "eq", values: ["runs"] }] },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );

    return data.value;
  },

  async createComputeCluster(ctx: Context, workspaceName: string, computeName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/computes/${computeName}?api-version=2023-04-01`;
    await axios.put<{ value: GeneralResource[] }>(
      url,
      {
        location: "westeurope",
        tags: {},
        properties: {
          computeType: "AmlCompute",
          computeLocation: "westeurope",
          disableLocalAuth: true,
          properties: {
            vmSize: "Standard_DS3_v2",
            vmPriority: "Dedicated",
            scaleSettings: {
              minNodeCount: 0,
              maxNodeCount: 1,
              nodeIdleTimeBeforeScaleDown: "PT120S",
            },
            remoteLoginPortPublicAccess: "Disabled",
            enableNodePublicIp: false,
            subnet: {
              id: `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${ML_NETWORK_RG}/providers/Microsoft.Network/virtualNetworks/${ML_VNET_NAME}/subnets/${ML_COMPUTE_SUBNET}`,
            },
          },
        },
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  },
  async setMlBuildTarget(ctx: Context, workspaceName: string, computeName: string) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}?api-version=2023-04-01`;
    await axios.patch<{ value: GeneralResource[] }>(
      url,
      {
        properties: {
          imageBuildCompute: computeName,
        },
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  },
  async attachAKS(
    ctx: Context,
    workspaceName: string,
    computeName: string,
    nodeSelector: GpuSelector,
    gpu: number,
  ) {
    const { token } = await ArmService.get(ctx);
    const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.MachineLearningServices/workspaces/${workspaceName}/computes/${computeName}?api-version=2022-10-01`;
    await axios.put<{ value: GeneralResource[] }>(
      url,
      {
        location: "westeurope",
        properties: {
          description: "VL k8s compute",
          resourceId: `/subscriptions/${SUBSCRIPTION_ID}/resourcegroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.ContainerService/managedClusters/${AKS_ML}`,
          computeType: "Kubernetes",
          properties: {
            namespace: workspaceName,
            defaultInstanceType: "defaultInstanceType",
            instanceTypes: {
              defaultInstanceType: {
                nodeSelector,
                resources: {
                  requests: {
                    cpu: "1",
                    memory: "4Gi",
                    "nvidia.com/gpu": gpu,
                  },
                  limits: {
                    cpu: "4",
                    memory: "8Gi",
                    "nvidia.com/gpu": gpu,
                  },
                },
              },
            },
          },
        },
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  },

  async moveResource(
    resources: string[],
    sourceResourceGroup: string,
    targetResourceGroup: string,
    credentials: ClientCertificateCredential,
  ) {
    const client = new ResourceManagementClient(credentials, SUBSCRIPTION_ID);
    return client.resources.beginMoveResourcesAndWait(sourceResourceGroup, {
      resources,
      targetResourceGroup,
    });
  },
};

export default MachineLearningService;
