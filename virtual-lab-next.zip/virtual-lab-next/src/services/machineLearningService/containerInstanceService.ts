import { ContainerInstanceManagementClient } from "@azure/arm-containerinstance";
import ArmService from "../../utils/armService";
import { AZURE_RESOURCE_GROUP, SUBSCRIPTION_ID } from "../../utils/config";
import { Tags } from "./types";

type Container = {
  name: string; // "sklearn-mnist-svc-3aed",
};

export type ContainerGroup = {
  id: string; // "/subscriptions/dec849c6-3664-4372-9569-749eb6820434/resourceGroups/rg-VLProd/providers/Microsoft.ContainerInstance/containerGroups/classificatio-best-model-deploy-wFTAgCleRUOwGOy0RrClqA";
  name: string; // "classificatio-best-model-deploy-wFTAgCleRUOwGOy0RrClqA";
  type: string; // "Microsoft.ContainerInstance/containerGroups";
  location: "westeurope";
  tags: Tags;
  containers: Container[];
};

const ContainerInstanceService = {
  async getContainerGroups() {
    const client = new ContainerInstanceManagementClient(
      ArmService.getArmClient(),
      SUBSCRIPTION_ID,
    );

    const containerGroupsIterator =
      client.containerGroups.listByResourceGroup(AZURE_RESOURCE_GROUP);

    const groups: ContainerGroup[] = [];
    // eslint-disable-next-line no-restricted-syntax
    for await (const containerGroup of containerGroupsIterator) {
      // real type is not currently exported
      groups.push(containerGroup as ContainerGroup);
    }

    return groups;
  },

  async setTags(containerGroupName: string, tags: Tags) {
    const client = new ContainerInstanceManagementClient(
      ArmService.getArmClient(),
      SUBSCRIPTION_ID,
    );

    await client.containerGroups.update(AZURE_RESOURCE_GROUP, containerGroupName, {
      tags,
    });
  },
};

export default ContainerInstanceService;
