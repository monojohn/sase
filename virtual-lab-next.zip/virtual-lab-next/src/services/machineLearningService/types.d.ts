export type Workspaces = {
  value: [{ name: string; tags: { project: string } }];
};
export type Compute = {
  name: string;
  properties: {
    createdOn: string;
    modifiedOn: string;
    computeType: string;
    properties: {
      state: string;
      vmSize: string;
      idleTimeBeforeShutdown: string;
      schedules: { computeStartStop: string };
      createdBy: { userId: string };
    };
  };
};

export type Computes = {
  value: Compute[];
};

export type ActivityLog = {
  authorization: {
    scope: string; // /subscriptions/1900189e-cd37-4df6-abf1-19a2839b2112/resourceGroups/rg-VLDev/providers/Microsoft.MachineLearningServices/workspaces/test1-workspace/privateEndpointConnectionProxies/testfl-pe-fl-20.f8310ce5-c0db-4234-b8b0-58291b7b2d6d
  };
  caller: string; // 1ad26fed-d49b-493d-820d-e4f05f6e7537
  operationName: {
    value: string; // Microsoft.MachineLearningServices/workspaces/computes/stop/action
  };
  status: {
    value: string; // Succeeded
  };
  eventTimestamp: string; // 2022-11-17T09:32:08.7703457Z
};

export type Tags = {
  [name: string]: string;
};

export type Endpoint = {
  containerResourceRequirements: [unknown];
  imageId: null;
  imageDigest: null;
  scoringUri: string; // 'http://3958a697-f7cf-4381-b1fd-b1fe209a3f05.westeurope.azurecontainer.io/score',
  location: "westeurope";
  authEnabled: false;
  sslEnabled: false;
  appInsightsEnabled: false;
  dataCollection: [unknown];
  sslCertificate: "";
  sslKey: string; // '',
  cname: null;
  publicIp: string; // '20.103.34.187',
  publicFqdn: string; // '3958a697-f7cf-4381-b1fd-b1fe209a3f05.westeurope.azurecontainer.io',
  swaggerUri: string; // 'http://3958a697-f7cf-4381-b1fd-b1fe209a3f05.westeurope.azurecontainer.io/swagger.json',
  modelConfigMap: null;
  environment: [unknown];
  environmentImageRequest: [unknown];
  vnetConfiguration: null;
  encryptionProperties: null;
  id: string; // 'classificatio-best-model-deploy',
  name: string; // 'classificatio-best-model-deploy',
  description: null;
  tags: Tags;
  kvTags: Tags;
  properties: [unknown];
  operationId: string; // '74bae8ae-6873-49dd-ba3e-98a31575c43b',
  createdTime: string; // '2022-02-09T18:16:15.1232512Z',
  updatedTime: string; // '2022-02-09T18:16:15.1232512Z',
  computeType: string; // 'ACI',
  createdBy: [unknown];
  endpointName: null;
};

export type GeneralResource = {
  id: string;
};

export type OnlineResource = {
  id: string;
  name: string;
  type: string;
  properties: {
    modifiedOn: string;
  };
};

export type EndpointMetrics = {
  metricSamples: [
    {
      value: [
        {
          data: {
            RequestsPerMinute: number;
          };
        },
      ];
    },
  ];
};
