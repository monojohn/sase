import { ContainerRegistryManagementClient } from "@azure/arm-containerregistry";
import ArmService from "../../utils/armService";
import { SUBSCRIPTION_ID } from "../../utils/config";
import { Tags } from "./types";

const ContainerRegistryService = {
  /**
   *
   * @param resourceGroup i.e. rg-VLTest
   * @param registryName i.e. 1ad9a531fd824296bafcb011c8bdaec2
   * @returns Registry
   */
  async get(resourceGroup: string, registryName: string) {
    const client = new ContainerRegistryManagementClient(
      ArmService.getArmClient(),
      SUBSCRIPTION_ID,
    );

    return client.registries.get(resourceGroup, registryName);
  },

  /**
   * Set tags on container registry
   *
   * @param resourceGroup i.e. rg-VLTest
   * @param registryName i.e. 1ad9a531fd824296bafcb011c8bdaec2
   * @param tags tag object
   * @returns
   */
  async setTags(resourceGroup: string, registryName: string, tags: Tags) {
    const client = new ContainerRegistryManagementClient(
      ArmService.getArmClient(),
      SUBSCRIPTION_ID,
    );

    return client.registries.beginUpdateAndWait(resourceGroup, registryName, {
      tags,
    });
  },
};

export default ContainerRegistryService;
