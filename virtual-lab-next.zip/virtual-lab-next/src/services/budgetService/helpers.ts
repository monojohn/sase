import moment from "moment";

export const createBudgetsBody = (
  teamName: string,
  projectName: string,
  supportEmail: string,
  startDate?: string,
) => {
  const startOfMonth = moment.utc().startOf("month").toDate().toUTCString();
  return {
    name: teamName,
    eTag: null,
    properties: {
      category: "Cost",
      amount: 800,
      timeGrain: "Monthly",
      timePeriod: {
        startDate: startDate ?? startOfMonth,
        endDate: "Sat, 31 Dec 2050 00:00:00 GMT",
      },
      notifications: {
        Actual_GreaterThan_60_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 60,
          contactEmails: [supportEmail],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
        Actual_GreaterThan_90_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 90,
          contactEmails: [supportEmail],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
        Actual_GreaterThan_100_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 100,
          contactEmails: [supportEmail],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
        Actual_GreaterThan_150_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 150,
          contactEmails: [supportEmail],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
      },
      filter: {
        tags: {
          name: "project",
          operator: "In",
          values: [projectName],
        },
      },
    },
  };
};
