export type Budget = {
  id: string; // "/subscriptions/231020c2-5e29-4ec6-8e69-c879b0c4ba0b/providers/Microsoft.Consumption/budgets/TEAM_VLB-ALEX_TEST_53";
  name: string; // "TEAM_VLB-ALEX_TEST_53";
  type: "Microsoft.Consumption/budgets";
  eTag: string; // '"1d82714a7b23780"';
  properties: {
    timePeriod: {
      startDate: "2022-02-01T00:00:00Z";
      endDate: "2050-12-31T00:00:00Z";
    };
    timeGrain: "Monthly";
    amount: 800;
    currentSpend: {
      amount: 0;
      unit: "EUR";
    };
    category: "Cost";
    notifications: {
      actual_GreaterThan_60_Percent: {
        enabled: true;
        operator: "GreaterThan";
        threshold: 60;
        contactEmails: ["virtuallab@ecb.europa.eu"];
        contactRoles: [];
        contactGroups: [];
        thresholdType: "Actual";
      };
      actual_GreaterThan_90_Percent: {
        enabled: true;
        operator: "GreaterThan";
        threshold: 90;
        contactEmails: ["virtuallab@ecb.europa.eu"];
        contactRoles: [];
        contactGroups: [];
        thresholdType: "Actual";
      };
      actual_GreaterThan_100_Percent: {
        enabled: true;
        operator: "GreaterThan";
        threshold: 100;
        contactEmails: ["virtuallab@ecb.europa.eu"];
        contactRoles: [];
        contactGroups: [];
        thresholdType: "Actual";
      };
      actual_GreaterThan_150_Percent: {
        enabled: true;
        operator: "GreaterThan";
        threshold: 150;
        contactEmails: ["virtuallab@ecb.europa.eu"];
        contactRoles: [];
        contactGroups: [];
        thresholdType: "Actual";
      };
    };
    filter: {
      tags: {
        name: "project";
        operator: "In";
        values: string[];
      };
    };
  };
};
