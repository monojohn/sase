import { Context } from "@azure/functions";
import axios, { AxiosError, AxiosInstance } from "axios";
import ArmService from "../../utils/armService";
import { ML_BUDGET_EMAIL, SUBSCRIPTION_ID } from "../../utils/config";
import { getTeamGroupName } from "../../utils/helpers";
import SlackService from "../slackService";
import { createBudgetsBody } from "./helpers";
import { Budget } from "./types.d";

const API_VERSION = "api-version=2021-10-01";

class BudgetService {
  private readonly axios: AxiosInstance;

  constructor(ctx: Context) {
    this.axios = axios.create({
      baseURL: `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/providers/Microsoft.Consumption`,
    });

    // inject auth header to all requests
    this.axios.interceptors.request.use(async (config) => {
      const { token } = await ArmService.get(ctx);

      // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-unsafe-member-access
      config.headers.Authorization = `Bearer ${token}`;

      return config;
    });
  }

  async getBudgets() {
    const budgets = await this.axios.get<{ value: Budget[] }>(`/budgets?${API_VERSION}`);
    return budgets.data.value;
  }

  async getProjectBudget(projectName: string) {
    const teamName = getTeamGroupName(projectName);
    const budgets = await this.axios.get<Budget>(`/budgets/${teamName}?${API_VERSION}`);
    return budgets.data;
  }

  async createProjectBudget(ctx: Context, projectName: string) {
    const teamName = getTeamGroupName(projectName);

    return this.axios
      .put<void>(
        `/budgets/${teamName}?${API_VERSION}`,
        createBudgetsBody(teamName, projectName, ML_BUDGET_EMAIL),
      )
      .catch(async (err) => {
        ctx.log(err, "Budget not created");
        await SlackService.logWarning(
          ctx,
          new Error(`Failed to create budget for project'${projectName}'`),
        );
      });
  }

  async updateBudget(projectName: string, startDate: string) {
    const teamName = getTeamGroupName(projectName);

    return this.axios.put<void>(
      `/budgets/${teamName}?${API_VERSION}`,
      createBudgetsBody(teamName, projectName, ML_BUDGET_EMAIL, startDate),
    );
  }

  async deleteBudget(ctx: Context, budgetName: string) {
    try {
      await this.axios.delete<unknown>(`/budgets/${budgetName}?${API_VERSION}`);
    } catch (e) {
      const err = e as AxiosError<{ error: { code?: number; message?: string } }>;
      // allow 404's to pass through
      if (err.response?.data?.error?.code !== 404) {
        const errorMessage = err?.response?.data?.error?.message ?? "unknown error";
        ctx.log("Budget not deleted", err?.response?.data ?? err?.response ?? err, errorMessage);
        await SlackService.logWarning(ctx, new Error(`Budget not deleted: ${errorMessage}`));
      }
    }
  }
}

export default BudgetService;
