export const doesItemMatchFilters = <T extends object>(item: T, filters: T) => {
  const entries = Object.entries(filters) as [keyof T, T[keyof T]][];
  for (let index = 0; index < entries.length; index++) {
    const [key, value] = entries[index];
    if (item[key] !== value) {
      return false;
    }
  }
  return true;
};

export const filterByProp = <T extends object>(items: T[], filters: T): T[] =>
  items.filter((item) => doesItemMatchFilters(item, filters));
