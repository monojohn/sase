import type { AccessibilityLevel, ConfidentialityLevel } from "../dbConnector/enums";
import { WorkspaceType } from "./enums";

export type Tag = {
  key: string;
  name: string;
};

export type ProjectTag = {
  key: string; // uuid
  name: string; // free text
};

export type SpProject = {
  AzureDevOpsProject: string | null; // "BeingCreated";
  AzureMLWorkspace: string | null;
  AzureMLWorkspaceType: WorkspaceType | null;
  AzureMLWorkspaceJustification: string | null;
  AzureMLWorkspaceExploratoryJusti: string | null; // NOTE: Azure automatically limits field names

  Created: string; // "2022-01-14T14:46:46Z";
  ID: number; // 113;
  Id: number; // 113;
  Modified: string; // "2022-01-17T14:35:57Z";
  ProjectConfClassification: ConfidentialityLevel; // "ECB-restricted";
  ProjectDescription: string; // "test project creation";
  ProjectImage: {
    Description: string; // "Project Icon";
    Url: string; //  "https://via.placeholder.com/150";
  };
  ProjectMS365GroupID: string; // "9376593e-8b27-4e28-9471-f6bb53657a6e";
  ProjectMembersId: number[];
  ProjectMembersStringId: string[];
  ProjectOwnersId: number[]; // number array [33];
  ProjectOwnersStringId: string[]; // string array ["33"];
  ProjectResources: null | string; // string array with { id: number; url: string;   text: string; }
  ProjectSiteUrl: {
    Description: string; // "https://ecbdevenv.sharepoint.com/sites/TEAM_VLB-TEST-PROJECT-ROSANNE-5";
    Url: string; // "https://ecbdevenv.sharepoint.com/sites/TEAM_VLB-TEST-PROJECT-ROSANNE-5";
  };
  ProjectStatus: string; // "Active";
  ProjectTags: string; //  // string array with { key: string; name: string; }
  ProjectType: AccessibilityLevel; // "Private";
  SiteID: string; // "23301559-2e61-4aec-91f0-67be8155de3b";
  Title: string; // "test-project-rosanne-5";
  memberGroupId: string; // "8e47d42a-cce8-42b4-a984-1195093dfe3a";
  ownerGroupId: string; // "f3a9c686-a001-4668-b7dd-16937e58552e";
  iconName: string;
  Entitlements?: string | null; // string array of entitlement names
  Roles?: string | null; // string array of role names

  /**
   * Data time string of last edit to Roles or Permissions.
   *
   * Write: Must be set as an ISO string, i.e. new Date().toISOString()
   *
   * Read: Must be converted to a string, i.e. new Date(project.PermissionsChangedDate)
   */
  PermissionsChangedDate: string; // "2022-01-17T14:35:57Z";

  /**
   * When ECB system access is required, Entitlements and Roles must be present in the project
   */
  RequiresEcbSystemsAccess: boolean | null;

  /**
   * Non ECB projects have special review requirements
   */
  isNonEscbProject: boolean | null;
};

export type FileWithModifiedBy = {
  ModifiedBy?: {
    Email: string;
  };
  TimeLastModified: string;
};

export type FileVersion = {
  Created: string;
  CreatedBy?: {
    Email: string;
  };
};
