import { Context } from "@azure/functions";
import { SPFI } from "@pnp/sp";

type SpError = {
  status: number; // 404
};

/**
 * Helper function meant to be used exclusively by spListService
 * Adds user to group
 *
 * @param client SPFI client
 * @param groupId visitor / member / owner group id
 * @param loginNames names of groups to add. i.e. ECBPROD-VLB-USG-SEC-VirtualLab-Users
 * @returns
 */
export const addUserToGroup = (
  ctx: Context,
  client: SPFI,
  groupId: number,
  loginNames: string[],
) => {
  ctx.log(`Adding users ${loginNames.join()} to ${groupId} group`);

  return Promise.all(
    loginNames.map(async (loginName) => {
      try {
        await client.web.siteGroups.getById(groupId).users.add(`c:0t.c|tenant|${loginName}`);
        ctx.log(`Adding of ${loginName} to ${groupId} was successful`);
      } catch (err) {
        // 404's can happen when assignment hasn't been completed.
        // To prevent false errors, we ignore 404's
        const error = err as SpError;
        if (error?.status !== 404) {
          throw err;
        }

        ctx.log(`404 detected for ${loginName}`, error);
      }
    }),
  );
};

/**
 * Helper function mean to be used exclusively by spListService
 * Removes user from group
 *
 * @param client SPFI client
 * @param groupId visitor / member / owner group id
 * @param loginNames names of groups to add. i.e. ECBPROD-VLB-USG-SEC-VirtualLab-Users
 * @returns
 */
export const removeUserFromGroup = (client: SPFI, groupId: number, loginNames: string[]) =>
  Promise.all(
    loginNames.map(async (loginName) => {
      try {
        await client.web.siteGroups
          .getById(groupId)
          .users.removeByLoginName(`c:0t.c|tenant|${loginName}`);
      } catch (err) {
        // 404's can happen when assignment hasn't been completed.
        // To prevent false errors, we ignore 404's
        const error = err as SpError;
        if (error?.status !== 404) {
          throw err;
        }
      }
    }),
  );
