import { Context } from "@azure/functions";
import { HUBSITE_NAME } from "../../utils/config";
import SpClient from "../../utils/sharepointClient";
import { SpLists } from "./enums";
import { withSharepointRetry } from "./withSharepointRetry";

// ignore auto generated props for creation
export type CreateItem<T> = Omit<T, "Id" | "ID" | "Created" | "Modified">;

type QueryConfig<T> = {
  select?: (keyof T)[];
  expand?: (keyof T)[];
  filter?: string;
  limit?: number;
  skip?: number;
  order?: {
    orderBy: keyof T;
    asc?: boolean;
  };
};

const SpListService = {
  getList(list: SpLists, site = HUBSITE_NAME) {
    return SpClient.getClient(site).web.lists.getByTitle(list);
  },

  getListItems(list: SpLists, site = HUBSITE_NAME) {
    return SpListService.getList(list, site).items;
  },

  getById<T>(ctx: Context, list: SpLists, id: number, config: QueryConfig<T> = {}) {
    const { select: fieldList } = config;
    const query = SpListService.getListItems(list);

    if (fieldList) {
      query.select(...(fieldList as string[]));
    }

    return withSharepointRetry(ctx, () => query.getById(id)<T>());
  },

  add<T>(ctx: Context, list: SpLists, item: CreateItem<T>) {
    return withSharepointRetry(ctx, () => SpListService.getListItems(list).add(item));
  },

  update<T>(ctx: Context, list: SpLists, id: number, update: Partial<T>) {
    return withSharepointRetry(ctx, async () =>
      SpListService.getListItems(list).getById(id).update(update),
    );
  },

  removeById(ctx: Context, list: SpLists, id: number) {
    return withSharepointRetry(ctx, async () =>
      SpListService.getListItems(list).getById(id).delete(),
    );
  },

  createQuery<T>(list: SpLists, config: QueryConfig<T> = {}) {
    const { select, filter, skip, limit, expand, order } = config;
    const query = SpListService.getListItems(list);

    if (filter) {
      query.filter(filter);
    }

    if (select) {
      query.select(select.join(", "));
    }

    if (expand) {
      query.expand(expand.join());
    }

    if (skip) {
      query.skip(skip);
    }

    if (limit) {
      query.top(limit);
    }

    if (order?.orderBy) {
      const { orderBy, asc = true } = order;
      query.orderBy(orderBy as string, asc);
    }

    return query;
  },
};

export default SpListService;
