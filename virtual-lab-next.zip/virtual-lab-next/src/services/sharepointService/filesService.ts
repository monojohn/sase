import { IFileInfo } from "@pnp/sp/files";
import moment from "moment";
import { MAX_DAYS_UNCHANGED } from "../../features/fileExpiration/helpers";
import FileExpirationModel from "../dbConnector/models/fileExpirationModel";

const FilesService = {
  async getExpiringFileIds(pid: string) {
    const files = await FileExpirationModel.find({ pid }, { fileId: 1, _id: 0 }).lean();
    return files.map(({ fileId }) => fileId);
  },

  async logExpiringFiles(pid: string, files: IFileInfo[]) {
    const expiringFileIds = await FilesService.getExpiringFileIds(pid);

    const newExpiringFiles = files
      // removing already logged items
      .filter(({ UniqueId }) => !expiringFileIds.includes(UniqueId))
      // prepare new entries
      .map((file) => ({
        pid,
        expirationTimestamp: moment
          .utc(file.TimeLastModified)
          .add(MAX_DAYS_UNCHANGED, "days")
          .format(),
        fileName: file.Name,
        fileId: file.UniqueId,
      }));

    // create new entries in bulk
    return FileExpirationModel.create(newExpiringFiles);
  },
};

export default FilesService;
