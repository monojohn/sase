import { Context } from "@azure/functions";
import { IFileInfo } from "@pnp/sp/files";
import XLSX from "xlsx";
import { HUBSITE_NAME } from "../../utils/config";
import SharePointClient from "../../utils/sharepointClient";
import { FileVersion, FileWithModifiedBy } from "./types";

const SpFolderService = {
  getFolders(site = HUBSITE_NAME) {
    const client = SharePointClient.getClient(site);
    return client.web.folders();
  },

  getFolderByName(ctx: Context, name: string, site = HUBSITE_NAME) {
    ctx.log(`Getting '${name}' folder of ${site}`);
    const client = SharePointClient.getClient(site);
    return client.web.folders.getByUrl(name)();
  },

  async getFiles(ctx: Context, folderName: string, site = HUBSITE_NAME) {
    const client = SharePointClient.getClient(site);
    const [original, ...split] = folderName.split("/");
    let base = client.web.rootFolder.folders.getByUrl(original);
    // navigate to correct place
    for (const name of split) {
      base = base.folders.getByUrl(name);
    }

    // try to get all files and folders
    const [allSubFoldersPromise, filesPromise] = await Promise.allSettled([
      base.folders(),
      base.files(),
    ]);

    if (allSubFoldersPromise.status !== "fulfilled" || filesPromise.status !== "fulfilled") {
      ctx.log("Error fetching files and/or folders", allSubFoldersPromise, filesPromise);
      return [];
    }

    const allSubFolders = allSubFoldersPromise.value;
    const files = filesPromise.value;

    // get all folders with items to avoid pointless iterations
    const foldersWithItems = allSubFolders.filter(({ ItemCount }) => ItemCount > 0);

    // get all files in subfolder
    const subFiles = await Promise.allSettled(
      foldersWithItems.map(({ Name }) =>
        SpFolderService.getFiles(ctx, `${folderName}/${Name}`, site),
      ),
    );

    // flatten arrays
    for (const promise of subFiles) {
      if (promise.status === "fulfilled") {
        files.push(...promise.value);
      }
    }

    // return flattened files
    return files;
  },

  /**
   * Returns all files for a project
   *
   * @param ctx Context
   * @param site Starting with TEAM_VLB-<project-name>
   * @returns
   */
  async getProjectFiles(ctx: Context, site: string) {
    const folder = await SpFolderService.getFolderByName(ctx, "Shared Documents", site);

    if (!folder) {
      ctx.log(`Folder not found`);
      return [];
    }

    return SpFolderService.getFiles(ctx, folder.Name, site);
  },

  async getFilesVersions(site: string, files: IFileInfo[]) {
    const client = SharePointClient.getClient(site);
    return Promise.all(
      files.map(async (file) => {
        const [fileInfo, versions] = await Promise.all([
          client.web
            .getFileByServerRelativePath(file.ServerRelativeUrl)
            .select("TimeLastModified", "ModifiedBy/Email")
            .expand("ModifiedBy")() as unknown as Promise<FileWithModifiedBy>,
          client.web
            .getFileByServerRelativePath(file.ServerRelativeUrl)
            .versions.select("Created", "CreatedBy/Email")
            .expand("CreatedBy")() as unknown as Promise<FileVersion[]>,
        ]);
        return { fileInfo, versions };
      }),
    );
  },

  async uploadFile(ctx: Context, file: XLSX.WorkBook, folder: string, fileName: string) {
    const client = SharePointClient.getClient();
    const blob: Blob = XLSX.write(file, {
      bookType: "xlsx",
      type: "buffer",
    }) as Blob;

    const folderInfo = await client.web.folders.getByUrl(folder).select("ServerRelativeUrl")();

    await client.web
      .getFolderByServerRelativePath(folderInfo.ServerRelativeUrl)
      .files.addChunked(fileName, blob, {
        progress: (data) => {
          ctx.log(`Uploading file - stage ${data.stage}`);
        },
        Overwrite: true,
      });
  },

  async downloadFile(ctx: Context, fileRelativeUrl: string) {
    const client = SharePointClient.getClient();
    return client.web.getFileByServerRelativePath(fileRelativeUrl).getBuffer();
  },

  async createGeneralFolder(ctx: Context, site: string) {
    ctx.log(`Creating folder for ${site}`);

    const client = SharePointClient.getClient(site);
    await client.web.rootFolder.folders
      .getByUrl("Shared Documents")
      .addSubFolderUsingPath("General");
  },
};

export default SpFolderService;
