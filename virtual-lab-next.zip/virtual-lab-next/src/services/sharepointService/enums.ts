export enum VlBenefits {
  Communication = "Communication",
  Collaboration = "Collaboration",
  Innovation = "Innovation",
  Quality = "Quality",
}

export enum SpLists {
  AWAITING_OWNERS_LIST = "AwaitingOwners",
  JOIN_REQUESTS = "JoinRequests",
  LEAVE_REQUESTS = "LeaveRequests",
  PROJECTS = "Projects",
  FOLLOWING_SITES = "FollowingSitesList",
  USER_ACTIONS = "UserActions",
  FEEDBACK = "Feedback",
  FEEDBACK_ACTIONS = "FeedbackActions",
  USAGE = "Usage",
  FILE_EXPIRATION = "FileExpiration",
  NOTIFICATIONS = "Notifications",
  ML_WHITELIST = "MlWhitelist",
  ML_WHITELIST_REQUESTS = "MlWhitelistRequests",
  SITE_PAGES = "Site Pages",
  USER_NOTIFICATIONS = "UserNotifications",

  DATA_GOVERNANCE = "DataGovernance",
}

export enum FeedbackActionValue {
  INPUT_PROVIDED = "inputProvided",
  CLICKED_AWAY = "clickedAway",
}

export enum WorkspaceType {
  SECURED = "Secured",
  EXPLORATORY = "Exploratory",
}
