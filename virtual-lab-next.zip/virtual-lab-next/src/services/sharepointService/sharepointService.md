# Sharepoint Service

This doc aims to document the various learnings and gotchas.

## Format of LoginName for SP users

SP login names can take multiple formats, i.e.:

- `c:0o.c|federateddirectoryclaimprovider|<group_guid>`
- `c:0o.c|federateddirectoryclaimprovider|<group_guid>`
- `c:0(.s|true`
- `c:0-.f|rolemanager|spo-grid-all-users/<tenant_id>`
- `c:0t.c|tenant|<guid>`

LoginNames should follow this format:

```
<IdentityClaim>:0<ClaimType><ClaimValueType><AuthMode>|<OriginalIssuer (optional)>|<ClaimValue>
```

Of which:

### IdentityClaim

indicates the type of claim and is the following

- `i` for an identity claim
- `c` for any other claim

### ClaimType

indicates the format for the claim value and is the following:

- `#` for a user logon name
- `.` for an anonymous user
- `5` for an email address
- `!` for an identity provider
- `+` for a Group security identifier (SID)
- `-` for a role
- `%` for a farm ID
- `?` for a name identifier
- `\` for a private personal identifier (PPID)
- `e` for a user principal name (UPN)
- `"` for a user ID
- `$` for a distribution list security identifier (SID)
- `&` for a process identity security identifier (SID)
- `'` for a process identity logon name
- `(` for an authenticated user
- `)` for a primary security identifier (SID)
- `\*` for a primary group security identifier (SID)
- `0` for an authorization decision
- `1` for a country
- `2` for a date of birth
- `3` for a deny only security identifier (SID)
- `4` for DNS
- `6` for a gender
- `7` for a given name
- `8` for a hash
- `9` for a home phone
- `<` for a locality
- `=` for a mobile phone
- `>` for a name
- `@` for other phone
- `[` for a postal code
- `]` for RSA
- `^` for a secure identifier (SID)
- `\_` for a service principal name (SPN)
- `"` for a state or province
- `a` for a street address
- `b` for a surname
- `c` for a system
- `d` for a thumbprint
- `f` for a uniform resource name (URI)
- `g` for a web page

### ClaimValueType

indicates the type of formatting for the claim value and is the following

- `.` for a string
- `+` for an RFC 822-formatted name
- `)` for an integer
- `"` for a Boolean
- `#` for a date
- `$` for a date with time
- `&` for a double
- `!` for a Base64 formatted binary
- `0` for a X.500 formatted name

### AuthMode

indicates the type of authentication used to obtain the identity claim and is the following

- `w` for Windows claims (no original issuer)
- `s` for the local SharePoint security token service (STS) (no original issuer)
- `t` for a trusted issuer
- `m` for a membership issuer
- `r` for a role provider issuer
- `f` for forms-based authentication
- `c` for a claim provider

### OriginalIssuer

indicates the original issuer of the claim.
Values can include:

- tenant
- federateddirectoryclaimprovider
- rolemanager

### ClaimValue

Unknown

### Examples

- Everyone: `c:0(.s|true`
- Everyone except external users: `c:0-.f|rolemanager|spo-grid-all-users/<tenant_id>`
- Group memebers: `c:0o.c|federateddirectoryclaimprovider|<group_guid>`
- Group Owners: `c:0o.c|federateddirectoryclaimprovider|<group_guid>`
- `Company Administrator` in Sharepoint Admin console: `c:0t.c|tenant|<guid>`
- An O365 user: `i:0#.f|membership|<email>`
