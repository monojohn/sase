import { Context } from "@azure/functions";
import FavoriteProjectModel from "../dbConnector/models/favoriteProjectModel";

const FavoritesService = {
  /**
   * Returns an ordered 2 dimensional array with project names and favorites count
   *
   * @param ctx
   * @returns [['<project-name>', <like-count>],['<project-name2>', <like-count>], ...]
   */
  async getMostFavorited(ctx: Context) {
    ctx.log("Getting all favorites");
    const favorites = await FavoriteProjectModel.find().lean();

    ctx.log("Reducing entries");
    // count number of favorites
    const reduced = favorites.reduce(
      (acc, item) => {
        acc[item.pid] = (acc[item.pid] ?? 0) + 1;
        return acc;
      },
      {} as Record<string, number>,
    );

    ctx.log("Ordering reduced entries");
    return Object.entries(reduced).sort((a, b) => b[1] - a[1]);
  },
};

export default FavoritesService;
