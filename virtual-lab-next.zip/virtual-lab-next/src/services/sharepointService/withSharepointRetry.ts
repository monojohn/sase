import { Context } from "@azure/functions";
import { AxiosError } from "axios";

export const withSharepointRetry = async <T>(ctx: Context, func: () => Promise<T>): Promise<T> => {
  let lastError: AxiosError | undefined;
  for (let index = 0; index < 5; index++) {
    try {
      const output = await func();
      if (index > 0) {
        ctx.log(`Sharepoint call succeeded at attempt #${index + 1}`);
      }

      return output;
    } catch (e) {
      lastError = e as AxiosError;
      // only retry when there is no response (i.e. Timeout) or server error (> 500)
      if (!lastError.response || lastError.response?.status >= 500) {
        ctx.log(
          `Attempt failed, with status ${lastError.response?.status} - ${lastError.name}, retrying`,
          lastError,
        );
      } else {
        throw lastError;
      }
    }
  }

  throw lastError ?? new Error("Failed to run sharepoint call");
};
