import { Context } from "@azure/functions";
import { HUBSITE_ID, HUBSITE_NAME, VL_MEMBERS_GROUP_ID } from "../../utils/config";
import SpClient from "../../utils/sharepointClient";
import { FeedbackActionValue, SpLists, VlBenefits } from "./enums";
import { addUserToGroup, removeUserFromGroup } from "./sharepointService.helpers";
import SpListService from "./spListService";
import { withRetry } from "../../utils/helpers";

export type SpEntry<T> = T & {
  ID: number; //  77,
  Id: number; //  77,
  Modified: string; // '2021-12-22T09:44:57Z',
  Created: string; // '2021-12-22T09:44:57Z',
};

export type Favorite = SpEntry<{
  UserIdentity: string; // 'Alexandru.Matlac@tadnet.eu',
  Title: string; // 'Test Alex 62',
}>;

export type CreateFavorite = Pick<Favorite, "UserIdentity" | "Title">;

export type AltFeedback = SpEntry<{
  hoursPerWeek: number;
  benefits: VlBenefits[];
}>;

export type Feedback = SpEntry<{
  rating: number; // 10
  comment?: string; // 'great'
}>;

export type FeedbackAction = SpEntry<{
  oid: string; // oid
  action: FeedbackActionValue; // 'inputProvided' || 'clickedAway'
}>;

export type JoinRequest = SpEntry<{
  Title: string; // upn
  SiteId: string; // uuid
  Message?: string; // free text
}>;

export type OwnershipInvite = SpEntry<{
  Title: string; // 'user UPN',
  SiteId: string; // '1640166296740',
}>;

export type LeaveRequest = SpEntry<{
  Title: string; // 'upn',
  SiteId: string; // '1640166296740',
}>;

export type SpItem = SpEntry<{
  actionTime: string;
  Title: string; // 'upn',
  SiteId: string; // '1640166296740',
}>;

export type Usage = {
  mlComputeCount: number;
  mlAverageComputeCount: number;
  mlComputeTotalTime: number;
  mlAverageCreatedComputeCount: number;
  mlAverageDeletedComputeCount: number;
  mlAverageComputeTime: number;
  mlJobsCount: number;
  mlJobsAverage: number;
  mlModelsCount: number;
  mlModelsAverage: number;
  mlEndpointsCount: number;
  mlEndpointsAverage: number;
  mlDataAssetsCount: number;
  mlDataAssetsAverage: number;
  mlPipelineRunsCount: number;
  mlPipelineRunsAverage: number;
  gitTotalCommits: number;
  gitAverageCommits: number;
  gitTotalActiveRepositories: number;
  gitAverageActiveRepositories: number;
  gitTotalRepositories: number;
  gitTotalActiveProjects: number;
  gitTotalProjects: number;
  plannerTotalTasksCount: number;
  plannerCount: number;
  plannerAverageTasksCount: number;
  teamsTotalReplyMessages: number;
  teamsAverageReplyMessages: number;
  teamsTotalPostMessages: number;
  teamsAveragePostMessages: number;
  teamsTotalChannelMessages: number;
  teamsAverageChannelMessages: number;
  teamsTotalReactions: number;
  teamsAverageReactions: number;
  teamsTotalMentions: number;
  teamsAverageMentions: number;
  teamsTotalChannels: number;
  teamsAverageChannels: number;
};

export type ExpiringFile = {
  ID: string;
  pid: number; // project id
  expirationTimestamp: string; // timestamp when the file will expire
  target: string; // name of file
  fileId: string; // id of file

  Created: string; // '2021-12-22T09:44:57Z',
  Modified: string; // '2021-12-22T09:44:57Z',
};

const SharePointService = {
  /**
   * Create page under <site>/SitePages<pageUrl>.aspx
   *
   * @param siteId Either a site name or a group name (i.e. TEAM_VLB-<name>)
   * @param pageUrl i.e. "Files" would become "Files.aspx"
   * @returns void
   */
  async createPage(siteId: string, pageUrl: string) {
    const client = SpClient.getClient(siteId);
    const page = await client.web.addClientsidePage(pageUrl, pageUrl);
    return page.save();
  },

  async createFilesPage(ctx: Context, projectName: string, siteId: string) {
    const client = SpClient.getClient(siteId);

    await client.web.update({
      QuickLaunchEnabled: false,
    });

    const documentsList = await client.web.lists
      .getByTitle("Documents")
      .select("RootFolder/ServerRelativeUrl")
      .expand("RootFolder")();

    await withRetry(
      () =>
        client.web.rootFolder.update({
          WelcomePage: documentsList.RootFolder.ServerRelativeUrl.split("/").slice(-1)[0],
        }),
      ctx,
      5,
    );
  },

  /**
   * Gets quick launch object (without call)
   *
   * @param siteId Either a site name or a group name (i.e. TEAM_VLB-<name>)
   * @returns INavigationNodes
   */
  getQuickLaunch(siteId: string) {
    return SpClient.getClient(siteId).web.navigation.quicklaunch;
  },

  /**
   * Adds groups as visitors
   *
   * @param siteId MUST be the siteId - the TEAM-VLB group can work but will be out of sync
   * @param groups names or ids of groups to add. i.e. ['ECBPROD-VLB-USG-SEC-VirtualLab-Users'] or ['047afb47-d2dd-40ec-b52a-4691cd15e62b']
   * @returns
   */
  async addVisitorGroups(ctx: Context, siteId: string, groups: string[]) {
    const client = SpClient.getClient(siteId);
    const visitorGroup = await client.web.associatedVisitorGroup();
    return addUserToGroup(ctx, client, visitorGroup.Id, groups);
  },

  /**
   * Removes groups from visitors
   *
   * @param site Either a site name or a group name (i.e. TEAM_VLB-<name>)
   * @param groups names or ids of groups to add. i.e. ['ECBPROD-VLB-USG-SEC-VirtualLab-Users'] or ['047afb47-d2dd-40ec-b52a-4691cd15e62b']
   * @returns
   */
  async removeVisitorGroups(site: string, groups: string[]) {
    const client = SpClient.getClient(site);
    const visitorGroup = await client.web.associatedVisitorGroup();
    return removeUserFromGroup(client, visitorGroup.Id, groups);
  },

  async addOwnerGroups(ctx: Context, site: string, groupNames: string[]) {
    const client = SpClient.getClient(site);
    const ownerGroup = await client.web.associatedOwnerGroup();
    return addUserToGroup(ctx, client, ownerGroup.Id, groupNames);
  },

  async setSitePagesPermissions(ctx: Context, site: string) {
    const client = SpClient.getClient(site);
    const spList = SpListService.getList(SpLists.SITE_PAGES, site);

    ctx.log("Breaking role inheritance");
    await spList.breakRoleInheritance(true, false);
    const memberGroup = await client.web.associatedMemberGroup();

    ctx.log("Breaking role inheritance");
    const [readRole, editRole] = await Promise.all([
      client.web.roleDefinitions.getByName("Read")(),
      client.web.roleDefinitions.getByName("Edit")(),
    ]);

    ctx.log("Changing role assignments");
    return Promise.all([
      spList.roleAssignments.add(memberGroup.Id, readRole.Id),
      spList.roleAssignments.remove(memberGroup.Id, editRole.Id),
    ]);
  },

  /**
   *
   * @param site Same as Team name, i.e. TEAM_VLB-<PROJECT-NAME>
   * @returns void
   */
  async joinHubSite(ctx: Context, site: string) {
    const info = await SpClient.getClient(site).site.getContextInfo();
    ctx.log(info);
    ctx.log(HUBSITE_ID);
    ctx.log(HUBSITE_NAME);
    return SpClient.getClient(site).site.joinHubSite(HUBSITE_ID);
  },

  /**
   * Returns a boolean signaling if the project is public or not
   *
   * @param siteId usually the team group name (TEAM_VLB-<name>) but can differ
   */
  async isProjectPublic(siteId: string) {
    const client = SpClient.getClient(siteId);
    const visitorGroup = await client.web.associatedVisitorGroup();

    const users = await client.web.siteGroups.getById(visitorGroup.Id).users();

    // Refer to the sharepointService.md file for more info on LoginName
    return users.some(({ LoginName }) => LoginName?.endsWith(VL_MEMBERS_GROUP_ID));
  },
};

export default SharePointService;
