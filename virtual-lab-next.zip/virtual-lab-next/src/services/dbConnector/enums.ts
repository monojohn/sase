import { IgamRequestStatus } from "../igamService/enums";

export enum ConfidentialityLevel {
  PUBLIC = "ECB-PUBLIC",
  UNRESTRICTED = "ECB-UNRESTRICTED",
  RESTRICTED = "ECB-RESTRICTED",
  CONFIDENTIAL = "ECB-CONFIDENTIAL",
  SECRET = "ECB-SECRET",
}

export enum AccessibilityLevel {
  "Public" = "Public",
  "Private" = "Private",
  "Protected" = "Protected",
}

export enum DataSensitivityLevel {
  CSI = "CSI",
  No = "No",
}

export enum ProjectStatus {
  Active = "Active",
  BeingCreated = "BeingCreated",
  BeingDeleted = "BeingDeleted",
  Deleted = "Deleted",
  AwaitingApproval = IgamRequestStatus.AWAITING_APPROVAL,
  ApprovalClosed = IgamRequestStatus.CLOSED,
  ApprovalExpired = IgamRequestStatus.EXPIRED,
  ApprovalRejected = IgamRequestStatus.REJECTED,
}

export enum RequestStatus {
  AWAITING_APPROVAL = IgamRequestStatus.AWAITING_APPROVAL,
  CLOSED = IgamRequestStatus.CLOSED,
  EXPIRED = IgamRequestStatus.EXPIRED,
  REJECTED = IgamRequestStatus.REJECTED,
  COMPLETED = IgamRequestStatus.COMPLETED,
  PENDING = "Request Pending", // needed when there's an active request in IGAM and we can't create a new one
}

export enum ProjectInvitationStatus {
  OPEN = "open",
  ACCEPTING = "accepting",
  ACCEPTED = "accepted",
  REJECTED = "rejected",
  CANCELLED = "cancelled",
  INVALID = "invalid",
  AWAITING_APPROVAL = IgamRequestStatus.AWAITING_APPROVAL,
  APPROVAL_CLOSED = IgamRequestStatus.CLOSED,
  APPROVAL_EXPIRED = IgamRequestStatus.EXPIRED,
  APPROVAL_REJECTED = IgamRequestStatus.REJECTED,
  PENDING = RequestStatus.PENDING,
}

export enum PendingInvitationStatus {
  OPEN = ProjectInvitationStatus.OPEN,
  ACCEPTING = ProjectInvitationStatus.ACCEPTING,
  AWAITING_APPROVAL = ProjectInvitationStatus.AWAITING_APPROVAL,
  PENDING = ProjectInvitationStatus.PENDING,
}

export enum RequestType {
  PROJECT_CREATION = "Project creation",
  ADD_OWNER = "Add owner",
  UPDATE_CONFIDENTIALITY = "Update confidentiality",
  UPDATE_ORG = "Update business organization",
  ADD_OWNER_WITH_ORG_UPDATE = "Add owner with BA org update",
}

export enum UpdateStatus {
  DONE = "Done",
  PENDING_APPROVAL = "Pending approval",
  PENDING_REQUEST_CREATION = "Pending request creation",
}

export enum GdprAssessment {
  LOW = "Low risk",
  MEDIUM = "Medium risk",
  HIGH = "High risk",
  VERY_HIGH = "Very high risk",
}

export enum BusinessRisk {
  NEGLECTIBLE = "Neglectible",
  LOW = "Low",
  MEDIUM = "Medium",
  HIGH = "High",
  VERY_HIGH = "Very High",
}

export enum AiAct {
  FORBIDDEN = "Forbidden",
  HIGH = "High risk",
  MEDIUM = "Medium risk",
  LOW = "Low risk",
}
