export type ProjectRequest = {
  /**
   * entry id
   */
  _id: string;

  /**
   * user id
   */
  oid: string;

  /**
   * project id
   */
  pid: string;

  /**
   * Name of project
   */
  name: string;

  /**
   * Optional user message
   */
  message?: string;

  createdAt: Date;
  updatedAt: Date;
};
