import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

type DataGovernance = {
  /**
   * ID of user who reviewed the data
   */
  oid: string;

  /**
   * project id
   */
  pid: string;

  createdAt: Date;
  updatedAt: Date;
};

const DataGovernanceSchema = new Schema<DataGovernance>(
  {
    oid: { type: String, required: true },
    pid: { type: String, required: true },
  },
  // https://mongoosejs.com/docs/timestamps.html
  { timestamps: true },
);

const DataGovernanceModel = model("DataGovernance", DataGovernanceSchema, "DataGovernances");

export default DataGovernanceModel;
