export type UserVisit = {
  /**
   * User ID
   */
  oid: string;

  /**
   * session ID
   */
  sessionId: string;

  /**
   * Creation timestamp
   */
  createdAt: Date;

  /**
   * Last update timestamp
   */
  updatedAt: Date;
};
