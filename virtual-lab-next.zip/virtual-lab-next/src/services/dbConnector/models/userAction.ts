import { ActionStatus, ActionType } from "../../../features/userActions/enums";

export type UserAction = {
  _id: string;
  /**
   * Project ID
   */
  pid: string;

  /**
   * User ID
   */
  oid: string;
  target?: string;

  /**
   * Action which was taken
   */
  action: ActionType;

  /**
   * Status of action: success, error, pending, etc
   */
  status: ActionStatus;

  /**
   * Id of execution
   */
  invocationId: string;

  /**
   * Creation timestamp
   */
  createdAt: Date;

  /**
   * Last update timestamp
   */
  updatedAt: Date;
};
