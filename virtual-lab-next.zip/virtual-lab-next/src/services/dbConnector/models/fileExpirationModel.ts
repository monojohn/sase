import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

export type FileExpiration = {
  /**
   * Unique id
   */
  _id: string;

  /**
   * project id
   */
  pid: string;

  /**
   * Expiration time
   */
  expirationTimestamp: Date;

  /**
   * Name of file
   */
  fileName: string;

  /**
   * Unique id of file
   */
  fileId: string;

  createdAt: Date;
  updatedAt: Date;
};

const FileExpirationSchema = new Schema<FileExpiration>(
  {
    pid: { type: String, required: true },
    fileId: { type: String, required: true },
    fileName: { type: String, required: true },
    expirationTimestamp: { type: Date, required: true },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

const FileExpirationModel = model("FileExpiration", FileExpirationSchema, "FileExpirations");

export default FileExpirationModel;
