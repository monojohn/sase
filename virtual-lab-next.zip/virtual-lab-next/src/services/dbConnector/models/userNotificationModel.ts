import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";
import { UserNotification } from "./userNotification";
import { ActionType } from "../../../features/userActions/enums";

void MongoConnector.connect();

const userNotificationSchema = new Schema<UserNotification>(
  {
    oid: { type: String, required: true },
    pid: { type: String, required: true },
    projectName: { type: String, required: true },

    target: { type: String },
    targetName: { type: String },
    read: { type: Boolean, default: false },
    triggeredBy: { type: String, required: true },
    triggeredByName: { type: String, required: true },
    type: { type: String, required: true, enum: ActionType },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

const UserNotificationModel = model(
  "UserNotification",
  userNotificationSchema,
  "UserNotifications",
);

export default UserNotificationModel;
