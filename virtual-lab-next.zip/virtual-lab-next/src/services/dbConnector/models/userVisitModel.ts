import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";
import { UserVisit } from "./userVisit";

void MongoConnector.connect();

const userVisitSchema = new Schema<UserVisit>(
  {
    oid: { type: String, required: true },
    sessionId: { type: String, required: true },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

userVisitSchema.index({ sessionId: 1 });

const UserVisitModel = model("UserVisit", userVisitSchema, "UserVisits");

export default UserVisitModel;
