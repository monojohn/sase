import { ActionType } from "../../../features/userActions/enums";

export type UserNotification = {
  /**
   * User to notify
   */
  oid: string;

  type: ActionType;
  triggeredBy: string; // oid of user who triggered notification
  triggeredByName: string; // name of user who triggered notification

  /**
   * project Id
   */
  pid: string;
  projectName: string;

  read: boolean;
  target?: string;
  targetName?: string;
};
