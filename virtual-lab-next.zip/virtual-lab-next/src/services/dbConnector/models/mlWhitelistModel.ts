import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

type MlWhitelist = {
  /**
   * whitelisted URL
   */
  url: string;

  /**
   * Description of listed item
   */
  description: string;

  createdAt: Date;
  updatedAt: Date;
};

const MlWhitelistSchema = new Schema<MlWhitelist>(
  {
    url: { type: String, required: true },
    description: { type: String },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

const MlWhitelistModel = model("MlWhitelist", MlWhitelistSchema, "MlWhitelists");

export default MlWhitelistModel;
