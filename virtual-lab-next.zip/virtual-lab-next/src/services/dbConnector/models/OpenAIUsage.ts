import { model, Schema } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

export type OpenAIUsage = {
  month: `${number}${number}${number}${number}-${number}${number}`; // YYYY-MM
  workspace: string;
  model: string;
  consumed: number;
  limits: number;
};

const OpenAIUsageSchema = new Schema<OpenAIUsage>(
  {
    month: {
      type: String,
      required: true,
      validate: {
        validator(value: string): value is OpenAIUsage["month"] {
          // Regex for YYYY-MM format
          return /^\d{4}-(0[1-9]|1[0-2])$/.test(value);
        },
        message: (props: { value: string }) =>
          `${props.value} is not a valid month format. Use YYYY-MM.`,
      },
    },
    workspace: {
      type: String,
      required: true,
    },
    model: {
      type: String,
      required: true,
    },
    consumed: {
      type: Number,
      required: true,
    },
    limits: {
      type: Number,
      required: true,
    },
  },
  { timestamps: true },
);

OpenAIUsageSchema.index({ month: 1, workspace: 1, model: 1 });

const OpenAIUsageModel = model("OpenAIUsage", OpenAIUsageSchema, "VLAzureOpenAI");

export default OpenAIUsageModel;
