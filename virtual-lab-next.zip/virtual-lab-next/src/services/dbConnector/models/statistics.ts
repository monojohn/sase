import { model, Schema } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

export type Statistics = {
  registeredUsers: number; // total number of registered users
  projects: number; // total number of projects
  activeUsers: number; // total active users of previous month
  siteVisits: number; // total site visits of previous month
  createdAt: Date;
  updatedAt: Date;
};

const StatisticsSchema = new Schema<Statistics>(
  {
    registeredUsers: {
      type: Number,
      required: true,
    },
    projects: {
      type: Number,
      required: true,
    },
    activeUsers: {
      type: Number,
      required: true,
    },
    siteVisits: {
      type: Number,
      required: true,
    },
  },
  { timestamps: true },
);

const StatisticsModel = model("Statistics", StatisticsSchema, "Statistics");

export default StatisticsModel;
