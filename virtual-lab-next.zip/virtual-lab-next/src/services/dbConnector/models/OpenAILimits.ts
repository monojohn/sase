import { model, Schema } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

export type OpenAILimits = {
  workspace: string;
  model: string;
  limit: number;
};

const OpenAILimitsSchema = new Schema<OpenAILimits>({
  workspace: {
    type: String,
    required: true,
  },
  model: {
    type: String,
    required: true,
  },
  limit: {
    type: Number,
    required: true,
  },
});

const OpenAILimitsModel = model("OpenAILimits", OpenAILimitsSchema, "VLAzureOpenAILimits");

export default OpenAILimitsModel;
