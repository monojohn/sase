import { Schema, model, HydratedDocument } from "mongoose";
import { z } from "zod";
import MongoConnector from "../mongoDb";
import { ConfidentialityLevel } from "../enums";

void MongoConnector.connect();

export type OpenAIUseCaseData = {
  useCaseId: string;
  confidentialityLevel: ConfidentialityLevel;
  familiarised: boolean;
};

export type OpenAIUseCase = {
  _id: string;
  pid: string;
  /**
   * Represents all unique owner's ids that has edited this document, while first id represents creator
   */
  oids: string[];
  createdAt: Date;
  updatedAt: Date;
} & OpenAIUseCaseData;

const OpenAIUseCaseSchema = new Schema<OpenAIUseCase>(
  {
    pid: { type: String, required: true, unique: true },
    oids: { type: [String], required: true, default: [] },
    useCaseId: {
      type: String,
      required: true,
      validate: {
        validator: (value: string) =>
          z
            .string()
            .refine((v) => Number(v) > 0)
            .safeParse(value).success,
        message: (props) => `Value ${props.value} must be positive number larger than 0!`,
      },
    },
    familiarised: { type: Boolean, required: true },
    confidentialityLevel: { type: String, enum: ConfidentialityLevel, required: true },
  },
  {
    // Automatically adds createdAt and updatedAt fields
    timestamps: true,
  },
);

function isSetUpdate(
  update: null | Record<string, unknown> | unknown[],
): update is { $set: Partial<OpenAIUseCase> } {
  return !!update && !Array.isArray(update) && update.$set !== undefined;
}

// eslint-disable-next-line consistent-return
OpenAIUseCaseSchema.pre("findOneAndUpdate", async function findOneAndUpdate(next) {
  const update = this.getUpdate();

  if (isSetUpdate(update)) {
    const currentDocument = await this.model.findOne<HydratedDocument<OpenAIUseCase>>(
      this.getQuery(),
    );

    if (!currentDocument) {
      return next(new Error("No document was found, nothing can be updated!"));
    }

    currentDocument.set(update.$set);

    try {
      // Validate whether updated document passes all the rules set on the schema
      await currentDocument.validate();
    } catch (err) {
      return next(new Error(err?.toString() ?? "Validation failed for OpenAIUseCase!"));
    }
  }

  next();
});

// prevent duplicates
OpenAIUseCaseSchema.index({ pid: 1 }, { unique: true });

const OpenAIUseCaseModel = model("OpenAIUseCase", OpenAIUseCaseSchema, "VLAIUseCases");

export default OpenAIUseCaseModel;
