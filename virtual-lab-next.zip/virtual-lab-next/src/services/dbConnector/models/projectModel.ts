import { Schema, model } from "mongoose";
import { getMembersGroupName, getOwnersGroupName, getTeamGroupName } from "../../../utils/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  ProjectStatus,
} from "../enums";
import MongoConnector from "../mongoDb";
import { Project, Resource } from "./project";
import { WorkspaceType } from "../../sharepointService/enums";
import OpenAIUseCaseModel from "./OpenAIUseCase";

void MongoConnector.connect();

const resourceSchema = new Schema<Resource>({
  text: { type: String, required: true },
  url: { type: String, required: true },
});

const projectSchema = new Schema<Project>(
  {
    name: { type: String, required: true, unique: true },
    url: { type: String },
    siteId: { type: String },
    description: { type: String, required: true },
    icon: { type: String },

    // Note for later: consider to extract workspace to separate collection
    workspaceUrl: { type: String },
    workspaceType: { type: String, enum: WorkspaceType },
    workspaceExploratoryJustification: { type: String },
    aiUsage: { type: Boolean },
    aiModels: { type: String, required: false },
    openAiConnection: { type: Boolean, required: false },
    ecbContact: { type: Boolean, required: false },
    aiUseCaseId: { type: String, required: false },
    gdpr: { type: String, required: false },
    aiAct: { type: String, required: false },
    businessRisk: { type: String, required: false },
    foundWorkspaceInactive: { type: Number, required: false },

    entitlements: { type: [String], default: [] },
    roles: { type: Schema.Types.Mixed, default: [] },
    iamRoles: { type: Schema.Types.Mixed, default: [] },
    rolesAndEntitlements: { type: Schema.Types.Mixed, default: [] },
    repositoryUrl: { type: String },
    repositoryUrlBackup: { type: String },
    confidentialityLevel: { type: String, enum: ConfidentialityLevel, required: true },
    accessibilityLevel: { type: String, enum: AccessibilityLevel, required: true },
    teamGroupName: { type: String, required: true },
    membersGroupName: { type: String, required: true },
    ownersGroupName: { type: String, required: true },
    teamGroupId: { type: String },
    membersGroupId: { type: String },
    ownersGroupId: { type: String },
    members: { type: [String], default: [] },
    owners: { type: [String], default: [] },
    resources: { type: [resourceSchema], default: [] },
    status: { type: String, enum: ProjectStatus },
    permissionsChangedDate: { type: Date, required: false },
    isNonEscbProject: { type: Boolean, required: true, default: false },
    tags: { type: [String], default: [] },
    foundProjectInactive: { type: Number, required: false },
    foundWithoutOwners: { type: Number, required: false },
    foundWithoutUsers: { type: Number, required: false },
    hasException: { type: Boolean, required: false },
    dataSensitivityLevel: { type: String, enum: DataSensitivityLevel, required: true },
    openAiUseCase: { type: Schema.Types.ObjectId, ref: OpenAIUseCaseModel },
    teamsUrl: { type: String },
    plannerUrl: { type: String },
    org: { type: String },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

// Note for later: consider to use mongoose virtuals for storing derived/computed data
// inject group names on creation
projectSchema.pre("validate", function injectGroupNames(next) {
  this.set({
    teamGroupName: getTeamGroupName(this.name),
    ownersGroupName: getOwnersGroupName(this.name),
    membersGroupName: getMembersGroupName(this.name),
  });
  next();
});

// Create case-insensitive index for project name
projectSchema.index({ name: 1 });

const ProjectModel = model("Projects", projectSchema, "Projects");

export default ProjectModel;
