import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";
import { ProjectRequest } from "./projectRequest";

void MongoConnector.connect();

const leaveProjectRequestSchema = new Schema<ProjectRequest>(
  {
    oid: { type: String, required: true },
    pid: { type: String, required: true },
    name: { type: String, required: true },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

// prevent duplicates
leaveProjectRequestSchema.index({ oid: 1, pid: 1 }, { unique: true });

const LeaveProjectRequestModel = model(
  "LeaveProjectRequest",
  leaveProjectRequestSchema,
  "LeaveProjectRequests",
);

export default LeaveProjectRequestModel;
