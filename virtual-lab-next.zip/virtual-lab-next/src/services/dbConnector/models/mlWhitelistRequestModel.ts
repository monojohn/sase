import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

export enum WhitelistRequestStatus {
  APPROVED = "approved",
  PENDING = "pending",
  REJECTED = "rejected",
}

export type MlWhitelistRequest = {
  _id: string;

  /**
   * whitelisted URL
   */
  urls: string;

  /**
   * Description of listed item
   */
  justification: string;

  /**
   * project id
   */
  pid: string;

  /**
   * Id of user who requested whitelist
   */
  oid: string;

  /**
   * Id of user who requested whitelist
   */
  status: WhitelistRequestStatus;

  createdAt: Date;
  updatedAt: Date;
};

const MlWhitelistRequestSchema = new Schema<MlWhitelistRequest>(
  {
    pid: { type: String, required: true },
    oid: { type: String, required: true },
    urls: { type: String, required: true },
    justification: { type: String, required: true },
    status: { type: String, enum: WhitelistRequestStatus, default: WhitelistRequestStatus.PENDING },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

// prevent duplicates
MlWhitelistRequestSchema.index({ oid: 1, pid: 1, urls: 1 }, { unique: true });

const MlWhitelistRequestModel = model(
  "MlWhitelistRequest",
  MlWhitelistRequestSchema,
  "MlWhitelistRequests",
);

export default MlWhitelistRequestModel;
