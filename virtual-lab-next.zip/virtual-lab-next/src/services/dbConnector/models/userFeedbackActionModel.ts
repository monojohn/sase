import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

type FeedbackAction = {
  /**
   * User OID
   */
  oid: string;
  survey?: boolean;
  createdAt: Date;
  updatedAt: Date;
};

const userFeedbackActionSchema = new Schema<FeedbackAction>(
  {
    oid: { type: String, required: true },
    survey: { type: Boolean },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

const UserFeedbackActionModel = model(
  "UserFeedbackAction",
  userFeedbackActionSchema,
  "UserFeedbackActions",
);

export default UserFeedbackActionModel;
