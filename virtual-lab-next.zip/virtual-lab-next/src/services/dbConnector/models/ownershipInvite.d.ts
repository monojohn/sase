import { ProjectInvitationStatus } from "../enums";

export type OwnershipInvite = {
  /**
   * entry id
   */
  _id: string;

  /**
   * oid of invitee
   */
  invitee: string;

  /**
   * oid of user who created the invite
   */
  inviter: string;

  /**
   * name of user who created the invite
   */
  inviterName: string;

  /**
   * project id
   */
  pid: string;

  /**
   * Name of project
   */
  projectName: string;

  /**
   * invitation status. Starts as undefined
   */
  status?: ProjectInvitationStatus;

  createdAt: Date;
  updatedAt: Date;
};
