import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";
import { IgamRequest } from "./igamRequest";
import { ConfidentialityLevel, DataSensitivityLevel, RequestStatus, RequestType } from "../enums";

void MongoConnector.connect();
const IgamRequestSchema = new Schema<IgamRequest>(
  {
    requestId: { type: String, required: false },
    requestType: { type: String, enum: RequestType, required: true },
    requestStatus: { type: String, enum: RequestStatus, required: true },
    pid: { type: String, required: true },
    requesterId: { type: String, required: true },
    oid: { type: String, required: false },
    confidentialityLevel: { type: String, enum: ConfidentialityLevel, required: false },
    dataSensitivityLevel: { type: String, enum: DataSensitivityLevel, required: false },
    org: { type: String, required: false },
    entitlementUrl: { type: String, required: false },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

IgamRequestSchema.index({ pid: 1, requestStatus: 1 });

const IgamRequestModel = model("IgamRequest", IgamRequestSchema, "IgamRequests");

export default IgamRequestModel;
