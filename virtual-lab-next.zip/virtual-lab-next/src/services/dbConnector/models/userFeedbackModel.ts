import { Schema, model } from "mongoose";
import { VlBenefits } from "../../sharepointService/enums";
import MongoConnector from "../mongoDb";

void MongoConnector.connect();

type Feedback = {
  hoursPerWeek: number;
  benefits: VlBenefits[];

  createdAt: Date;
  updatedAt: Date;
};

const userFeedbackSchema = new Schema<Feedback>(
  {
    hoursPerWeek: { type: Number, required: true },
    benefits: { type: [String], enum: VlBenefits, default: [] },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);
// NOTE: This collection was created with a lowercase "U" in "u"serFeedbacks.
// Using an uppercase "U" will cause an error
const UserFeedbackModel = model("UserFeedback", userFeedbackSchema, "userFeedbacks");

export default UserFeedbackModel;
