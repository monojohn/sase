import { Schema, model } from "mongoose";
import { ActionStatus, ActionType } from "../../../features/userActions/enums";
import MongoConnector from "../mongoDb";
import { UserAction } from "./userAction";

void MongoConnector.connect();

const userActionSchema = new Schema<UserAction>(
  {
    pid: { type: String }, // can't be required for project creation
    oid: { type: String, required: true },
    target: { type: String },
    action: { type: String, enum: ActionType, required: true },
    status: { type: String, enum: ActionStatus, required: true },
    invocationId: { type: String, required: true },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

const UserActionModel = model("UserAction", userActionSchema, "UserActions");

export default UserActionModel;
