export type FavoriteProject = {
  /**
   * user id
   */
  oid: string;

  /**
   * project id
   */
  pid: string;

  createdAt: Date;
  updatedAt: Date;
};
