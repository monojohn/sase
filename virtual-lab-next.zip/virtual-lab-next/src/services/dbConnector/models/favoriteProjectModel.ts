import { Schema, model } from "mongoose";
import MongoConnector from "../mongoDb";
import { FavoriteProject } from "./favoriteProject";

void MongoConnector.connect();
const FavoriteProjectSchema = new Schema<FavoriteProject>(
  {
    oid: { type: String, required: true },
    pid: { type: String, required: true },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

// prevent duplicates
FavoriteProjectSchema.index({ oid: 1, pid: 1 }, { unique: true });

const FavoriteProjectModel = model("FavoriteProject", FavoriteProjectSchema, "FavoriteProjects");

export default FavoriteProjectModel;
