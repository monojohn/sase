import { ConfidentialityLevel, DataSensitivityLevel, RequestStatus, RequestType } from "../enums";

export type IgamRequest = {
  _id: string;
  requestId?: string; // request id from IGAM
  requestType: RequestType;
  requestStatus: RequestStatus;
  pid: string; // projectId
  requesterId: string; // oid of user who initiated request

  // optional fields, depending on type of requets
  oid?: string; // oid of user invited as owner in case of RequestType.ADD_OWNER
  confidentialityLevel?: ConfidentialityLevel; // new confidentiality level in case of RequestType.UPDATE_CONFIDENTIALITY
  dataSensitivityLevel?: DataSensitivityLevel; // new data sensitivity level in case of RequestType.UPDATE_CONFIDENTIALITY as part of updating project
  org?: string; // new org in case of RequestType.UPDATE_ORG
  entitlementUrl?: string; // url including apiRequestId to check entitlement creation after approval is granted, only for RequestType.PROJECT_CREATION

  createdAt: Date;
  updatedAt: Date;
};
