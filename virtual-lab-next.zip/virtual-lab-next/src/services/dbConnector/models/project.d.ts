import type { IamRole } from "../../iamService/iamService.types";
import type { Role } from "../../igamService/types";
import type { WorkspaceType } from "../../sharepointService/enums";
import type {
  AccessibilityLevel,
  AiAct,
  BusinessRisk,
  ConfidentialityLevel,
  DataSensitivityLevel,
  GdprAssessment,
  ProjectStatus,
} from "../enums";
import type { OpenAIUseCase } from "./OpenAIUseCase";

export type Resource = {
  text: string;
  url: string;
};

export type PickRole = Pick<Role, "id" | "displayName" | "roleName">;

export type RolesAndEntitlements = {
  entitlements: string[];
  roles: PickRole[];
  iamRoles: IamRole[];
};

export type RolesAndEntitlementsStrings = {
  entitlements: string[];
  roles: string[];
  iamRoles: string[];
};

export type Project = {
  _id: string;
  url: string;
  name: string;
  icon: string;
  siteId: string;
  description: string;

  workspaceUrl: string;
  workspaceType: WorkspaceType;
  workspaceExploratoryJustification?: string; // necessary on WorkspaceType.EXPLORATORY
  aiUsage: boolean;
  aiModels: string | null; // needed if aiUsage
  openAiConnection: boolean | null; // needed if aiUsage
  ecbContact: boolean | null; // needed if aiUsage and user creating the ML is non-ECB
  aiUseCaseId: string | null; // needed if aiUsage and there's an ECB user in the project ( = user is ECB or they say there's an ecb user in project)
  gdpr: GdprAssessment | null; // needed if aiUsage and no ECB user in project
  aiAct: AiAct | null; // needed if aiUsage and no ECB user in project
  businessRisk: BusinessRisk | null; // needed if aiUsage and no ECB user in project

  entitlements: string[];
  roles: PickRole[];
  iamRoles: IamRole[];
  rolesAndEntitlements: RolesAndEntitlements[];

  repositoryUrl: string;
  repositoryUrlBackup: string;

  confidentialityLevel: ConfidentialityLevel;
  accessibilityLevel: AccessibilityLevel;

  teamGroupId: string;
  ownersGroupId: string;
  membersGroupId: string;

  teamGroupName: string;
  ownersGroupName: string;
  membersGroupName: string;

  members: string[];
  owners: string[];

  resources: Resource[];

  status: ProjectStatus;

  /**
   * Data time string of last edit to Roles or Permissions.
   *
   * Write: Must be set as an ISO string, i.e. new Date().toISOString()
   *
   * Read: Must be converted to a string, i.e. new Date(project.PermissionsChangedDate)
   */
  permissionsChangedDate: Date | null; // "2022-01-17T14:35:57Z";

  /**
   * Non ECB projects have special review requirements
   */
  isNonEscbProject: boolean | null;

  createdAt: Date;
  updatedAt: Date;

  tags: string[];

  /**
   * Count how many times a project:
   * - was found inactive
   * - had an inactive ML workspace
   * - was found without owners
   * - was found without any users
   */
  foundProjectInactive: number | null;
  foundWorkspaceInactive: number | null;
  foundWithoutOwners: number | null;
  foundWithoutUsers: number | null;

  /**
   * Some projects have been exempted from deletion
   */
  hasException: boolean | null;
  dataSensitivityLevel: DataSensitivityLevel;

  /**
   * Project can have VL Azure Open AI use case
   *  - OpenAIUseCase is linked to every project automatically after it's creation
   */
  openAiUseCase?: OpenAIUseCase;

  teamsUrl: string;
  plannerUrl: string;

  /**
   * owner of entitlements
   */
  org: string;
};

type ProjectUser = Pick<GraphUser, "displayName" | "userPrincipalName" | "id">;

export type ExpandedProject = Omit<Project, "owners" | "members"> & {
  owners?: ProjectUser[];
  members?: ProjectUser[];
  pendingConfidentialityLevel?: ConfidentialityLevel;
  pendingDataSensitivityLevel?: DataSensitivityLevel;
  org?: string;
  ownersDepartments?: { displayName: string; department: string }[];
  pendingOrg?: string;
  budget?: {
    limit: number;
    consumed: number;
  };
  openAiUsage?: {
    model: string;
    consumed: number;
    limit: number;
  }[];
};
