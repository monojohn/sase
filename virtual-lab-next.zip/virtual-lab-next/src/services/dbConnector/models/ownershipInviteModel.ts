import { Schema, model } from "mongoose";
import { ProjectInvitationStatus } from "../enums";
import MongoConnector from "../mongoDb";
import { OwnershipInvite } from "./ownershipInvite";

void MongoConnector.connect();

const OwnershipInviteSchema = new Schema<OwnershipInvite>(
  {
    pid: { type: String, required: true },
    invitee: { type: String, required: true },
    inviter: { type: String, required: true },
    inviterName: { type: String, required: true },
    projectName: { type: String, required: true },
    status: { type: String, enum: ProjectInvitationStatus, default: ProjectInvitationStatus.OPEN },
  },
  // https://mongoosejs.com/docs/timestamps.html
  // https://www.mongodb.com/docs/manual/core/index-case-insensitive/
  { timestamps: true },
);

// prevent duplicates
OwnershipInviteSchema.index({ invitee: 1, pid: 1 }, { unique: true });

const OwnershipInviteModel = model("OwnershipInvite", OwnershipInviteSchema, "OwnershipInvites");

export default OwnershipInviteModel;
