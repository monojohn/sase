/*  eslint-disable no-console */

import mongoose from "mongoose";
import { IS_JEST, MONGO_URL } from "../../utils/config";
import SlackService from "../slackService";
import { wait } from "../../utils/helpers";

if (!MONGO_URL) {
  throw new Error(`MONGO_URL not present`);
}

let mongoUrl = MONGO_URL;

class Connector {
  private connection: Promise<typeof mongoose> | undefined;

  public async connect(): Promise<typeof mongoose> {
    this.connection ??= this.createConnection();

    return this.connection;
  }

  async disconnect() {
    const con = await this.connection;

    await con?.disconnect();

    this.connection = undefined;
  }

  private async createConnection() {
    const maxRetryCount = 50;

    if (IS_JEST) {
      while (!process.env.MONGO_URL?.includes("127.0.0.1")) {
        await wait(1);
      }
      mongoUrl = process.env.MONGO_URL;
    }

    for (let index = 0; index < maxRetryCount; index++) {
      try {
        mongoose.connection.on("error", () => {
          console.error("DB connection error, reconnecting");
          void this.connect();
        });

        // we don't have permissions to create collections via code
        mongoose.set("autoCreate", false);

        return await mongoose.connect(mongoUrl, {
          directConnection: true,
        });
      } catch (e) {
        console.log("Initial DB connection failed, trying again", e);
      }
    }

    // after 50 failures in quick succession, we give up
    const error = `initial DB connection failed after ${maxRetryCount} retries`;
    await SlackService.send(`\`\`\`${error}\`\`\``);
    throw new Error(error);
  }
}

const MongoConnector = new Connector();

export default MongoConnector;
