import { ClientCertificateCredential } from "@azure/identity";
import { QueueServiceClient } from "@azure/storage-queue";
import {
  AZURE_TENANT_ID,
  INFRA_CERTIFICATE,
  INFRA_CLIENT_ID,
  STORAGE_ACCOUNT,
} from "../utils/config";

const atob = (str: string) => Buffer.from(str).toString("base64");

let globalClient: QueueServiceClient;
const login = () => {
  const authorization = new ClientCertificateCredential(AZURE_TENANT_ID, INFRA_CLIENT_ID, {
    certificate: INFRA_CERTIFICATE,
  });

  globalClient ??= new QueueServiceClient(
    `https://${STORAGE_ACCOUNT}.queue.core.windows.net`,
    authorization,
  );

  return globalClient;
};

export enum QUEUE {
  TEMPLATE = "templates-private",
  ML_CREATION = "workspace-creation-private",
  ML_DELETION = "workspace-deletion-private",
  CREATE_PROJECT = "project-creation-private",
  DELETE_PROJECT = "project-delete-private",
}

const QueueService = {
  async put<T = Record<string, unknown>>(queue: QUEUE, message: T) {
    const client = login();
    const queueClient = client.getQueueClient(queue);
    const b64Msg = atob(JSON.stringify(message));
    await queueClient.sendMessage(b64Msg);
  },
};

export default QueueService;
