import { jest } from "@jest/globals";
import NotificationService from "./emails";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Project Workspace emails", () => {
  it("sendWorkspaceCreatedEmail works", async () => {
    await NotificationService.sendWorkspaceCreatedEmail(ctx, "unit test", "url", [userEmail]);
  });

  it("sendWorkspaceCreatedErrorEmail works", async () => {
    await NotificationService.sendWorkspaceCreatedErrorEmail(ctx, {
      projectName: "unit test",
      projectId: "id",
      userEmail,
    });
  });

  it("sendWorkspaceDeletedEmail works", async () => {
    await NotificationService.sendWorkspaceDeletedEmail(ctx, "unit test", [userEmail]);
  });

  it("sendWorkspaceDeletedErrorEmail works", async () => {
    await NotificationService.sendWorkspaceDeletedErrorEmail(ctx, "unit test", userEmail);
  });
});
