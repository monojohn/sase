import { Context } from "@azure/functions";
import moment from "moment";
import EmailService from "../../services/emailService/emailService";

type ErrorProps = {
  projectName: string;
  projectId: string;
  userEmail: string;
};

const NotificationService = {
  async sendWorkspaceCreatedEmail(
    ctx: Context,
    projectName: string,
    ctaUrl: string,
    emails: string[],
  ) {
    const subject = `[Notification] The AI | ML workspace for ${projectName} has been created`;
    const headline = "Your AI | ML workspace has been created ";
    const ctaLabel = "View workspace";

    return EmailService.sendSuccessCtaEmail(ctx, {
      bcc: emails,
      subject,
      templateData: {
        ctaUrl,
        projectName,
        projectId: projectName,
        ctaLabel,
        headline,
      },
    });
  },

  async sendWorkspaceCreatedErrorEmail(
    ctx: Context,
    { projectName, projectId, userEmail }: ErrorProps,
  ) {
    const subject = `[Failure] AI | ML workspace creation for ${projectName} has failed`;
    const headline = "Your attempt to create a AI | ML workspace has failed";
    const actionName = "AI | ML workspace creation";

    return EmailService.sendErrorEmail(ctx, {
      subject,
      bcc: userEmail,

      templateData: {
        headline,
        actionName,
        projectName,
        userEmail,
        projectId,
        time: moment.utc().format("dddd, MMMM Do YYYY, h:mm:ss A z"),
      },
    });
  },

  sendWorkspaceDeletedEmail(ctx: Context, projectName: string, bcc: string[]) {
    const subject = `[Notification] The AI | ML workspace for ${projectName} has been deleted`;
    const headline = "Your AI | ML workspace has been deleted";

    return EmailService.sendSuccessEmail(ctx, {
      bcc,
      subject,
      templateData: {
        headline,
        userEmail: bcc,
        projectName,
      },
    });
  },

  sendWorkspaceDeletedErrorEmail(ctx: Context, projectName: string, bcc: string) {
    const subject = `[Failure] AI | ML workspace deletion for ${projectName} has failed`;
    const headline = "Your attempt to delete the AI | ML workspace was unsuccessful ";
    const actionName = "Deletion of AI | ML workspace";

    return EmailService.sendErrorEmail(ctx, {
      bcc,
      subject,
      templateData: {
        actionName,
        projectName,
        projectId: projectName,
        userEmail: bcc,
        headline,
        time: moment.utc().format("dddd, MMMM Do YYYY, h:mm:ss A z"),
      },
    });
  },
};
export default NotificationService;
