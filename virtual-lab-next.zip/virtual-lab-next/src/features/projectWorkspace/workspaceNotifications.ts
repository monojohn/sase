import { Context } from "@azure/functions";
import { Session } from "../../middleware/withHttpSession";
import { Project } from "../../services/dbConnector/models/project";
import GraphService from "../../services/graphService/graphService";
import UserNotificationService from "../../services/userNotificationService/userNotificationService";
import NotificationService from "./emails";
import { getEmailOfUser } from "../../utils/helpers";
import { ActionType } from "../userActions/enums";

export const sendWorkspaceCreatedNotifications = async (
  ctx: Context,
  project: Project,
  workspaceUrl: string,
  session: Session,
) => {
  const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
    "id",
    "mail",
    "otherMails",
    "identities",
  ]);
  const bcc = users.map((owner) => getEmailOfUser(owner));

  await Promise.all([
    UserNotificationService.notifyUsers(ctx, users, {
      target: { id: workspaceUrl },
      type: ActionType.CREATE_WORKSPACE,
      project: { id: project._id, name: project.name },
      triggerer: { id: session.oid, displayName: session.name },
    }),
    NotificationService.sendWorkspaceCreatedEmail(ctx, project.name, workspaceUrl, bcc),
  ]);
};

export const sendWorkspaceDeletedNotifications = async (
  ctx: Context,
  project: Project,
  session: Session,
) => {
  const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
    "id",
    "mail",
    "otherMails",
    "identities",
  ]);
  const bcc = users.map((owner) => getEmailOfUser(owner));

  await Promise.all([
    UserNotificationService.notifyUsers(ctx, users, {
      type: ActionType.DELETE_WORKSPACE,
      project: { id: project._id, name: project.name },
      triggerer: { id: session.oid, displayName: session.name },
    }),
    NotificationService.sendWorkspaceDeletedEmail(ctx, project.name, bcc),
  ]);
};
