import { jest } from "@jest/globals";
import {
  sendWorkspaceCreatedNotifications,
  sendWorkspaceDeletedNotifications,
} from "./workspaceNotifications";
import { createTestProject } from "../../../jest/helpers";
import { Project } from "../../services/dbConnector/models/project";
import { Session } from "../../middleware/withHttpSession";
import GraphService from "../../services/graphService/graphService";

const ctx = { log: jest.fn() } as any;

describe("Project Workspace emails", () => {
  let testProject: Project;
  const session: Session = { name: "test", upn: "upn", oid: "oid" };
  beforeAll(async () => {
    testProject = await createTestProject({ workspaceUrl: "https://ml.azure.com/wsid=test" });
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
  });
  it("sendWorkspaceCreatedNotifications works", async () => {
    await sendWorkspaceCreatedNotifications(ctx, testProject, "url", session);
  });

  it("sendWorkspaceDeletedNotifications works", async () => {
    await sendWorkspaceDeletedNotifications(ctx, testProject, session);
  });
});
