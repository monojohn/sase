import { Context } from "@azure/functions";
import { client, v2 } from "@datadog/datadog-api-client";

let instance: v2.MetricsApi;
const configurationOpts = {
  authMethods: {
    apiKeyAuth: process.env.DATADOG_API_KEY,
    appKeyAuth: process.env.DATADOG_APP_KEY,
  },
};

const MLMetrics = {
  getClient() {
    if (!instance) {
      const configuration = client.createConfiguration(configurationOpts);
      configuration.setServerVariables({ site: "datadoghq.eu" });
      instance = new v2.MetricsApi(configuration);
    }

    return instance;
  },

  submitMetrics(ctx: Context, workspace: string, data: v2.MetricsApiSubmitMetricsRequest) {
    ctx.log(`Fetching metrics client for ${workspace}`);
    const metricsClient = MLMetrics.getClient();
    return metricsClient.submitMetrics(data);
  },
};

export default MLMetrics;
