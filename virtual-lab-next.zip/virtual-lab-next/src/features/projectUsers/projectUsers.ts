import { Context } from "@azure/functions";
import { FilterQuery } from "mongoose";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import GraphService from "../../services/graphService/graphService";
import SlackService from "../../services/slackService";
import { ProjectStatus } from "../../services/dbConnector/enums";
import { arraysAreEquivalent } from "../../utils/helpers";
import EntitlementsService from "../../services/igamService/entitlementsService";

export type ProjectUsersContext = Context & {
  filterQuery?: FilterQuery<Project>;
};

/**
 * Check if all values of arr1 are present in arr2, regardless of order
 *
 * Returns true if they are
 *
 * @param arr1
 * @param arr2
 */

const validateProject = async (ctx: Context, project: Project) => {
  const { ownersGroupId, membersGroupId, members, owners } = project;

  const [graphOwners, graphMembers] = await Promise.all([
    GraphService.getGroupUsers(ctx, ownersGroupId, ["id", "userType", "mail", "userPrincipalName"]),
    GraphService.getGroupUsers(ctx, membersGroupId, ["id"]),
  ]);

  const groupOwners = graphOwners.map(({ id }) => id);
  const groupMembers = graphMembers.map(({ id }) => id);

  if (!arraysAreEquivalent(owners, groupOwners) || !arraysAreEquivalent(members, groupMembers)) {
    ctx.log(`Missmatching owners or members`, { owners, groupOwners, members, groupMembers });
    await ProjectModel.updateOne(
      { _id: project._id },
      { $set: { members: groupMembers, owners: groupOwners } },
    );
  } else {
    ctx.log(`Project ${project.name}'s users are up to date`);
  }

  // check org of project
  const {
    owners: ownersEntitlement,
    members: membersEntitlement,
    team: teamEntitlement,
  } = await EntitlementsService.getProjectEntitlements(ctx, project.name);
  if (
    ownersEntitlement.owner !== membersEntitlement.owner ||
    ownersEntitlement.owner !== teamEntitlement.owner
  ) {
    throw new Error(
      `Missmatching entitlements owners: owners ${ownersEntitlement.owner}, members ${membersEntitlement.owner}, team ${teamEntitlement.owner}`,
    );
  }

  if (teamEntitlement.owner === project.org) {
    ctx.log(`Project ${project.name}'s org is already set correctly`);
  } else {
    ctx.log(`Updating project org from ${project.org} to ${teamEntitlement.owner}`);
    await ProjectModel.updateOne({ _id: project._id }, { $set: { org: teamEntitlement.owner } });
  }
};

const ProjectUsers = {
  /**
   * Goes through each project and ensures the 'owners' and 'members' match the project's Azure groups
   * @param ctx
   * @param query optional query to filter projects to validate. Used by unit tests
   */
  async validateProjectUsers(ctx: Context, query: FilterQuery<Project> = {}) {
    const projects = await ProjectModel.find({ ...query, status: ProjectStatus.Active });

    ctx.log(`Found ${projects.length} to validate`);
    const errors: string[] = [];

    for (let index = 0; index < projects.length; index++) {
      const project = projects[index];
      try {
        await validateProject(ctx, project);
      } catch (err) {
        const message = `Project ${project.name} could not be validated: ${(err as Error).message}`;
        ctx.log(err, message);
        errors.push(message);
      }
    }
    if (errors.length) {
      await SlackService.logWarning(ctx, new Error(errors.join("\n")));
    }
  },
};
export default ProjectUsers;
