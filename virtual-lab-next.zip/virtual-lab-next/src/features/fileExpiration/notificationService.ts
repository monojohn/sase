import { Context } from "@azure/functions";
import type { IFileInfo } from "@pnp/sp/files";
import EmailService from "../../services/emailService/emailService";
import { getDaysUntilFileExpires } from "./helpers";
import { ProjectAndExpiredFiles } from "./types";
import { TEMPLATE_ID } from "../../services/emailService/flowmailer";

type FilesExpiringEmailProps = ProjectAndExpiredFiles & {
  emails: string[];
};

const getFileRows = (files: IFileInfo[]) => {
  const now = Date.now();
  return files
    .map((file) => {
      const daysUntilExpiration = getDaysUntilFileExpires(now, file);
      return `
      <tr>
        <td><a href="${file.LinkingUrl}">${file.Name}</a></td>
        <td>${Math.max(daysUntilExpiration, 0)}</td>
      </tr>
      `;
    })
    .join("");
};

const NotificationService = {
  async sendFilesExpiringEmail(ctx: Context, props: FilesExpiringEmailProps) {
    const { project, emails, expiringFiles } = props;

    const count = expiringFiles.length;
    const subject = `[Action required] Warning: ${count} file(s) of ${project.name} will be deleted soon`;
    const ctaLabel = "View files";

    const ctaUrl = `${project.url}`;

    return EmailService.sendEmail(ctx, TEMPLATE_ID.FILE_DELETION, {
      bcc: emails,
      subject,
      templateData: {
        count,
        ctaUrl,
        ctaLabel,
        fileRows: getFileRows(expiringFiles.map(({ file }) => file)),
      },
    });
  },
};

export default NotificationService;
