import type { IFileInfo } from "@pnp/sp/files";
import { Project } from "../../services/dbConnector/models/project";

export type ExpiredFile = {
  file: IFileInfo;
  daysUntilExpiration: number;
};

export type ProjectAndExpiredFiles = {
  project: Project;
  expiringFiles: ExpiredFile[];
};
