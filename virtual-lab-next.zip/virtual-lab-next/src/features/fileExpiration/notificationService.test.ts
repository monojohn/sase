import { jest } from "@jest/globals";
import NotificationService from "./notificationService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("File Expiration NotificationService", () => {
  it("sendSuccessEmail works", async () => {
    await NotificationService.sendFilesExpiringEmail(ctx, {
      emails: [userEmail],
      expiringFiles: [
        {
          file: {
            LinkingUrl: "LinkingUrl",
            Name: "Name",
            TimeLastModified: Date.now(),
          },
          daysUntilExpiration: 1,
        },
      ] as any,
      project: { Title: "Unit test", ProjectSiteUrl: { Url: "Url" } } as any,
    });
  });
});
