import { Context } from "@azure/functions";
import { IFileInfo } from "@pnp/sp/files/index";
import moment from "moment";
import FileExpirationModel, {
  FileExpiration,
} from "../../services/dbConnector/models/fileExpirationModel";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import UserActionModel from "../../services/dbConnector/models/userActionModel";
import GraphService from "../../services/graphService/graphService";
import FilesService from "../../services/sharepointService/filesService";
import SpFolderService from "../../services/sharepointService/spFolderService";
import SlackService from "../../services/slackService";
import { chunkArray } from "../../utils/chunkArray";
import { ActionStatus, ActionType } from "../userActions/enums";
import { getDaysUntilFileExpires, shouldFileBeIgnored } from "./helpers";
import NotificationService from "./notificationService";
import { ExpiredFile, ProjectAndExpiredFiles } from "./types";
import { wait } from "../../utils/helpers";
import { ProjectStatus } from "../../services/dbConnector/enums";

const DAYS_FOR_LOGGING_ACTION = 1;
const DAYS_FOR_URGENT_NOTIFICATION = 4;
const DAYS_FOR_WARNING_NOTIFICATION = 10;

export const getExpiringFiles = async (ctx: Context, project: Project) => {
  const now = Date.now();
  const filesCloseToExpiration: ExpiredFile[] = [];

  try {
    const { teamGroupId } = project;
    // skip check when groupId is not present
    if (!teamGroupId) {
      const message = `Broken project detected, skipping file check: ${project.name}`;
      ctx.log(message);
      await SlackService.logWarning(ctx, new Error(message));
      return filesCloseToExpiration;
    }

    ctx.log(`Getting site for ${project.name} and group ${teamGroupId}`);
    // get site name. siteName is NOT *always* the group name, *sometimes* it's different
    const site = await GraphService.getSiteById(ctx, teamGroupId);

    // Get all project files
    ctx.log(`Getting files of ${project.name}`);
    const projectFiles = await SpFolderService.getProjectFiles(ctx, site.name);
    // Keep files close to expiration
    ctx.log(`Filtering ${projectFiles.length} files of ${project.name}`);

    return projectFiles.reduce((acc, file) => {
      if (shouldFileBeIgnored(project, file)) {
        ctx.log(`Ignoring file ${file.Name}`);
        return acc;
      }
      const daysUntilExpiration = getDaysUntilFileExpires(now, file);

      ctx.log({
        fileName: file.Name,
        daysUntilExpiration,
        leq: daysUntilExpiration <= DAYS_FOR_WARNING_NOTIFICATION,
      });

      // store files expiring in DAYS_FOR_WARNING_NOTIFICATION days
      if (daysUntilExpiration <= DAYS_FOR_WARNING_NOTIFICATION) {
        acc.push({ file, daysUntilExpiration });
      }

      return acc;
    }, filesCloseToExpiration);
  } catch (e) {
    const errMessage = `Failed to get expiring files of project #${project?._id}: ${project?.name}`;
    ctx.log(errMessage, e);
    await SlackService.logWarning(ctx, new Error(errMessage));
  }

  return filesCloseToExpiration;
};

export const getProjectWithExpiringFiles = async (ctx: Context) => {
  // get all projects
  const projects = await ProjectModel.find({ status: ProjectStatus.Active }).lean();
  const projectsWithExpiringFiles: ProjectAndExpiredFiles[] = [];

  // chunk to prevent graph timeouts
  const chunks = chunkArray(projects);

  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    await Promise.all(
      // for each project
      chunk.map(async (project) => {
        const expiringFiles = await getExpiringFiles(ctx, project);
        if (expiringFiles.length > 0) {
          projectsWithExpiringFiles.push({ project, expiringFiles });
        }
      }),
    );
  }

  return projectsWithExpiringFiles;
};

export const notifyOwnersOfFileExpiration = async (ctx: Context) => {
  // get projects and files which are expiring
  ctx.log("Getting projects with expiring files");
  const projectsWithExpiringFiles = await getProjectWithExpiringFiles(ctx);
  ctx.log(`Found ${projectsWithExpiringFiles.length} projects with expiring files`);

  // get emails of project owners
  ctx.log("Chunking results");
  const chunks = chunkArray(projectsWithExpiringFiles);

  // keep track of failed attempts
  let failures = 0;

  ctx.log(`Processing ${chunks.length} chunks`);
  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    ctx.log(`Processing chunk ${index} / ${chunks.length}`);

    const results = await Promise.allSettled(
      chunk.map(async (pair) => {
        await FilesService.logExpiringFiles(
          pair.project._id,
          pair.expiringFiles
            .filter(({ daysUntilExpiration }) => daysUntilExpiration <= DAYS_FOR_LOGGING_ACTION)
            .map(({ file }) => file),
        );

        if (
          pair.expiringFiles.some(
            ({ daysUntilExpiration }) => daysUntilExpiration === DAYS_FOR_URGENT_NOTIFICATION,
          )
        ) {
          // if there's at least one file for which the days until expiration is equal to days for urgent notification
          const emails = await GraphService.getGroupOwnersEmails(ctx, pair.project.name);

          if (emails.length === 0) {
            // if a project has expiring files but no owners were found, throw an error
            const error = `No owners found for project ${pair.project.name} with ${pair.expiringFiles.length} files expiring soon`;
            ctx.log(error);
            throw new Error(error);
          }

          ctx.log(
            `Notifying ${emails.length} owners of project ${pair.project.name} with ${pair.expiringFiles.length} files expiring soon`,
          );
          await NotificationService.sendFilesExpiringEmail(ctx, {
            ...pair,
            emails,
          });
        }
      }),
    );

    // eslint-disable-next-line @typescript-eslint/no-loop-func
    for (const [i, promise] of results.entries()) {
      if (promise.status === "rejected") {
        const { _id, name } = chunk[i].project;
        // keep track of errors
        failures += 1;

        ctx.log(`Failed to get owners for project ${_id}: ${name}`, promise.reason);
      }
    }

    await wait(1);
  }

  // if any errors happened, send slack message
  if (failures > 0) {
    const error = new Error(
      `Had ${failures} failures when fetching projects with files close to expiration`,
    );
    ctx.log(error);
    await SlackService.logError(ctx, error);
  }

  return projectsWithExpiringFiles;
};

/**
 * Compare a project's files to the expiring files entry from the FileExpiration list
 *
 * @param ctx Context
 */
const compareExpiringFilesToProjectFiles = async (
  ctx: Context,
  pid: string,
  filesToCheck: FileExpiration[],
  projectFiles: IFileInfo[],
) => {
  // checking files one by one so DB can handle the requests
  for (const fileToCheck of filesToCheck) {
    const { _id, fileId, fileName } = fileToCheck;
    const file = projectFiles.find(({ UniqueId }) => UniqueId === fileId);
    if (file) {
      // check when the file will expire
      const daysUntilExpiration = getDaysUntilFileExpires(Date.now(), file);
      if (daysUntilExpiration > DAYS_FOR_LOGGING_ACTION) {
        await wait(1);
        // file was updated and doesn't expire anymore -> remove entry from FileExpiration list
        await FileExpirationModel.deleteOne({ _id }).lean();
      }
    } else {
      // the file doesn't exist anymore -> add it to UserActions and remove it from FileExpiration
      await wait(1);
      await UserActionModel.create({
        pid,
        oid: "system",
        target: fileName,
        status: ActionStatus.DONE,
        action: ActionType.FILE_REMOVAL,
        invocationId: ctx.invocationId,
      });

      await FileExpirationModel.deleteOne({ _id }).lean();
    }
  }
};

/**
 * Check if the expring files from the FileExpiration list have been removed
 *
 * @param ctx Context
 */
export const checkLoggedExpiringFiles = async (ctx: Context) => {
  const expiringFiles = await FileExpirationModel.find().lean();
  const possiblyExpiredFiles = expiringFiles.filter(
    ({ expirationTimestamp }) => moment.utc(expirationTimestamp) < moment.utc(),
  );

  if (possiblyExpiredFiles.length === 0) {
    return;
  }
  const projects = await ProjectModel.find({ status: ProjectStatus.Active }).lean();

  // get only the projects that could have expired files
  const filteredProjects = projects.filter(({ _id }) =>
    possiblyExpiredFiles.map(({ pid }) => pid).includes(_id.toString()),
  );

  const errors: string[] = [];
  // for each project that contains at least a file that could be expired
  for (const project of filteredProjects) {
    const { _id, teamGroupId } = project;
    try {
      // get all the files that have to be checked for that project
      const filesToCheck = possiblyExpiredFiles.filter(({ pid }) => pid === _id.toString());
      const site = await GraphService.getSiteById(ctx, teamGroupId);

      // get all the files that the project has
      const projectFiles = await SpFolderService.getProjectFiles(ctx, site.name);

      // validate the files that are marked as expired against the existing files
      await compareExpiringFilesToProjectFiles(ctx, _id, filesToCheck, projectFiles);
    } catch (err) {
      ctx.log(err);
      const error = `Failed to compare expiring files to project files for project ${project.name}`;
      errors.push(error);
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};
