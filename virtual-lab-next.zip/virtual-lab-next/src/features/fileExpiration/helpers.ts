import type { IFileInfo } from "@pnp/sp/files";
import { Project } from "../../services/dbConnector/models/project";

export const MAX_DAYS_UNCHANGED = 365;

export const getDaysUntilFileExpires = (now: number, file: IFileInfo) => {
  const daysUnchanged = (now - Date.parse(file.TimeLastModified)) / 1000 / 60 / 60 / 24;
  return Math.round(MAX_DAYS_UNCHANGED - daysUnchanged);
};

export const shouldFileBeIgnored = (project: Project, file: IFileInfo) => {
  const ignorableNames = [
    "Wiki.one",
    "Wiki.onetoc2",
    `VL - ${project.name} - Wiki.one`,
    `VL - ${project.name} - Wiki.onetoc2`,
  ];
  return ignorableNames.includes(file.Name);
};
