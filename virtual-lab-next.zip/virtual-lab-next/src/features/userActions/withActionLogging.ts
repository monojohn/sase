import { HttpTriggerMw } from "../../../@types/types";
import { ActionStatus, ActionType } from "./enums";
import { logAction, updateActionStatus } from "./userActions";

export const withActionLogging: HttpTriggerMw<ActionType> = (handler, action) => async (ctx) => {
  let id: string = "";

  try {
    const userAction = {
      action,
      oid: ctx.session.oid,
      pid: ctx.req.params.pid,
    };

    // log action
    ctx.log(`Creating user action `, { userAction });
    try {
      const item = await logAction(ctx, userAction);

      id = item._id.toString();
      ctx.log(`User action #${id} created`);
      ctx.actionId = id;
    } catch (e) {
      ctx.log(`Failed to create action`, e);
    }

    // run action
    await handler(ctx);

    // log success
    await updateActionStatus(ctx, ActionStatus.DONE);
  } catch (e) {
    // log error
    await updateActionStatus(ctx, ActionStatus.ERROR);
    throw e;
  }
};
