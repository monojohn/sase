import { Context } from "@azure/functions";
import { ActionStatus, ActionType } from "./enums";

export type Action = {
  Id: number;
  ID: number;
  oid: string;
  action: ActionType;
  pid: number;
  status: ActionStatus;
  Created: string;
  Modified: string;
  invocationId: string;
  target?: string;
};

export type ContextWithActionId = Context & {
  actionId: string;
};
