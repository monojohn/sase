import { Context } from "@azure/functions";
import { UserAction } from "../../services/dbConnector/models/userAction";
import UserActionModel from "../../services/dbConnector/models/userActionModel";
import { ActionStatus } from "./enums";
import { ContextWithActionId } from "./types";

export const getProjectActions = (pid: string) => UserActionModel.find({ pid });

type LogActionProps = Pick<UserAction, "action" | "oid" | "pid">;

export const logAction = async (ctx: Context, action: LogActionProps) =>
  UserActionModel.create({
    ...action,
    status: ActionStatus.PENDING,
    invocationId: ctx.invocationId,
  });

export const updateAction = async (ctx: Context, update: Partial<UserAction>) => {
  const { actionId } = ctx as ContextWithActionId;

  if (!actionId) {
    const error = "actionId not present when applying update";
    ctx.log.error(error, update);
    throw new Error(error);
  }

  ctx.log(`Updating action ${actionId}`, update);
  return UserActionModel.findOneAndUpdate({ _id: actionId }, { $set: update }, { lean: true });
};

export const updateActionStatus = (ctx: Context, status: ActionStatus) =>
  updateAction(ctx, { status });

export const updateActionTarget = (ctx: Context, target: string) => updateAction(ctx, { target });

export const updateActionPid = (ctx: Context, pid: string) => updateAction(ctx, { pid });
