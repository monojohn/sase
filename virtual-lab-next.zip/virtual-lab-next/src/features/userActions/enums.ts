export enum ActionStatus {
  PENDING = "pending",
  ERROR = "error",
  DONE = "done",
}

export enum ActionType {
  ACCEPT_OWNERSHIP = "Accept ownership",
  REJECT_OWNERSHIP = "Reject ownership",

  ADD_MEMBER = "Add member",
  REMOVE_MEMBER = "Remove member",
  BULK_ADD_MEMBER = "Bulk add member",

  REQUEST_MEMBERSHIP = "Request membership",
  CANCEL_MEMBERSHIP_REQUEST = "Cancel membership request",

  ACCEPT_MEMBERSHIP = "Accept membership",
  REJECT_MEMBERSHIP = "Reject membership",

  ADD_OWNER = "Add owner", // admins can add owners directly
  INVITE_OWNER = "Invite owner",
  REMOVE_OWNER = "Remove owner",

  CREATE_WORKSPACE = "Create ML workspace",
  UPDATE_WORKSPACE = "Update ML workspace",
  DELETE_WORKSPACE = "Delete ML workspace",

  CREATE_OPENAI_USE_CASE = "Create OpenAI Use Case",
  UPDATE_OPENAI_USE_CASE = "Update OpenAI Use Case",

  CREATE_REPOSITORY = "Create GIT Repository",
  DELETE_REPOSITORY = "Delete GIT Repository",

  ADD_ENTITLEMENTS_AND_ROLES = "Add Entitlements and Roles",

  UPDATE_PROJECT_SETTINGS = "Update project settings", // this has been replaced by the ones below. we still keep it as there will be data saved in the DB using it

  UPDATE_ACCESSIBILITY = "Update accessibility",
  UPDATE_CONFIDENTIALITY = "Update confidentiality",
  UPDATE_DATA_SENSITIVITY = "Update data sensitivity level",
  UPDATE_DESCRIPTION = "Update description",
  UPDATE_ICON = "Update icon",
  UPDATE_TAGS = "Update tags",
  EDIT_PROJECT_RESOURCES = "Edit links",

  CREATE_PROJECT = "Create project",
  DELETE_PROJECT = "Delete project",

  FILE_REMOVAL = "File removal",

  UPDATE_ORG = "Update organization",

  REQUEST_WHITELIST = "Request whitelist",
}
