import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
} from "../../services/dbConnector/enums";
import { VlComponent } from "./enums";

export type FilesVersions = { fileInfo: FileWithModifiedBy; versions: FileVersion[] };

export type ComponentLog = {
  timestamp: Date;
  oid?: string;
  email?: string;
  component: VlComponent;
};

export type UserLog = {
  oid: string;
  component: VlComponent;
  timestamp: Date;
};

export type UserMetadata = {
  oid: string;
  institution: string;
  businessArea: string;
  division: string;
  section: string;
  countryCode: string;
  email: string;
  timestamp: Date;
};

export type ProjectLog = {
  id: string;
  name: string;
  dataSensitivityLevel: DataSensitivityLevel;
  accessibilityLevel: AccessibilityLevel;
  confidentialityLevel: ConfidentialityLevel;
  mlWorkspace: boolean;
  secureWorkspace: boolean;
  activeWorkspace: boolean;
  mlEndpointsCount: number;
  cpuCount: number;
  gpuCount: number;
  gitRepo: boolean;
  activeGit: boolean;
  activeFiles: boolean;
  activePlanner: boolean;
  activeTeams: boolean;
  lastMonthCosts: number | string;
  thisYearCosts: number | string;
  vlTestProject: boolean;
  vlDemoProject: boolean;
  projectDescription: string;
  creationDate: Date;
  modifiedDate: Date;
  tags: string;
  projectResources: boolean;
  rolesAndEntitlements: boolean;
  timestamp: Date;
  aiUseCaseId: string;
  baOrg: string;
};

export type ProjectToUser = {
  pid: string;
  oid: string;
  owner: boolean;
  timestamp: Date;
};

export type TokenConsumption = {
  workspace: string;
  model: string;
  consumed: number;
  limits: number;
  remaining: number;
  timestamp: Date;
};
