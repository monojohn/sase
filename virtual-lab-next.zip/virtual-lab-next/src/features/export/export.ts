import { Context } from "@azure/functions";
import moment from "moment";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { chunkArray } from "../../utils/chunkArray";
import { endOfLastMonth, fetchCollectionInChunks, startOfLastMonth } from "../../utils/helpers";
import { Project } from "../../services/dbConnector/models/project";
import SlackService from "../../services/slackService";
import {
  ComponentLog,
  ProjectLog,
  ProjectToUser,
  TokenConsumption,
  UserLog,
  UserMetadata,
} from "./types";
import TeamsService from "../../services/teamService/teamsService";
import UserActionModel from "../../services/dbConnector/models/userActionModel";
import {
  buildUserLog,
  buildUserMetadata,
  filterByLastMonth,
  getComputeCount,
  getFilesLogs,
  getPlannerLogs,
  getSettledResult,
  getProjectLogs,
  getSofaLogs,
  getTimestamp,
  getUserData,
  getWorkspaceLogs,
} from "./helpers";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import { ProjectStatus } from "../../services/dbConnector/enums";
import { WorkspaceType } from "../../services/sharepointService/enums";
import DevoService from "../../services/devoService/devoService";
import { OpenAIUsage } from "../../services/dbConnector/models/OpenAIUsage";
import { enrichOpenAiUsage, findOpenAiUsage } from "../../utils/openAIUsage";
import StatisticsModel from "../../services/dbConnector/models/statistics";
import GraphService from "../../services/graphService/graphService";
import { VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../../utils/config";
import { VlComponent } from "./enums";

const timePeriod = 30;

const getProjectData = async (ctx: Context, project: Project) => {
  // get logs with allSettled so if some fail, we still get some for the other components
  const [files, planner, sofa, workspace, computes] = await Promise.allSettled([
    getFilesLogs(ctx, project),
    getPlannerLogs(ctx, project),
    getSofaLogs(ctx, project),
    getWorkspaceLogs(ctx, project),
    getComputeCount(ctx, project),
  ]);
  const { logs: workspaceLogs, endpointsCount: mlEndpointsCount } =
    workspace.status === "fulfilled" ? workspace.value : { logs: [], endpointsCount: 0 };
  return {
    files: filterByLastMonth(getSettledResult(files)),
    planner: filterByLastMonth(getSettledResult(planner)),
    sofa: filterByLastMonth(getSettledResult(sofa)),
    workspace: filterByLastMonth(workspaceLogs),
    computes: computes.status === "fulfilled" ? computes.value : { cpuCount: 0, gpuCount: 0 },
    mlEndpointsCount,
  };
};

export const monthlyExport = async (ctx: Context) => {
  const errors: string[] = [];
  const allProjectLogs: {
    files: ComponentLog[];
    planner: ComponentLog[];
    sofa: ComponentLog[];
    workspace: ComponentLog[];
    computes: { cpuCount: number; gpuCount: number };
    mlEndpointsCount: number;
    project: Project;
  }[] = [];
  const timestamp = getTimestamp();

  const [projects, teamsReport, userActions, userData, lastMonthCosts, thisYearCosts] =
    await Promise.all([
      ProjectModel.find({ status: ProjectStatus.Active }).lean(),
      TeamsService.getReport(ctx, timePeriod),
      fetchCollectionInChunks(UserActionModel, { oid: { $ne: "system" } }),
      getUserData(ctx),
      MachineLearningService.getCosts(
        ctx,
        startOfLastMonth().startOf("month").toISOString(),
        endOfLastMonth().endOf("month").toISOString(),
      ),
      MachineLearningService.getCosts(
        ctx,
        startOfLastMonth().startOf("year").toISOString(),
        endOfLastMonth().endOf("month").toISOString(),
      ),
    ]);

  // get project data
  const projectChunks = chunkArray(projects);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const data = await getProjectData(ctx, project);
        allProjectLogs.push({ ...data, project });
      }),
    );
    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(
          `Error for project ${chunk[ind].name}: ${(promiseResult.reason as Error).toString()}`,
        );
      }
    }
  }

  // build user metadata
  const userMetadata = userData.map((user) => {
    const { userDetails, error } = buildUserMetadata(user);
    if (error) {
      errors.push(error);
    }
    return userDetails as UserMetadata;
  });

  // build user logs
  const projectLogs = await getProjectLogs();
  const userLogs = [
    ...projectLogs,
    ...allProjectLogs
      .flatMap(({ files, planner, sofa, workspace }) => [
        ...files,
        ...planner,
        ...sofa,
        ...workspace,
      ])
      .sort((a, b) => moment.utc(a.timestamp).diff(moment.utc(b.timestamp)))
      .flatMap((log) => buildUserLog(userData, log)),
  ] as UserLog[];

  // save current statistics
  const [ecbUsers, guestUsers] = await Promise.all([
    GraphService.getAllGroupUsers(ctx, VL_MEMBERS_GROUP_ID, ["id"]),
    GraphService.getAllGroupUsers(ctx, VL_GUESTS_GROUP_ID, ["id"]),
  ]);

  await StatisticsModel.create({
    registeredUsers: ecbUsers.length + guestUsers.length,
    projects: projects.length,
    activeUsers: new Set(projectLogs.map(({ oid }) => oid)).size,
    siteVisits: projectLogs.filter(({ component }) => component === VlComponent.ProjectLogs).length,
  });

  // build project logs
  const formattedProjectLogs = allProjectLogs.map(
    ({ files, planner, sofa, workspace, project, computes, mlEndpointsCount }) => {
      const {
        name,
        dataSensitivityLevel,
        accessibilityLevel,
        confidentialityLevel,
        workspaceType,
        tags,
        description,
        createdAt,
        _id,
        resources,
        rolesAndEntitlements,
        repositoryUrl,
        workspaceUrl,
        teamGroupId,
      } = project;
      const { cpuCount, gpuCount } = computes;
      const lastProjectActivity =
        userActions
          .filter(({ pid }) => pid === _id.toString())
          .sort((a, b) => moment.utc(b.createdAt).diff(moment.utc(a.createdAt)))[0]?.createdAt ||
        createdAt;

      const log: ProjectLog = {
        id: _id.toString(),
        name,
        dataSensitivityLevel,
        accessibilityLevel,
        confidentialityLevel,
        mlWorkspace: workspaceUrl?.startsWith("http") ?? false,
        secureWorkspace: workspaceType === WorkspaceType.SECURED,
        activeWorkspace: workspace.length > 0,
        mlEndpointsCount,
        cpuCount,
        gpuCount,
        gitRepo: repositoryUrl?.startsWith("http") ?? false,
        activeGit: sofa.length > 0,
        activeFiles: files.length > 0,
        activePlanner: planner.length > 0,
        activeTeams: TeamsService.isTeamActive(teamsReport, teamGroupId),
        lastMonthCosts:
          lastMonthCosts.properties.rows.find(
            (array) => array[2] === project.name.toLowerCase(),
          )?.[0] ?? 0,
        thisYearCosts:
          thisYearCosts.properties.rows.find(
            (array) => array[2] === project.name.toLowerCase(),
          )?.[0] ?? 0,
        vlTestProject: tags.includes("VL_internal_test"),
        vlDemoProject: tags.includes("VL_demo"),
        projectDescription: description,
        creationDate: moment.utc(createdAt).toDate(),
        modifiedDate: moment.utc(lastProjectActivity).toDate(),
        tags: tags.join(", "),
        projectResources: resources.length > 0,
        rolesAndEntitlements: rolesAndEntitlements?.length > 0,
        timestamp,
        aiUseCaseId: project.aiUseCaseId ?? "",
        baOrg: project.org,
      };
      return log;
    },
  );

  // build project to user connection
  const projectToUser: ProjectToUser[] = [];
  for (const { _id, owners, members } of projects) {
    projectToUser.push(
      ...owners.map((oid) => ({ pid: _id.toString(), oid, owner: true, timestamp })),
      ...members.map((oid) => ({ pid: _id.toString(), oid, owner: false, timestamp })),
    );
  }

  let enrichedMetrics: TokenConsumption[] = [];
  try {
    const yearMonth = startOfLastMonth().format("YYYY-MM") as OpenAIUsage["month"];

    ctx.log(`Finding all OpenAI usage metrics for ${yearMonth}`);
    const metrics = await findOpenAiUsage(yearMonth);

    ctx.log(`Counting remaining token usage...`);
    enrichedMetrics = enrichOpenAiUsage(metrics, timestamp);
  } catch (e) {
    ctx.log(e);
    errors.push(`Failed to retrieve tokens`);
  }

  // upload data to Devo
  await Promise.all([
    DevoService.uploadData(ctx, userMetadata, "user_metadata"),
    DevoService.uploadData(ctx, projectToUser, "project_to_user"),
    DevoService.uploadData(ctx, userLogs, "user_logs"),
    DevoService.uploadData(ctx, formattedProjectLogs, "project_logs"),
    DevoService.uploadData(ctx, enrichedMetrics, "token_consumption"),
  ]);

  if (errors.length) {
    const message = new Error(`Errors during cron-logs: ${[...new Set(errors)].join("\n")}`);
    await SlackService.logWarning(ctx, message);
  }
};
