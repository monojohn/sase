import { Context } from "@azure/functions";
import moment from "moment";
import XLSX from "xlsx";
import { Workspace } from "@azure/arm-machinelearning";
import { Project } from "../../services/dbConnector/models/project";
import GraphService from "../../services/graphService/graphService";
import SpFolderService from "../../services/sharepointService/spFolderService";
import PlannerService from "../../services/plannerService/plannerService";
import RepositoryService from "../../services/repositoryService/repositoryService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import UserVisitModel from "../../services/dbConnector/models/userVisitModel";
import UserActionModel from "../../services/dbConnector/models/userActionModel";
import {
  endOfLastMonth,
  fetchCollectionInChunks,
  getEmailOfUser,
  startOfLastMonth,
  withRetry,
} from "../../utils/helpers";
import { TaskResponse } from "../../services/plannerService/types";
import { ComponentLog } from "./types";
import { VlComponent } from "./enums";
import { VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../../utils/config";
import { isTechnicalAccount } from "../../utils/isTechnicalAccount";

import { GraphUser, Institution } from "../../services/graphService/types";
import { institutionsToCountryMap } from "../../services/graphService/constants";

const userProps: (keyof GraphUser)[] = [
  "id",
  "mail",
  "otherMails",
  "userType",
  "identities",
  "department",
  "displayName",
];

export const filterByLastMonth = (logs: ComponentLog[]) =>
  logs.filter(({ timestamp }) =>
    moment(timestamp).isBetween(startOfLastMonth(), endOfLastMonth(), null, "[]"),
  );

export const getTimestamp = () => moment().subtract(1, "month").toDate();

export const getFilesLogs = async (ctx: Context, project: Project) => {
  const site = await GraphService.getSiteById(ctx, project.teamGroupId);
  const logs: ComponentLog[] = [];
  // with retry because files aren't always retrieved on the first try
  await withRetry(
    async () => {
      const projectFiles = await SpFolderService.getProjectFiles(ctx, site.name);
      const fileVersions = await SpFolderService.getFilesVersions(site.name, projectFiles);
      logs.push(
        ...fileVersions.flatMap(({ fileInfo, versions }) => [
          {
            timestamp: new Date(fileInfo.TimeLastModified),
            email: fileInfo.ModifiedBy?.Email,
            component: VlComponent.File,
          },
          ...versions.map(({ Created, CreatedBy }) => ({
            timestamp: new Date(Created),
            email: CreatedBy?.Email,
            component: VlComponent.File,
          })),
        ]),
      );
    },
    ctx,
    10,
  );
  return logs;
};

export const getPlannerLogs = async (ctx: Context, project: Project) => {
  let plannerTasks: TaskResponse[][] = [];
  // with retry because planner throws 429
  await withRetry(
    async () => {
      plannerTasks = await PlannerService.getAllPlannerTasks(ctx, project.teamGroupId);
    },
    ctx,
    10,
  );
  const logs = plannerTasks.flat(1).flatMap(({ assignments, createdBy, createdDateTime }) => [
    { timestamp: new Date(createdDateTime), oid: createdBy.user.id },
    ...Object.values(assignments).map(({ assignedBy, assignedDateTime }) => ({
      timestamp: new Date(assignedDateTime),
      oid: assignedBy?.user?.id,
    })),
  ]);

  return logs.map((log) => ({
    ...log,
    component: VlComponent.Planner,
  }));
};

export const getSofaLogs = async (ctx: Context, project: Project) => {
  if (!project.repositoryUrl?.startsWith("http")) {
    return [];
  }
  const commits = await RepositoryService.getCommitsForAllRepos(ctx, project);
  return commits.commitDetails.flat(1).map(({ author_email, authored_date }) => ({
    timestamp: new Date(authored_date),
    email: author_email,
    component: VlComponent.Sofa,
  }));
};

export const getWorkspaceEndpointsCount = async (ctx: Context, workspace: Workspace) => {
  const workspaceName = workspace.name!;

  const workspaceProperties = await MachineLearningService.getWorkspaceProperties(
    ctx,
    workspaceName,
  );
  if (workspaceProperties.properties.v1LegacyMode === true) {
    // if legacy mode is true, there are no endpoints
    return 0;
  }

  const [onlineEndpoints, batchEndpoints, serverlessEndpoints] = await Promise.all([
    MachineLearningService.getOnlineEndpoints(ctx, workspaceName),
    MachineLearningService.getBatchEndpoints(ctx, workspaceName),
    MachineLearningService.getServerlessEndpoints(ctx, workspaceName),
  ]);

  return onlineEndpoints.length + batchEndpoints.length + serverlessEndpoints.length;
};

export const getWorkspaceLogs = async (ctx: Context, project: Project) => {
  if (!project.workspaceUrl?.startsWith("http")) {
    return {
      logs: [],
      endpointsCount: 0,
    };
  }
  const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
  if (!workspace?.id) {
    const error = `Project ${project.name} workspace is missing`;
    ctx.log(error);
    throw new Error(error);
  }
  const [activityLogs, endpointsCount] = await Promise.all([
    MachineLearningService.getActivityLog(
      ctx,
      workspace.id,
      startOfLastMonth().format(),
      endOfLastMonth().format(),
    ),
    getWorkspaceEndpointsCount(ctx, workspace),
  ]);
  return {
    logs: activityLogs.map(({ caller, eventTimestamp }) => ({
      timestamp: new Date(eventTimestamp),
      email: caller,
      component: VlComponent.ML,
    })),
    endpointsCount,
  };
};

export const getProjectLogs = async () => {
  const userVisits = await fetchCollectionInChunks(UserVisitModel, {
    createdAt: { $gte: startOfLastMonth(), $lte: endOfLastMonth() },
  });
  const userActions = await fetchCollectionInChunks(UserActionModel, {
    $and: [
      { createdAt: { $gte: startOfLastMonth(), $lte: endOfLastMonth() } },
      { oid: { $ne: "system" } },
    ],
  });
  const visitLogs = userVisits.map(({ oid, createdAt }) => ({
    oid,
    component: VlComponent.ProjectLogs,
    timestamp: createdAt,
  }));
  const actionLogs = userActions.map(({ oid, createdAt }) => ({
    oid,
    component: VlComponent.ProjectActions,
    timestamp: createdAt,
  }));
  return [...visitLogs, ...actionLogs];
};

export const readExcelFile = (fileBuffer: ArrayBuffer): (string | number | boolean | null)[][] => {
  const workbook = XLSX.read(fileBuffer, { type: "array" });

  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  return XLSX.utils.sheet_to_json(sheet, { header: 1 });
};

export const getComputeCount = async (ctx: Context, project: Project) => {
  let cpuCount = 0;
  let gpuCount = 0;
  if (!project.workspaceUrl?.startsWith("http")) {
    return { cpuCount, gpuCount };
  }
  const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
  if (!workspace?.id || !workspace?.name) {
    return { cpuCount, gpuCount };
  }
  const computes = await MachineLearningService.getComputes(ctx, workspace.name);
  const computeInstances = computes.filter(
    ({ properties }) => properties.computeType === "ComputeInstance",
  );

  for (const compute of computeInstances) {
    if (MachineLearningService.isComputeInstanceGPU(compute)) {
      gpuCount += 1;
    } else {
      cpuCount += 1;
    }
  }

  return { cpuCount, gpuCount };
};

export const getUserData = async (ctx: Context) => {
  const [ecbUsers, guestUsers] = await Promise.all([
    GraphService.getGroupUsers(ctx, VL_MEMBERS_GROUP_ID, userProps),
    GraphService.getGroupUsers(ctx, VL_GUESTS_GROUP_ID, userProps),
  ]);
  return [
    ...ecbUsers.filter(({ displayName }) => !isTechnicalAccount(displayName)),
    ...guestUsers.filter(({ displayName }) => !isTechnicalAccount(displayName)),
  ];
};

export const getBusinessAreaSplit = (department: string) => {
  const split = department?.replaceAll("-", "/").split("/") ?? [];
  const businessArea = split?.[0];
  const division = split?.[1];
  const section = split?.[2];
  return { businessArea, division, section };
};

export const buildUserMetadata = (user: Pick<GraphUser, (typeof userProps)[number]>) => {
  const email = getEmailOfUser(user) ?? "";
  const emailSuffix = email?.split("@")[1]?.toLowerCase() as Institution;
  const institutionInfo = institutionsToCountryMap[emailSuffix];

  let businessArea = "";
  let division = "";
  let section = "";
  if (user.userType === "Member") {
    const split = getBusinessAreaSplit(user.department);
    businessArea = split.businessArea ?? "";
    division = split.division ?? "";
    section = split.section ?? "";
  }

  const userDetails = {
    oid: user.id,
    institution: institutionInfo?.institutionAcronym ?? "",
    businessArea,
    division,
    section,
    countryCode: institutionInfo?.countryCode ?? "",
    email,
    timestamp: getTimestamp(),
  };

  if (!institutionInfo) {
    return {
      error: `Institution does not exist for ${emailSuffix}`,
      userDetails,
    };
  }

  return {
    userDetails,
  };
};

export const buildUserLog = (
  users: Pick<GraphUser, (typeof userProps)[number]>[],
  log: ComponentLog,
) => {
  const { email, oid } = log;

  const user = users.find(
    ({ id, mail, otherMails }) =>
      id === oid ||
      (email &&
        (email.toLowerCase() === mail?.toLowerCase() ||
          otherMails.map((otherMail) => otherMail.toLowerCase()).includes(email.toLowerCase()))),
  );
  if (user) {
    return [{ ...log, oid: user.id }];
  }
  return [];
};

export const replaceKeysWithColumnNames = (
  objects: Record<string, string | boolean | number | object | undefined>[],
  columns: Record<string, string>,
) =>
  objects.map((obj) => {
    const newObj = {} as Record<string, string | boolean | number | object | undefined>;
    for (const key of Object.keys(columns)) {
      newObj[columns[key]] = obj[key];
    }
    return newObj;
  });

export const getSettledResult = (result: PromiseSettledResult<ComponentLog[]>) =>
  result.status === "fulfilled" ? result.value : [];
