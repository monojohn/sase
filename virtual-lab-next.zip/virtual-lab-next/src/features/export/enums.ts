export enum VlComponent {
  File = "File",
  Planner = "Planner",
  Sofa = "Sofa",
  ML = "Azure Machine Learning workspace",
  ProjectLogs = "Project logs",
  ProjectActions = "Project actions",
}
