import { Context } from "@azure/functions";
import XLSX from "xlsx";
import moment from "moment";
import { IFileInfo } from "@pnp/sp/files";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { chunkArray } from "../../utils/chunkArray";
import { getEmailOfUser } from "../../utils/helpers";
import { Project } from "../../services/dbConnector/models/project";
import GraphService from "../../services/graphService/graphService";
import { VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../../utils/config";
import { institutionsToCountryMap } from "../../services/graphService/constants";
import SlackService from "../../services/slackService";
import SpFolderService from "../../services/sharepointService/spFolderService";
import { Institution } from "../../services/graphService/types";
import { ComponentLog } from "./types";
import {
  filterByLastMonth,
  getBusinessAreaSplit,
  getFilesLogs,
  getPlannerLogs,
  getProjectLogs,
  getSofaLogs,
  getWorkspaceLogs,
  readExcelFile,
  replaceKeysWithColumnNames,
} from "./helpers";

type UserLog = {
  oid: string;
  institution: string;
  businessArea: string;
  division: string;
  section: string;
  countryCode: string;
  email: string;
  component: string;
  timestamp: string;
};

const columnNames = {
  oid: "User id",
  institution: "Institution acronym",
  businessArea: "Business area",
  division: "Division",
  section: "Section",
  countryCode: "Country Code",
  email: "Email",
  component: "VL component",
  timestamp: "Access timestamp",
};

const folderName = "User logs";
const fileNamePrefix = "User_logs_";
const fileNameSuffix = ".xlsx";

const getAllProjectLogs = async (ctx: Context, project: Project) => {
  const [files, planner, sofa, workspace] = await Promise.all([
    getFilesLogs(ctx, project),
    getPlannerLogs(ctx, project),
    getSofaLogs(ctx, project),
    getWorkspaceLogs(ctx, project),
  ]);
  return filterByLastMonth([...files, ...planner, ...sofa, ...workspace.logs].flat(1));
};

export const exportUserLogs = async (ctx: Context) => {
  const projects = await ProjectModel.find().lean();
  const errors: string[] = [];
  const allProjectLogs: ComponentLog[] = [];

  // get all project logs
  const projectChunks = chunkArray(projects);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const logs = await getAllProjectLogs(ctx, project);
        allProjectLogs.push(...logs);
      }),
    );
    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(
          `Error for project ${chunk[ind].name}: ${(promiseResult.reason as Error).toString()}`,
        );
      }
    }
  }
  // get project logs and actions
  const projectLogs = await getProjectLogs();
  allProjectLogs.push(...projectLogs);

  // get user details
  const [ecbUsers, guestUsers] = await Promise.all([
    GraphService.getGroupUsers(ctx, VL_MEMBERS_GROUP_ID, [
      "id",
      "mail",
      "otherMails",
      "userType",
      "identities",
      "department",
    ]),
    GraphService.getGroupUsers(ctx, VL_GUESTS_GROUP_ID, [
      "id",
      "mail",
      "otherMails",
      "userType",
      "identities",
      "department",
    ]),
  ]);
  const allUsers = [...ecbUsers, ...guestUsers];

  // map user details to logs
  const sortedLogs = [...allProjectLogs].sort((a, b) =>
    moment.utc(a.timestamp).diff(moment.utc(b.timestamp)),
  );
  const logs = sortedLogs.reduce((acc, log) => {
    const { oid, email } = log;

    const user = allUsers.find(
      ({ id, mail, otherMails }) =>
        id === oid ||
        (email &&
          (email.toLowerCase() === mail?.toLowerCase() ||
            otherMails.map((otherMail) => otherMail.toLowerCase()).includes(email.toLowerCase()))),
    );
    if (!user) {
      // technical users can do actions too in ML workspace, these should be ignored
      return acc;
    }
    const userEmail = getEmailOfUser(user);
    const emailSuffix = (userEmail?.split("@")[1] ?? "").toLowerCase() as Institution;
    const institutionInfo = institutionsToCountryMap[emailSuffix];
    if (!institutionInfo) {
      errors.push(`Institution does not exist for ${emailSuffix}`);
    }
    let businessArea = "";
    let division = "";
    let section = "";
    if (user.userType === "Member") {
      const split = getBusinessAreaSplit(user.department);
      businessArea = split.businessArea;
      division = split.division ?? "";
      section = split.section ?? "";
    }

    acc.push({
      oid: user.id,
      institution: institutionInfo?.institutionAcronym ?? "",
      businessArea,
      division,
      section,
      countryCode: institutionInfo?.countryCode ?? "",
      email: userEmail,
      component: log.component,
      timestamp: moment(log.timestamp).format("YYYY-MM-DD HH:mm:ss.SSS"),
    });
    return acc;
  }, [] as UserLog[]);

  // create worksheet
  const workSheet = XLSX.utils.json_to_sheet(replaceKeysWithColumnNames(logs, columnNames));

  // create workbook
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, workSheet, "User Logs");

  await SpFolderService.uploadFile(
    ctx,
    workbook,
    folderName,
    `${fileNamePrefix}${moment.utc().subtract(1, "month").format("YYYY-MM")}${fileNameSuffix}`,
  );

  // if it's beginning of new quarter, build quarterly file
  const lastMonth = moment.utc().subtract(1, "month");
  const quarterEndMonhts = [2, 5, 8, 11];

  if (quarterEndMonhts.includes(lastMonth.month())) {
    const quarter = quarterEndMonhts.indexOf(lastMonth.month()) + 1;
    ctx.log(`Build log file for Q${quarter}`);

    // define months in last quarter
    const months = [
      lastMonth.clone().subtract(2, "month").format("YYYY-MM"),
      lastMonth.clone().subtract(1, "month").format("YYYY-MM"),
      lastMonth.clone().format("YYYY-MM"),
    ];

    // get user log files
    const userLogsFiles = await SpFolderService.getFiles(ctx, folderName);
    const lastQuarterFiles = months.reduce((acc, month) => {
      const fileName = `${fileNamePrefix}${month}${fileNameSuffix}`;
      const file = userLogsFiles.find(({ Name }) => Name === fileName);
      if (file) {
        acc.push(file);
      }
      return acc;
    }, [] as IFileInfo[]);
    if (lastQuarterFiles.length < 3) {
      errors.push(
        `Could not find all files for Q${quarter}. Found only ${lastQuarterFiles.length}`,
      );
    }
    const fileBuffers = await Promise.all(
      lastQuarterFiles.map(async (file) =>
        SpFolderService.downloadFile(ctx, file.ServerRelativeUrl),
      ),
    );
    const allData = fileBuffers.map((fileBuffer) => readExcelFile(fileBuffer));
    const combinedData = allData.reduce(
      (acc, data, index) => (index === 0 ? acc.concat(data) : acc.concat(data.slice(1))), // keep header just from first file
      [] as (string | number | boolean | null)[][],
    );

    const quarterSheet = XLSX.utils.aoa_to_sheet(combinedData);
    const quarterWorkbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(quarterWorkbook, quarterSheet, "User Logs");

    await SpFolderService.uploadFile(
      ctx,
      quarterWorkbook,
      folderName,
      `${fileNamePrefix}${lastMonth.clone().year()}_Q${quarter}${fileNameSuffix}`,
    );
  }

  if (errors.length) {
    const message = new Error(`Errors during cron-logs: ${[...new Set(errors)].join("\n")}`);
    await SlackService.logWarning(ctx, message);
  }
};
