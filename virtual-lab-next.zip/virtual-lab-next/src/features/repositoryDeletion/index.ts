import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import RepositoryService from "../../services/repositoryService/repositoryService";
import GraphService from "../../services/graphService/graphService";

export const deleteRepository = async (ctx: Context, project: Project) => {
  const { _id, name } = project;
  ctx.log(`Mark repository group of ${name} for deletion`);
  await RepositoryService.markRepositoryGroupForDeletion(ctx, name);

  // remove user access
  const [projectOwnersEmails, projectMembersEmails] = await Promise.all([
    GraphService.getGroupOwnersEmails(ctx, project.name),
    GraphService.getGroupMembersEmails(ctx, project.name),
  ]);

  // in cases where users have both guest and normal account in the project, they have the same email and we shouldn't remove them twice
  const emails = [...new Set([...projectOwnersEmails, ...projectMembersEmails])];

  await Promise.all(emails.map((email) => RepositoryService.removeUser(ctx, project.name, email)));

  ctx.log("Updating DB");
  await ProjectModel.updateOne({ _id }, { $set: { repositoryUrl: null } });
};
