import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import GraphService from "../../services/graphService/graphService";
import RepositoryService from "../../services/repositoryService/repositoryService";

export const createSofaRepository = async (ctx: Context, project: Project) => {
  const { _id, name, description } = project;

  ctx.log("Creating repository group for:", name);

  const [repositoryGroupUrl, projectOwnersEmails, projectMembersEmails] = await Promise.all([
    RepositoryService.createRepositoryGroup(ctx, name, description),
    GraphService.getGroupOwnersEmails(ctx, name),
    GraphService.getGroupMembersEmails(ctx, name),
  ]);

  await ProjectModel.updateOne({ _id }, { $set: { repositoryUrl: repositoryGroupUrl } });

  await Promise.all([
    ...[...new Set(projectOwnersEmails)].map((email) =>
      RepositoryService.addUser(ctx, name, email, true),
    ),
    ...[
      ...new Set(projectMembersEmails.filter((email) => !projectOwnersEmails.includes(email))),
    ].map((email) => RepositoryService.addUser(ctx, name, email, false)),
  ]);

  return repositoryGroupUrl;
};
