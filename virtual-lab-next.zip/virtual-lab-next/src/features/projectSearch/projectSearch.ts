import { Context } from "@azure/functions";
import { FilterQuery } from "mongoose";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { ProjectStatus } from "../../services/dbConnector/enums";
import { buildQuery, getNonAdminFilter, getSearchTerm } from "./helpers";
import { Permissions, ProjectSearchProps } from "./types";
import { ProjectFilter } from "./enums";
import FavoriteProjectModel from "../../services/dbConnector/models/favoriteProjectModel";
import OwnershipInviteModel from "../../services/dbConnector/models/ownershipInviteModel";
import GraphService from "../../services/graphService/graphService";

/**
 * Gets all projects the user can see
 */
// prettier-ignore
export const searchProjects = async (
  ctx: Context,
  oid: string,
  permissions: Permissions,
  search: ProjectSearchProps,
) => {
  const {
    searchTerm,
    filters = {},
    filterType
  } = search;
  ctx.log(`Getting project list`, search);

  const queryFilter: FilterQuery<Project> = {};
  queryFilter.$and = queryFilter.$and ?? [];

  if (!permissions.isAdmin) {
    queryFilter.$and = [{ $or: getNonAdminFilter(oid, permissions.isUserNonEscb) }];
  }

  if (searchTerm) {
    queryFilter.$and.push(getSearchTerm(searchTerm));
  }

  queryFilter.$and.push({
    status: {$in: [ProjectStatus.Active, ProjectStatus.AwaitingApproval, ProjectStatus.BeingCreated, ProjectStatus.BeingDeleted]}
  })

  const filterPairs = Object.entries(filters);
  ctx.log({ filterPairs });

  if (filterPairs.length > 0) {
    queryFilter.$and.push(
      filterPairs.reduce(
        (acc, [key, val]) => {
          acc.$and.push({ [key]: val as unknown });
          return acc;
        },
        { $and: [] as Record<string, unknown>[] },
      ),
    );
  }

    if(filterType === ProjectFilter.membership) {
    queryFilter.$and.push({members: oid})
  } else if(filterType === ProjectFilter.ownership) {
    queryFilter.$and.push({owners: oid})
  } else if(filterType === ProjectFilter.myProjects) {
    queryFilter.$and.push({ $or: [{ owners: oid }, { members: oid }] })
  } else if(filterType === ProjectFilter.favorites) {
    const userFavorites = await FavoriteProjectModel.find({oid})
    queryFilter.$and.push({_id: {$in: userFavorites.map(({pid}) => pid)}})
  } else if(filterType === ProjectFilter.invitations) {
    const invitations = await OwnershipInviteModel.find({invitee: oid})
    queryFilter.$and.push({_id: {$in: invitations.map(({pid}) => pid)}})
  }

  const query = await buildQuery(ctx, queryFilter, search);

  const [projects, count] = await Promise.all([query, ProjectModel.find(queryFilter).countDocuments()]);

  const ownersEmails = await Promise.allSettled(projects.map(project => GraphService.getGroupOwnersEmails(ctx, project.name)));

  return {
    data: projects.map((project, index) => ({...project, ownersEmails: ownersEmails[index].status === "fulfilled" ? ownersEmails[index].value : []})),
    total: count,
  };
};
