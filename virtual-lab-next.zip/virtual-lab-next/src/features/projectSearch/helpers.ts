import { FilterQuery } from "mongoose";
import escapeRegex from "escape-string-regexp";
import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { ProjectSearchProps } from "./types";

export const getNonAdminFilter = (oid: string, isUserNonEscb: boolean) => {
  // admins can see everything, extra filters are applied to all other users
  const orFilters: FilterQuery<Project>[] = [{ members: oid }, { owners: oid }];

  if (!isUserNonEscb) {
    // non-escb users can't see Public nor Protected projects
    orFilters.push({ accessibilityLevel: "Public" }, { accessibilityLevel: "Protected" });
  }
  return orFilters;
};

export const getSearchTerm = (searchTerm: string) => {
  const allTerms = searchTerm.split(/\s+/);

  const andConditons = allTerms.map((term) => {
    const escapedTerm = new RegExp(`.*${escapeRegex(term)}.*`, "i");
    return {
      $or: [{ name: escapedTerm }, { tags: escapedTerm }, { description: escapedTerm }],
    };
  });
  return { $and: andConditons };
};

export const buildQuery = async (
  ctx: Context,
  queryFilter: FilterQuery<Project>,
  search: ProjectSearchProps,
) => {
  const query = ProjectModel.find(queryFilter, undefined, { collation: { locale: "en" } });
  const { sortOrder, sortProp, limit, skip, select } = search;

  if (select) {
    void query.select(select);
  }

  if (sortOrder && sortProp) {
    ctx.log("sorting projects by", { sortProp, sortOrder });
    void query.sort({ [sortProp]: sortOrder === "asc" ? 1 : -1 });
  }

  if (limit) {
    ctx.log("Adding limit", { limit });
    void query.limit(limit);
  }

  if (skip) {
    ctx.log("Adding skip", { skip });
    void query.skip(skip);
  }

  ctx.log({
    queryPipeline: JSON.stringify(queryFilter, null, 2),
    limit,
    skip,
    sortOrder,
    sortProp,
  });

  void query.lean();
  return query;
};
