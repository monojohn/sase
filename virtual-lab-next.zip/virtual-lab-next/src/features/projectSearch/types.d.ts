import { UserPermissions } from "../../../@types/types";
import { Project } from "../../services/dbConnector/models/project";
import { ProjectFilter } from "./enums";

export type SortOrder = "asc" | "desc";

export type ProjectSearchProps = {
  skip?: number;
  limit?: number;
  searchTerm?: string;
  sortProp?: keyof Project;
  sortOrder?: SortOrder;
  filters?: Partial<Project>;
  select?: (keyof Project)[];
  filterType?: ProjectFilter;
};

export type Permissions = Pick<UserPermissions, "isAdmin" | "isUserNonEscb">;
