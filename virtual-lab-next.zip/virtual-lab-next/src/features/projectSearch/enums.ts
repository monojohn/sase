export enum ProjectFilter {
  ownership = "Ownership",
  membership = "Membership",
  myProjects = "MyProjects",
  favorites = "Favorites",
  invitations = "Invitations",
  all = "All",
}
