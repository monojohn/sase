import { jest } from "@jest/globals";
import NotificationService from "./notificationService";

const { TEST_EMAIL: email = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Notification Entitlements NotificationService", () => {
  it("notifyNewUsersOfMissingCondition works", async () => {
    await NotificationService.notifyNewUsersOfMissingCondition(ctx, email, "name");
  });

  it("notifyRemovedUsersOfMissingCondition works", async () => {
    await NotificationService.notifyRemovedUsersOfMissingCondition(ctx, email, "name");
  });

  it("notifyOwners works", async () => {
    await NotificationService.notifyOwners(
      ctx,
      {
        upns: ["upn"],
        projectName: "test",
        missingRolesAndEntitlements: { test: [] },
        owners: [],
      },
      [email],
    );
  });
});
