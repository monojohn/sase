export enum EmailType {
  NEW_USERS = "NEW_USERS",
  USERS_REMOVED = "USERS_REMOVED",
}
