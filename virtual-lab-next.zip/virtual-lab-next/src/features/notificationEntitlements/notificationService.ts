import { Context } from "@azure/functions";
import { Project, RolesAndEntitlements } from "../../services/dbConnector/models/project";
import EmailService from "../../services/emailService/emailService";
import { MissingEntAndRoles } from "../../services/igamService/types";
import { UI_DOMAIN } from "../../utils/config";
import { getEmailOfUser, getRolesAndEntitlementsNames } from "../../utils/helpers";
import { GraphUser } from "../../services/graphService/types";
import { Analysis } from "../../services/projectService/types";
import { EmailType } from "./enums";
import SlackService from "../../services/slackService";

type Props = {
  email: string;
  projectName: string;
  rolesAndEntitlements: RolesAndEntitlements[];
};

const NotificationService = {
  async notifyUsers(
    ctx: Context,
    users: Pick<
      GraphUser,
      "userPrincipalName" | "userType" | "id" | "mail" | "otherMails" | "identities"
    >[],
    analysis: Analysis,
    type: EmailType,
    project: Project,
  ) {
    const results = await Promise.allSettled(
      users.map((user) => {
        const upn = user.userPrincipalName;
        const email = getEmailOfUser(user);
        const missingRolesAndEntitlements = analysis.missingRolesAndEntitlements[upn] ?? [];
        const missingCondition =
          user.userType === "Member"
            ? analysis.missingConditions.Member.length > 0
            : analysis.missingConditions.Guest.length > 0;

        if (!email) {
          const error = `User ${user.id} has no email configured`;
          ctx.log(error);
          return Promise.reject(new Error(error));
        }

        // don't notify users with all permissions
        if (missingRolesAndEntitlements.length === 0 && !missingCondition) {
          const error = `User ${user.id} has no missing roles / entitlements`;
          ctx.log(error);

          return Promise.reject(new Error(error));
        }

        if (type === EmailType.NEW_USERS) {
          if (missingRolesAndEntitlements.length) {
            return NotificationService.notifyNewUsersOfMissingRoles(ctx, {
              email,
              rolesAndEntitlements: missingRolesAndEntitlements,
              projectName: project.name,
            });
          }
          return NotificationService.notifyNewUsersOfMissingCondition(ctx, email, project.name);
        }

        if (missingRolesAndEntitlements.length) {
          return NotificationService.notifyRemovedUsersOfMissingRoles(ctx, {
            email,
            rolesAndEntitlements: missingRolesAndEntitlements,
            projectName: project.name,
          });
        }

        return NotificationService.notifyRemovedUsersOfMissingCondition(ctx, email, project.name);
      }),
    );

    const errors: Error[] = [];

    // check for errors
    for (let index = 0; index < results.length; index++) {
      const result = results[index];
      if (result.status === "rejected") {
        errors.push(result.reason as Error);
      }
    }

    if (errors.length > 0) {
      const error = [`Errors detected`, ...errors].join("\n");
      ctx.log(error);
      await SlackService.logWarning(ctx, new Error(error));
    }

    // NOTE: check for error in notifications
    ctx.log(errors);
  },

  notifyNewUsersOfMissingRoles(ctx: Context, data: Props) {
    const { email, projectName, rolesAndEntitlements } = data;

    const subject = "[Action required] Please request roles/entitlements";
    const preHeadline = `A user tried to add you to the`;
    const postHeadline = [
      `Project on the Virtual Lab. However, you could not be added, because the following entitlements/roles are added to the project, which you do not have:`,
      '<ul style="text-align: left;">',
      ...getRolesAndEntitlementsNames(rolesAndEntitlements).map((roles) => `<li>${roles}</li>`),
      "</ul>",
      "Required actions:",
      '<ul style="text-align: left;">',
      "<li>Request these roles / entitlements via IGAM / IAM</li>",
      `<li><a style="color: #00858c;" href="${UI_DOMAIN}/projects">Request access to ${projectName} again</a></li>`,
      `<li>If the project is private (no longer visible in the project list) or has no project owner, please reach out to virtuallab@ecb.europa.eu</li>`,
    ].join("");

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: email,
      subject,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  notifyNewUsersOfMissingCondition(ctx: Context, email: string, projectName: string) {
    const subject = `[Action required] A user tried to add you to ${projectName}`;
    const preHeadline = `A user tried to add you to the`;
    const postHeadline =
      "Project on the Virtual Lab. However, you could not be added because you are missing roles and entitlements. Please get in contact with the project owner.";

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: email,
      subject,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  notifyRemovedUsersOfMissingRoles(ctx: Context, data: Props) {
    const { email, projectName, rolesAndEntitlements } = data;

    const subject = "[Action required] Please request roles/entitlements";
    const preHeadline = `You have been removed from the`;
    const postHeadline = [
      `Project on the Virtual Lab because you are missing the following entitlements/roles:`,
      '<ul style="text-align: left;">',
      ...getRolesAndEntitlementsNames(rolesAndEntitlements).map((roles) => `<li>${roles}</li>`),
      "</ul>",
      "Required actions:",
      '<ul style="text-align: left;">',
      "<li>Request these roles / entitlements via IGAM / IAM</li>",
      `<li><a style="color: #00858c;" href="${UI_DOMAIN}/projects">Request access to ${projectName} again</a></li>`,
      `<li>If the project is private (no longer visible in the project list) or has no project owner, please reach out to virtuallab@ecb.europa.eu</li>`,
      "</ul>",
    ].join("");

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: email,
      subject,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  notifyRemovedUsersOfMissingCondition(ctx: Context, email: string, projectName: string) {
    const subject = `[Notification] You have been removed from ${projectName}`;
    const preHeadline = `You have been removed from the`;
    const postHeadline =
      "Project on the Virtual Lab because you are missing roles and entitlements. Please get in contact with the project owner for further details. In case you believe it is an error, you can also reach out to the Virtual Lab support team.";
    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: email,
      subject,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },

  notifyOwners(ctx: Context, data: MissingEntAndRoles, owners: string[]) {
    const { projectName, missingRolesAndEntitlements, upns } = data;

    const subject = "[Action required] Users have missing entitlements/roles";
    const preHeadline = `Users from the`;
    const postHeadline = [
      `project are missing the following entitlements/roles:`,
      '<ul style="text-align: left;">',
      ...upns.map(
        (upn) => `<li>${upn}</li>
      <ul>
      ${
        missingRolesAndEntitlements[upn]
          ? getRolesAndEntitlementsNames(missingRolesAndEntitlements[upn])
              .map((roles) => `<li>${roles}</li>`)
              .join("\n")
          : ""
      }
      </ul>
      `,
      ),
      "</ul>",
      "Required actions:",
      '<ul style="text-align: left;">',
      '<li>Request these entitlements/roles via <a style="color: #00858c;" href="https://igam-services.ecb01.ecb.de/identity/faces/home">IGAM</a> or IAM</li>',
      `<li>Ask users to <a style="color: #00858c;" href="${UI_DOMAIN}/projects">request access to ${projectName} again</a></li>`,
      "</ul>",
    ].join("");

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: owners,
      subject,
      templateData: {
        projectName,
        preHeadline,
        postHeadline,
        senderName: ``,
        message: ``,
      },
    });
  },
};

export default NotificationService;
