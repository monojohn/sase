export type CleanupType = keyof Pick<
  Project,
  "foundProjectInactive" | "foundWorkspaceInactive" | "foundWithoutOwners" | "foundWithoutUsers"
>;
