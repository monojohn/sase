import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { getTeamGroupName, wait, withRetry } from "../../utils/helpers";
import { CleanupType } from "./types";
import { chunkArray } from "../../utils/chunkArray";
import EntitlementsService from "../../services/igamService/entitlementsService";
import GraphService from "../../services/graphService/graphService";
import IgamRequestModel from "../../services/dbConnector/models/igamRequestModel";
import { ProjectStatus, RequestStatus, RequestType } from "../../services/dbConnector/enums";
import SlackService from "../../services/slackService";
import { GraphUser } from "../../services/graphService/types";

/**
 * Helper function to build the message to be logged to slack
 * @param project Project for which to build the message
 * @param timesFound How many times it was retrieved so far
 * @returns
 */
export const buildMessage = (project: Project, timesFound: number, maxRetrievals: number) => {
  let message = `${project.name} found ${timesFound} time${timesFound > 1 ? "s" : ""}`;
  if (project.hasException) {
    message += " - has exception";
  } else if (timesFound > maxRetrievals) {
    message += " - to be deleted";
  }
  return message;
};

/**
 * Helper function to reset count for previously marked projects in case the projects are not retrieved anymore
 * @param projectsToBeMarked Projects to be marked this time
 * @param property For which category was this project found before
 */
export const cleanupPreviouslyMarkedProjects = async (
  ctx: Context,
  projectsToBeMarked: Project[],
  property: CleanupType,
) => {
  const findQuery: Record<string, Record<string, number>> = {};
  findQuery[property] = { $gt: 0 };
  // get projects that were marked before
  const projectsMarkedPreviously = await ProjectModel.find(findQuery);

  const setQuery: Record<string, number> = {};
  setQuery[property] = 0;

  await Promise.all(
    projectsMarkedPreviously.map(async (project) => {
      // if a project was retrieved before, but not now, reset count to 0
      if (!projectsToBeMarked.map(({ _id }) => _id.toString()).includes(project._id.toString())) {
        await withRetry(
          async () => {
            await wait(2);
            await ProjectModel.updateOne({ _id: project._id }, { $set: setQuery });
          },
          ctx,
          10,
        );
      }
    }),
  );
};

const projectOrgOwnersCheck = async (ctx: Context, project: Project) => {
  const { name } = project;
  ctx.log(`Checking project ${name}`);
  const [entitlements, projectOrgIsVlOrg] = await Promise.all([
    EntitlementsService.get(ctx, getTeamGroupName(name)),
    EntitlementsService.isProjectOrgVlOrg(ctx, project.ownersGroupName),
  ]);
  const projectEntitlement =
    entitlements.find(({ displayName }) => displayName.includes(name)) ?? entitlements[0];
  const projectOrg = projectEntitlement.owner;
  if (projectOrgIsVlOrg) {
    ctx.log(
      `Project ${name}'s org is VL or VL team (has only guest users or has VL team members), skipping`,
    );
    return { pass: true };
  }
  // get ECB owner's departments (orgs)
  const ecbOwners = await GraphService.getGroupMemberUsers(ctx, project.ownersGroupId, [
    "department",
    "displayName",
    "id",
    "userType",
  ]);
  const ecbOwnersOrgs = await Promise.all(
    ecbOwners.map(async (owner) => GraphService.getUserDepartment(ctx, owner)),
  );

  if (ecbOwnersOrgs.includes(projectOrg)) {
    ctx.log(`Project ${name} has at least one owner from the project org ${projectOrg}`);
    return { pass: true };
  }

  const ecbMembers = await GraphService.getGroupMemberUsers(ctx, project.membersGroupId, [
    "displayName",
    "department",
  ]);

  ctx.log(
    `Project ${name} is missing owners from the project org ${projectOrg}. Owner's orgs are ${ecbOwnersOrgs.join(", ")}`,
  );
  return { pass: false, projectOrg, ecbOwners, ecbMembers };
};

export const getProjectsWihoutOrgOwners = async (ctx: Context) => {
  const [projects, openRequests] = await Promise.all([
    ProjectModel.find({
      // get projects with owners or members. if it's empty it's picked up by another cron job
      $and: [
        { status: ProjectStatus.Active },
        { $or: [{ owners: { $not: { $size: 0 } } }, { members: { $not: { $size: 0 } } }] },
      ],
    }),
    IgamRequestModel.find({
      // get pending requests to update org
      requestType: { $in: [RequestType.UPDATE_ORG, RequestType.ADD_OWNER_WITH_ORG_UPDATE] },
      requestStatus: { $in: [RequestStatus.PENDING, RequestStatus.AWAITING_APPROVAL] },
    }),
  ]);
  const pidsOfOpenRequests = new Set(openRequests.map(({ pid }) => pid));
  // filter out projects with pending IGAM request to update org
  const projectsToCheck = projects.filter(({ _id }) => !pidsOfOpenRequests.has(_id));

  const projectChunks = chunkArray(projectsToCheck);
  const errors: string[] = [];
  const projectsToNotify: {
    project: Project;
    projectOrg: string;
    ecbOwners: Pick<GraphUser, "department" | "displayName">[];
    ecbMembers: Pick<GraphUser, "department" | "displayName">[];
  }[] = [];

  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const { pass, projectOrg, ecbOwners, ecbMembers } = await projectOrgOwnersCheck(
          ctx,
          project,
        );
        if (!pass) {
          if (!projectOrg) {
            errors.push(`Missing org for project ${project.name}`);
            return;
          }
          projectsToNotify.push({ project, projectOrg, ecbOwners, ecbMembers });
        }
      }),
    );
    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(
          `Error for project ${chunk[ind].name}: ${(promiseResult.reason as Error).toString()}`,
        );
      }
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }

  return projectsToNotify;
};
