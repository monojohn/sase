import { Context } from "@azure/functions";
import moment from "moment";
import MetricsService from "../../services/metricsService/metricsService";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import GraphService from "../../services/graphService/graphService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import SlackService from "../../services/slackService";
import { chunkArray } from "../../utils/chunkArray";
import {
  endOfLastMonth,
  fetchCollectionInChunks,
  getTeamGroupName,
  startOfLastMonth,
  wait,
  withRetry,
} from "../../utils/helpers";
import NotificationService from "./notificationService";
import {
  NON_ESCB_GUEST_GROUP,
  VL_GUESTS_GROUP_ID,
  VL_MEMBERS_GROUP_ID,
  VL_ORG,
} from "../../utils/config";
import {
  buildMessage,
  cleanupPreviouslyMarkedProjects,
  getProjectsWihoutOrgOwners,
} from "./helpers";
import OrgService from "../../services/igamService/orgService";
import TeamsService from "../../services/teamService/teamsService";
import { ReportEntry } from "../../services/teamService/types";
import { ProjectStatus } from "../../services/dbConnector/enums";
import UserActionModel from "../../services/dbConnector/models/userActionModel";
import { UserAction } from "../../services/dbConnector/models/userAction";
import ProjectService from "../../services/projectService/projectService";

const maxRetrievals = 2;
const groupIds = [VL_MEMBERS_GROUP_ID, VL_GUESTS_GROUP_ID, NON_ESCB_GUEST_GROUP];

const Cleanup = {
  /**
   * This fn checks that each user only has one of the "sacred" entitlements
   *
   * @param ctx
   * @returns string[] of log messages
   */
  async userEntitlementCheck(ctx: Context) {
    const missingGroups = groupIds.filter((id) => !id);
    ctx.log({ missingGroups });
    if (missingGroups.length > 0) {
      const err = `${missingGroups.length} groups not found`;
      ctx.log(err, { groupIds });
      throw new Error(err);
    }

    const usersPerGroup = await Promise.all(
      groupIds.map((id) => GraphService.getGroupUsers(ctx, id, ["id"])),
    );

    const userMap: Record<string, string[]> = {};
    // for each group
    for (let index = 0; index < usersPerGroup.length; index++) {
      const groupId = groupIds[index];
      // get group users
      const groupUsers = usersPerGroup[index];

      // for all users in a group
      for (let t = 0; t < groupUsers.length; t++) {
        const user = groupUsers[t];

        // if the user is not in the map
        if (!userMap[user.id]) {
          // initialize with an empty array
          userMap[user.id] = [];
        }

        // always add the current group to the array
        userMap[user.id].push(groupId);
      }
    }

    const logs: string[] = ["---User groups check---"];

    // for each user in the map
    const entries = Object.entries(userMap);
    for (let index = 0; index < entries.length; index++) {
      const [userId, groups] = entries[index];

      // if there are more than 1 groups
      if (groups.length > 1) {
        const error = `User "${userId}" is in ${groups.length} groups:\n${groups.join(",\n")}`;
        ctx.log(error);
        logs.push(error);
      }
    }
    return logs;
  },

  async notifyUsersOfInactiveWorkspaces(ctx: Context, inactiveWorkspaces: Project[]) {
    await cleanupPreviouslyMarkedProjects(ctx, inactiveWorkspaces, "foundWorkspaceInactive");

    const logs: string[] = [];
    logs.push("---Inactive workspaces---");
    await Promise.all(
      inactiveWorkspaces.map(async (project) => {
        let foundWorkspaceInactive = project.foundWorkspaceInactive ?? 0;
        foundWorkspaceInactive += 1;
        if (foundWorkspaceInactive <= maxRetrievals && !project.hasException) {
          const bcc = await GraphService.getAllGroupUserEmails(ctx, project.name);
          await NotificationService.sendInactiveWorkspaceEmail(ctx, {
            projectName: project.name,
            timesRemaining: maxRetrievals - foundWorkspaceInactive + 1,
            bcc,
          });
        }
        await withRetry(
          async () => {
            await wait(2);
            await ProjectModel.updateOne(
              { _id: project._id },
              { $set: { foundWorkspaceInactive } },
            );
          },
          ctx,
          10,
        );
        logs.push(buildMessage(project, foundWorkspaceInactive, maxRetrievals));
      }),
    );

    return logs;
  },

  async notifyUsersOfInactiveProjects(ctx: Context, inactiveProjects: Project[]) {
    await cleanupPreviouslyMarkedProjects(ctx, inactiveProjects, "foundProjectInactive");

    const logs: string[] = [];

    logs.push("---Inactive projects---");

    await Promise.all(
      inactiveProjects.map(async (project) => {
        let foundProjectInactive = project.foundProjectInactive ?? 0;
        foundProjectInactive += 1;
        if (foundProjectInactive <= maxRetrievals && !project.hasException) {
          const bcc = await GraphService.getAllGroupUserEmails(ctx, project.name);
          await NotificationService.sendInactiveProjectEmail(ctx, {
            projectName: project.name,
            timesRemaining: maxRetrievals - foundProjectInactive + 1,
            bcc,
            link: ProjectService.getProjectUrl(project),
          });
        }
        await withRetry(
          async () => {
            await wait(2);
            await ProjectModel.updateOne({ _id: project._id }, { $set: { foundProjectInactive } });
          },
          ctx,
          10,
        );
        logs.push(buildMessage(project, foundProjectInactive, maxRetrievals));
      }),
    );
    return logs;
  },

  /**
   * Find inactive projects and inactive workspaces
   * @param ctx
   * @returns string[] of log messages
   */
  async inactiveProjectsAndWorkspacesCheck(ctx: Context) {
    const errors: string[] = [];
    const inactiveProjects: Project[] = [];
    const inactiveWorkspaces: Project[] = [];
    const projects = await ProjectModel.find({ status: ProjectStatus.Active });
    const userActions = await fetchCollectionInChunks(UserActionModel, { oid: { $ne: "system" } });
    const chunks = chunkArray(projects);

    const teamsReport = await TeamsService.getReport(ctx, 90);

    for (let index = 0; index < chunks.length; index++) {
      const chunk = chunks[index];
      const settled = await Promise.allSettled(
        chunk.map(async (project) => {
          const { workspaceActive, projectActive } = await this.isProjectActive(
            ctx,
            project,
            teamsReport,
            userActions.filter(({ pid }) => pid === project._id.toString()),
          );
          if (!workspaceActive) {
            inactiveWorkspaces.push(project);
          }
          if (!projectActive) {
            inactiveProjects.push(project);
          }
        }),
      );

      for (const [ind, promiseResult] of settled.entries()) {
        if (promiseResult.status === "rejected") {
          errors.push(
            `Failed checking project ${chunk[ind].name} for inactivity: ${promiseResult.reason}`,
          );
        }
      }
    }
    const inactiveWorkspacesLogs = await this.notifyUsersOfInactiveWorkspaces(
      ctx,
      inactiveWorkspaces,
    );
    const inactiveProjectsLogs = await this.notifyUsersOfInactiveProjects(ctx, inactiveProjects);

    return { logs: [...inactiveWorkspacesLogs, ...inactiveProjectsLogs], errors };
  },

  /**
   * Check if project is active
   * @param ctx
   * @param project Project to be checked
   * @returns boolean
   */
  async isProjectActive(
    ctx: Context,
    project: Project,
    teamsReport: ReportEntry[],
    projectActions: UserAction[],
  ) {
    let workspaceActive: boolean = true;
    if (project.workspaceUrl?.startsWith("http")) {
      const userMails = await GraphService.getProjectUsersMails(ctx, project.name);
      // checking first if ML workspace is active since it has to be checked for every project
      const mlUsed = await this.isMachineLearningWorkspaceActive(ctx, project, userMails);
      if (mlUsed) {
        return { workspaceActive, projectActive: true };
      }
      workspaceActive = false;
    }

    // has the project been changed in the last 11 months?
    if (
      projectActions.some(
        ({ createdAt }) => moment.utc().diff(moment.utc(createdAt), "months") < 11,
      )
    ) {
      return { workspaceActive, projectActive: true };
    }

    // is teams active?
    const activeTeams = TeamsService.isTeamActive(teamsReport, project.teamGroupId);
    if (activeTeams) {
      return { workspaceActive, projectActive: true };
    }

    // has the project been accessed in the last 120 days?
    const teamGroupName = getTeamGroupName(project.name);
    const teamGroupId = await GraphService.getGroupIdByName(ctx, teamGroupName);
    const siteId = await GraphService.getSiteId(ctx, teamGroupId);
    const views = await GraphService.getPageViews(
      ctx,
      siteId,
      moment.utc().subtract(120, "days").format().slice(0, 10),
      moment.utc().format().slice(0, 10),
    );
    if (views > 0) {
      return { workspaceActive, projectActive: true };
    }

    const elevenMonthsAgo = moment.utc().subtract(11, "months").startOf("month").startOf("day");

    // have the files been changed in the last 11 months?
    const activeFiles = await MetricsService.areFilesActive(
      ctx,
      project,
      elevenMonthsAgo,
      endOfLastMonth(),
    );
    if (activeFiles) {
      return { workspaceActive, projectActive: true };
    }

    // was planner active in the last 11 months?
    await wait(10);
    const activePlanner = await MetricsService.isPlannerActive(
      ctx,
      teamGroupId,
      elevenMonthsAgo,
      endOfLastMonth(),
    );
    return { workspaceActive, projectActive: activePlanner };
  },

  /**
   * Check if ML workspace is active
   * @param ctx
   * @param project Project to be checked
   * @returns boolean
   */
  async isMachineLearningWorkspaceActive(ctx: Context, project: Project, userMails: string[]) {
    const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
    if (!workspace?.id || !workspace?.name) {
      throw new Error(`Project ${project.name} has missing workspace`);
    }

    const mlActive = await MetricsService.isMachineLearningWorkspaceActive(
      ctx,
      workspace,
      userMails,
      startOfLastMonth(),
      endOfLastMonth(),
    );

    return mlActive;
  },

  /**
   * Check if there are projects without users
   * @returns string[] of log messages
   */
  async projectsWithoutUsersCheck(ctx: Context) {
    const logs: string[] = ["---Projects without users---"];
    const projectsWithoutUsers = await ProjectModel.find({
      $and: [{ owners: { $size: 0 } }, { members: { $size: 0 } }],
    });

    await cleanupPreviouslyMarkedProjects(ctx, projectsWithoutUsers, "foundWithoutUsers");

    await Promise.all(
      projectsWithoutUsers.map(async (project) => {
        let foundWithoutUsers = project.foundWithoutUsers ?? 0;
        foundWithoutUsers += 1;

        await withRetry(
          async () => {
            await wait(2);
            await ProjectModel.updateOne({ _id: project._id }, { $set: { foundWithoutUsers } });
          },
          ctx,
          10,
        );
        logs.push(buildMessage(project, foundWithoutUsers, maxRetrievals));
      }),
    );

    return logs;
  },

  /**
   * Check if there are projects without owners
   * @param ctx
   * @returns string[] of log messages
   */
  async projectsWithoutOwnersCheck(ctx: Context) {
    const logs: string[] = ["---Projects without owners---"];

    const projectsWithoutOrgOwners = await getProjectsWihoutOrgOwners(ctx);

    // besides projects with org defined, there are projects where the org is VL. we need to notify members of these projects in case the project is without owner
    const projectsWithoutOwners = await ProjectModel.find({
      owners: { $size: 0 },
      members: { $not: { $size: 0 } },
      org: VL_ORG,
    });
    // filter our the projects which are notified by the other process
    const projectsToNotifyMembers = projectsWithoutOwners.filter(
      ({ _id }) =>
        !projectsWithoutOrgOwners.some(({ project }) => project._id.toString() === _id.toString()),
    );

    await cleanupPreviouslyMarkedProjects(
      ctx,
      [...projectsWithoutOrgOwners.map(({ project }) => project), ...projectsToNotifyMembers],
      "foundWithoutOwners",
    );

    await Promise.all(
      projectsWithoutOrgOwners.map(async ({ project, projectOrg, ecbOwners, ecbMembers }) => {
        let foundWithoutOwners = project.foundWithoutOwners ?? 0;
        foundWithoutOwners += 1;
        if (foundWithoutOwners <= maxRetrievals && !project.hasException) {
          const org = await OrgService.getOrgByName(ctx, projectOrg);
          const emails: string[] = [];
          if (org.manager) {
            emails.push(org.manager.email);
          }
          emails.push(...org.deputies.map(({ email }) => email));
          await NotificationService.sendMissingOrgOwnersEmails(ctx, {
            projectName: project.name,
            timesRemaining: maxRetrievals - foundWithoutOwners + 1,
            bcc: emails,
            orgName: projectOrg,
            ecbOwners,
            ecbMembers,
          });
        }
        await withRetry(
          async () => {
            await wait(2);
            await ProjectModel.updateOne({ _id: project._id }, { $set: { foundWithoutOwners } });
          },
          ctx,
          10,
        );
        logs.push(buildMessage(project, foundWithoutOwners, maxRetrievals));
      }),
    );
    await Promise.all(
      projectsToNotifyMembers.map(async (project) => {
        let foundWithoutOwners = project.foundWithoutOwners ?? 0;
        foundWithoutOwners += 1;
        if (foundWithoutOwners <= maxRetrievals && !project.hasException) {
          const bcc = await GraphService.getGroupMembersEmails(ctx, project.name);
          await NotificationService.sendProjectWithoutOwnersEmail(ctx, {
            projectName: project.name,
            timesRemaining: maxRetrievals - foundWithoutOwners + 1,
            bcc,
          });
        }
        await withRetry(
          async () => {
            await wait(2);
            await ProjectModel.updateOne(
              { _id: project._id },
              { $set: { foundWithoutOwners } },
              { lean: true },
            );
          },
          ctx,
          10,
        );
        logs.push(buildMessage(project, foundWithoutOwners, maxRetrievals));
      }),
    );

    return logs;
  },

  /**
   * Monthly cleanup includes:
   * - checking for inactive workspaces and inactive projects
   * - checking for projects without users
   * - checking for users being part of more than 1 VL group
   * @param ctx
   */
  async monthlyCleanup(ctx: Context) {
    const [{ logs: inactivityLogs, errors }, projectsWithoutUsersLogs, userEntitlementLogs] =
      await Promise.all([
        this.inactiveProjectsAndWorkspacesCheck(ctx),
        this.projectsWithoutUsersCheck(ctx),
        this.userEntitlementCheck(ctx),
      ]);

    const logs = [inactivityLogs, projectsWithoutUsersLogs, userEntitlementLogs, errors];

    await Promise.all(
      logs
        .filter((log) => log.length)
        .map(async (logSet) => {
          await SlackService.logInfo(ctx, { message: logSet.join("\n") });
        }),
    );
  },

  /**
   * Weekly cleanup includes:
   * - checking for projects without owners
   * This is done weekly instead of monthly, like the other cleanups because it is a security concern
   * @param ctx
   */
  async weeklyCleanup(ctx: Context) {
    const projectsWithoutOwnersLogs = await this.projectsWithoutOwnersCheck(ctx);
    const logs = ["---Weekly cleanup---\n", ...projectsWithoutOwnersLogs];
    await SlackService.logInfo(ctx, { message: logs.join("\n") });
  },
};

export default Cleanup;
