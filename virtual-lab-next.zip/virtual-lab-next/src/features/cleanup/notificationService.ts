import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";
import { TEMPLATE_ID } from "../../services/emailService/flowmailer";
import { GraphUser } from "../../services/graphService/types";
import { UI_DOMAIN } from "../../utils/config";

type CleanupProps = {
  projectName: string;
  timesRemaining: number;
  bcc: string[];
  link?: string;
};

type MissingOrgOwnersProps = CleanupProps & {
  orgName: string;
  ecbOwners: Pick<GraphUser, "department" | "displayName">[];
  ecbMembers: Pick<GraphUser, "department" | "displayName">[];
};

const NotificationService = {
  async sendProjectWithoutOwnersEmail(ctx: Context, props: CleanupProps) {
    const { projectName, timesRemaining, bcc } = props;
    const subject = `[Action required] Project ${projectName} without owner`;

    await EmailService.sendEmail(ctx, TEMPLATE_ID.PROJECT_WITHOUT_USERS, {
      subject,
      bcc,
      templateData: {
        projectName,
        periodRemaining: `${timesRemaining} WEEK${timesRemaining > 1 ? "S" : ""}`,
        ctaLabel: "Reply",
        ctaUrl: `mailto:virtuallab@ecb.europa.eu?subject=Re: ${subject}&amp;body=`,
      },
    });
  },

  async sendInactiveWorkspaceEmail(ctx: Context, props: CleanupProps) {
    const { projectName, timesRemaining, bcc } = props;
    const subject = `[Action required] AI | ML workspace for ${projectName} is inactive`;
    const headline = `No activity has been registered in your AI | ML workspace for the Virtual Lab project ${projectName} over the past months.<br><br><b>If the workspace remains inactive, it will be automatically deleted in ${timesRemaining} month${
      timesRemaining > 1 ? "s" : ""
    } to optimize resources centrally. If you no longer need this workspace, no action is required and it will be safely removed. Should you need a workspace within ${projectName} again in the future, you can easily recreate it.</b><br><br>If you still need the current workspace, please navigate to your Virtual Lab project and access the respective AI | ML workspace notebooks to mark it as active and prevent deletion. Please only take this step if the workspace is genuinely needed, as this helps us keep resources available and costs under control.`;

    await EmailService.sendSuccessCtaLeftAlignEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "Access Virtual Lab",
        ctaUrl: UI_DOMAIN,
      },
    });
  },

  async sendInactiveProjectEmail(ctx: Context, props: CleanupProps) {
    const { projectName, timesRemaining, bcc, link } = props;
    const subject = `[Action required] Project ${projectName} is inactive`;
    const headline = `No activity was registered over the past months for your Virtual Lab project ${projectName}. <b><u>If the project remains inactive, it will be automatically deleted in ${timesRemaining} month${
      timesRemaining > 1 ? "s" : ""
    }</u>.</b> To prevent this, access your project via the button below to keep it active. Before the deletion, please ensure to transfer all relevant business documents to their appropriate folders in DARWIN, as the documents will be removed from Virtual Lab.`;

    await EmailService.sendSuccessCtaLeftAlignEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "Access project",
        ctaUrl: link!,
      },
    });
  },

  async sendMissingOrgOwnersEmails(ctx: Context, props: MissingOrgOwnersProps) {
    const { projectName, orgName, timesRemaining, bcc, ecbOwners, ecbMembers } = props;
    const subject = `[Action required] Assign a New Project Owner for ${projectName} project`;

    const headline = [
      `We are writing to inform you that the project ${projectName} currently assigned to your Business Area organization (BA Org), no longer has an active Project Owner from your BA Org ${orgName}. To ensure the continuity and success of your project, we kindly request your prompt attention regarding its ownership.<br><br>`,
      `To keep the project within your BA Org, please provide the name of the new Project Owner. Alternatively, if you wish to transfer the project to a different BA Org, please inform us of the new Project Owner from that organization, and we will make the necessary reassignment. Below you can find a list of members involved in this project, along with their roles and associated BA Orgs. If the project is no longer required, kindly let us know, and we will proceed with its deletion.<br><br>`,
      `${ecbOwners.length ? "ECB Owners:" : ""}<ul style="text-align: left;">`,
      ...ecbOwners.map(({ department, displayName }) => `<li>${displayName}: ${department}</li>`),
      `</ul>`,
      `${ecbMembers.length ? "ECB Members:" : ""}<ul style="text-align: left;">`,
      ...ecbMembers.map(({ department, displayName }) => `<li>${displayName}: ${department}</li>`),
      `</ul>`,
      `Attention: If no project owner is determined within ${timesRemaining} week${timesRemaining > 1 ? "s" : ""}, this project will be deleted automatically. To prevent the deletion of the project, please use the Reply button below to provide us with the name of the Virtual Lab user who will assume the Project Owner role and its associated responsibilities.<br><br>`,
      `Should you have any questions or require further assistance, please do not hesitate to contact us (virtuallab@ecb.europa.eu).`,
    ].join("");

    return EmailService.sendSuccessCtaLeftAlignEmail(ctx, {
      bcc,
      subject,
      templateData: {
        projectName,
        headline,
        ctaLabel: "Reply",
        ctaUrl: `mailto:virtuallab@ecb.europa.eu?subject=Re: ${subject}&amp;body=`,
      },
    });
  },
};
export default NotificationService;
