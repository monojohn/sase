import { jest } from "@jest/globals";
import NotificationService from "./notificationService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("repository deletion NotificationService", () => {
  const props = {
    projectName: "unit test",
    bcc: [userEmail],
    timesRemaining: 1,
    link: "link",
  };
  it("sendInactiveProjectEmail works", async () => {
    await NotificationService.sendInactiveProjectEmail(ctx, props);
  });

  it("sendInactiveWorkspaceEmail works", async () => {
    await NotificationService.sendInactiveWorkspaceEmail(ctx, props);
  });

  it("sendProjectWithoutOwnersEmail works", async () => {
    await NotificationService.sendProjectWithoutOwnersEmail(ctx, props);
  });
});
