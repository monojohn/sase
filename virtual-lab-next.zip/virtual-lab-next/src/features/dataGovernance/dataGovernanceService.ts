import { Context } from "@azure/functions";
import DataGovernanceModel from "../../services/dbConnector/models/dataGovernanceModel";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import GraphService from "../../services/graphService/graphService";
import SlackService from "../../services/slackService";
import { FLOWMAILER_EMAIL_REPLY_TO } from "../../utils/config";
import DataGovernanceNotificationService from "./dataGovernanceNotificationService";

/**
 * Returns the number of days the month has
 *
 * @param date
 * @returns
 */
const getDaysInMonth = (date: Date) => {
  const month = date.getMonth();
  const year = date.getFullYear();
  return new Date(year, month + 1, 0).getDate();
};

const DataGovernanceService = {
  /**
   * Gets projects with data governance requirements
   *
   * @param ctx
   */
  getProjects() {
    return ProjectModel.find({ isNonEscbProject: true });
  },

  /**
   * Gets Data Governance entries for the specific pid
   *
   * @param pid Project ID
   */
  async getLastEntry(pid: string) {
    return DataGovernanceModel.findOne({ pid }).sort({ createdAt: 1 }).lean();
  },

  /**
   * Get projects with data governance requirements which haven't been reviewed by 'currentDate'.
   *
   * @param ctx
   * @param currentDate date to use as limit
   */
  async getProjectsToNotify(ctx: Context, currentDate: Date) {
    const currentMonth = currentDate.getMonth(); // Jan - Dec : 0 - 11
    const currentDayOfMonth = currentDate.getDate(); // 1 - 31
    const currentDayOfWeek = currentDate.getDay(); // Sunday - Saturday : 0 - 6

    ctx.log(`Getting data governance projects`, {
      currentDate,
      currentMonth,
      currentDayOfMonth,
      currentDayOfWeek,
    });

    const projects = await DataGovernanceService.getProjects();
    ctx.log(`Found ${projects.length} projects with data governance requirements`);

    const lastEntries = await Promise.all(
      projects.map(({ _id: pid }) => DataGovernanceService.getLastEntry(pid)),
    );

    const projectsToNotify = projects.filter((project, index) => {
      const { _id, name } = project;
      const dataGovernance = lastEntries[index];

      ctx.log(`Data governance for project #${_id} - ${name}`, dataGovernance);
      if (!dataGovernance) {
        return true;
      }

      const dataGovernanceDate = new Date(dataGovernance.createdAt);
      const dataGovernanceMonth = dataGovernanceDate.getMonth();
      const createdThisMonth = dataGovernanceMonth === currentMonth;

      ctx.log(`Data gov of ${_id}: `, {
        dataGovernanceMonth,
        dataGovernanceDate,
        createdThisMonth,
      });

      return !createdThisMonth;
    });

    ctx.log(
      `Found ${projectsToNotify.length} projects missing data governance reviews:`,
      projectsToNotify.map(({ _id, name }) => `#${_id}: ${name}`),
    );

    return projectsToNotify;
  },

  async notifyProjectsWithMissingDataGov(ctx: Context) {
    const currentDate = new Date();
    const lastDayOfMonth = getDaysInMonth(currentDate);
    const currentDayOfMonth = currentDate.getDate(); // 1 - 31
    const currentDayOfWeek = currentDate.getDay(); // Sunday - Saturday : 0 - 6
    const projectsToNotify = await DataGovernanceService.getProjectsToNotify(ctx, currentDate);
    const messages: string[] = [];

    await Promise.all(
      // eslint-disable-next-line consistent-return
      projectsToNotify.map(async (project) => {
        const { name, _id: pid } = project;

        messages.push(`Data Governance not up to date for project #${pid} - '${name}'`);

        const emails = [
          ...(await GraphService.getGroupUsersEmails(ctx, project.ownersGroupId)),
          FLOWMAILER_EMAIL_REPLY_TO,
        ];

        // if it's the last day of the month
        if (currentDayOfMonth === lastDayOfMonth) {
          // send final warning
          const message = `Sending Final Data Governance warning email to owners of '${name}'`;
          messages.push(message);
          ctx.log(message);
          return DataGovernanceNotificationService.sendFinalWarningEmail(ctx, project, emails);
        }

        // otherwise if it's Monday
        if (currentDayOfWeek === 1) {
          // send email notifications
          const message = `Sending Data Governance warning email to owners of '${name}'`;
          messages.push(message);
          ctx.log(message);
          return DataGovernanceNotificationService.sendWarningEmail(ctx, project, emails);
        }
      }),
    );

    if (messages.length) {
      await SlackService.logInfo(ctx, { message: messages.join("\n") });
    }
  },
};

export default DataGovernanceService;
