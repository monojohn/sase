import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import EmailService from "../../services/emailService/emailService";
import ProjectService from "../../services/projectService/projectService";

const preHeadline = (period: string) =>
  [
    "As project owner you are responsible to review that all data uploaded to the project workspace is public. If you do not react in time, access to the project will be blocked for all project members.",
    `<p>If you do not act <strong>${period}</strong>, all members will be removed from the project</p>`,
  ].join("");

const headline = [
  `<div style="margin-top: 10px; display: block;"><strong>Please take action by logging in to Virtual Lab and reviewing the following:</strong></div>`,
  '<ul style="text-align: left; margin-top: 0">',
  "<li>AI | ML workspace</li>",
  "<li>Git Repo</li>",
  "<li>Files library</li>",
  "<li>MS Teams channel</li>",
  "<li>Planner</li>",
  "</ul>",
  "<p>Make sure that all guidelines and best practices for an exploratory ML workspace are known and followed by all project members and confirm the required fields in the Data Governance pop-up</p>",
].join("");

const DataGovernanceNotificationService = {
  sendMemberRemovalEmail(ctx: Context, project: Pick<Project, "name">, email: string | string[]) {
    const { name } = project;
    const subject = `[Notification] You have been removed from ${name} project in Virtual Lab`;
    const preHeadlineRemoval = `
      You have been removed from ${name}, because the Project Owner has not reviewed the data confidentiality in time.
      Please contact virtuallab@ecb.europa.eu or the project owner for support or next steps
    `;

    return EmailService.sendInfoEmail(ctx, {
      bcc: email,
      subject,
      templateData: { projectName: name, preHeadline: preHeadlineRemoval },
    });
  },

  sendFinalWarningEmail(
    ctx: Context,
    project: Pick<Project, "name" | "_id">,
    email: string | string[],
  ) {
    const { name } = project;
    const subject = `[Final Warning] Review Virtual Lab data confidentiality compliance of ${name}`;

    return EmailService.sendInfoCtaEmail(ctx, {
      bcc: email,
      subject,
      templateData: {
        projectName: name,
        headline,
        ctaLabel: "Access project",
        ctaUrl: ProjectService.getProjectUrl(project),
        preHeadline: preHeadline("within 24h"),
      },
    });
  },

  sendWarningEmail(ctx: Context, project: Pick<Project, "name" | "_id">, email: string | string[]) {
    const { name } = project;
    const subject = `[Action required] Please review Virtual Lab data confidentiality compliance of ${name}`;

    return EmailService.sendInfoCtaEmail(ctx, {
      bcc: email,
      subject,
      templateData: {
        projectName: name,
        headline,
        ctaLabel: "Access project",
        ctaUrl: ProjectService.getProjectUrl(project),
        preHeadline: preHeadline("until the end of the month"),
      },
    });
  },
};

export default DataGovernanceNotificationService;
