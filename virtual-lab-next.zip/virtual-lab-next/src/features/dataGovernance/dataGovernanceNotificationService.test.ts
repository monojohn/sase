import { jest } from "@jest/globals";
import NotificationService from "./dataGovernanceNotificationService";
import { createTestProject } from "../../../jest/helpers";
import { Project } from "../../services/dbConnector/models/project";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("repository deletion NotificationService", () => {
  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject();
  });

  it("sendMemberRemovalEmail works", async () => {
    await NotificationService.sendMemberRemovalEmail(ctx, testProject, userEmail);
  });

  it("sendFinalWarningEmail works", async () => {
    await NotificationService.sendFinalWarningEmail(ctx, testProject, userEmail);
  });

  it("sendWarningEmail works", async () => {
    await NotificationService.sendWarningEmail(ctx, testProject, userEmail);
  });
});
