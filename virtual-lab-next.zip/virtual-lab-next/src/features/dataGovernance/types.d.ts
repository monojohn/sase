import { SpEntry } from "../../services/sharepointService/sharepointService";

export type DataGovernance = SpEntry<{
  pid: number; // project ID
  oid: string; // ID of user who reviewed the data
}>;
