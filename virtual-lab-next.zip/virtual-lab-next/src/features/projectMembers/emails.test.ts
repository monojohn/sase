import { jest } from "@jest/globals";
import NotificationService from "./emails";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("add member email", () => {
  it("sendAddMemberEmail works", async () => {
    await NotificationService.sendAddMemberEmail(ctx, {
      bcc: [userEmail],
      ctaUrl: "url.com",
      projectName: "project name",
    });
  });
});
