import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";

type AddMemberProps = {
  bcc: string[];
  ctaUrl: string;
  projectName: string;
};

const NotificationService = {
  async sendAddMemberEmail(ctx: Context, data: AddMemberProps) {
    const subject = `[Notification] You have been assigned to ${data.projectName}`;
    const headline = `You have been assigned as Member`;

    return EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc: data.bcc,
      templateData: {
        ...data,
        ctaLabel: "View project board",
        headline,
      },
    });
  },
};
export default NotificationService;
