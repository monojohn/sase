import { jest } from "@jest/globals";
import { createTestProject } from "../../../jest/helpers";
import NotificationService from "./notificationService";

const { TEST_EMAIL: email = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Machine learning NotificationService", () => {
  it("sendSuccessEmail works", async () => {
    const testProject = await createTestProject({ workspaceUrl: "https://ml.azure.com/wsid=test" });

    await NotificationService.sendInactiveComputeEmail(ctx, {
      cpu: 1,
      gpu: 2,
      email,
      project: testProject,
      computeInstances: [{ computeName: "test", daysLeft: 1 }],
    });
  });
});
