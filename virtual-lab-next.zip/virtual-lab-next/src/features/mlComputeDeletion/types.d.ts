export type ComputeInfo = { computeName: string; daysLeft: number };

export type ComputeInfoMap = Record<string, ComputeInfo[]>;
