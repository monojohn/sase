import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import EmailService from "../../services/emailService/emailService";
import { ComputeInfo } from "./types";
import { TEMPLATE_ID } from "../../services/emailService/flowmailer";

type EmailProps = {
  cpu: number;
  gpu: number;
  email: string;
  project: Project;
  computeInstances: ComputeInfo[];
};

const getComputeRows = (urlBeggining: string, urlEnd: string, computeInstances: ComputeInfo[]) =>
  computeInstances
    .map(
      (compute) => `
        <tr>
          <td><a href="${urlBeggining}${compute.computeName}/details?wsid=${urlEnd}">${
            compute.computeName
          }</a></td>
          <td>${Math.max(compute.daysLeft, 0)}</td>
        </tr>
        `,
    )
    .join("");

const NotificationService = {
  async sendInactiveComputeEmail(ctx: Context, props: EmailProps) {
    const { cpu, gpu, email, project, computeInstances } = props;

    const count = computeInstances.length;
    const subject = `[Action required] Warning: ${count} compute instances are about to be deleted`;
    const headline = `${count} compute instances are about to be deleted from your Virtual Lab project`;
    const ctaLabel = "View compute instances";

    const computeUrlPrefix = "https://ml.azure.com/compute/";
    const computeUrlSuffix = project.workspaceUrl?.split("wsid=")[1];
    const ctaUrl = `${computeUrlPrefix}list/instances?wsid=${computeUrlSuffix}`;

    return EmailService.sendEmail(ctx, TEMPLATE_ID.ML_COMPUTE_DELETION, {
      bcc: email,
      subject,
      templateData: {
        count,
        cpu,
        gpu,
        ctaUrl,
        ctaLabel,
        headline,
        computeInstances: getComputeRows(computeUrlPrefix, computeUrlSuffix, computeInstances),
      },
    });
  },
};

export default NotificationService;
