import { Context } from "@azure/functions";
import moment from "moment";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import GraphService from "../../services/graphService/graphService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import SlackService from "../../services/slackService";
import { chunkArray } from "../../utils/chunkArray";
import { IS_PROD } from "../../utils/config";
import NotificationService from "./notificationService";
import { ComputeInfoMap } from "./types";
import { Compute } from "../../services/machineLearningService/types";

const times = IS_PROD
  ? {
      cpu: 30,
      gpu: 30,
      email: 7,
    }
  : {
      cpu: 7,
      gpu: 7,
      email: 2,
    };

const deleteComputeInstances = async (ctx: Context, workspaceName: string, toDelete: string[]) => {
  await Promise.all(
    toDelete.map(async (compute) => {
      ctx.log(`Deleting compute ${compute} in workspace ${workspaceName}`);
      await MachineLearningService.deleteCompute(ctx, workspaceName, compute);
    }),
  );
};

const sendEmails = async (ctx: Context, project: Project, toEmail: ComputeInfoMap) => {
  await Promise.all(
    Object.keys(toEmail)
      .filter((userId) => toEmail[userId].some(({ daysLeft }) => daysLeft === times.email))
      .map(async (userId) => {
        // send email only if at least one compute instance will be deleted after the exact number of days days
        const userEmail = await GraphService.getUserEmail(ctx, userId);
        const email = IS_PROD ? userEmail : "virtuallab@ecb.europa.eu";
        ctx.log(
          `Sending email to ${email} regarding ${toEmail[userId]
            .map(({ computeName }) => computeName)
            .join(", ")} in ${project.workspaceUrl}`,
        );
        await NotificationService.sendInactiveComputeEmail(ctx, {
          cpu: times.cpu,
          gpu: times.gpu,
          email,
          project,
          computeInstances: toEmail[userId],
        });
      }),
  );
};

const checkComputes = async (
  ctx: Context,
  project: Project,
  workspaceName: string,
  computes: Compute[],
) => {
  const toDelete: string[] = [];
  const toEmail: ComputeInfoMap = {};
  const errors: string[] = [];
  for (const compute of computes) {
    ctx.log(`Checking compute ${compute.name}`);

    const computeType = MachineLearningService.isComputeInstanceGPU(compute) ? "gpu" : "cpu";
    const { userId } = compute.properties.properties.createdBy;
    const computeName = compute.name;

    const daysSinceLastUpdate = moment
      .utc()
      .diff(moment.utc(compute.properties.modifiedOn), "days");

    // if compute instance has been updated recently, do nothing
    if (daysSinceLastUpdate < times[computeType] - times.email) {
      continue;
    }

    if (!compute.properties.properties.idleTimeBeforeShutdown) {
      errors.push(
        `Workspace ${workspaceName} has compute instance ${computeName} running, but without idle shut down schedule.`,
      );
    }

    // if compute is running, do nothing
    if (compute.properties.properties.state === "Running") {
      continue;
    }

    // delete the compute instance if it has been inactive for at least the defined period
    if (daysSinceLastUpdate >= times[computeType]) {
      toDelete.push(computeName);
    } else {
      // send email
      if (!toEmail[userId]) {
        toEmail[userId] = [];
      }
      toEmail[userId].push({
        computeName,
        daysLeft: times[computeType] - daysSinceLastUpdate,
      });
    }
  }

  await deleteComputeInstances(ctx, workspaceName, toDelete);
  await sendEmails(ctx, project, toEmail);

  return errors;
};

const checkProjectWorkspace = async (ctx: Context, project: Project) => {
  const toLog: string[] = [];
  const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
  if (!workspace?.name) {
    const error = `Workspace not found for ${project.name}`;
    ctx.log(error);
    return;
  }
  const workspaceName = workspace.name;

  const computes = await MachineLearningService.getComputes(ctx, workspaceName);

  const logs = await checkComputes(
    ctx,
    project,
    workspaceName,
    computes.filter(({ properties }) => properties.computeType === "ComputeInstance"),
  );
  toLog.push(...logs);

  if (toLog.length) {
    await SlackService.logWarning(ctx, new Error(toLog.join("\n")));
  }
};

export const deleteInactiveComputes = async (ctx: Context) => {
  const projects = await ProjectModel.find().lean();
  const projectsChunks = chunkArray(
    projects.filter(({ workspaceUrl }) => workspaceUrl?.startsWith("http")),
  );

  const errors: string[] = [];
  for (let index = 0; index < projectsChunks.length; index++) {
    const chunk = projectsChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        await checkProjectWorkspace(ctx, project);
      }),
    );

    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        const errorMessage = `Failed checking inactive computes for project ${chunk[ind].name}`;
        errors.push(errorMessage);
        ctx.log(new Error(errorMessage), promiseResult.reason);
      }
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};
