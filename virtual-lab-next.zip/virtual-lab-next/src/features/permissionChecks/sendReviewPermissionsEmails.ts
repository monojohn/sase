import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import EmailService from "../../services/emailService/emailService";
import { getRolesAndEntitlementsNames } from "../../utils/helpers";
import ProjectService from "../../services/projectService/projectService";

const NotificationService = {
  async sendReviewExistingPermissionsEmail(
    ctx: Context,
    emails: string[],
    project: Pick<Project, "name" | "url" | "rolesAndEntitlements" | "_id">,
  ) {
    const { name, rolesAndEntitlements } = project;
    const subject = "[Action required] Update AI | ML workspace entitlements/roles";
    const headline = [
      `In the AI | ML workspace for the ${name} project it is marked that there is a need for data connectivity and the following entitlements/roles have been added:`,
      '<ul style="text-align: left;">',
      ...getRolesAndEntitlementsNames(rolesAndEntitlements).map((roles) => `<li>${roles}</li>`),
      "</ul>",
      "<p>Please review whether this is still up to date and add entitlements/role when needed.</p>",
    ].join("");

    return EmailService.sendSimpleEmail(ctx, {
      bcc: emails,
      subject,
      templateData: {
        headline,
        ctaLabel: "Review",
        ctaUrl: ProjectService.getProjectUrl(project),
      },
    });
  },

  async sendReviewNoPermissionsEmail(
    ctx: Context,
    emails: string[],
    project: Pick<Project, "name" | "_id">,
  ) {
    const { name } = project;
    const subject = "[Action required] Update AI | ML workspace entitlements/roles";
    const headline = [
      `<p>In the AI | ML workspace for the ${name} project it is marked that there is a need for data connectivity, but no entitlements/roles have been added.</p>`,
      "<br />",
      "<p>Please review whether this is still up to date and add entitlements/role when needed.</p>",
    ].join("");

    return EmailService.sendSimpleEmail(ctx, {
      bcc: emails,
      subject,
      templateData: {
        headline,
        ctaLabel: "Review",
        ctaUrl: ProjectService.getProjectUrl(project),
      },
    });
  },
};

export default NotificationService;
