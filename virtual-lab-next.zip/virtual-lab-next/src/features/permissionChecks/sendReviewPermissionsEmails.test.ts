import { jest } from "@jest/globals";
import NotificationService from "./sendReviewPermissionsEmails";

const { TEST_EMAIL: email = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Review permissions notification service", () => {
  const project = {
    name: "test project",
    url: "url",
    rolesAndEntitlements: [{ entitlements: ["ent"], roles: [], iamRoles: [] }],
    _id: "123",
  };
  it("sendReviewExistingPermissionsEmail works", async () => {
    await NotificationService.sendReviewExistingPermissionsEmail(ctx, [email], project);
  });

  it("sendReviewNoPermissionsEmail works", async () => {
    await NotificationService.sendReviewNoPermissionsEmail(ctx, [email], project);
  });
});
