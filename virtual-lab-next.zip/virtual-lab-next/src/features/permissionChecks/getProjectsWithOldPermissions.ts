import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { chunkArray } from "../../utils/chunkArray";
import { isProjectWorkspaceActive } from "../usage/workspaceUsage";

/**
 * The maximum time permissions (entitlements and roles) can remain unchanged
 *
 * Currently 90 days in ms
 */
const MAX_TIME_UNCHANGED = 90 * 24 * 60 * 60 * 1000;

/**
 * Returns all projects which have an ML Workspace but haven't
 * updated their permissions in over 90 days
 *
 * @param ctx
 */
export const getProjectsWithOldPermissions = async (ctx: Context) => {
  // fetch all projects
  const projects = await ProjectModel.find().lean();
  const filteredProjects: Project[] = [];
  const today = Date.now();

  const potentialProjects = projects.filter((project) => {
    const changeTime = project.permissionsChangedDate?.getTime();
    // if NaN or falsy
    if (!changeTime) {
      return false;
    }

    return (
      // has an ML workspace
      project.workspaceUrl?.startsWith("http") &&
      // requires ECB access
      project.openAiConnection &&
      // and permissions haven't been updated recently
      today - changeTime > MAX_TIME_UNCHANGED
    );
  });

  ctx.log(`Found ${potentialProjects.length} potential projects`);

  // start from most recent as older projects are more likely to be correct
  const chunks = chunkArray([...potentialProjects].reverse(), 10);
  const errors: string[] = [];
  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    const percentage = Math.round(((index + 1) / chunks.length) * 100);
    ctx.log(`At ${index} / ${chunks.length} (~${percentage}%)`);

    await Promise.all(
      chunk.map(async (project) => {
        try {
          if (!(await isProjectWorkspaceActive(ctx, project.name))) {
            // ignore inactive projects
            return;
          }
          filteredProjects.push(project);
        } catch (err) {
          const error = `Failed to handle workspace of project ${project?.name}`;
          ctx.log(error, err);
          errors.push(error);
        }
      }),
    );
  }

  ctx.log(`Found ${potentialProjects.length} projects with old data`);
  return { errors, projects: filteredProjects };
};
