import { Context } from "@azure/functions";
import GraphService from "../../services/graphService/graphService";
import SlackService from "../../services/slackService";
import { getProjectsWithOldPermissions } from "./getProjectsWithOldPermissions";
import NotificationService from "./sendReviewPermissionsEmails";

export const notifyOwnersOfProjectsWithOldPermissions = async (ctx: Context) => {
  const { errors: fetchErrors, projects } = await getProjectsWithOldPermissions(ctx);
  const errors: string[] = [];

  ctx.log(`Found ${projects.length} projects with old permissions`);

  for (let index = 0; index < projects.length; index++) {
    const project = projects[index];

    try {
      // fetch owner emails
      const ownerEmails = await GraphService.getGroupUsersEmails(ctx, project.ownersGroupId);
      const validOwnerEmails = ownerEmails.filter((email) => !email);

      if (validOwnerEmails.length === 0) {
        const warning = `No owner emails found for project ${project.name}`;
        ctx.log(warning);
        errors.push(warning);
      }

      ctx.log(`Sending review permissions email to owners of project ${project.name}`);
      // if it has, and permissions have been added
      if (project.rolesAndEntitlements?.length > 0) {
        // Remind owners to check permissions are up to date
        await NotificationService.sendReviewExistingPermissionsEmail(
          ctx,
          validOwnerEmails,
          project,
        );
      } else {
        // otherwise, remind owners they likely need to add permissions
        await NotificationService.sendReviewNoPermissionsEmail(ctx, validOwnerEmails, project);
      }
    } catch (err) {
      const error = `Failed to process project ${project?.name}`;
      ctx.log(error, err);
      errors.push(error);
    }
  }

  // log activity fetch errors
  ctx.log(`Had ${fetchErrors.length} errors while fetching workspace activity`, fetchErrors);
  if (fetchErrors.length) {
    await SlackService.logWarning(
      ctx,
      new Error(`Failed to process ${fetchErrors.length} projects. ${fetchErrors.join("\n")}`),
    );
  }

  // log processing errors
  ctx.log(`Had ${errors.length} errors while notifying owners`, errors);
  if (errors.length) {
    await SlackService.logWarning(
      ctx,
      new Error(`Failed to process ${errors.length} projects. ${errors.join("\n")}`),
    );
  }
};
