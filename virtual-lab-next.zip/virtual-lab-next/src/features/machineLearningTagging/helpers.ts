import { Workspace } from "@azure/arm-machinelearning";
import { Context } from "@azure/functions";
import ContainerInstanceService, {
  ContainerGroup,
} from "../../services/machineLearningService/containerInstanceService";
import ContainerRegistryService from "../../services/machineLearningService/containerRegistryService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import SlackService from "../../services/slackService";
import { AZURE_CR_RESOURCE_GROUP, AZURE_RESOURCE_GROUP } from "../../utils/config";

export const filterValidWorkspaces = async (ctx: Context, workspaces: Workspace[]) => {
  const validWorkspaces: Workspace[] = [];
  ctx.log("Filtering workspaces");
  const errors: string[] = [];

  // eslint-disable-next-line no-restricted-syntax
  for (const workspace of workspaces) {
    // must have a name
    if (!workspace.name) {
      const errMessage = `Workspace ${workspace.id} is missing the 'name' property`;
      ctx.log(errMessage);
      errors.push(errMessage);
      // must have a project tag
    } else if (workspace.tags?.project) {
      validWorkspaces.push(workspace);
    } else {
      const errMessage = `Workspace ${workspace.name} is missing the 'project' tag`;
      ctx.log(errMessage);
      errors.push(errMessage);
    }
  }

  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }

  ctx.log(`Filtered out ${workspaces.length - validWorkspaces.length} workspaces`);
  return validWorkspaces;
};

export const tagContainerInstances = async (
  ctx: Context,
  workspace: Workspace,
  containerGroups: ContainerGroup[],
) => {
  const workspaceName = workspace.name!;
  const projectName = workspace.tags!.project;
  ctx.log(`Tagging container instances in workspace ${workspaceName} for project ${projectName}`);

  // get container endpoints
  ctx.log(`Getting workspace endpoints`);
  const workspaceEndpoints = await MachineLearningService.getWorkspaceEndpoints(ctx, workspaceName);

  // map names for filtering
  const endpointNames = workspaceEndpoints.map((endpoint) => endpoint.id);
  ctx.log({ [workspaceName]: endpointNames });

  // find matching container groups
  const workspaceContainerGroups = containerGroups.filter((containerGroup) =>
    containerGroup.containers.some(({ name }) => endpointNames.includes(name)),
  );
  ctx.log(`Found ${workspaceContainerGroups.length} container groups`);

  // eslint-disable-next-line no-restricted-syntax -- for each matching container
  for (const containerGroup of workspaceContainerGroups) {
    // tag must match project name
    if (containerGroup.tags?.project !== projectName) {
      // if not present or they don't match, add them in
      ctx.log(`Container ${containerGroup.name} is missing project tag`);
      await ContainerInstanceService.setTags(containerGroup.name, {
        ...containerGroup.tags,
        project: workspaceName,
      });
    }
  }

  ctx.log(`Done with Container instances of workspace ${workspaceName}`);
};

export const tagContainerRegistry = async (ctx: Context, workspace: Workspace) => {
  if (!workspace.containerRegistry) {
    return;
  }

  const workspaceName = workspace.name ?? "";
  const projectName = workspace.tags!.project;
  const split = workspace.containerRegistry.split("/");
  const resourceGroupRawValue =
    split[split.findIndex((el) => el.toLowerCase() === "resourcegroups") + 1];
  const resourceGroup =
    resourceGroupRawValue.toLowerCase() === AZURE_RESOURCE_GROUP.toLowerCase()
      ? AZURE_RESOURCE_GROUP
      : AZURE_CR_RESOURCE_GROUP;
  const registryName = split.at(-1)!;

  // get registry
  ctx.log(`Getting registry ${registryName} of workspace ${workspaceName}`);
  const registry = await ContainerRegistryService.get(resourceGroup, registryName);
  const registryTags = registry.tags ?? {};

  //  if project tag does not match
  if (registryTags.project === projectName) {
    ctx.log(`Registry ${registryName} is up to date`);
  } else {
    const tagsToAdd = { project: projectName };
    ctx.log(`Registry ${registryName} is missing tags`, registry.tags);
    ctx.log(`Adding tags to Registry ${registryName} of ${workspaceName}`, tagsToAdd);
    // add tags
    await ContainerRegistryService.setTags(resourceGroup, registryName, {
      ...registryTags,
      project: projectName,
    });
  }
  ctx.log(`Done with Registry ${registryName} of workspace ${workspaceName}`);
};
