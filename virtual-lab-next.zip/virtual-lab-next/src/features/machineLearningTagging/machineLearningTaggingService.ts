import { Context } from "@azure/functions";
import ContainerInstanceService from "../../services/machineLearningService/containerInstanceService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import SlackService from "../../services/slackService";
import { filterValidWorkspaces, tagContainerInstances, tagContainerRegistry } from "./helpers";

const MachineLearningTaggingService = {
  async tagStrayResources(ctx: Context) {
    // get all workspaces and container groups
    const [workspaces, containerGroups] = await Promise.all([
      MachineLearningService.getAllProjects(),
      ContainerInstanceService.getContainerGroups(),
    ]);

    // filter out bad workspaces
    const validWorkspaces = await filterValidWorkspaces(ctx, workspaces);
    const errors: Error[] = [];
    // for each workspace
    // eslint-disable-next-line no-restricted-syntax
    for (const workspace of validWorkspaces) {
      ctx.log(`Started ${workspace.name} `);
      const projectName = workspace.tags!.project;
      ctx.log(`Tag check for ${workspace.name} of project ${projectName} started`);

      try {
        await tagContainerInstances(ctx, workspace, containerGroups);
        await tagContainerRegistry(ctx, workspace);
      } catch (e) {
        errors.push(e as Error);
      }

      ctx.log(`Finished ${workspace.name}`);
    }
    if (errors.length) {
      await SlackService.logError(ctx, new Error(errors.map(({ message }) => message).join("\n")));
    }
  },
};

export default MachineLearningTaggingService;
