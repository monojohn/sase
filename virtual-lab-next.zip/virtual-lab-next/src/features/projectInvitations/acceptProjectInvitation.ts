import { Context } from "@azure/functions";
import {
  ProjectInvitationStatus as ProjectInviteStatus,
  RequestStatus,
  RequestType,
  UpdateStatus,
} from "../../services/dbConnector/enums";
import { OwnershipInvite } from "../../services/dbConnector/models/ownershipInvite";
import OwnershipInviteModel from "../../services/dbConnector/models/ownershipInviteModel";
import { Project } from "../../services/dbConnector/models/project";
import ProjectService from "../../services/projectService/projectService";
import { activeRequestsExist } from "../../services/igamService/helpers";
import IgamRequestModel from "../../services/dbConnector/models/igamRequestModel";
import { sendAcceptOwnershipNotifications } from "./notificationService";
import GraphService from "../../services/graphService/graphService";
import LlmNotificationService from "../openAIUseCase/notificationService";
import NotificationService from "../../services/projectService/notificationService";
import InvitationsNotificationService from "./emails";

export const acceptProjectInvitation = async (
  ctx: Context,
  invitation: OwnershipInvite,
  project: Project,
  postApproval?: boolean,
) => {
  ctx.log(
    `Setting invitation status from ${invitation.status} to '${ProjectInviteStatus.ACCEPTING}'`,
  );
  if (!postApproval) {
    await OwnershipInviteModel.updateOne(
      { _id: invitation._id },
      { $set: { status: ProjectInviteStatus.ACCEPTING } },
    );
  }

  try {
    ctx.log(`Adding owner to project`);
    await ProjectService.addUser(ctx, project, invitation.invitee, true, postApproval);
  } catch (err) {
    ctx.log(`Reverting invitation status to '${invitation.status}'`);
    await OwnershipInviteModel.updateOne(
      { _id: invitation._id },
      { $set: { status: invitation.status } },
    );

    throw err;
  }

  ctx.log(`Setting invitation status to '${ProjectInviteStatus.ACCEPTED}'`);
  await OwnershipInviteModel.updateOne(
    { _id: invitation._id },
    { $set: { status: ProjectInviteStatus.ACCEPTED } },
  );

  if (postApproval) {
    // notify owner that he has been added
    const userEmail = await GraphService.getUserEmail(ctx, invitation.invitee);
    await InvitationsNotificationService.sendOwnerAddedPostApprovalEmail(ctx, {
      bcc: [userEmail],
      ctaUrl: ProjectService.getProjectUrl(project),
      projectName: project.name,
    });
  } else {
    // notify users
    ctx.log(`Notifying users`);
    await sendAcceptOwnershipNotifications(ctx, invitation.invitee, project);
  }

  // Wait for previous one to finish before sending this
  // Only send if user is not already a member and LLM exists
  if (!project.members.includes(invitation.invitee) && project.aiUsage) {
    const email = await GraphService.getUserEmail(ctx, invitation.invitee);

    void LlmNotificationService.sendLlmAwarenessInfoToUsers(ctx, {
      projectName: project.name,
      projectUrl: ProjectService.getProjectUrl(project),
      confidentialityLevel: project.confidentialityLevel,
      emails: [email],
      created: false,
    });
  }
};

export const acceptProjectInvitationWithApproval = async (
  ctx: Context,
  invitation: OwnershipInvite,
  project: Project,
  oid: string,
) => {
  const [requestExists] = await Promise.all([
    activeRequestsExist(project._id),
    OwnershipInviteModel.updateOne(
      { _id: invitation._id },
      { $set: { status: ProjectInviteStatus.ACCEPTING } },
    ),
  ]);
  if (requestExists) {
    // create pending request
    const [ownersEmails] = await Promise.all([
      GraphService.getGroupUsersEmails(ctx, project.ownersGroupId),
      IgamRequestModel.create({
        requestType: RequestType.ADD_OWNER,
        requestStatus: RequestStatus.PENDING,
        pid: project._id,
        requesterId: oid,
        oid: invitation.invitee,
      }),
    ]);
    await OwnershipInviteModel.updateOne(
      { _id: invitation._id },
      { $set: { status: ProjectInviteStatus.PENDING } },
    );
    await NotificationService.sendPendingRequestEmail(ctx, project.name, ownersEmails);
    return UpdateStatus.PENDING_REQUEST_CREATION;
  }

  const { requestId, requestType, org } = await ProjectService.addOwnerWithApproval(
    ctx,
    project,
    invitation.invitee,
    invitation.inviterName,
  );

  await IgamRequestModel.create({
    requestType,
    requestStatus: RequestStatus.AWAITING_APPROVAL,
    pid: project._id,
    requesterId: oid,
    oid: invitation.invitee,
    requestId,
    org,
  });

  await Promise.all([
    sendAcceptOwnershipNotifications(
      ctx,
      invitation.invitee,
      project,
      UpdateStatus.PENDING_APPROVAL,
      requestId,
      requestType,
    ),

    OwnershipInviteModel.updateOne(
      { _id: invitation._id },
      { $set: { status: ProjectInviteStatus.AWAITING_APPROVAL } },
    ),
  ]);
  return UpdateStatus.PENDING_APPROVAL;
};
