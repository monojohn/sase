import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";

type SendOwnershipAcceptanceEmailProps = {
  bcc: string[];
  ctaUrl: string;
  userName: string;
  projectName: string;
};

type SendOwnershipRejectionEmailProps = {
  bcc: string[];
  userName: string;
  projectName: string;
};

const NotificationService = {
  async sendOwnershipAcceptanceEmail(ctx: Context, data: SendOwnershipAcceptanceEmailProps) {
    const subject = `[Notification] ${data.userName} accepted ownership of ${data.projectName}`;
    const preHeadline = `${data.userName} has accepted ownership of`;
    const headline = `${data.userName} is now an owner of  ${data.projectName}`;

    return EmailService.sendInfoCtaEmail(ctx, {
      subject,
      bcc: data.bcc,
      templateData: {
        ...data,
        ctaLabel: "View project",
        headline,
        preHeadline,
      },
    });
  },
  sendOwnershipRejectionEmail(ctx: Context, props: SendOwnershipRejectionEmailProps) {
    const subject = `[Notification] ${props.userName} rejected ownership of ${props.projectName}`;
    const preHeadline = `${props.userName} has rejected ownership of`;

    return EmailService.sendInfoEmail(ctx, {
      subject,
      bcc: props.bcc,
      templateData: {
        ...props,
        preHeadline,
      },
    });
  },

  sendOwnerAddedPostApprovalEmail(
    ctx: Context,
    data: Pick<SendOwnershipAcceptanceEmailProps, "projectName" | "bcc" | "ctaUrl">,
  ) {
    const { projectName, bcc } = data;
    const subject = `[Notification] Approval of Project Owner Request for ${projectName} project`;
    const preHeadline = `The request to add you as an additional Project Owner to`;
    const headline = `has been approved by the relevant Business Area Organization (BA Org). You are now an owner of the project.`;

    return EmailService.sendInfoCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        ...data,
        ctaLabel: "View project",
        headline,
        preHeadline,
      },
    });
  },
};
export default NotificationService;
