import { Context } from "@azure/functions";
import { Project } from "../../services/dbConnector/models/project";
import GraphService from "../../services/graphService/graphService";
import UserNotificationService from "../../services/userNotificationService/userNotificationService";
import InvitationsNotificationService from "./emails";
import { getEmailOfUser } from "../../utils/helpers";
import { RequestType, UpdateStatus } from "../../services/dbConnector/enums";
import NotificationService from "../../services/projectService/notificationService";
import OrgService from "../../services/igamService/orgService";
import IgamRequestModel from "../../services/dbConnector/models/igamRequestModel";
import { ActionType } from "../userActions/enums";
import ProjectService from "../../services/projectService/projectService";

/**
 * Notifies owners + user of ownership rejection
 *
 * @param ctx
 * @param inviteeOid
 * @param invitation rejected invitation
 */
export const sendRejectOwnershipNotifications = async (
  ctx: Context,
  inviteeOid: string,
  project: Project,
) => {
  const { ownersGroupId, name } = project;
  const [owners, invitee] = await Promise.all([
    GraphService.getGroupUsers(ctx, ownersGroupId, [
      "id",
      "mail",
      "otherMails",
      "displayName",
      "identities",
    ]),
    GraphService.getSimpleUser(ctx, inviteeOid),
  ]);

  const users = [...owners, invitee];
  await Promise.all([
    // notify owners + user who rejected
    UserNotificationService.notifyUsers(ctx, users, {
      project: { id: project._id, name: project.name },
      triggerer: { id: invitee.id, displayName: invitee.displayName },
      type: ActionType.REJECT_OWNERSHIP,
    }),

    // email owners
    InvitationsNotificationService.sendOwnershipRejectionEmail(ctx, {
      bcc: users.map((user) => getEmailOfUser(user)),
      userName: invitee.displayName,
      projectName: name,
    }),
  ]);
};

/**
 * Notifies owners + user of ownership acceptance
 *
 * @param ctx
 * @param inviteeOid oid of invitee
 */
export const sendAcceptOwnershipNotifications = async (
  ctx: Context,
  inviteeOid: string,
  project: Project,
  updateStatus?: UpdateStatus,
  requestId?: string,
  requestType?: RequestType,
) => {
  const { _id: pid, name } = project;
  const [owners, invitee] = await Promise.all([
    GraphService.getGroupUsers(ctx, project.ownersGroupId, [
      "id",
      "mail",
      "otherMails",
      "identities",
    ]),
    GraphService.getSimpleUser(ctx, inviteeOid),
  ]);

  await UserNotificationService.notifyUsers(ctx, [...owners, invitee], {
    project: { id: pid, name },
    triggerer: { id: invitee.id, displayName: invitee.displayName },
    type: ActionType.ACCEPT_OWNERSHIP,
  });

  if (updateStatus !== UpdateStatus.PENDING_APPROVAL) {
    await InvitationsNotificationService.sendOwnershipAcceptanceEmail(ctx, {
      bcc: [...owners, invitee].map((user) => getEmailOfUser(user)),
      userName: invitee.displayName,
      projectName: name,
      ctaUrl: ProjectService.getProjectUrl(project),
    });
    return;
  }

  if (!requestId) {
    throw new Error(`Missing request id for ${pid}`);
  }

  // check what type of request it is. if it's with org update the mail should contain the contacts of the new org
  let org: string = "";
  if (requestType === RequestType.ADD_OWNER_WITH_ORG_UPDATE) {
    const request = await IgamRequestModel.findOne({ requestId });
    if (!request?.org) {
      throw new Error(`Missing request or org for request id ${requestId}`);
    }
    org = request.org;
  } else {
    org = project.org;
  }

  const orgApprovers = await OrgService.getApproversEmails(ctx, org);

  await NotificationService.sendOwnerAwaitingApprovalEmail(
    ctx,
    [...owners, invitee].map((user) => getEmailOfUser(user)),
    name,
    invitee.displayName,
    requestId,
    org,
    orgApprovers,
  );
};
