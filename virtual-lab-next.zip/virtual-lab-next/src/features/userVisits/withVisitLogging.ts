import { HttpTriggerMwWithoutParams } from "../../../@types/types";
import UserVisitModel from "../../services/dbConnector/models/userVisitModel";

export const withVisitLogging: HttpTriggerMwWithoutParams = (handler) => async (ctx) => {
  // run action
  await handler(ctx);

  const { oid, sessionId } = ctx.session;

  // log visit
  ctx.log(`Creating user visit for`, { oid, sessionId });
  try {
    const sessionAlreadyLogged = await UserVisitModel.findOne({ sessionId });
    if (sessionAlreadyLogged) {
      ctx.log(`Session ${sessionId} already logged`);
    } else {
      ctx.log(`Session ${sessionId} not logged yet`);
      await UserVisitModel.create({
        oid,
        sessionId,
      });
    }
  } catch (e) {
    ctx.log(`Failed to create visit`, e);
  }
};
