import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";

type RemoveOwnerProps = {
  userEmail: string;
  projectName: string;
  bcc: string[];
};

type RemoveUserProps = {
  userEmail: string;
  projectName: string;
};

const NotificationService = {
  async sendOwnerRemovedEmail(ctx: Context, data: RemoveOwnerProps) {
    const subject = `[Notification] ${data.userEmail} has been removed from ${data.projectName}`;
    const preHeadline = `${data.userEmail} has been removed from`;
    const message =
      "If you believe this is an error, please reach out to the project owner or to the Virtual Lab support team.";

    return EmailService.sendInformationWithMessageEmail(ctx, {
      subject,
      bcc: data.bcc,
      templateData: {
        ...data,
        headline: "",
        postHeadline: "",
        senderName: "",
        preHeadline,
        message,
      },
    });
  },

  async sendUserRemovedEmail(ctx: Context, data: RemoveUserProps) {
    const subject = `[Notification] You have been removed from ${data.projectName}`;
    const preHeadline = `You have been removed from`;
    const message =
      "Please get in contact with the project owenr for future details. In case you believe it is an error, you can also reach out to the Virtual Lab support team.";

    return EmailService.sendInformationWithMessageEmail(ctx, {
      subject,
      bcc: data.userEmail,
      templateData: {
        ...data,
        headline: "",
        preHeadline,
        message,
        senderName: "",
        postHeadline: "",
      },
    });
  },
};
export default NotificationService;
