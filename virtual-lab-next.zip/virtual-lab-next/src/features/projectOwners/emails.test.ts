import { jest } from "@jest/globals";
import NotificationService from "./emails";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("add owner emails", () => {
  it("sendOwnerRemovedEmail works", async () => {
    await NotificationService.sendOwnerRemovedEmail(ctx, {
      bcc: [userEmail],
      userEmail,
      projectName: "project name",
    });
  });

  it("sendUserRemovedEmail works", async () => {
    await NotificationService.sendUserRemovedEmail(ctx, { userEmail, projectName: "project name" });
  });
});
