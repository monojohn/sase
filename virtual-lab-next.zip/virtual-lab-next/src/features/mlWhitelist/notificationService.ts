import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";
import { MlWhitelistRequest } from "./types";

const escapeDangerousChars = (str: string) =>
  str
    .replaceAll("&", "&amp")
    .replaceAll(">", "&gt")
    .replaceAll("<", "&lt")
    .replaceAll('"', "&quot")
    .replaceAll("'", "&#39");

const NotificationService = {
  async sendWhitelistRequestEmail(
    ctx: Context,
    requesterUpn: string,
    request: Pick<MlWhitelistRequest, "justification" | "urls">,
  ) {
    const subject = `[Action required] Whitelist request`;
    const headline: string[] = [
      `<p>User <b>${requesterUpn}</b> has requested whitelisting of the following urls:<p>`,
    ];

    headline.push(
      '<ul style="text-align:left;">',
      ...request.urls.split(",").map((url) => `<li>${escapeDangerousChars(url.trim())}</li>`),
      "</ul>",
      "<p>The following business justification was provided:</p>",
      `<i>"${escapeDangerousChars(request.justification)}"</i>`,
    );

    await EmailService.sendSuccessEmail(ctx, {
      subject,
      bcc: "virtuallab@ecb.europa.eu",
      templateData: {
        headline: headline.join(""),
        projectName: "Whitelist request",
      },
    });
  },
};

export default NotificationService;
