export type MlWhitelistItem = {
  Id: number;
  url: string;
  description: string;
  status: "Approved";

  // default fields
  Modified: string; // date string i.e. 2023-04-02T10:55:08Z
  Created: string; // date string i.e. 2023-04-02T10:55:08Z
};

export type MlWhitelistRequest = {
  Id: number;
  pid: number;
  oid: string;
  urls: string;
  justification: string;
  status: "Approved" | "Pending" | "Rejected";

  /**
   * Optional field to be filled in by request handler
   */
  comments?: string;

  // default fields
  Modified: string; // date string i.e. 2023-04-02T10:55:08Z
  Created: string; // date string i.e. 2023-04-02T10:55:08Z
};
