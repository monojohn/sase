import { Context } from "@azure/functions";
import { Session } from "../../middleware/withHttpSession";
import MlWhitelistRequestModel from "../../services/dbConnector/models/mlWhitelistRequestModel";
import NotificationService from "./notificationService";

const MlWhitelistService = {
  async requestApproval(
    ctx: Context,
    requesterSession: Session,
    pid: string,
    urls: string,
    justification: string,
  ) {
    const { upn, oid } = requesterSession;

    await MlWhitelistRequestModel.create({
      pid,
      oid,
      urls,
      justification,
    });

    // send email to VL team
    return NotificationService.sendWhitelistRequestEmail(ctx, upn, {
      justification,
      urls,
    });
  },
};

export default MlWhitelistService;
