import { jest } from "@jest/globals";
import { ConfidentialityLevel } from "../../services/dbConnector/enums";
import NotificationService from "./notificationService";

const ctx = { log: jest.fn() } as any;

describe("Open AI use case NotificationService", () => {
  it("sendSubmittedOpenAiUseCaseEmail works", async () => {
    await NotificationService.sendSubmittedOpenAiUseCaseEmail(ctx, {
      openAiUseCaseId: "123",
      projectName: "Dummy project name",
      ownerEmail: "email",
      ownerName: "test",
      // Since array is empty, email will not be sent
    });
  });

  it("sendUpdatedOpenAiUseCaseEmail works", async () => {
    await NotificationService.sendUpdatedOpenAiUseCaseEmail(ctx, {
      openAiUseCaseId: "123",
      projectName: "Dummy project name",
      ownerEmail: "email",
      ownerName: "test",
      updateOpenAiUseCaseId: "1234",
      // Since array is empty, email will not be sent
    });
  });

  it("sendLlmAwarenessInfoToUsers works", async () => {
    await NotificationService.sendLlmAwarenessInfoToUsers(ctx, {
      projectName: "Dummy project name",
      projectUrl: "Dummy project url",
      confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,

      // Since array is empty, email will not be sent
      emails: [],
      created: false,
    });
  });

  it("sendLlmAwarenessInfoToUsers works - created", async () => {
    await NotificationService.sendLlmAwarenessInfoToUsers(ctx, {
      projectName: "Dummy project name",
      projectUrl: "Dummy project url",
      confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,

      // Since array is empty, email will not be sent
      emails: [],
      created: true,
    });
  });

  it("sendLlmAwarenessInfoWithOpenAI works", async () => {
    await NotificationService.sendLlmAwarenessInfoWithOpenAI(ctx, {
      projectName: "Dummy project name",
      projectUrl: "Dummy project url",
      confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,

      // Since array is empty, email will not be sent
      emails: [],
      created: false,
      ecbContact: false,
    });
  });

  it("sendLlmAwarenessInfoWithOpenAI works - created", async () => {
    await NotificationService.sendLlmAwarenessInfoWithOpenAI(ctx, {
      projectName: "Dummy project name",
      projectUrl: "Dummy project url",
      confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,

      // Since array is empty, email will not be sent
      emails: [],
      created: true,
      ecbContact: true,
    });
  });
});
