import { Context } from "@azure/functions";
import { ConfidentialityLevel } from "../../services/dbConnector/enums";
import EmailService from "../../services/emailService/emailService";

type OpenAiUseCaseDetails = {
  openAiUseCaseId: string;
  updateOpenAiUseCaseId: string;
  projectName: string;
  projectUrl: string;
  confidentialityLevel: ConfidentialityLevel;
  ownerName: string;
  ownerEmail: string;
  created: boolean;
  ecbContact: boolean;
};
const NotificationService = {
  async sendSubmittedOpenAiUseCaseEmail(
    ctx: Context,
    data: Pick<
      OpenAiUseCaseDetails,
      "projectName" | "ownerEmail" | "ownerName" | "openAiUseCaseId"
    >,
  ) {
    const message = [
      "Hello Product Team,<br>This is an automated notification to inform you that a Project Owner has added an <strong>Inventory Use Case ID</strong> for a project in the Virtual Lab.",
      "<ul style='text-align: left'>",
      `<li><strong>Project Name:</strong> ${data.projectName}</li>`,
      `<li><strong>Project Owner:</strong> ${data.ownerName} (${data.ownerEmail})</li>`,
      `<li><strong>Use Case ID:</strong> ${data.openAiUseCaseId}</li>`,
      `<li><strong>Action required:</strong> Please ask the Product Owner to review this change</li>`,
      "</ul>",
    ]
      .flat()
      .filter(Boolean)
      .join("");

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: "virtuallab@ecb.europa.eu",
      subject: `[Notification] - New Inventory Use Case ID: ${data.projectName}`,
      templateData: {
        projectName: data.projectName,
        senderName: "",
        preHeadline: "",
        postHeadline: "",
        message,
      },
    });
  },

  async sendUpdatedOpenAiUseCaseEmail(
    ctx: Context,
    data: Pick<
      OpenAiUseCaseDetails,
      "projectName" | "ownerEmail" | "ownerName" | "openAiUseCaseId" | "updateOpenAiUseCaseId"
    >,
  ) {
    const message = [
      "Hello Product Team,<br>This is an automated notification to inform you that a Project Owner has updated the <strong>Inventory Use Case ID</strong> for a project in the Virtual Lab.",
      "<ul style='text-align: left'>",
      `<li><strong>Project Name:</strong> ${data.projectName}</li>`,
      `<li><strong>Project Owner:</strong> ${data.ownerName} (${data.ownerEmail})</li>`,
      `<li><strong>Old Use Case ID:</strong> ${data.openAiUseCaseId}</li>`,
      `<li><strong>New Case ID:</strong> ${data.updateOpenAiUseCaseId}</li>`,
      `<li><strong>Action required:</strong> Please ask the Product Owner to review this change</li>`,
      "</ul>",
    ]
      .flat()
      .filter(Boolean)
      .join("");

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: "virtuallab@ecb.europa.eu",
      subject: `[Notification] - Inventory Use Case ID Updated: ${data.projectName}`,
      templateData: {
        projectName: data.projectName,
        senderName: "",
        preHeadline: "",
        postHeadline: "",
        message,
      },
    });
  },

  async sendLlmAwarenessInfoToUsers(
    ctx: Context,
    data: Pick<
      OpenAiUseCaseDetails,
      "projectName" | "projectUrl" | "confidentialityLevel" | "created"
    > & {
      emails: string[];
    },
  ) {
    const headline = `
      <div style="padding:0px 0px 18px 0px; line-height:22px; text-align:justify;">
        <p style='text-align: center'>Your AI | ML workspace has been ${data.created ? "created" : "updated"} for an AI use case</p>
        <br />
        <p>The owner of the project has linked a LLM use-case to this Virtual Lab workspace. As being part of this project, upon starting developing and using AI models, make sure to read and understand <a href="https://darwin.escb.eu/livelink/livelink/app/nodes/1812905479" target="_blank" rel="noopener">the AI awareness material and the environment usage guidelines</a>. We encourage you to <strong>familiarise yourself</strong> with our usage guidelines and to use the environment responsibly. Please do not include any personal information in your experiments. The confidentiality of the environment has been assessed up to <strong>${data.confidentialityLevel}</strong></p>
      </div>
    `;

    return EmailService.sendInfoCtaEmail(ctx, {
      bcc: data.emails,
      subject: `[Action required] Connection to ECB Large Language Models (LLMs) - Awareness Material`,
      priority: "high",
      templateData: {
        projectName: data.projectName,
        preHeadline: "",
        headline,
        ctaLabel: "View project board",
        ctaUrl: data.projectUrl,
      },
    });
  },

  async sendLlmAwarenessInfoWithOpenAI(
    ctx: Context,
    data: Pick<
      OpenAiUseCaseDetails,
      "projectName" | "projectUrl" | "confidentialityLevel" | "created" | "ecbContact"
    > & {
      emails: string[];
    },
  ) {
    const headline = `
      <div style="padding:0px 0px 18px 0px; line-height:22px; text-align:justify;">
        <p style='text-align: center'>Your AI | ML workspace has been ${data.created ? "created" : "updated"} for an AI use case. ${data.ecbContact ? "Access to the Azure OpenAI models will be granted if/when the idea in the AI Use Case Inventory has reached <a href='https://europeancentralbank.atlassian.net/wiki/spaces/AIKP/pages/363242275/3.+Experimentation#Experimentation-Phase-To-Dos%3A' target='_blank'>green-lit for experimentation</a>." : "Access to the Azure OpenAI models will be granted after review from the Virtual Lab team."}</p>
        <br />
        <p>The owner of the project has linked a LLM use-case to this Virtual Lab workspace. As being part of this project, upon starting developing and using AI models, make sure to read and understand <a href="https://darwin.escb.eu/livelink/livelink/app/nodes/1812905479" target="_blank" rel="noopener">the AI awareness material and the environment usage guidelines</a>. We encourage you to <strong>familiarise yourself</strong> with our usage guidelines and to use the environment responsibly. Please do not include any personal information in your experiments. The confidentiality of the environment has been assessed up to <strong>${data.confidentialityLevel}</strong></p>
      </div>
    `;

    return EmailService.sendInfoCtaEmail(ctx, {
      bcc: data.emails,
      subject: `[Action required] Connection to ECB Large Language Models (LLMs) - Awareness Material`,
      priority: "high",
      templateData: {
        projectName: data.projectName,
        preHeadline: "",
        headline,
        ctaLabel: "View project board",
        ctaUrl: data.projectUrl,
      },
    });
  },
};

export default NotificationService;
