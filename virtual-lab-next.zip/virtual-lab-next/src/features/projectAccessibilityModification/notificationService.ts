import { Context } from "@azure/functions";
import moment from "moment";
import EmailService from "../../services/emailService/emailService";
import GraphService from "../../services/graphService/graphService";
import { getTeamGroupName } from "../../utils/helpers";
import { AccessibilityLevel } from "../../services/dbConnector/enums";

const NotificationService = {
  async sendSuccessEmail(
    ctx: Context,
    projectName: string,
    accessLevel: AccessibilityLevel,
    ctaUrl: string,
  ) {
    const groupId = await GraphService.getGroupIdByName(ctx, getTeamGroupName(projectName));

    const bcc = await GraphService.getGroupUsersEmails(ctx, groupId);

    const subject = `[Notification] Project accessibility changed for ${projectName} project`;
    const headline = `Project accessibility changed. Project is now ${accessLevel}`;

    await EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "View project",
        ctaUrl,
      },
    });
  },

  sendErrorEmail(ctx: Context, projectName: string, userEmail: string) {
    const subject = `[Failure] Your attempt to change the accessibility of the ${projectName} project was unsuccessful`;
    const headline = "Your attempt to change the project accessibility was unsuccessful";
    const actionName = "Change in project accessibility";

    return EmailService.sendErrorEmail(ctx, {
      bcc: userEmail,
      subject,
      templateData: {
        headline,
        userEmail,
        actionName,
        projectName,
        projectId: projectName,
        time: moment.utc().format("dddd, MMMM Do YYYY, h:mm:ss A z"),
      },
    });
  },
};

export default NotificationService;
