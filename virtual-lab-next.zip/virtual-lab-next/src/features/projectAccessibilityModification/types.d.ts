import { WithSession } from "../../../@types/types";

export type ProjectAccessLevel = "public" | "private" | "protected";

export type SetProcessAccessLevelProps = WithSession<{
  accessRequest: ProjectAccessLevel;
  groupName: string;
  siteName: string;
  itemId: number;
  email: string;
}>;
