import { jest } from "@jest/globals";
import NotificationService from "./notificationService";
import { createTestProject } from "../../../jest/helpers";
import { AccessibilityLevel } from "../../services/dbConnector/enums";
import GraphService from "../../services/graphService/graphService";
import { Project } from "../../services/dbConnector/models/project";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("repository deletion NotificationService", () => {
  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject();
  });
  beforeAll(() => {
    jest.spyOn(GraphService, "getGroupIdByName").mockImplementation(async () => "id");
    jest.spyOn(GraphService, "getGroupUsersEmails").mockImplementation(async () => []);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupIdByName").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
  });

  it("sendSuccessEmail works", async () => {
    await NotificationService.sendSuccessEmail(
      ctx,
      testProject.name,
      AccessibilityLevel.Private,
      "url",
    );
  });

  it("sendErrorEmail works", async () => {
    await NotificationService.sendErrorEmail(ctx, testProject.name, userEmail);
  });
});
