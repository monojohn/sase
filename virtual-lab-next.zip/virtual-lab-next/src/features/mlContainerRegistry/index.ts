import { Context } from "@azure/functions";
import { ContainerRegistryManagementClient, Registry } from "@azure/arm-containerregistry";
import { ClientCertificateCredential } from "@azure/identity";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import SlackService from "../../services/slackService";
import { AZURE_CR_RESOURCE_GROUP, AZURE_RESOURCE_GROUP, SUBSCRIPTION_ID } from "../../utils/config";

const moveContainerRegistries = async (
  ctx: Context,
  credentials: ClientCertificateCredential,
  containerRegistries: Registry[],
) => {
  const containerRegistriesToMove: string[] = [];

  for (const containerRegistry of containerRegistries) {
    ctx.log(`Check resource group for ${containerRegistry.name}`);
    const containerRegistryId = containerRegistry.id!;
    if (containerRegistryId.toLowerCase().includes(`/${AZURE_RESOURCE_GROUP.toLowerCase()}/`)) {
      ctx.log(`Container registry ${containerRegistry.name} will be moved`);
      containerRegistriesToMove.push(containerRegistryId);
    }
  }
  if (!containerRegistriesToMove.length) {
    return;
  }
  const sourceResourceGroup = AZURE_RESOURCE_GROUP;
  const targetResourceGroup = `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_CR_RESOURCE_GROUP}`;
  try {
    await MachineLearningService.moveResource(
      containerRegistriesToMove,
      sourceResourceGroup,
      targetResourceGroup,
      credentials,
    );
  } catch (e) {
    const error = new Error("Failed moving container registries");
    ctx.log(error, e);
    await SlackService.logWarning(ctx, error);
  }
};

export const updateContainerRegistries = async (ctx: Context) => {
  const credentials = MachineLearningService.connect();
  const client = new ContainerRegistryManagementClient(credentials, SUBSCRIPTION_ID);
  const containerRegistries = await MachineLearningService.getAllResources(
    client.registries.list(),
  );

  await moveContainerRegistries(ctx, credentials, containerRegistries);
};
