import { Context } from "@azure/functions";
import { Session } from "../../middleware/withHttpSession";
import { Project } from "../../services/dbConnector/models/project";
import GraphService from "../../services/graphService/graphService";
import UserNotificationService from "../../services/userNotificationService/userNotificationService";
import NotificationService from "./emails";
import { getEmailOfUser } from "../../utils/helpers";
import { ActionType } from "../userActions/enums";

export const sendRepositoryCreatedNotifications = async (
  ctx: Context,
  project: Pick<Project, "_id" | "name" | "teamGroupId">,
  repositoryUrl: string,
  session: Session,
) => {
  const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
    "id",
    "mail",
    "otherMails",
    "identities",
  ]);
  const bcc = users.map((owner) => getEmailOfUser(owner));

  await Promise.all([
    UserNotificationService.notifyUsers(ctx, users, {
      target: { id: repositoryUrl },
      type: ActionType.CREATE_REPOSITORY,
      project: { id: project._id, name: project.name },
      triggerer: { id: session.oid, displayName: session.name },
    }),
    NotificationService.sendRepositoryCreatedEmail(ctx, project.name, repositoryUrl, bcc),
  ]);
};

export const sendRepositoryDeletedNotifications = async (
  ctx: Context,
  project: {
    teamGroupId: string;
    id: string | number;
    name: string;
  },
  session: Session,
) => {
  const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
    "id",
    "mail",
    "otherMails",
    "identities",
  ]);
  const bcc = users.map((owner) => getEmailOfUser(owner));

  await Promise.all([
    UserNotificationService.notifyUsers(ctx, users, {
      type: ActionType.DELETE_REPOSITORY,
      project: { id: project.id, name: project.name },
      triggerer: { id: session.oid, displayName: session.name },
    }),
    NotificationService.sendRepositoryDeletedEmail(ctx, project.name, bcc),
  ]);
};
