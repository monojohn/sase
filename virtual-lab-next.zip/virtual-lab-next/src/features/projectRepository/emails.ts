import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";

const NotificationService = {
  async sendRepositoryCreatedEmail(
    ctx: Context,
    projectName: string,
    ctaUrl: string,
    bcc: string[],
  ) {
    const subject = `[Notification] The Git Repository for ${projectName} has been created`;
    const headline = "Your Git Repository has been created.";

    await EmailService.sendSuccessCtaEmail(ctx, {
      subject,
      bcc,
      templateData: {
        headline,
        projectName,
        ctaLabel: "View repository",
        ctaUrl,
      },
    });
  },

  async sendRepositoryDeletedEmail(ctx: Context, projectName: string, emails: string[]) {
    const subject = `[Notification] Your Git Repository in ${projectName} has been deleted`;
    const headline = "Your Git Repository has been deleted";

    return EmailService.sendSuccessEmail(ctx, {
      subject,
      bcc: emails,
      templateData: {
        projectName,
        headline,
      },
    });
  },
};
export default NotificationService;
