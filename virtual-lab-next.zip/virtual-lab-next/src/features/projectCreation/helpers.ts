import { Context } from "@azure/functions";
import { AccessibilityLevel } from "../../services/dbConnector/enums";
import GraphService from "../../services/graphService/graphService";
import PermissionService from "../../services/permissionService";
import PlannerService from "../../services/plannerService/plannerService";
import ProjectCreationService from "../../services/projectService/projectCreationService";
import SharePointService from "../../services/sharepointService/sharepointService";
import TeamsService from "../../services/teamService/teamsService";
import { AZURE_TENANT_ID } from "../../utils/config";
import { GraphUser } from "../../services/graphService/types";
import { ProjectCreationType } from "../../services/projectService/enums";
import { Project } from "../../services/dbConnector/models/project";
import SpFolderService from "../../services/sharepointService/spFolderService";
import QueueService, { QUEUE } from "../../services/queueService";

type CreateGroupsProps = {
  project: Project;
  owner: Pick<GraphUser, "id" | "userPrincipalName" | "userType" | "displayName" | "department">;
  projectCreationType: ProjectCreationType;
  department: string;
};

export const createGroups = async (ctx: Context, props: CreateGroupsProps) => {
  const entitlements = await ProjectCreationService.createGroups(ctx, {
    ...props,
  });

  if (props.projectCreationType === ProjectCreationType.APPROVAL_REQUIRED) {
    return {};
  }

  const groupIdNames = ["teamGroupId", "membersGroupId", "ownersGroupId"];

  ctx.log(`Group creation succeeded`);
  const ids = entitlements.map(([{ entCode }]) => entCode.split("~")[1]);

  const gIds = Object.fromEntries(groupIdNames.map((key, index) => [key, ids[index]]));
  ctx.log(`New group ids:`, gIds);

  return gIds;
};

type CreateContentProps = {
  itemId: number;
  title: string;
  type: AccessibilityLevel;
  teamGroupId: string;
  ownersGroupId: string;
  membersGroupId: string;
};

export const createContent = async (ctx: Context, props: CreateContentProps) => {
  const { itemId, title, type, teamGroupId, ownersGroupId, membersGroupId } = props;

  ctx.log(`Get General channel ID ${teamGroupId}`);
  const channelId = await TeamsService.getChannelId(ctx, teamGroupId);

  ctx.log(`Get Teams URL ${teamGroupId}`);
  const { webUrl: teamsUrl } = await TeamsService.getTeam(ctx, teamGroupId);

  ctx.log("Create Planner instance related to m365 group ID");
  const { id: plannerId } = await PlannerService.createPlanner(ctx, teamGroupId, title, channelId);

  const plannerUrl = `https://planner.cloud.microsoft/webui/plan/${plannerId}/view/board?tid=${AZURE_TENANT_ID}`;
  ctx.log({ plannerUrl });

  ctx.log("Get SharePoint project site name and project site URL", {
    teamGroupId,
  });

  const {
    name: siteName,
    webUrl: siteUrl,
    id: sharepointSiteIds,
  } = await GraphService.getSiteById(ctx, teamGroupId);
  const siteId = sharepointSiteIds.split(",")[1];

  ctx.log(`Join hubsite ${siteName}, ${siteUrl}, ${sharepointSiteIds}, ${siteId}`);
  await SharePointService.joinHubSite(ctx, siteName);

  ctx.log("Setting permissions", { type, siteName });
  await PermissionService.setPermissions(ctx, type, siteName);

  await SharePointService.createFilesPage(ctx, title, siteName);

  await SpFolderService.createGeneralFolder(ctx, siteName);

  const message = {
    itemId,
    siteUrl,
    projectName: title,
    m365GroupId: teamGroupId,
    ownersGroupId,
    membersGroupId,
  };

  ctx.log("Triggering template assign function", { message });
  await QueueService.put(QUEUE.TEMPLATE, message);

  return { siteId, siteUrl, teamsUrl, plannerUrl };
};
