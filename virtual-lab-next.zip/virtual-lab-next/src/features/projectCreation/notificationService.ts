import { Context } from "@azure/functions";
import moment from "moment";
import EmailService from "../../services/emailService/emailService";

type BaseData = {
  userEmail: string | string[];
  projectName: string;
};

type SuccessProps = BaseData & {
  ctaUrl: string;
};

type ApprovalPending = BaseData & {
  org: string;
  requestId: string;
  approvers: string[];
};

type ErrorProps = { userEmail: string; projectName: string };

const NotificationService = {
  sendErrorEmail(ctx: Context, data: ErrorProps) {
    const { userEmail } = data;

    const subject = "[Failure] Your attempt to create a project was unsuccessful";
    const headline = `Your attempt to create project ${data.projectName} was unsuccessful`;
    const actionName = "Create project";

    return EmailService.sendErrorEmail(ctx, {
      bcc: userEmail,
      subject,
      templateData: {
        ...data,
        headline,
        actionName,
        projectId: data.projectName,
        time: moment.utc().format("dddd, MMMM Do YYYY, h:mm:ss A z"),
        userEmail,
      },
    });
  },

  sendSuccessEmail(ctx: Context, data: SuccessProps) {
    const { projectName, ctaUrl, userEmail } = data;
    const subject = `[Notification] Your project ${projectName} has been created`;
    const headline = [`You are now project owner of ${projectName}.`];

    const ctaLabel = "View project board";

    return EmailService.sendSuccessCtaEmail(ctx, {
      bcc: data.userEmail,
      subject,
      templateData: {
        projectName,
        ctaUrl,
        userEmail,
        ctaLabel,
        headline: headline.join(""),
      },
    });
  },

  sendAwaitingManagerApprovalEmail(ctx: Context, data: ApprovalPending) {
    const { projectName, userEmail, org, requestId, approvers } = data;
    const subject = `[Notification] Approval Pending for Project Creation Request for ${projectName} project`;
    const headline = [
      `Your request ${requestId} to create the project ${projectName} has been submitted to the relevant Business Area Organization (${org}) in IGAM for its approval. Please note that your request may take some time, as the BA Org ${org} has 15 days to approve it. Below you can find the list of approvers.`,
      '<ul style="text-align: left;">',
      ...approvers.map((approver) => `<li>${approver}</li>`),
      "</ul>",
      `To ensure smooth communication and efficiency, please reach out to your approvers only in cases where there are delays in approval. You will receive a notification once your request has been approved.`,
    ];

    return EmailService.sendSuccessEmail(ctx, {
      bcc: userEmail,
      subject,
      templateData: {
        ...data,
        headline: headline.join(""),
      },
    });
  },
};

export default NotificationService;
