import { jest } from "@jest/globals";
import NotificationService from "./notificationService";

const { TEST_EMAIL: userEmail = "" } = process.env;
const ctx = { log: jest.fn() } as any;

jest.setTimeout(5 * 60 * 1000);

describe("NotificationService", () => {
  it("sendErrorEmail works", async () => {
    await NotificationService.sendErrorEmail(ctx, {
      projectName: "unit test",
      userEmail,
    });
  });

  it("sendSuccessEmail works", async () => {
    await NotificationService.sendSuccessEmail(ctx, {
      projectName: "unit test",
      userEmail,
      ctaUrl: "www.particleforward.com",
    });
  });

  it("sendAwaitingManagerApprovalEmail works", async () => {
    await NotificationService.sendAwaitingManagerApprovalEmail(ctx, {
      projectName: "unit test",
      userEmail,
      approvers: ["manager"],
      org: "org",
      requestId: "1234",
    });
  });
});
