import { Context } from "@azure/functions";
import type { MainHandler } from "../../../@types/types";
import { ProjectStatus, RequestType } from "../../services/dbConnector/enums";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import GraphService from "../../services/graphService/graphService";
import ProjectDeletionService from "../../services/projectService/projectDeletionService";
import SlackService from "../../services/slackService";
import { getTeamGroupName, wait } from "../../utils/helpers";
import { waitForProjectConstellation } from "../../utils/waitForProjectConstellation";
import { createContent, createGroups } from "./helpers";
import NotificationService from "./notificationService";
import type { CreateProjectProps } from "./types";
import { ProjectCreationType } from "../../services/projectService/enums";
import { GraphUser } from "../../services/graphService/types";
import IgamRequestModel from "../../services/dbConnector/models/igamRequestModel";
import OrgService from "../../services/igamService/orgService";
import ProjectService from "../../services/projectService/projectService";

/**
 * [Project creation step 4] handles resources creation
 *    creates groups in IGAM
 *    creates planner, pages and triggers template assign
 *    updates db with new ids
 */
export const createProject = async (
  ctx: Context,
  props: CreateProjectProps,
  owner: Pick<GraphUser, "id" | "userPrincipalName" | "userType" | "displayName" | "department">,
) => {
  const { project } = props;

  const department = await GraphService.getUserDepartment(ctx, owner);

  // [Project creation step 4.1] creates the groups
  const groups = await createGroups(ctx, {
    ...props,
    owner,
    department,
  });

  const { teamGroupId, membersGroupId, ownersGroupId } = groups;

  // [Project creation step 4.2] creates the content
  const content = await createContent(ctx, {
    type: project.accessibilityLevel,
    title: project.name,
    itemId: 0,
    teamGroupId,
    ownersGroupId,
    membersGroupId,
  });

  // [Project creation step 4.2] updates DB with new data
  await ProjectModel.findOneAndUpdate(
    { _id: project._id },
    {
      $set: {
        teamGroupId,
        membersGroupId,
        ownersGroupId,
        siteId: content.siteId,
        url: content.siteUrl,
        teamsUrl: content.teamsUrl,
        plannerUrl: content.plannerUrl,
        org: department,
      },
    },
  );

  return { ...content, teamGroupId };
};

/**
 * [Project creation step 3] - alternate project creation in which approval is necessary
 */
const createSimpleProject = async (
  ctx: Context,
  props: CreateProjectProps,
  title: string,
  owner: Pick<GraphUser, "id" | "userPrincipalName" | "userType" | "displayName" | "department">,
  userEmail: string,
) => {
  const department = await GraphService.getUserDepartment(ctx, owner);
  // [Project creation step 3.1] - create just owners group with approval request
  const { ownersGroupId } = await createGroups(ctx, {
    ...props,
    owner,
    department,
  });

  // [Project creation step 3.2] update project with owner group id
  await ProjectModel.findOneAndUpdate(
    { _id: props.project._id },
    {
      $set: {
        ownersGroupId,
        org: department,
      },
    },
    { lean: true },
  );

  // [Project creation step 3.3] - notify owner about the request sent to his BA Org
  const igamRequest = await IgamRequestModel.findOne({
    pid: props.project._id,
    requestType: RequestType.PROJECT_CREATION,
  });

  if (!igamRequest?.requestId) {
    throw new Error(`Missing request or requestId in db for project ${props.project.name}`);
  }

  const org = await GraphService.getUserDepartment(ctx, owner);
  const approvers = await OrgService.getApproversEmails(ctx, org);

  // notify owner
  await NotificationService.sendAwaitingManagerApprovalEmail(ctx, {
    userEmail,
    projectName: title,
    requestId: igamRequest.requestId,
    org,
    approvers,
  });
  return true;
};

/**
 * [Project creation step 2] handles the creation of the project
 * Recent changes:
 *  if project needs approval, only the owner group is created while we wait for approval, the db is updated with the owner group id and the owner is notified
 *  if not, the entire project is created just like it was so far
 */
const projectCreation: MainHandler<CreateProjectProps> = async (ctx, props) => {
  let isExistingError = false;
  let mainOwnerEmail: string | undefined;

  try {
    const { project, owner, projectCreationType } = props;
    const { name } = project;

    ctx.log(`Creating project ${props.project.name}`, props);
    const graphOwner = await GraphService.getUserProps(ctx, owner, [
      "userPrincipalName",
      "displayName",
      "userType",
      "department",
      "id",
    ]);

    // check if project with the same name exists
    const [existingTeamGroup] = await GraphService.getGroupByName(ctx, getTeamGroupName(name));
    // throw if a group with the same name already exists
    if (existingTeamGroup) {
      isExistingError = true;
      throw new Error(`Group with name '${existingTeamGroup.displayName}', already exists`);
    }

    const ownerUpn = graphOwner.userPrincipalName;
    mainOwnerEmail = await GraphService.getUserEmail(ctx, ownerUpn);
    if (projectCreationType === ProjectCreationType.APPROVAL_REQUIRED) {
      // [Project creation step 3] - alternatively
      return await createSimpleProject(ctx, props, name, graphOwner, mainOwnerEmail);
    }

    ctx.log("Creating project entitlements");
    // [Project creation step 4] handles resources creation
    await createProject(ctx, props, graphOwner);

    // [Project creation step 5] wait a bit for the site template to be assigned before sending the email
    await wait(5 * 60);

    const updatedProject = await ProjectModel.findOneAndUpdate(
      { _id: project._id },
      { $set: { status: ProjectStatus.Active } },
      { lean: true },
    );

    if (!updatedProject) {
      throw new Error(`Missing project with id ${project._id}`);
    }

    // wait for users to be assigned to the right groups before proceeding
    const usersAssigned = await waitForProjectConstellation(ctx, updatedProject);
    if (usersAssigned) {
      ctx.log("All users were assigned to groups");
    } else {
      ctx.log("Not all users were assigned to groups");
    }

    // [Project creation step 6] notify user
    ctx.log(`Sending owner email notification to *****${mainOwnerEmail.split("@")[1]}`);
    await NotificationService.sendSuccessEmail(ctx, {
      userEmail: mainOwnerEmail,
      projectName: name,
      ctaUrl: ProjectService.getProjectUrl(project),
    });

    return true;
  } catch (e) {
    const err = e as Error;
    const errorMessage = `${err.message}\n${JSON.stringify(props, null, 2)}`;
    ctx.log.error(`createProjectFailure: ${errorMessage}`);
    ctx.log({ isExistingError });

    await SlackService.logError(ctx, new Error(errorMessage));

    ctx.log(`Error`, err);
    if (mainOwnerEmail) {
      ctx.log(`Notifying user who created the project`);
      await NotificationService.sendErrorEmail(ctx, {
        projectName: props.project.name,
        userEmail: mainOwnerEmail,
      });
    } else {
      ctx.log("Owner email not present, no user to notify");
    }

    if (!isExistingError) {
      ctx.log(`Cleaning up project`);
      // wait before triggering group deletion: groups creation can take a while
      await wait(10 * 60);
      await ProjectDeletionService.handleCreationFailure(ctx, {
        id: props.project._id,
        name: props.project.name,
      });
    }
  }

  return false;
};

export default projectCreation;
