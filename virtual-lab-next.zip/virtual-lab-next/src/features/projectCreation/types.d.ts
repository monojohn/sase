import { Project } from "../../services/dbConnector/models/project";
import { ProjectCreationType } from "../../services/projectService/enums";

export type CreateProjectProps = {
  /**
   * oid of owner
   */
  owner: string; // oid

  /**
   * Project
   */
  project: Project;
  addAllOwners?: boolean;
  projectCreationType: ProjectCreationType;
};
