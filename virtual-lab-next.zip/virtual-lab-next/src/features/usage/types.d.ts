export type ActivityLog = {
  authorization: {
    scope: string; // /subscriptions/1900189e-cd37-4df6-abf1-19a2839b2112/resourceGroups/rg-VLDev/providers/Microsoft.MachineLearningServices/workspaces/test1-workspace/privateEndpointConnectionProxies/testfl-pe-fl-20.f8310ce5-c0db-4234-b8b0-58291b7b2d6d
  };
  operationName: {
    value: string; // Microsoft.MachineLearningServices/workspaces/computes/stop/action
  };
  status: {
    value: string; // Succeeded
  };
  eventTimestamp: string; // 2022-11-17T09:32:08.7703457Z
};
