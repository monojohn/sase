import { Context } from "@azure/functions";
import moment from "moment";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";

export const getRecentWorkspaceActivities = async (
  ctx: Context,
  workspaceId: string,
  days = 90,
) => {
  ctx.log(`${workspaceId}: Fetching`);
  return MachineLearningService.getActivityLog(
    ctx,
    workspaceId,
    moment.utc().subtract(days, "days").format(),
    moment.utc().format(),
  );
};

/**
 * Returns a boolean indicating if the workspace
 * has been used in the last 90 days
 */
export const isProjectWorkspaceActive = async (ctx: Context, projectName: string) => {
  const workspace = await MachineLearningService.getWorkspaceByProjectName(projectName);
  if (!workspace?.id) {
    const error = `Project ${projectName} workspace is missing`;
    ctx.log(error);
    throw new Error(error);
  }

  const activities = await getRecentWorkspaceActivities(ctx, workspace.id, 90);
  return activities?.length > 0;
};
