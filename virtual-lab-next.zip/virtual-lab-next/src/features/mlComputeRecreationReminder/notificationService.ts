import { Context } from "@azure/functions";
import EmailService from "../../services/emailService/emailService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import { TEMPLATE_ID } from "../../services/emailService/flowmailer";

type EmailProps = {
  email: string;
  workspaceName: string;
  computeInstances: string[];
};

const getComputeRows = (urlBeggining: string, urlEnd: string, computeInstances: string[]) =>
  computeInstances
    .map(
      (compute) => `
        <tr>
          <td><a href="${urlBeggining}${compute}/details?wsid=${urlEnd}">${compute}</a></td>
        </tr>
        `,
    )
    .join("");

const NotificationService = {
  async sendComputeRecreationEmail(ctx: Context, props: EmailProps) {
    const { email, workspaceName, computeInstances } = props;

    const count = computeInstances.length;
    const subject = `[Notification] Warning: ${count} compute instance(s) have to be recreated`;
    const headline = `${count} compute instance(s) have to be recreated in your Virtual Lab project`;
    const ctaLabel = "View compute instances";

    const computeUrlPrefix = "https://ml.azure.com/compute/";
    const computeUrlSuffix =
      MachineLearningService.getWorkspaceUrlByName(workspaceName).split("wsid=")[1];
    const ctaUrl = `${computeUrlPrefix}list/instances?wsid=${computeUrlSuffix}`;

    return EmailService.sendEmail(ctx, TEMPLATE_ID.ML_COMPUTE_RECREATION_REMINDER, {
      bcc: email,
      subject,
      templateData: {
        count,
        ctaUrl,
        ctaLabel,
        headline,
        computeInstances: getComputeRows(computeUrlPrefix, computeUrlSuffix, computeInstances),
      },
    });
  },
};

export default NotificationService;
