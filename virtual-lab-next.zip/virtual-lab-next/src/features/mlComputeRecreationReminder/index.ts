import { Context } from "@azure/functions";
import { SecurityCenter } from "@azure/arm-security";
import { Workspace } from "@azure/arm-machinelearning";
import GraphService from "../../services/graphService/graphService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import { chunkArray } from "../../utils/chunkArray";
import { IS_PROD, SUBSCRIPTION_ID } from "../../utils/config";
import NotificationService from "./notificationService";
import SlackService from "../../services/slackService";

async function emailComputeOwners(
  ctx: Context,
  workspace: Workspace,
  computeInstancesToBeRecreated: string[],
) {
  if (!workspace?.name) {
    const error = `Workspace name not defined for ${workspace.id}`;
    ctx.log(error);
    return;
  }
  const workspaceName = workspace.name;
  const computes = await MachineLearningService.getComputes(ctx, workspaceName);

  const toEmail: Record<string, string[]> = {};

  // get compute owners who have to be notified
  for (const compute of computes.filter(({ name }) =>
    computeInstancesToBeRecreated.includes(name),
  )) {
    const { userId } = compute.properties.properties.createdBy;

    if (!toEmail[userId]) {
      toEmail[userId] = [];
    }
    toEmail[userId].push(compute.name);
  }
  // send email to compute owners
  await Promise.all(
    Object.keys(toEmail).map(async (userId) => {
      const userEmail = await GraphService.getUserEmail(ctx, userId);
      const email = IS_PROD ? userEmail : "virtuallab@ecb.europa.eu";
      ctx.log(`Sending email to ${email} regarding ${toEmail[userId].join(", ")}`);
      await NotificationService.sendComputeRecreationEmail(ctx, {
        email,
        workspaceName,
        computeInstances: toEmail[userId],
      });
    }),
  );
}

export const sendComputeRecreationReminder = async (ctx: Context) => {
  // get unhealthy resources from Microsoft Defender
  const credentials = MachineLearningService.connect();
  const securityCenterClient = new SecurityCenter(credentials, SUBSCRIPTION_ID);
  const assessmentDisplayName =
    "Azure Machine Learning compute instances should be recreated to get the latest software updates";
  const unhealthyComputes = await MachineLearningService.getUnhealthyAssessments(
    securityCenterClient,
    assessmentDisplayName,
  );

  const computeNamesToBeRecreated = unhealthyComputes.map(
    ({ resourceDetails }) => (resourceDetails as unknown as { ResourceName: string }).ResourceName,
  );

  const workspaces = await MachineLearningService.getAllProjects();
  const chunks = chunkArray(workspaces);

  const errors: string[] = [];
  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (workspace) => {
        await emailComputeOwners(ctx, workspace, computeNamesToBeRecreated);
      }),
    );

    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        const error = `Failed checking unhealthy computes for workspace ${chunk[ind].name}`;
        ctx.log(error, promiseResult.reason);
        errors.push(error);
      }
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};
