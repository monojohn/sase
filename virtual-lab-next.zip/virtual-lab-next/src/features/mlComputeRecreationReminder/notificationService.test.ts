import { jest } from "@jest/globals";
import NotificationService from "./notificationService";

const { TEST_EMAIL: email = "" } = process.env;
const ctx = { log: jest.fn() } as any;

describe("Machine learning NotificationService", () => {
  it("sendSuccessEmail works", async () => {
    await NotificationService.sendComputeRecreationEmail(ctx, {
      email,
      workspaceName: "workspace name",
      computeInstances: ["test"],
    });
  });
});
