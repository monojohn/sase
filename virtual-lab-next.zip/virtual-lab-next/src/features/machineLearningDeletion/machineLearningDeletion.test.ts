import { jest } from "@jest/globals";
import WorkspaceDeletionService, * as WorkspaceDeletionFunctions from "./index";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { createTestProject, getCtx } from "../../../jest/helpers";

const ctx = getCtx({ name: "Project workspace deletion" });

describe("WorkspaceDeletionService", () => {
  const deleteWorkspace = jest.fn<typeof WorkspaceDeletionFunctions.helper.deleteWorkspace>();

  beforeEach(() => {
    jest
      .spyOn(WorkspaceDeletionFunctions.helper, "deleteWorkspace")
      .mockImplementationOnce(deleteWorkspace);
  });

  it("should work when project is not provided", async () => {
    expect(await WorkspaceDeletionService.delete(ctx, null)).toBeUndefined();
  });

  it("should handle deleting a project", async () => {
    const project = await createTestProject();

    await WorkspaceDeletionService.delete(ctx, project);
    expect(deleteWorkspace).toHaveBeenCalledWith(ctx, project);

    // Assert that all ml workspace related data were deleted in project
    const deletedMlWorkspaceFromProject = (await ProjectModel.findById(project._id))!.toJSON();
    expect(deletedMlWorkspaceFromProject).toStrictEqual(
      expect.objectContaining({
        workspaceUrl: null,
        workspaceType: null,
        permissionsChangedDate: null,
        workspaceExploratoryJustification: null,
        rolesAndEntitlements: [],
        aiUsage: null,
        aiModels: null,
        openAiConnection: null,
        ecbContact: null,
        aiUseCaseId: null,
        gdpr: null,
        aiAct: null,
        businessRisk: null,
      }),
    );
  });
});
