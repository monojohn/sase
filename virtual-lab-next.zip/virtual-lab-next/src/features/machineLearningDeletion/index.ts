import { Context } from "@azure/functions";
import BudgetService from "../../services/budgetService/budgetService";
import { Project } from "../../services/dbConnector/models/project";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import KubernetesService from "../../services/kubernetes/kubernetesService";
import MachineLearningService from "../../services/machineLearningService/machineLearningService";
import { WorkspaceType } from "../../services/sharepointService/enums";
import SlackService from "../../services/slackService";
import { ML_NETWORK_RG, ML_VNET_NAME, SUBSCRIPTION_ID } from "../../utils/config";
import { getOwnersGroupName, getTeamGroupName } from "../../utils/helpers";

/**
 * This helper is exported only for the purpose of easier testing (mocking), it IS NOT meant to be used directly!
 *  -> Use WorkspaceDeletionService.delete
 *
 * @param ctx
 * @param project
 */
export const helper = {
  deleteWorkspace: async (ctx: Context, project: Project) => {
    const { name: projectName, workspaceType, membersGroupName } = project;
    ctx.log(`Deleting Azure ML workspace of ${projectName}`);

    ctx.log("Connecting to Azure");
    const credentials = MachineLearningService.connect();

    ctx.log("Getting Workspace name for k8s");
    const workspaceData = await MachineLearningService.getWorkspaceByProjectName(projectName);

    ctx.log("Deleting ML workspace");
    void (await MachineLearningService.deleteWorkspace(ctx, credentials, projectName));

    ctx.log("Deleting Budget");
    const budgetService = new BudgetService(ctx);
    await budgetService.deleteBudget(ctx, getTeamGroupName(projectName));

    if (workspaceType === WorkspaceType.SECURED) {
      ctx.log("Deleting network permissions for owners");
      await MachineLearningService.deleteNetworkPermission(
        ctx,
        SUBSCRIPTION_ID,
        ML_VNET_NAME,
        getOwnersGroupName(projectName),
        ML_NETWORK_RG,
      );
      ctx.log("Deleting network permissions for members");
      await MachineLearningService.deleteNetworkPermission(
        ctx,
        SUBSCRIPTION_ID,
        ML_VNET_NAME,
        membersGroupName,
        ML_NETWORK_RG,
      );

      if (!workspaceData?.name) {
        const error = `Kubernetes workspace not found for project ${projectName}`;
        ctx.log(error);
        await SlackService.logWarning(ctx, new Error(error));
        return;
      }

      ctx.log("Deleting ML project k8s namespace");
      await KubernetesService.deleteNamespace(workspaceData.name);
    }

    ctx.log("Azure ML workspace deleted");
  },
} as const;

const WorkspaceDeletionService = {
  async delete(ctx: Context, project: Project | null) {
    if (!project) {
      ctx.log(`No project received`);
      return;
    }

    const { _id } = project;
    await helper.deleteWorkspace(ctx, project);

    ctx.log("Removing ml workspace data from ProjectModel");
    await ProjectModel.updateOne(
      { _id },
      {
        $set: {
          workspaceUrl: null,
          workspaceType: null,
          permissionsChangedDate: null,
          workspaceExploratoryJustification: null,
          rolesAndEntitlements: [],
          aiUsage: null,
          aiModels: null,
          openAiConnection: null,
          ecbContact: null,
          aiUseCaseId: null,
          gdpr: null,
          aiAct: null,
          businessRisk: null,
        },
      },
    );
  },
} as const;

export default WorkspaceDeletionService;
