/**
 * Function used to adapt the group name to the infrastructure
 * naming limits
 */
export const nameOps = (groupName: string) => {
  const projectName = groupName.toLowerCase().replace(/[^a-zA-Z0-9]/g, ""); // NOSONAR wants replaceAll

  const mlName = projectName.length >= 25 ? projectName.substring(0, 24) : projectName;
  const storageName = projectName.length >= 18 ? projectName.substring(0, 17) : projectName;

  return { mlName, storageName, projectName };
};

export const computeName = (azureMlName: string) => {
  const compute = azureMlName.slice(-7);
  return /^\d$/.test(compute[0]) ? `a${compute}` : compute;
};
