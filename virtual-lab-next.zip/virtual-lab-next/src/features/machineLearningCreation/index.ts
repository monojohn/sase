import { Context } from "@azure/functions";
import KubernetesService from "../../services/kubernetes/kubernetesService";
import MlService from "../../services/machineLearningService/machineLearningService";
import SlackService from "../../services/slackService";

import BudgetService from "../../services/budgetService/budgetService";
import ProjectModel from "../../services/dbConnector/models/projectModel";
import { enableStorageAccountLogging } from "../../services/machineLearningService/helpers";
import {
  AZURE_LOCATION,
  AZURE_RESOURCE_GROUP,
  AZURE_TENANT_ID,
  CONTRIBUTOR_ROLE_ID,
  CUSTOM_MEMBER_ROLE_ID,
  ML_NETWORK_RG,
  ML_SUBNET_JOIN_ROLE,
  ML_SUBNET_NAME,
  ML_VNET_NAME,
  RESOURCE_GROUP_DNS,
  SUBSCRIPTION_ID,
  SUBSCRIPTION_ID_DNS,
} from "../../utils/config";
import {
  generateRandomString,
  getMembersGroupName,
  getOwnersGroupName,
  wait,
} from "../../utils/helpers";
import WorkspaceDeletionService from "../machineLearningDeletion/index";
import { computeName, nameOps } from "./helpers";
import {
  AiAct,
  BusinessRisk,
  DataSensitivityLevel,
  GdprAssessment,
  RequestStatus,
  RequestType,
} from "../../services/dbConnector/enums";
import { Project } from "../../services/dbConnector/models/project";
import GraphService from "../../services/graphService/graphService";
import IgamRequestModel from "../../services/dbConnector/models/igamRequestModel";

export enum WorkspaceType {
  SECURED = "Secured",
  EXPLORATORY = "Exploratory",
}

type CreateWorkspace = {
  pid: string;
  workspaceType: WorkspaceType;
  projectName: string;
};

type CreateWorkspaceProps = CreateWorkspace & {
  workspaceExploratoryJustification?: string;
  aiUsage: boolean;
  aiModels?: string;
  openAiConnection?: boolean;
  ecbContact?: boolean;
  aiUseCaseId?: string;
  gdpr?: GdprAssessment;
  aiAct?: AiAct;
  businessRisk?: BusinessRisk;
};

type WorkspaceTags = {
  app: "virtuallab";
  project: string;
  workspaceType?: WorkspaceType.EXPLORATORY;
};

const createWorkspace = async (ctx: Context, props: CreateWorkspace) => {
  const { projectName, workspaceType: type } = props;
  const randString = generateRandomString(4);
  const infraName = nameOps(projectName);
  const tags: WorkspaceTags = { app: "virtuallab", project: projectName };
  const budgetService = new BudgetService(ctx);
  if (type === WorkspaceType.EXPLORATORY) {
    tags.workspaceType = WorkspaceType.EXPLORATORY;
  }

  const storageAccountName = `st${infraName.storageName}${randString}`;
  const azureMlName = `mlw-${infraName.mlName}${randString}`;
  const keyVaultName = `kv-${infraName.storageName}${randString}`;
  const keyVaultKeyName = `kvk-${infraName.storageName}${randString}`;
  const appInsightsName = `appi-mlw-${infraName.projectName}${randString}`;
  const privateEndpointName = `${infraName.mlName}${randString}`;

  ctx.log("Connecting to Azure");
  const credentials = MlService.connect();
  let workspaceUrl = "";

  const keyVault = await MlService.createKeyVault(
    ctx,
    credentials,
    SUBSCRIPTION_ID,
    AZURE_TENANT_ID,
    AZURE_RESOURCE_GROUP,
    keyVaultName,
    tags,
  );
  const keyVaultKey = await MlService.createKeyVaultKey(
    ctx,
    credentials,
    SUBSCRIPTION_ID,
    AZURE_RESOURCE_GROUP,
    keyVaultName,
    keyVaultKeyName,
    tags,
  );
  await Promise.all([
    MlService.createStorageAccount(ctx, credentials, {
      subscriptionId: SUBSCRIPTION_ID,
      resourceGroupName: AZURE_RESOURCE_GROUP,
      storageAccountName,
      keyVaultKey,
      keyVault,
      tags: { ...tags, Backup: "disabled" },
    }),
    MlService.createAppInsights(
      ctx,
      credentials,
      SUBSCRIPTION_ID,
      AZURE_RESOURCE_GROUP,
      appInsightsName,
      tags,
    ),
  ]);

  await MlService.createWorkspace(ctx, credentials, {
    subscriptionId: SUBSCRIPTION_ID,
    resourceGroup: AZURE_RESOURCE_GROUP,
    storageAccountName,
    azureMlName,
    keyVaultName,
    appInsightsName,
    tags,
  });

  const promises: Promise<unknown>[] = [];

  if (type === WorkspaceType.SECURED) {
    ctx.log("Creating Private endpoint");
    promises.push(
      // Private endpoint creation using template
      MlService.createMlPrivateEndpoint(ctx, {
        subscriptionId: SUBSCRIPTION_ID,
        resourceGroup: AZURE_RESOURCE_GROUP,
        azureMlName,
        networkRg: ML_NETWORK_RG,
        vnetName: ML_VNET_NAME,
        subnetName: ML_SUBNET_NAME,
        infraName: privateEndpointName,
        tag: projectName,
        resourceGroupDns: RESOURCE_GROUP_DNS,
        subscriptionIdDns: SUBSCRIPTION_ID_DNS,
      }),
      MlService.createNetworkPermission(
        ctx,
        SUBSCRIPTION_ID,
        ML_VNET_NAME,
        getOwnersGroupName(projectName),
        ML_SUBNET_JOIN_ROLE,
        ML_NETWORK_RG,
      ),
      MlService.createNetworkPermission(
        ctx,
        SUBSCRIPTION_ID,
        ML_VNET_NAME,
        getMembersGroupName(projectName),
        ML_SUBNET_JOIN_ROLE,
        ML_NETWORK_RG,
      ),

      MlService.modifyAzureMLQuota(
        ctx,
        credentials,
        SUBSCRIPTION_ID,
        AZURE_LOCATION,
        AZURE_RESOURCE_GROUP,
        azureMlName,
      ),
    );
  }

  promises.push(
    MlService.createPermissions(
      ctx,
      SUBSCRIPTION_ID,
      AZURE_RESOURCE_GROUP,
      getOwnersGroupName(projectName),
      CONTRIBUTOR_ROLE_ID,
      azureMlName,
    ),
    MlService.createPermissions(
      ctx,
      SUBSCRIPTION_ID,
      AZURE_RESOURCE_GROUP,
      getMembersGroupName(projectName),
      CUSTOM_MEMBER_ROLE_ID,
      azureMlName,
    ),

    MlService.modifyAzureMLQuota(
      ctx,
      credentials,
      SUBSCRIPTION_ID,
      AZURE_LOCATION,
      AZURE_RESOURCE_GROUP,
      azureMlName,
    ),

    budgetService.createProjectBudget(ctx, projectName),
    enableStorageAccountLogging(storageAccountName),
  );

  await Promise.all(promises);
  if (type === WorkspaceType.SECURED) {
    ctx.log("Verify ML private endpoint creation");
    let provisioningState = "Running";
    let retryCount = 0;

    while (provisioningState !== "Succeeded" && retryCount < 60) {
      /* eslint-disable no-await-in-loop */
      provisioningState = await MlService.verifyDeployment(
        ctx,
        `Microsoft.PrivateEndpoint-${privateEndpointName}`,
        AZURE_RESOURCE_GROUP,
        SUBSCRIPTION_ID,
      );
      if (provisioningState === "Succeeded") {
        ctx.log(`Private endpoint creation status:`, provisioningState);
      }
      if (provisioningState === "Failed") {
        throw new Error(`Failed to create private endpoint`);
      }
      await wait(5);
      retryCount += 1;
    }

    await MlService.updateMlNetworkAccess(ctx, SUBSCRIPTION_ID, AZURE_RESOURCE_GROUP, azureMlName);

    // wait needed after the network access change in order to create a compute cluster
    await wait(20);

    ctx.log("Creating Builder Compute Cluster");
    await MlService.createComputeCluster(ctx, azureMlName, `${computeName(azureMlName)}-bld`);

    ctx.log("Setting default builder target");
    await MlService.setMlBuildTarget(ctx, azureMlName, `${computeName(azureMlName)}-bld`);

    ctx.log("Creating Kubernetes namespace");
    await KubernetesService.createNamespace(azureMlName);

    ctx.log("Creating Kubernetes cpu instance");
    await MlService.attachAKS(
      ctx,
      azureMlName,
      `${computeName(azureMlName)}`,
      { type: "ml-cpu" },
      0,
    );
  }

  // NOTE: uncomment when connection works
  // ctx.log("Updating storage accounts");
  // await MlService.updateStorageAcc(
  //   ctx,
  //   credentials,
  //   storageAccountName,
  //   azureMlName
  // );

  ctx.log("Updating blob service");
  await MlService.updateBlobService(ctx, credentials, storageAccountName);

  workspaceUrl = MlService.getWorkspaceUrlByName(azureMlName);
  ctx.log("workspace created", { workspaceUrl, AzureMLWorkspaceType: type });
  return workspaceUrl;
};

export const createMlWorkspace = async (ctx: Context, props: CreateWorkspaceProps) => {
  try {
    const workspaceUrl = await createWorkspace(ctx, props);
    ctx.log("Updating Project list with AzureML Studio link");

    const {
      workspaceType,
      workspaceExploratoryJustification,
      aiUsage,
      aiModels,
      openAiConnection,
      ecbContact,
      aiUseCaseId,
      gdpr,
      aiAct,
      businessRisk,
    } = props;

    await ProjectModel.updateOne(
      { _id: props.pid },
      {
        $set: {
          workspaceUrl,
          workspaceType,
          workspaceExploratoryJustification,
          aiUsage,
          aiModels,
          openAiConnection,
          ecbContact,
          aiUseCaseId,
          gdpr,
          aiAct,
          businessRisk,
        },
      },
    );

    return workspaceUrl;
  } catch (e) {
    ctx.log(`Failed to create ML workspace`, e);
    const project = await ProjectModel.findById(props.pid);
    await SlackService.logError(ctx, e as Error);
    await WorkspaceDeletionService.delete(ctx, project);
    throw e;
  }
};

export const validateMlProps = async (
  ctx: Context,
  props: CreateWorkspaceProps,
  project: Project,
  oid: string,
) => {
  const {
    workspaceType,
    workspaceExploratoryJustification,
    aiUsage,
    aiModels,
    openAiConnection,
    ecbContact,
    aiUseCaseId,
    gdpr,
    aiAct,
    businessRisk,
  } = props;

  const types = Object.values(WorkspaceType);
  if (!types.includes(workspaceType)) {
    return {
      passed: false,
      message: `Invalid workspace type: '${workspaceType}' is invalid. Expected one of ${types.join(
        ", ",
      )}`,
    };
  }

  // expect a specific justification for exploratory workspaces
  if (
    workspaceType === WorkspaceType.EXPLORATORY &&
    (typeof workspaceExploratoryJustification !== "string" ||
      workspaceExploratoryJustification.length <= 0)
  ) {
    return {
      passed: false,
      message: `Invalid workspaceExploratoryJustification: '${typeof workspaceExploratoryJustification}' is invalid. Expected a string with >0 length`,
    };
  }

  // validate data sensitivity level
  if (
    workspaceType === WorkspaceType.EXPLORATORY &&
    project.dataSensitivityLevel === DataSensitivityLevel.CSI
  ) {
    return {
      passed: false,
      message: `Invalid workspaceType ${workspaceType} for a ${project.dataSensitivityLevel} data sensitivity level. Expected workspaceType ${WorkspaceType.SECURED}`,
    };
  }

  // if aiUsage is true -> aiModels and openAiConnection are needed
  if (aiUsage && (!aiModels || openAiConnection == null)) {
    return { passed: false, message: `Missing aiModels or openAiConnection when aiUsage is true` };
  }

  // validate pending data sensitivity level if it exists
  const [pendingConfidentiality, user] = await Promise.all([
    IgamRequestModel.findOne({
      pid: project._id,
      requestType: RequestType.UPDATE_CONFIDENTIALITY,
      requestStatus: { $in: [RequestStatus.AWAITING_APPROVAL, RequestStatus.PENDING] },
    }),
    GraphService.getUserProps(ctx, oid, ["userType"]),
  ]);
  if (
    pendingConfidentiality?.dataSensitivityLevel === DataSensitivityLevel.CSI &&
    workspaceType === WorkspaceType.EXPLORATORY
  ) {
    return {
      passed: false,
      message: `Invalid workspaceType ${workspaceType} for a pending ${project.dataSensitivityLevel} data sensitivity level. Expected workspaceType ${WorkspaceType.SECURED}`,
    };
  }

  // if aiUsage is true and the user creating the workspace is Guest, ecbContact is needed
  if (aiUsage && user.userType === "Guest" && ecbContact == null) {
    return {
      passed: false,
      message: `Missing ecbContact when user creating the workspace is guest`,
    };
  }

  const ecbUserInProject = user.userType === "Member" || ecbContact;

  // if aiUsage is true and the user creating the workspace is Guest or there is an ecbContact in the project, aiUseCaseId is needed
  if (aiUsage && ecbUserInProject && !aiUseCaseId) {
    return {
      passed: false,
      message: `Missing aiUseCaseId when user is ECB or there is an ecbContact in the project`,
    };
  }

  // if aiUsage is true and there is no ecb user in project, gdpr, aiAct and businessRisk are needed
  if (aiUsage && !ecbUserInProject && (!gdpr || !aiAct || !businessRisk)) {
    return {
      passed: false,
      message: `Missing gdpr, aiAct or businessRisk when user is not ECB and there is no ecbContact in the project`,
    };
  }

  return { passed: true };
};
