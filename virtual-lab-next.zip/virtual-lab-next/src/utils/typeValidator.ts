import { Resource } from "../services/dbConnector/models/project";

export const isStringArray = (entry?: string[]) =>
  Array.isArray(entry) && entry.every((tag) => typeof tag === "string");

export const isResourceArray = (entry: Resource[]) =>
  Array.isArray(entry) &&
  entry.every(
    (resource) =>
      typeof resource === "object" &&
      // has exactly these properties
      Object.keys(resource).length === 2 &&
      // and they're both strings
      typeof resource.text === "string" &&
      typeof resource.url === "string" &&
      // with >0 length
      resource.text.length > 0 &&
      resource.url.length > 0,
  );

export const areStringArraysEqual = (arrayA: string[], arrayB: string[]) =>
  isStringArray(arrayA) &&
  isStringArray(arrayB) &&
  arrayA.length === arrayB.length &&
  arrayA.every((element) => arrayB.includes(element));
