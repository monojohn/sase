import { createLogger, format, Logger, transports } from "winston";
import { DATADOG_API_KEY, ENV, IS_JEST, IS_LOCAL } from "./config";

// docs available at https://docs.datadoghq.com/logs/log_collection/nodejs/?tab=winston30&tabs=winston30#agentless-logging
// decide which prefix to use based on env
const servicePrefix = `func-${ENV}`;
const env = ENV.toUpperCase();

let logger: Logger;

const CreateLogger = (appName: string) => {
  // reuse logger when possible
  if (logger) {
    return logger;
  }

  const logTransports = [];
  if (!IS_JEST) {
    if (IS_LOCAL) {
      // If we're running locally then log to console
      logTransports.push(new transports.Console());
    } else {
      const tags = {
        // mandatory tags, for more info follow the url below
        // https://tableau.ecb.de/#/views/DG-ISServiceCatalogue/DG-ISServiceCatalogue?:iid=1
        Service: `VirtualLab`,
        ServiceID: "S200320",
        CostCenter: "K340400",
        ServiceContact: "VIRTUALLAB-TEAM@ecb.europa.eu",
        ServiceOwner: "DGIS/PRS",
        Environment: env,
        env,
        CIID: "CI623049",

        // function specific tags
        function_name: `${servicePrefix}-${appName}`,
      };

      const httpTransportOptions = {
        host: "http-intake.logs.datadoghq.eu",
        path: `/api/v2/logs?dd-api-key=${DATADOG_API_KEY}&ddsource=nodejs&service=${encodeURIComponent(
          tags.Service,
        )}&ddtags=${Object.entries(tags)
          .map(([key, value]) => encodeURIComponent(`${key}:${value}`))
          .join()}`,

        // path: `/api/v2/logs?${new URLSearchParams(tags).toString()}`,
        ssl: true,
      };
      // otherwise log to DataDog
      logTransports.push(new transports.Http(httpTransportOptions));
    }
  }

  logger = createLogger({
    level: "info",
    exitOnError: false,
    format: format.json(),
    transports: logTransports,
    exceptionHandlers: [new transports.Console()],
  });

  return logger;
};

export default CreateLogger;
