import { Configuration } from "@azure/msal-node";
import { SPDefault } from "@pnp/nodejs";
import { SPFI, spfi } from "@pnp/sp";
import "@pnp/sp/clientside-pages/web";
import "@pnp/sp/folders/web";
import "@pnp/sp/files";
import "@pnp/sp/hubsites/index";
import "@pnp/sp/hubsites/web";
import "@pnp/sp/hubsites/site";
import "@pnp/sp/hubsites/types";
import "@pnp/sp/items/index";
import "@pnp/sp/lists/index";
import "@pnp/sp/lists/types";
import "@pnp/sp/lists/web";
import "@pnp/sp/navigation/index";
import "@pnp/sp/navigation/types";
import "@pnp/sp/navigation/web";
import "@pnp/sp/security/index"; // required for breakRoleInheritance
import "@pnp/sp/security/funcs"; // required for breakRoleInheritance
import "@pnp/sp/security/item"; // required for breakRoleInheritance
import "@pnp/sp/security/list"; // required for breakRoleInheritance
import "@pnp/sp/security/types"; // required for breakRoleInheritance
import "@pnp/sp/security/web"; // required for breakRoleInheritance
import "@pnp/sp/site-groups/web";
import "@pnp/sp/site-users/web";
import "@pnp/sp/sites/index";
import "@pnp/sp/sites/types";
import "@pnp/sp/webs/index";
import "@pnp/sp/webs/types";
import {
  AUTHORITY,
  AZURE_CLIENT_ID,
  AZURE_TENANT,
  HUBSITE_NAME,
  AZURE_PRIVATE_KEY,
  AZURE_THUMBPRINT,
} from "./config";

const createClient = (title: string) => {
  const config: Configuration = {
    auth: {
      authority: AUTHORITY,
      clientCertificate: {
        thumbprint: AZURE_THUMBPRINT,
        privateKey: AZURE_PRIVATE_KEY,
      },
      clientId: AZURE_CLIENT_ID,
      knownAuthorities: [AUTHORITY],
    },
  };

  return spfi().using(
    SPDefault({
      baseUrl: `https://${AZURE_TENANT}.sharepoint.com/sites/${title}`,
      msal: {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment -- type mismatch
        config: config as any,
        scopes: [`https://${AZURE_TENANT}.sharepoint.com/.default`],
      },
    }),
  );
};

const clientPool: Record<string, SPFI> = {};

const SpClient = {
  getClient(title = HUBSITE_NAME) {
    clientPool[title] ??= createClient(title);

    return clientPool[title];
  },
};

export default SpClient;
