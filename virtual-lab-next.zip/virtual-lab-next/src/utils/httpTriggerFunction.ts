import { Context, HttpMethod } from "@azure/functions";
import { HttpTrigger } from "../../@types/types";
import { withErrorLogging } from "../middleware/withErrorLogging";
import { withHttpLogging } from "../middleware/withHttpLogging";
import { withHttpSession } from "../middleware/withHttpSession";
import GraphService from "../services/graphService/graphService";

type RouteConfig = {
  allowNonEscb?: boolean;
};

type CallMap<D> = {
  [key in Partial<HttpMethod>]?: {
    handler: HttpTrigger<D>;
    config?: RouteConfig;
  };
};

type InnerRoute = <C>(handler: HttpTrigger<C>, config?: RouteConfig) => unknown;

type HttpTriggerFunc = {
  (ctx: Context): Promise<unknown>;
  get: InnerRoute;
  put: InnerRoute;
  head: InnerRoute;
  post: InnerRoute;
  patch: InnerRoute;
  delete: InnerRoute;
};

const addToMap = <A>(
  callMap: CallMap<A>,
  method: HttpMethod,
  handler: HttpTrigger<A>,
  config?: RouteConfig,
) => {
  if (callMap[method]) {
    throw new Error(`Attempted to re-map ${method} method `);
  }

  // eslint-disable-next-line no-param-reassign
  callMap[method] = { handler, config };
};

const mainHandler = (callMap: CallMap<unknown>) =>
  withErrorLogging(
    withHttpLogging(
      withHttpSession(async (ctx) => {
        const method = ctx.req.method ?? "TRACE";
        const props = callMap[method];

        if (!props?.handler) {
          const supportedMethods = Object.keys(callMap).join(", ");
          const message = `Unsupported method '${ctx.req.method}' for ${ctx.req.url}. Supported methods: ${supportedMethods}`;
          ctx.log(message);
          ctx.res = { status: 404, body: { message } };
          return;
        }

        // if non-escb users are not explicitly allowed
        if (!props.config?.allowNonEscb) {
          let userIsNonEscb: boolean;
          if (typeof ctx.permissions?.isUserNonEscb === "boolean") {
            userIsNonEscb = ctx.permissions.isUserNonEscb;
          } else {
            const userGroupsInfo = await GraphService.getUserGroupsInfo(ctx, ctx.session.upn);
            userIsNonEscb = userGroupsInfo.isNonEscb;
          }
          if (userIsNonEscb) {
            const message = "Non-ESCB accounts cannot take this action";
            ctx.log(message, { userIsNonEscb });
            ctx.res = { status: 403, body: { message } };
            return;
          }
        }

        return props.handler(ctx);
      }),
    ),
  );

const HttpTriggerFunction = () => {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-explicit-any -- temporary
  const callMap: CallMap<unknown> = {};
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-explicit-any
  const func: HttpTriggerFunc = mainHandler(callMap) as any;

  func.head = (handler, config) => {
    addToMap(callMap, "HEAD", handler, config);
  };

  func.get = (handler, config) => {
    addToMap(callMap, "GET", handler, config);
  };

  func.put = (handler, config) => {
    addToMap(callMap, "PUT", handler, config);
  };

  func.post = (handler, config) => {
    addToMap(callMap, "POST", handler, config);
  };

  func.patch = (handler, config) => {
    addToMap(callMap, "PATCH", handler, config);
  };

  func.delete = (handler, config) => {
    addToMap(callMap, "DELETE", handler, config);
  };

  return func;
};

export default HttpTriggerFunction;
