import moment from "moment";
import OpenAIUsageModel, { OpenAIUsage } from "../services/dbConnector/models/OpenAIUsage";
import { TokenConsumption } from "../features/export/types";
import OpenAILimitsModel from "../services/dbConnector/models/OpenAILimits";

export const findOpenAiUsage = (month: OpenAIUsage["month"]) =>
  OpenAIUsageModel.find({ month }).lean();

export const enrichOpenAiUsage = (metrics: OpenAIUsage[], timestamp: Date) =>
  metrics.map(
    ({ workspace, model, consumed, limits }) =>
      ({
        workspace,
        model,
        consumed,
        limits,
        remaining: limits - consumed,
        timestamp,
      }) satisfies TokenConsumption,
  );

const extractWorkspaceFromUrl = (url: string) => {
  const parsedUrl = new URL(url);
  const pathSegments = parsedUrl.href.split("/");
  const workspaceIndex = pathSegments.indexOf("workspaces") + 1;

  const workspace =
    workspaceIndex > 0 && workspaceIndex < pathSegments.length ? pathSegments[workspaceIndex] : "";
  return workspace;
};

export const getOpenAiUsage = async (workspaceUrl: string) => {
  const workspace = extractWorkspaceFromUrl(workspaceUrl);

  if (!workspace) {
    throw new Error(`Could not extract workspace from: ${workspaceUrl}`);
  }
  const month = moment.utc().format("YYYY-MM");
  const [usage, limits] = await Promise.all([
    OpenAIUsageModel.find({ month, workspace }, null, {
      lean: true,
      runValidators: true,
    }),
    OpenAILimitsModel.find({ workspace }),
  ]);

  return limits.map((limit) => {
    const usageFound = usage.find(({ model }) => model === limit.model);
    if (usageFound) {
      return {
        model: usageFound.model,
        consumed: usageFound.consumed,
        limit: usageFound.limits,
      };
    }
    return { model: limit.model, consumed: 0, limit: limit.limit };
  });
};
