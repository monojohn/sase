import { Context } from "@azure/functions";
import { Project } from "../services/dbConnector/models/project";
import GraphService from "../services/graphService/graphService";
import { wait } from "./helpers";

type Config = {
  timeToWait: number;
  iterations: number;
};

export const waitForProjectConstellation = async (
  ctx: Context,
  project: Project,
  { timeToWait = 5000, iterations = 500 } = {} as Config,
) => {
  const { name, ownersGroupId, membersGroupId, teamGroupId, members, owners } = project;
  const ownerCount = owners.length;
  const memberCount = members.length;
  const teamCount = 2 + ownerCount + memberCount;
  const allUsers = [...members, ...owners];

  ctx.log(`Waiting for project constellation of ${name}`, {
    ownerCount,
    memberCount,
    teamCount,
    timeToWait,
    iterations,
  });

  if (!ownersGroupId || !membersGroupId || !teamGroupId) {
    ctx.log(project);
    throw new Error(
      `Groups not defined, team: '${teamGroupId}' | owners: ${ownersGroupId} | members: ${membersGroupId}`,
    );
  }

  for (let index = 0; index < iterations; index++) {
    // eslint-disable-next-line block-scoped-var, no-var, vars-on-top
    const [teamGroup, ownerGroup, memberGroup] = await Promise.all([
      GraphService.getAllGroupUsers(ctx, teamGroupId, ["id"]),
      GraphService.getAllGroupUsers(ctx, ownersGroupId, ["id"]),
      GraphService.getAllGroupUsers(ctx, membersGroupId, ["id"]),
    ]);

    // expect all users to be in right groups
    const isTeamComplete = allUsers.every((oid) => teamGroup.find(({ id }) => id === oid));
    const isOwnersComplete = owners.every((oid) => ownerGroup.find(({ id }) => id === oid));
    const isMembersComplete = members.every((oid) => memberGroup.find(({ id }) => id === oid));

    ctx.log(
      `${name}: Attempt ${index} / ${iterations}: team ${teamGroup.length} / ${teamCount} | owners ${owners.length} / ${ownerCount} | members ${memberGroup.length} / ${memberCount}`,
      { isTeamComplete, isOwnersComplete, isMembersComplete },
    );

    if (isTeamComplete && isOwnersComplete && isMembersComplete) {
      ctx.log(`Groups have members after ${index} tries`);
      return true;
    }

    ctx.log({ isTeamComplete, isOwnersComplete, isMembersComplete });

    await wait(timeToWait / iterations);
  }

  // never got all members
  return false;
};
