import axios from "axios";

const axiosConfig = (token: string) => ({
  headers: {
    Authorization: `Bearer ${token}`,
  },
});

type SkypeToken = {
  tokens: { skypeToken: string };
};

const SkypeTokenService = {
  async connect(teamsToken: string) {
    const loginUrl = `https://authsvc.teams.microsoft.com/v1.0/authz`;

    const response = await axios.post<SkypeToken>(loginUrl, "", axiosConfig(teamsToken));

    return response.data.tokens.skypeToken;
  },
};

export default SkypeTokenService;
