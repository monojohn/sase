import { Context } from "@azure/functions";
import {
  AuthenticationResult,
  ConfidentialClientApplication,
  Configuration,
} from "@azure/msal-node";
import { Client } from "@microsoft/microsoft-graph-client";
import "cross-fetch";
import moment from "moment";
import { AUTHORITY, AZURE_CLIENT_ID, AZURE_PRIVATE_KEY, AZURE_THUMBPRINT } from "./config";
import { wait } from "./helpers";

const clientConfig: Configuration = {
  auth: {
    clientId: AZURE_CLIENT_ID,
    authority: AUTHORITY,
    knownAuthorities: [AUTHORITY],
    clientCertificate: {
      thumbprint: AZURE_THUMBPRINT,
      privateKey: AZURE_PRIVATE_KEY,
    },
  },
};

const clientCredentialRequest = {
  scopes: ["https://graph.microsoft.com/.default"],
};

let graphClient: Promise<Client>;
let token: AuthenticationResult;
const createConnection = async (context: Context) => {
  let lastError: Error | undefined;
  for (let index = 0; index < 5; index++) {
    try {
      const cca = new ConfidentialClientApplication(clientConfig);
      const newToken = await cca.acquireTokenByClientCredential(clientCredentialRequest);
      if (!newToken) {
        throw new Error(`Failed to acquire token`);
      }

      token = newToken;
      const { accessToken } = token;
      const client = Client.init({
        // defaultVersion: "v1.0",
        debugLogging: false,
        authProvider: (done) => {
          done(null, accessToken);
        },
      });
      return client;
    } catch (err) {
      lastError = err as Error;
      context.log(`Failed to create graph connection`, err);
      await wait(2);
    }
  }
  context.log("Failed to create graph connection");
  throw lastError ?? new Error("Failed to create graph connection");
};

const tokenIsExpired = (tokenExpirationDate?: Date | null) => {
  if (!tokenExpirationDate) {
    return true;
  }

  const now = moment.utc();
  const expire = moment.utc(tokenExpirationDate).subtract(5, "minutes");
  return now.isAfter(expire);
};

const GraphClient = {
  async get(context: Context) {
    if (
      // eslint-disable-next-line @typescript-eslint/no-misused-promises
      !graphClient || // NOSONAR
      (token && tokenIsExpired(token.expiresOn))
    ) {
      context.log(`Creating graph connection`);
      graphClient = createConnection(context);
    }
    return graphClient;
  },

  async getToken(context: Context) {
    await GraphClient.get(context);
    return token;
  },
};

export default GraphClient;
