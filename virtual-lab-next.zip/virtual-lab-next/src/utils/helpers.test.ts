import { Context } from "@azure/functions";
import { jest } from "@jest/globals";
import {
  generateRandomString,
  isConfidentialityHigher,
  isConfidentialityLabel,
  withRetry,
} from "./helpers";
import { ConfidentialityLevel } from "../services/dbConnector/enums";

const mockContext: Context = {
  log: jest.fn(),
} as any;

jest.setTimeout(60 * 10 * 1000);

describe(`${withRetry.name}`, () => {
  it("Returns the value when the fn succeeds", async () => {
    const value = await withRetry(async () => 5, mockContext, 5);
    expect(value).toEqual(5);
  });

  it("Throws when the fn fails", async () => {
    const error = "mock Error";
    let failed = false;

    try {
      await withRetry(
        async () => {
          throw new Error(error);
        },
        mockContext,
        1,
      );
      // eslint-disable-next-line sonarjs/no-ignored-exceptions
    } catch (err) {
      failed = true;
    }

    expect(failed).toEqual(true);
  });

  it("Succeeds after x tries", async () => {
    let counter = 0;

    const res = await withRetry(
      async () => {
        counter += 1;
        if (counter < 3) {
          throw new Error("Fake error");
        }
        return true;
      },
      mockContext,
      5,
    );

    expect(res).toBe(true);
  });
});

describe(`${isConfidentialityLabel.name}`, () => {
  it("Should return true for all confidentiality labels", async () => {
    for (const confidentialityLabel of Object.values(ConfidentialityLevel)) {
      expect(isConfidentialityLabel(confidentialityLabel)).toBe(true);
    }
  });

  it("Should return false for wrong confidentiality labels", async () => {
    expect(isConfidentialityLabel("random")).toBe(false);
    expect(isConfidentialityLabel(" ECB-CONFIDENTIAL ")).toBe(false);
  });
});

describe(`${isConfidentialityHigher.name}`, () => {
  it("Should disallow lower restricted confidentiality labels", async () => {
    expect(
      isConfidentialityHigher(ConfidentialityLevel.CONFIDENTIAL, ConfidentialityLevel.RESTRICTED),
    ).toBe(true);

    expect(
      isConfidentialityHigher(ConfidentialityLevel.UNRESTRICTED, ConfidentialityLevel.PUBLIC),
    ).toBe(true);
  });

  it("Should allow higher restricted confidentiality labels", async () => {
    expect(
      isConfidentialityHigher(ConfidentialityLevel.PUBLIC, ConfidentialityLevel.CONFIDENTIAL),
    ).toBe(false);

    expect(
      isConfidentialityHigher(ConfidentialityLevel.UNRESTRICTED, ConfidentialityLevel.RESTRICTED),
    ).toBe(false);
  });
});

describe(`${generateRandomString.name}`, () => {
  it("Should generate random string", async () => {
    const value = generateRandomString(5);
    expect(value.length).toEqual(5);
  });
});
