import { chunkArray } from "./chunkArray";

describe("chunk array", () => {
  it("Chunks empty array", () => {
    expect(chunkArray([])).toEqual([]);
  });

  it("Chunks small array", () => {
    expect(chunkArray([1, 2])).toEqual([[1, 2]]);
  });

  it("Chunks array into units", () => {
    expect(chunkArray([1, 2], 1)).toEqual([[1], [2]]);
  });
});
