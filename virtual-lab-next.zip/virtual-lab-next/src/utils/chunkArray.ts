export const chunkArray = <P>(arr: readonly P[], chunkSize = 10): readonly P[][] => {
  const output: P[][] = [];

  for (let i = 0; i < arr.length; i += chunkSize) {
    output.push(arr.slice(i, i + chunkSize));
  }

  return output;
};
