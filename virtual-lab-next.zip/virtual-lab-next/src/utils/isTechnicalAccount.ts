export const isTechnicalAccount = (displayName: string) => {
  if (typeof displayName !== "string") {
    return false;
  }

  const uppercaseName = displayName?.toLocaleUpperCase();

  return (
    uppercaseName.startsWith("ECBDEVENV-") ||
    uppercaseName.startsWith("ECBPROD-") ||
    uppercaseName.startsWith("AP-")
  );
};
