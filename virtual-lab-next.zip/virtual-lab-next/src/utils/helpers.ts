import { Context } from "@azure/functions";
import crypto from "node:crypto";
import { Model, FilterQuery } from "mongoose";
import moment from "moment";
import { ConfidentialityLevel } from "../services/dbConnector/enums";
import { RolesAndEntitlements } from "../services/dbConnector/models/project";
import { Identity, UserType } from "../services/graphService/types";
import {
  GROUP_MEMBERS_SUFFIX,
  GROUP_OWNERS_SUFFIX,
  GROUP_SEC_PREFIX,
  GROUP_TEAM_PREFIX,
  ORG_PREFIX,
} from "./config";

export const wait = (timeInSec = 5) =>
  new Promise((resolve) => {
    setTimeout(resolve, timeInSec * 1000);
  });

export const getMembersGroupName = (name: string) =>
  `${GROUP_SEC_PREFIX}${name.replaceAll(" ", "_").toLocaleUpperCase()}${GROUP_MEMBERS_SUFFIX}`;

export const getOwnersGroupName = (name: string) =>
  `${GROUP_SEC_PREFIX}${name.replaceAll(" ", "_").toLocaleUpperCase()}${GROUP_OWNERS_SUFFIX}`;

export const getTeamGroupName = (name: string) =>
  `${GROUP_TEAM_PREFIX}${name.replaceAll(" ", "_").toLocaleUpperCase()}`;

export const getOrgName = (projectName: string) =>
  `${ORG_PREFIX}${projectName.replaceAll(" ", "_").toLocaleUpperCase()}`;

export const getRolesAndEntitlementsNames = (rolesAndEntitlements: RolesAndEntitlements[]) =>
  rolesAndEntitlements.map(({ roles, entitlements, iamRoles }) =>
    [
      ...roles.map(({ roleName }) => roleName),
      ...entitlements,
      ...iamRoles.map(({ roleName }) => roleName),
    ].join(" or "),
  );
export const getEmailOfUser = ({
  identities,
  otherMails,
  mail,
}: {
  identities: Identity[];
  otherMails: string[];
  mail: string;
}) => {
  if (identities.some(({ issuer }) => issuer === "ExternalAzureAD")) {
    return mail;
  }
  return otherMails?.[0] ?? mail;
};

/**
 * Strips invalid characters.
 * @param text
 * @returns the clean string
 */
export const stripInvalidChars = (text: string) =>
  text
    // Remove already escaped special characters
    .replaceAll(String.raw`\t`, "")
    .replaceAll(String.raw`\n`, "")
    .replaceAll(String.raw`\r`, "")
    // Remove non-alphanumeric/space/hyphen characters
    .replace(/[^\w\s-]+/g, "") // NOSONAR wants replaceAll
    // Remove some other
    .replace(/\p{C}/gu, ""); // NOSONAR wants replaceAll

/** Smaller index is the highest confidentiality */
const confidentialityLevelsRankOrder: ConfidentialityLevel[] = [
  ConfidentialityLevel.SECRET,
  ConfidentialityLevel.CONFIDENTIAL,
  ConfidentialityLevel.RESTRICTED,
  ConfidentialityLevel.UNRESTRICTED,
  ConfidentialityLevel.PUBLIC,
] as const;

export const isConfidentialityLabel = (
  maybeConfidentialityLabel?: string,
): maybeConfidentialityLabel is ConfidentialityLevel =>
  Object.values(ConfidentialityLevel).includes(maybeConfidentialityLabel as ConfidentialityLevel);

/**
 * Evaluate if primary confidentiality level is higher than secondary confidentiality level
 * @param primaryConfidentialityLevel primary confidentiality level to compare
 * @param secondaryConfidentialityLevel secondary confidentiality level to compare
 * @returns `boolean`
 */
export const isConfidentialityHigher = (
  primaryConfidentialityLevel: ConfidentialityLevel,
  secondaryConfidentialityLevel: ConfidentialityLevel,
) =>
  confidentialityLevelsRankOrder.indexOf(primaryConfidentialityLevel) <
  confidentialityLevelsRankOrder.indexOf(secondaryConfidentialityLevel);

/**
 * Check if manager approval is required for a given confidentiality level and the type of user (ECB or nonECB)
 * @param confidentialityLevel confidentiality level
 * @param ownerUserType user type of owner that creates the project
 * @returns `boolean`
 */
export const requiresManagerApproval = (
  confidentialityLevel: ConfidentialityLevel,
  ownerUserType: UserType,
) =>
  isConfidentialityHigher(confidentialityLevel, ConfidentialityLevel.UNRESTRICTED) &&
  ownerUserType === "Member";

/**
 * Retries an async function with a delay in between
 *
 * @param fn
 * @param ctx
 * @param maxRetries how many call to make in total. A value of 1 means 2 max calls
 * @param delayInSeconds how long to wait between failures
 * @returns
 */
export const withRetry = async <T>(
  fn: () => Promise<T>,
  ctx: Context,
  maxRetries: number,
  delayInSeconds = 3,
): Promise<T> => {
  let error: Error | undefined;

  for (let index = 0; index <= maxRetries; index++) {
    try {
      // NOTE: must be awaited to be caught by the try-catch
      return await fn();
    } catch (err: unknown) {
      ctx.log(
        `Retrying request ${index} of ${maxRetries} failed with error: ${JSON.stringify(err, null, 2)}`,
      );
      error = err as Error;
    }
    await wait(delayInSeconds);
  }

  throw error ?? new Error("Retrying request failed", { cause: error });
};

export const generateRandomString = (length: number) =>
  crypto.getRandomValues(new Uint32Array(1))[0].toString(36).substring(0, length);

export const fetchCollectionInChunks = async <T>(
  model: Model<T>,
  filter: FilterQuery<T>,
  chunkSize = 5000,
): Promise<T[]> => {
  const allRecords: T[] = [];
  let done = false;
  let lastId = null;

  do {
    // build query based on lastId
    const query: FilterQuery<T> = {
      ...filter,
      ...(lastId ? { _id: { $gt: lastId } } : {}),
    };

    // get chunk of data
    await wait(1);
    const records = await model.find(query).sort({ _id: 1 }).limit(chunkSize).exec();

    // push retrieved records
    allRecords.push(...records);

    // in case less records were retrieved than the chunkSize, we are at the end
    if (records.length < chunkSize) {
      done = true;
    } else {
      // otherwise, save new lastId
      lastId = records.at(-1)!._id;
    }
  } while (!done);

  return allRecords;
};

export const startOfLastMonth = () =>
  moment.utc().subtract(1, "month").startOf("month").startOf("day");
export const endOfLastMonth = () =>
  moment.utc().subtract(1, "month").endOf("month").hour(23).minute(59).second(59).millisecond(999);

export const arraysAreEquivalent = (arr1: string[], arr2: string[]) =>
  arr1.length === arr2.length && arr1.every((value) => arr2.includes(value));
