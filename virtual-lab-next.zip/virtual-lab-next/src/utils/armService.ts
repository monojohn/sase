import { Context } from "@azure/functions";
import { AccessToken, ClientCertificateCredential } from "@azure/identity";
import moment from "moment";
import { AZURE_TENANT_ID, INFRA_CERTIFICATE, INFRA_CLIENT_ID } from "./config";

const scope = "https://management.azure.com/.default";

const tokenIsExpired = (tokenExpire?: number) => {
  if (!tokenExpire) {
    return true;
  }

  const now = moment.utc();
  const expire = moment.utc(tokenExpire).subtract(5, "minutes");
  return now.isAfter(expire);
};

const getArmClient = () =>
  new ClientCertificateCredential(AZURE_TENANT_ID, INFRA_CLIENT_ID, {
    certificate: INFRA_CERTIFICATE,
  });

/**
 * Connects to Azure API and generates auth token. Used for Azure Resource Manager direct API calls
 *
 * @function
 * @name azureApiConnection
 * @public
 *
 * @returns {string} Azure token
 *
 */
let armClient: Promise<AccessToken>;
let armToken: AccessToken;
const azureApiConnection = async () => {
  const client = getArmClient();
  const newToken = await client.getToken(scope);
  if (!newToken) {
    throw new Error(`Failed to fetch ARM token`);
  }
  armToken = newToken;
  return armToken;
};

const ArmService = {
  get(context: Context) {
    if (
      // eslint-disable-next-line @typescript-eslint/no-misused-promises
      !armClient || // NOSONAR
      tokenIsExpired(armToken?.expiresOnTimestamp)
    ) {
      context.log(`Creating ARM connection`);
      armClient = azureApiConnection();
    } else {
      context.log(`Reusing ARM connection`);
    }

    return armClient;
  },
  getArmClient,
};

export default ArmService;
