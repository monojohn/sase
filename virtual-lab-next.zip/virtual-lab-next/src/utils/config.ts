//  named exports for code auto complete
import "dotenv/config";

export const AZURE_PRIVATE_KEY =
  process.env.AZURE_PRIVATE_KEY?.replaceAll(String.raw`\n`, "\n") ?? "";
export const INFRA_CERTIFICATE =
  process.env.INFRA_CERTIFICATE?.replaceAll(String.raw`\n`, "\n") ?? "";
type Environment = "test" | "stg" | "prod";

export const {
  IS_JEST = "",
  IS_LOCAL,
  AUTHORITY = "",
  AZURE_TENANT,
  AZURE_CR_RESOURCE_GROUP = "",
  AZURE_CLIENT_ID = "",
  AZURE_THUMBPRINT = "",
  AZURE_RESOURCE_GROUP = "",
  CONTRIBUTOR_ROLE_ID = "",
  CUSTOM_MEMBER_ROLE_ID = "",
  STORAGE_ACCOUNT,
  AZURE_TENANT_ID = "",
  TEMPLATE_QUEUE_NAME,
  IGAM_KEY = "",
  IGAM_CERT = "",
  IGAM_ENDPOINT = "",
  // Blob storage
  INFRA_CLIENT_ID = "",

  // used for group creation
  GROUP_SERVICE,
  GROUP_ACCOUNT_TYPE,
  VL_ADMINS_GROUP_ID = "",
  HUBSITE_ID = "",
  HUBSITE_NAME = "",

  // Flowmailer props
  FLOWMAILER_ACCOUNT_ID = "",
  FLOWMAILER_CLIENT_ID = "",
  FLOWMAILER_CLIENT_SECRET = "",
  FLOWMAILER_SMTP_USER = "",
  FLOWMAILER_SMTP_PASS = "",
  FLOWMAILER_EMAIL_SENDER = "",
  FLOWMAILER_EMAIL_REPLY_TO = "",
  DATADOG_API_KEY,
  DATADOG_APP_KEY,
  SUBSCRIPTION_ID = "",
  DEVOPS_TOKEN = "",
  GIT_REPOSITORY_TOKEN = "",
  ML_BUDGET_EMAIL = "",
  KUBECONFIG = "",
  SLACK_WEBHOOK_URL = "",
  DISABLE_SLACK = "",
  MONGO_URL = "",

  IAM_CLIENT_ID = "",
  IAM_CLIENT_SECRET = "",

  SONAR_TOKEN = "",
  SONAR_HOST_URL = "",

  DEVO_SECRET_ACCESS_KEY = "",
} = process.env;

export const ENV = process.env.ENVIRONMENT as Environment;
export const IS_PROD = ENV === "prod";

export const IGAM_BASE_URL = `https://${IGAM_ENDPOINT}/oim-bulk-exec-ui/rest/jersey/bulk/services/oauth`;
export const IGAM_FINGERPRINT = "_F1Pb-oy-wkAgQx3OFzvMEXKfdI";

export const ML_PROJECT_SPACE_PAGE_URL = "SitePages/ML-Project-Space.aspx";
export const FILES_PAGE_URL = "SitePages/Files.aspx";

export const AZURE_LOCATION = "westeurope";

// Group naming conventions
export const GROUP_MEMBERS_SUFFIX = "-Members";
export const GROUP_OWNERS_SUFFIX = "-Owners";

export const BACKUP_PREFIX = IS_JEST ? "MOCK" : ""; // prefix to add to backed up files, used for integration tests
export const BACKUP_PERSISTENCY = 60; // number of days to keep the backups for

export const BACKUP_STORAGE_CONTAINER = "backups"; // name of container inside storage account

export const RESOURCE_GROUP_DNS = "vwan";
export const VL_INBOX_GROUP = "35d7d9e2-557c-4c19-be88-0d658877cf87"; // group id for team users with access to inbox
export const VL_ORG = "CI587574"; // org id for VL
export const VL_TEAM_ORG = "Virtual Lab Custom 1(CI587574)"; // used for testing approvals in IGAM

const config = {
  test: {
    VL_TEAM_GROUP_ID: "4e6fc169-54b6-402e-aa2d-30d599378089",
    VL_MEMBERS_GROUP_ID: "047afb47-d2dd-40ec-b52a-4691cd15e62b",
    VL_GUESTS_GROUP_ID: "2a2a818a-86af-44f0-aa93-675ac2ec6c5e",
    NON_ESCB_GUEST_GROUP: "56e24ac9-f185-4e8d-b275-f5b322e4f78f",
    ML_VNET_NAME: "vl-spoke-mlpool",
    ML_NETWORK_RG: "network-mlpool",
    ML_COMPUTE_SUBNET: "vl-spoke-mlpool-cmp1",
    ML_SUBNET_NAME: "vl-spoke-mlpool-wrk",
    ML_SUBNET_JOIN_ROLE: "a9f28177-4608-bb27-ccda-e897be86e0b2",
    SUBSCRIPTION_ID_DNS: "eb1d8aa2-d030-4161-ac8a-2ea1fa669ee8",
    STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID: "ebd1cb4f-1873-454f-adba-8bc92ce41cfb",
    VLB_AZURE_APP_ID: "1ad26fed-d49b-493d-820d-e4f05f6e7537",
    STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME: "id-virtuallab-keyvaults",
    AKS_ML: "aks-test-network",
    BACKUP_STORAGE_ACCOUNT: "sttstmongobackup",
    GROUP_SEC_PREFIX: "ECBDEVENV-VLB-MSG-SEC-",
    ORG_PREFIX: "DEV_ORG-",
    APP_INSTANCE: "AADtest",
    GROUP_TEAM_PREFIX: "TEAM_VLB-",
    UI_DOMAIN: "https://t-virtuallab.escb.eu",
    VL_SITE_ID: "afe671cf-cc02-4e97-9ffb-69336ddf879f",
    VL_WEB_ID: "d072b11d-3834-4fe9-a81a-d82048e519ea",
    SOFA_HOST: "https://l-gitlab.sofa.dev",
    SOFA_NAMESPACE_ID: 436,
    IAM_AUTH_URL: "https://t-iamfed.wam.escb.eu",
    IAM_BASE_URL: "https://t-esb-api-gw.fr.escb.eu/gateway/ICT_IAM-Governance/1.1",
    IAM_SPLIT_TERM: "_t-iam",
  },
  stg: {
    VL_TEAM_GROUP_ID: "e565a689-2af8-49e3-9748-3c9c09de90ad",
    VL_MEMBERS_GROUP_ID: "594d3891-0949-424e-b138-f102390954f9",
    VL_GUESTS_GROUP_ID: "6fd81c80-6d8c-421d-a7a0-95cbd26d2da9",
    NON_ESCB_GUEST_GROUP: "0fe56370-60b9-496b-bf84-ad0e6d76dc2c",
    ML_VNET_NAME: "vl-stg-spoke-mlpool",
    ML_NETWORK_RG: "network-mlpool",
    ML_COMPUTE_SUBNET: "vl-stg-spoke-mlpool-cmp1",
    ML_SUBNET_NAME: "vl-stg-spoke-mlpool-wrk",
    ML_SUBNET_JOIN_ROLE: "1e9653b6-294e-f27a-0a99-3233e0d45001",
    SUBSCRIPTION_ID_DNS: "95cea28e-3aa1-408e-9cab-cf70d17da5b6",
    STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID: "a3fa8233-9140-4f86-88fd-b666fe9012c2",
    VLB_AZURE_APP_ID: "d2b4dca5-69b7-4e7b-9f46-db855dbb6760",
    STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME: "id-virtuallab-keyvaults-stg",
    AKS_ML: "aks-stg-ml",
    BACKUP_STORAGE_ACCOUNT: "ststgcosmosbackup",
    GROUP_SEC_PREFIX: "ECBSTG-VLB-MSG-SEC-",
    ORG_PREFIX: "STG_ORG-",
    APP_INSTANCE: "AADproduction",
    GROUP_TEAM_PREFIX: "TEAM_VLB-STG-",
    UI_DOMAIN: "https://a-virtuallab.escb.eu",
    VL_SITE_ID: "b39087f1-f34d-4cca-a8eb-b91dfc3441a5",
    VL_WEB_ID: "354e5da4-1464-4984-b1c1-032afb5a8dbc",
    SOFA_HOST: "https://gitlab.sofa.dev",
    SOFA_NAMESPACE_ID: 37403,
    IAM_AUTH_URL: "https://iamfed.wam.escb.eu",
    IAM_BASE_URL: "https://esb-api-gw.fr.escb.eu/gateway/ICT_IAM-Governance/1.1",
    IAM_SPLIT_TERM: "_iam",
  },
  prod: {
    VL_TEAM_GROUP_ID: "e565a689-2af8-49e3-9748-3c9c09de90ad",
    VL_MEMBERS_GROUP_ID: "8d6d8d4e-57b4-415e-b46d-723a659d5dfe",
    VL_GUESTS_GROUP_ID: "d71e3689-9bfa-40fc-9821-344dcfe14a03",
    NON_ESCB_GUEST_GROUP: "5f5e2240-62ca-4c12-940a-7d06768894fd",
    ML_VNET_NAME: "vl-spoke-mlpool",
    ML_NETWORK_RG: "network-mlpool",
    ML_COMPUTE_SUBNET: "vl-spoke-mlpool-cmp1",
    ML_SUBNET_NAME: "vl-spoke-mlpool-wrk",
    ML_SUBNET_JOIN_ROLE: "1e9653b6-294e-f27a-0a99-3233e0d45001",
    SUBSCRIPTION_ID_DNS: "95cea28e-3aa1-408e-9cab-cf70d17da5b6",
    STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID: "d0cbab13-4521-4cbb-aebc-15f3345b1be2",
    VLB_AZURE_APP_ID: "8861ca83-52ad-49eb-af47-cce6bcd5ba75",
    STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME: "id-virtuallab-keyvaults",
    AKS_ML: "aks-prod-ml",
    BACKUP_STORAGE_ACCOUNT: "stprdcosmosbackup",
    GROUP_SEC_PREFIX: "ECBPROD-VLB-MSG-SEC-",
    ORG_PREFIX: "ORG-",
    APP_INSTANCE: "AADproduction",
    GROUP_TEAM_PREFIX: "TEAM_VLB-",
    UI_DOMAIN: "https://virtuallab.escb.eu",
    VL_SITE_ID: "a910b217-d75a-456c-bd89-8f55f3036889",
    VL_WEB_ID: "0dd76b07-2f35-4a46-becb-3251faae4bc8",
    SOFA_HOST: "https://gitlab.sofa.dev",
    SOFA_NAMESPACE_ID: 28777,
    IAM_AUTH_URL: "https://iamfed.wam.escb.eu",
    IAM_BASE_URL: "https://esb-api-gw.fr.escb.eu/gateway/ICT_IAM-Governance/1.1",
    IAM_SPLIT_TERM: "_iam",
  },
};

const currentConfig = config[ENV];
export const {
  VL_TEAM_GROUP_ID,
  VL_MEMBERS_GROUP_ID,
  VL_GUESTS_GROUP_ID,
  NON_ESCB_GUEST_GROUP,
  ML_VNET_NAME,
  ML_NETWORK_RG,
  ML_COMPUTE_SUBNET,
  ML_SUBNET_NAME,
  ML_SUBNET_JOIN_ROLE,
  SUBSCRIPTION_ID_DNS,
  STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID,
  VLB_AZURE_APP_ID,
  STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME,
  AKS_ML,
  BACKUP_STORAGE_ACCOUNT,
  GROUP_SEC_PREFIX,
  ORG_PREFIX,
  APP_INSTANCE,
  GROUP_TEAM_PREFIX,
  UI_DOMAIN,
  VL_SITE_ID,
  VL_WEB_ID,
  SOFA_HOST,
  SOFA_NAMESPACE_ID,
  IAM_AUTH_URL,
  IAM_BASE_URL,
  IAM_SPLIT_TERM,
} = currentConfig;

const requiredVars = ["AZURE_TENANT", "AZURE_CLIENT_ID", "STORAGE_ACCOUNT", "DATADOG_API_KEY"];

const checkEnvVars = (envVars: string[]) => {
  const errors: string[] = [];
  // eslint-disable-next-line no-plusplus
  for (let index = 0; index < envVars.length; index++) {
    const key = envVars[index];
    const value = process.env[key];

    if (!value) {
      errors.push(`${key}: ${value}`);
    }
  }

  if (errors.length > 0) {
    throw new Error(`Missing env vars:\n${errors.join("\n")}`);
  }
};

// DEVO
export const DEVO_ROLE_ARN = "arn:aws:iam::185476615772:role/ECB_AWS_LOCAL_A2A_VIRTUALLAB_PRD";
export const DEVO_ACCESS_KEY_ID = "AKIAROKG4ZBHWVPKX2NN";
export const DEVO_BUCKET = "devo-lab-prj-vlab-atsn67j43dctnqmh4dyekwird7st4euc1a-s3alias";
export const DEVO_REGION = "eu-central-1";
export const DEVO_ENDPOINT =
  "https://vpce-075309ec02582e242-6g7eeejk.sts.eu-central-1.vpce.amazonaws.com";

if (IS_LOCAL) {
  checkEnvVars(requiredVars);
}
