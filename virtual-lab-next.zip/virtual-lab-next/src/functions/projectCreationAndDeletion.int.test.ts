import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../jest/helpers";
import ProjectModel from "../services/dbConnector/models/projectModel";
import GraphService from "../services/graphService/graphService";
import { waitForProjectConstellation } from "../utils/waitForProjectConstellation";
import { mainHandler as projectCreationHandler } from "./virtuallab/project-creation-queue/project-creation-queue";
import { mainHandler as deletionHandler } from "./virtuallab/project-deletion-queue/project-deletion-queue";
import { wait } from "../utils/helpers";
import { ProjectCreationType } from "../services/projectService/enums";
import { Project } from "../services/dbConnector/models/project";

jest.setTimeout(60 * 20 * 1000);

const ownerOid = global.robertaOid;

describe("Project creation and deletion", () => {
  let testProject: Project;

  describe("Project creation", () => {
    const ctx = getCtx({ name: "Project creation" });

    it("Creates project", async () => {
      testProject = await createTestProject({
        name: `Project creation test ${Date.now()}`,
        owners: [ownerOid],
      });

      await projectCreationHandler(ctx, {
        owner: ownerOid,
        project: testProject,
        projectCreationType: ProjectCreationType.NO_APPROVAL,
      });

      // get updated project
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj).not.toBeNull();

      const { ownersGroupId, membersGroupId, teamGroupId } = proj!;

      // expect groups to exist
      expect(ownersGroupId.length).toBe(36);
      expect(membersGroupId.length).toBe(36);
      expect(teamGroupId.length).toBe(36);

      const result = await waitForProjectConstellation(ctx, proj!);
      expect(result).toBe(true);
    });
  });

  describe("Project deletion", () => {
    const ctx = getCtx({ name: "Project deletion" });

    it("Deletes project", async () => {
      await deletionHandler(ctx, { pid: testProject._id.toString(), oid: ownerOid });

      // expect project to be gone from DB
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj).toBeNull();

      // wait for Azure to catch up
      await wait(60 * 5);

      // expect entitlements to be gone
      const groups = await GraphService.searchGroups(ctx, testProject.teamGroupName);
      expect(groups.length).toBe(0);
    });
  });
});
