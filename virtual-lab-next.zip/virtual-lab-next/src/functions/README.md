# /src/functions

This folder holds the different Azure Functions instances we have:

1. virtuallab
2. virtuallab-cron

Our build process expects a 1:1 folder to function map, meaning we only need to add the code here (after deploying the Azure Function via Terraform)

Each of the HTTP functions here has a different endpoint, so it's not recommended to add more.

## src/function/\<function-name\>

Folders inside `/src/function/<name>` represent endpoints, for example, `src/functions/virtuallab/data-governance` is mapped to an endpoint via the `function.json` file inside, which (simplified), is:

```json
{
  "route": "v3/data-governance/{pid?}",
  "methods": ["get", "post"]
},
```

## Creating a new endpoint

As a practical example, here's how you'd create and deploy a new endpoint which sends back the unix timestamp in JSON format.

1. Copy-paste the `src/functions/virtuallab/data-governance` or any other existing endpoint.
2. Rename the `data-governance copy` folder to `timestamp`
3. Rename the `data-governance.ts` file to `timestamp.ts`

```
NOTE: The main entry file for the function MUST match the folder name, otherwise the build will throw an error.
```

4. update the `function.json` file and remove the `"post"` option and changing the URL to `v1/timestamp`
5. Update the `timestamp.ts` file to the following:

```typescript
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

/**
 * Get system time
 */
app.get(async (ctx) => {
  ctx.res = {
    body: Date.now(),
  };
});

export const mainHandler = app;
```

6. Write a test for this endpoint by changing the `data-governance.test.ts` to the following:

```typescript
import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./timestamp";

const ctx = getCtx({ name: "Timestamp" });

describe("Timestamp", () => {
  beforeAll(async () => {
    jest
      .spyOn(GraphService, "getUserGroups")
      .mockImplementation(async () => [{ id: VL_MEMBERS_GROUP_ID }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroups").mockRestore();
  });

  describe("GET timestamp", () => {
    it("Receives a timestamp", async () => {
      await mainHandler(ctx);
      expect(typeof ctx.res.body).toBe("number");
    });
  });
});
```

7. Run the test with

> `yarn test --testRegex timestamp.test.ts`

8. At this stage, it's time to deploy.
9. Create your branch, push and notice the pipeline.
10. Use the "Deploy all" button to deploy all functions

![deploy-image](../../docs/images/deploy.png)

> NOTE: You could deploy the `virtuallab` function only but since we often touch code which impacts other functions, it's recommended to deploy all every time.

11. As a last step, head over to virtuallab UI, open your favorite dev tools, copy one of the existing BE calls (as NodeJs), change the URL and have a test!
