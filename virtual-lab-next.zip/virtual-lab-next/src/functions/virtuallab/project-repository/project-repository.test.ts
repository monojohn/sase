import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import { mainHandler } from "./project-repository";

describe("Project repository", () => {
  const ctx = getCtx({ name: "Project repository" });
  const mock = jest.fn(async () => "repositoryUrl");

  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(GraphService, "getGroupOwnersEmails").mockImplementation(async () => ["mail1"]);
    jest.spyOn(GraphService, "getGroupMembersEmails").mockImplementation(async () => ["mail2"]);
    jest.spyOn(RepositoryService, "createRepositoryGroup").mockImplementation(mock);
    jest.spyOn(RepositoryService, "addUser").mockImplementation(async () => ({}) as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupOwnersEmails").mockRestore();
    jest.spyOn(GraphService, "getGroupMembersEmails").mockRestore();
    jest.spyOn(RepositoryService, "createRepositoryGroup").mockRestore();
    jest.spyOn(RepositoryService, "addUser").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject({
      owners: [ctx.authOid],
      repositoryUrl: "repositoryUrl",
    });
    ctx.req.params.pid = testProject._id;
  });
  describe("GET project repository", () => {
    it("Returns project repository", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual({
        repositoryUrl: testProject.repositoryUrl,
      });
    });
  });

  describe("POST project repository", () => {
    beforeAll(() => {
      ctx.req.method = "POST";
    });

    it("Returns early when a repo already exists", async () => {
      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined);
      expect(mock).toHaveBeenCalledTimes(0);
    });

    it("Creates repo", async () => {
      testProject = await createTestProject({
        owners: [ctx.authOid],
      });
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined);
      expect(mock).toHaveBeenCalledTimes(1);
    });
  });

  describe("Delete project repository", () => {
    beforeAll(() => {
      ctx.req.method = "DELETE";
    });

    it("Deletes repo", async () => {
      testProject = await createTestProject({
        owners: [ctx.authOid],
        repositoryUrl: "repositoryUrl",
      });
      ctx.req.params.pid = testProject._id;
      const mockDeletion = jest.fn(async () => undefined);
      jest
        .spyOn(RepositoryService, "markRepositoryGroupForDeletion")
        .mockImplementationOnce(mockDeletion);

      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined);
      expect(mockDeletion).toHaveBeenCalledTimes(1);
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.repositoryUrl).toBeFalsy();
    });
  });
});
