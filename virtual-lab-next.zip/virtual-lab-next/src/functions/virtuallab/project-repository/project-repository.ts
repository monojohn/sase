import {
  sendRepositoryCreatedNotifications,
  sendRepositoryDeletedNotifications,
} from "../../../features/projectRepository/repositoryNotifications";
import { deleteRepository } from "../../../features/repositoryDeletion";
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectService from "../../../services/projectService/projectService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = {
        body: {
          repositoryUrl: project.repositoryUrl,
        },
      };
    }),
  ),
);

type PostProps = {
  body: Partial<Project>;
  params: { pid: string };
};

app.post<PostProps>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;

        if (project.repositoryUrl) {
          return; // end early when repo exists
        }

        // create repo
        const repositoryUrl = await ProjectService.createSofaRepository(ctx, project);

        ctx.log("Notifying team");
        await sendRepositoryCreatedNotifications(ctx, project, repositoryUrl, session);
      }, ActionType.CREATE_REPOSITORY),
    ),
  ),
);

app.delete<PostProps>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { project, permissions } = ctx;

        ctx.log(`Deleting repository of project ${project.name}`, { permissions });

        await deleteRepository(ctx, project);

        ctx.log("Notifying team");
        await sendRepositoryDeletedNotifications(
          ctx,
          { id: project._id, name: project.name, teamGroupId: project.teamGroupId },
          ctx.session,
        );
      }, ActionType.DELETE_REPOSITORY),
    ),
  ),
);

export const mainHandler = app;
