import { CreateProjectProps } from "../../../features/projectCreation/types";
import { ActionType } from "../../../features/userActions/enums";
import { updateActionPid } from "../../../features/userActions/userActions";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withHttpParamCheck } from "../../../middleware/withHttpParamCheck";
import { withAdminBlock } from "../../../middleware/withPermissions";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  ProjectStatus,
} from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { ProjectCreationType } from "../../../services/projectService/enums";
import QueueService, { QUEUE } from "../../../services/queueService";
import { requiresManagerApproval } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

export type CreateProject = {
  name: string;
  tags?: string[];
  owners: string[];
  members: string[];
  description: string;
  dataSensitivityLevel: DataSensitivityLevel;
  accessibilityLevel: AccessibilityLevel;
  confidentialityLevel: ConfidentialityLevel;
  icon: string;
  LLM?: string;
};

const requiredPostParams: (keyof CreateProject)[] = [
  "dataSensitivityLevel",
  "accessibilityLevel",
  "confidentialityLevel",
  "description",
  "name",
];

/**
 * [Project creation step 1] an entry is created in the database and a message is added to the queue to handle the creation
 * Recent changes: projectCreationType tells us if the project needs approval or can be fully created
 */
app.post<{ body: CreateProject }>(
  withAdminBlock(
    withActionLogging(
      withHttpParamCheck(async (ctx) => {
        const { oid } = ctx.session;
        const body = ctx.req.body as CreateProject;
        const { tags = [], icon: iconName } = body;

        const projectName = body.name.trim();
        const existingProject = await ProjectModel.exists({ name: projectName });

        // check if name already exists
        if (existingProject) {
          const message = `A project named ${projectName} already exists`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        const owner = await GraphService.getUserProps(ctx, oid, ["userType"]);
        const requiresApproval = requiresManagerApproval(body.confidentialityLevel, owner.userType);

        const data: Partial<Project> = {
          name: projectName,
          description: body.description,
          dataSensitivityLevel: body.dataSensitivityLevel,
          accessibilityLevel: body.accessibilityLevel,
          confidentialityLevel: body.confidentialityLevel,
          owners: [oid], // other owners must accept invite
          icon: iconName,
          tags,
          status: requiresApproval ? ProjectStatus.AwaitingApproval : ProjectStatus.BeingCreated,
        };

        ctx.log("Creating project in DB", data);
        const project = await ProjectModel.create(data);
        await updateActionPid(ctx, project._id);

        const message: CreateProjectProps = {
          owner: oid,
          project,
          projectCreationType: requiresApproval
            ? ProjectCreationType.APPROVAL_REQUIRED
            : ProjectCreationType.NO_APPROVAL,
        };

        // add item to queue
        ctx.log(`Adding message to project creation queue`, message);
        await QueueService.put(QUEUE.CREATE_PROJECT, message);
      }, requiredPostParams),
      ActionType.CREATE_PROJECT,
    ),
  ),
);

export const mainHandler = app;
