import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
} from "../../../services/dbConnector/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import QueueService from "../../../services/queueService";
import { getMembersGroupName, getOwnersGroupName, getTeamGroupName } from "../../../utils/helpers";
import { CreateProject, mainHandler } from "./project-creation";

const ctx = getCtx({ method: "POST", name: "Project creation" });

describe("Project creation", () => {
  beforeAll(() => {
    jest.spyOn(QueueService, "put").mockImplementation(async () => void 0);
    jest
      .spyOn(GraphService, "getUserGroupsInfo")
      .mockImplementation(async () => ({ isAdmin: false, isNonEscb: false, isVlUser: true }));
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(async () => ({ userType: "Guest" }) as any);
  });

  afterAll(() => {
    jest.spyOn(QueueService, "put").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
  });

  describe("Create project", () => {
    beforeEach(() => {
      ctx.res = undefined;
    });

    it("Throws missing params error when all are missing", async () => {
      ctx.req.body = undefined;
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Throws missing params error when just one is missing", async () => {
      const name = `UT project ${Date.now()}`;
      const tags = ["tag1"];
      const owners = [ctx.authOid];
      ctx.req.body = {
        name,
        tags,
        owners,
        members: [],
        icon: "icon",
        description: "Unit test project",
        dataSensitivityLevel: DataSensitivityLevel.No,
        accessibilityLevel: AccessibilityLevel.Public,
      };

      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual("Missing parameter(s):\nconfidentialityLevel");
    });

    it("Creates a new project", async () => {
      const name = `UT project ${Date.now()}`;
      const tags = ["tag1"];
      const owners = [ctx.authOid];
      ctx.req.body = {
        name,
        tags,
        owners,
        members: [],
        icon: "icon",
        description: "Unit test project",
        dataSensitivityLevel: DataSensitivityLevel.No,
        accessibilityLevel: AccessibilityLevel.Public,
        confidentialityLevel: ConfidentialityLevel.PUBLIC,
      } as CreateProject;

      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined);

      // a project was added to the DB with the correct values
      const project = await ProjectModel.findOne({ name }).lean();

      // test model save hooks injection
      expect(project?.teamGroupName).toBe(getTeamGroupName(name));
      expect(project?.ownersGroupName).toBe(getOwnersGroupName(name));
      expect(project?.membersGroupName).toBe(getMembersGroupName(name));
    });
  });
});
