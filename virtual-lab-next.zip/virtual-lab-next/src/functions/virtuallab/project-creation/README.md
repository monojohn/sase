# project-creation

The project creation process is documented throughout the code with steps [Project creation step x]. Search for it and follow the flow.

At the end of the process is when the Project template assign is triggered. This updates the Sharepoint site to follow a certain structure, which in the new UI is just the Files page.
