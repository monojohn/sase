import { withPermissions } from "../../../middleware/withPermissions";
import UserFeedbackActionModel from "../../../services/dbConnector/models/userFeedbackActionModel";
import UserFeedbackModel from "../../../services/dbConnector/models/userFeedbackModel";
import { VlBenefits } from "../../../services/sharepointService/enums";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type FeedbackInputProps = {
  hoursPerWeek: number;
  benefits: VlBenefits[];
};

/**
 * ensures received benefits is correctly formatted
 *
 * @param benefits array of benefits
 * @returns
 */
const benefitsAreValid = (benefits: VlBenefits[]) =>
  Array.isArray(benefits) && !benefits.some((benefit) => !VlBenefits[benefit]);

app.post<FeedbackInputProps>(
  withPermissions(async (ctx) => {
    const { hoursPerWeek, benefits } = ctx.req.body as FeedbackInputProps;
    ctx.log(hoursPerWeek, benefits);

    // validate rating
    if (!benefitsAreValid(benefits)) {
      const error = `Invalid benefits ('${benefits?.toString?.()}'). Expected an array with any of the following: ${Object.keys(
        VlBenefits,
      ).join()}`;
      ctx.log(error);
      ctx.res = { status: 400, body: { error, message: error } };
      return;
    }

    // validate hoursPerWeek
    if (
      typeof hoursPerWeek !== "number" ||
      Number.isNaN(hoursPerWeek) ||
      hoursPerWeek < 0 ||
      hoursPerWeek > 4
    ) {
      const error = `Invalid hoursPerWeek ('${hoursPerWeek}'). Expected a number between 0 and 4`;
      ctx.log(error);
      ctx.res = { status: 400, body: { error, message: error } };
      return;
    }

    ctx.log(`Creating feedback entry`);
    await UserFeedbackModel.create({
      hoursPerWeek,
      benefits,
    });
    ctx.log(`Creating feedback action entry`);
    await UserFeedbackActionModel.create({ oid: ctx.session.oid });
  }),
);

export const mainHandler = app;
