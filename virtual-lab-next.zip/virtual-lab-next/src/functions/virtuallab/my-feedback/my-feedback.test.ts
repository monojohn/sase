import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import UserFeedbackModel from "../../../services/dbConnector/models/userFeedbackModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-feedback";

const ctx = getCtx({ method: "POST", name: "My feedback" });

describe("My feedback", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.params = {};
    ctx.res = undefined;
  });

  describe("POST feedback input", () => {
    it("Returns 400 when benefits are not an array", async () => {
      ctx.req.body = { benefits: "benefits" };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 when benefits are an invalid array", async () => {
      ctx.req.body = { benefits: ["benefits"] };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 when hoursPerWeek is not a number", async () => {
      ctx.req.body = { benefits: [], hoursPerWeek: "1" };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 when hoursPerWeek is NaN", async () => {
      ctx.req.body = { benefits: [], hoursPerWeek: NaN };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 when hoursPerWeek is < 0", async () => {
      ctx.req.body = { benefits: [], hoursPerWeek: -1 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 when hoursPerWeek is > 4", async () => {
      ctx.req.body = { benefits: [], hoursPerWeek: 5 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 200 on success", async () => {
      ctx.req.body = { benefits: [], hoursPerWeek: 4 };
      await mainHandler(ctx);

      const entries = await UserFeedbackModel.find().lean();
      expect(ctx.res).toBe(undefined);
      expect(entries.length).toBe(1);
    });
  });
});
