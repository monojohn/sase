import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import { mainHandler } from "./project-owners";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import { VL_TEAM_ORG } from "../../../utils/config";
import NotificationService from "../../../features/openAIUseCase/notificationService";

const testMember = genId();
const testOwner = genId();

const ctx = getCtx({ method: "PATCH", name: "Project members" });

describe("Project members error cases", () => {
  const openAiMailMock = jest.fn(async () => void 0);

  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => [] as any);
    jest.spyOn(GraphService, "getGroupMemberUsers").mockImplementation(async () => [] as any);
    jest
      .spyOn(GraphService, "getUsersProps")
      .mockImplementation(
        async () => [{ id: "id", identities: [], mail: "mail", userType: "Member" }] as any,
      );
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(
        async () => ({ id: "id", identities: [], mail: "mail", displayName: "user" }) as any,
      );
    jest.spyOn(EntitlementsService, "isProjectOrgVlOrg").mockImplementation(async () => false);
    jest
      .spyOn(EntitlementsService, "get")
      .mockImplementation(async () => [{ owner: VL_TEAM_ORG }] as any);
    jest.spyOn(EntitlementsService, "addUser").mockImplementation(async () => ({}) as any);

    jest.spyOn(EntitlementsService, "removeUser").mockImplementation(async () => ({}) as any);

    jest.spyOn(EntitlementsService, "updateOrg").mockImplementation(async () => ({}) as any);
    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementation(async () => ({ passed: true }) as any);
    jest
      .spyOn(NotificationService, "sendLlmAwarenessInfoToUsers")
      .mockImplementation(openAiMailMock);

    testProject = await createTestProject({
      owners: [ctx.authOid],
      members: [testMember],
      rolesAndEntitlements: [{ entitlements: ["ent"], roles: [], iamRoles: [] }],
      aiUseCaseId: "123",
      aiUsage: true,
    });
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(GraphService, "getGroupMemberUsers").mockRestore();
    jest.spyOn(GraphService, "getUsersProps").mockRestore();
    jest.spyOn(GraphService, "getUserDepartment").mockRestore();
    jest.spyOn(EntitlementsService, "isProjectOrgVlOrg").mockRestore();
    jest.spyOn(EntitlementsService, "get").mockRestore();
    jest.spyOn(EntitlementsService, "addUser").mockRestore();
    jest.spyOn(EntitlementsService, "removeUser").mockRestore();
    jest.spyOn(EntitlementsService, "updateOrg").mockRestore();
    jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockRestore();
    jest.spyOn(NotificationService, "sendLlmAwarenessInfoToUsers").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
    ctx.req.params = { pid: testProject._id };
  });

  describe("PATCH Project owner", () => {
    it("Returns 400 when role & ent check fails", async () => {
      const analysis = {
        missingUsers: [],
        missingRolesAndEntitlements: {},
        missingConditions: {
          Guest: [],
          Member: [],
        },
        errors: [],
        errorUsers: [],
      };
      jest
        .spyOn(ProjectService, "checkRolesAndEntitlements")
        .mockImplementationOnce(async () => ({ passed: false, analysis }) as any);
      ctx.req.body = { oid: genId() };

      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual("Roles and entitlements check did not pass");
    });

    it("Returns 400 when user is already an owner", async () => {
      ctx.req.body = { oid: ctx.authOid };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Following invitees are already owners: ${ctx.authOid}`,
        },
      });
    });

    it("Returns 200 when user is invited", async () => {
      ctx.req.body = { oid: genId() };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({ status: 200 });

      // check invite was created
      const invite = await OwnershipInviteModel.findOne({ pid: testProject._id }).lean();
      expect(invite).not.toBeNull();

      // check that oid is not immediately added (contains only the original owner)
      const project = await ProjectModel.findById(testProject._id).lean();
      expect(project?.owners).toEqual([ctx.authOid]);
    });

    it("Adds owner as admin", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementationOnce(async () => ({
        isAdmin: true,
        isNonEscb: false,
        isVlUser: true,
      }));
      ctx.req.body = { oid: testOwner };
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);
      expect(openAiMailMock).toHaveBeenCalledTimes(1);
    });
  });

  describe("DELETE Project owner", () => {
    beforeAll(() => {
      ctx.req.method = "DELETE";
    });

    it("Removes owner", async () => {
      const body = [
        { id: ctx.authOid, userType: "Member", identities: [], mail: "mail" } as any,
        { id: testOwner, userType: "Guest", identities: [], mail: "mail" } as any,
      ];
      ctx.req.body = { oid: testOwner };
      jest
        .spyOn(GraphService, "getGroupUsers")
        .mockResolvedValueOnce(body)
        .mockResolvedValueOnce(body);
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);
    });

    it("Returns 400 when last owner from current BA org is being removed", async () => {
      ctx.req.body = { oid: ctx.authOid };
      jest
        .spyOn(GraphService, "getGroupMemberUsers")
        .mockImplementationOnce(async () => [{ department: "dep", id: ctx.authOid }] as any);

      jest.spyOn(GraphService, "getUserDepartment").mockResolvedValueOnce(VL_TEAM_ORG);

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `The last owner from the BA org of a project cannot be removed` },
      });
    });

    it("Returns 400 when last owner is being removed", async () => {
      ctx.req.body = { oid: ctx.authOid };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `The last owner of a project cannot be removed` },
      });
    });

    it("Returns 400 when last ESCB owner is being removed from a non-ESCB project", async () => {
      const extraOwnerId = genId();
      const proj = await createTestProject({
        owners: [ctx.authOid, extraOwnerId],
        members: [testMember],
        isNonEscbProject: true,
      });

      jest
        .spyOn(GraphService, "getGroupUsers")
        .mockResolvedValueOnce([
          { id: ctx.authOid, userType: "Member" } as any,
          { id: extraOwnerId, userType: "Guest" } as any,
        ]);

      ctx.req.body = { oid: ctx.authOid };
      ctx.req.params = { pid: proj._id };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `The last ESCB owner of a non-ESCB project cannot be removed` },
      });
    });

    it("Returns 200 when a non-owner is incorrectly in the DB", async () => {
      const badOwnerId = genId();
      const proj = await createTestProject({
        owners: [ctx.authOid],
        members: [testMember],
        isNonEscbProject: true,
      });

      jest
        .spyOn(GraphService, "getGroupUsers")
        .mockResolvedValueOnce([
          { id: ctx.authOid, userType: "Member" } as any,
          { id: badOwnerId, userType: "Guest" } as any,
        ]);

      ctx.req.body = { oid: badOwnerId };
      ctx.req.params = { pid: proj._id };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 200,
        body: { message: `User is not a project owner` },
      });

      // expect the project owners to have been updated
      const project = await ProjectModel.findById(proj._id);
      expect(project?.owners).toEqual([ctx.authOid]);
    });
  });
});
