import OwnersNotificationService from "../../../features/projectOwners/emails";
import { ActionType } from "../../../features/userActions/enums";
import { updateActionTarget } from "../../../features/userActions/userActions";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import NotificationService from "../../../services/projectService/notificationService";
import { removeUserFromProject } from "../../../services/projectService/projectModificationService/removeUser";
import ProjectService from "../../../services/projectService/projectService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import EntitlementsNotificationService from "../../../features/notificationEntitlements/notificationService";
import { getEmailOfUser, getTeamGroupName, requiresManagerApproval } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { EmailType } from "../../../features/notificationEntitlements/enums";
import { RolesAndEntitlements } from "../../../services/dbConnector/models/project";

const app = HttpTriggerFunction();

type DefaultBody = {
  oid: string | string[];
};

type DefaultProps = {
  pid: string;
  body: DefaultBody;
};

/**
 * Add owner to project
 */
app.patch<DefaultProps>(
  withProject(
    withOwnerPermissions((ctx) => {
      const { isAdmin } = ctx.permissions;
      const action = isAdmin ? ActionType.ADD_OWNER : ActionType.INVITE_OWNER;

      return withActionLogging(async () => {
        const { session, project } = ctx;
        const { oid: inviteeOid } = ctx.req.body as DefaultBody;
        const { _id: pid, name: projectName, owners } = project;

        const useBulkAdd = Array.isArray(inviteeOid);
        const oidArray = useBulkAdd ? inviteeOid : [inviteeOid];

        const inviteesAlreadyOwners = oidArray.filter((oid) => owners.includes(oid));
        if (inviteesAlreadyOwners.length) {
          ctx.res = {
            status: 400,
            body: {
              message: `Following invitees are already owners: ${inviteesAlreadyOwners.join(",")}`,
            },
          };
          return;
        }

        await updateActionTarget(ctx, oidArray.join());

        const users = await GraphService.getUsersProps(ctx, oidArray, [
          "id",
          "mail",
          "otherMails",
          "displayName",
          "userPrincipalName",
          "userType",
          "identities",
        ]);

        if (project.rolesAndEntitlements?.length) {
          // only check if there is something to check
          const { analysis, passed } = await ProjectService.checkRolesAndEntitlements(
            ctx,
            users,
            project,
          );

          if (!passed) {
            await EntitlementsNotificationService.notifyUsers(
              ctx,
              users,
              analysis,
              EmailType.NEW_USERS,
              project,
            );
            ctx.log("Missing roles or entitlements, returning 400");
            ctx.res = {
              status: 400,
              body: {
                ...analysis,
                message: analysis.errors.length
                  ? analysis.errors.join(". ")
                  : "Roles and entitlements check did not pass",
              },
            };
            return;
          }
        }

        if (isAdmin) {
          ctx.log(`Admin triggered Add User for project ${pid}`, { inviteeOid });

          await ProjectService.addOwnerAsAdmin(ctx, users, project, session.oid, session.name);
        } else {
          ctx.log(`Owner triggered Add User for project ${pid}`, { inviteeOid });

          await OwnershipInviteModel.create({
            pid,
            projectName,
            invitee: inviteeOid,
            inviter: session.oid,
            inviterName: session.name,
          });

          const [ecbOwners, invitee] = await Promise.all([
            GraphService.getGroupMemberUsers(ctx, project.ownersGroupId, ["id"]),
            GraphService.getUsersProps(ctx, oidArray, ["userType", "id", "userPrincipalName"]),
          ]);
          const projectUserType =
            ecbOwners.length || invitee.some(({ userType }) => userType === "Member")
              ? "Member"
              : "Guest";

          const requiresApproval = requiresManagerApproval(
            project.confidentialityLevel,
            projectUserType,
          );

          await Promise.all(
            users.map((user) =>
              NotificationService.sendOwnershipInvitationEmail(ctx, {
                bcc: getEmailOfUser(user),
                projectName: project.name,
                requiresApproval,
              }),
            ),
          );

          ctx.res = { status: 200 };
        }
      }, action)(ctx);
    }),
  ),
);

/**
 * Remove owner from project
 */
app.delete<DefaultProps>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { oid, rolesAndEntitlements } = ctx.req.body as {
          oid: string;
          rolesAndEntitlements?: RolesAndEntitlements[];
        };
        const { _id: pid, name: projectName } = project;

        await updateActionTarget(ctx, oid);

        const [ecbOwners, entitlement] = await Promise.all([
          GraphService.getGroupMemberUsers(ctx, project.ownersGroupId, [
            "department",
            "id",
            "userType",
          ]),
          EntitlementsService.get(ctx, getTeamGroupName(project.name)),
        ]);

        const ownersFromProjectOrg: string[] = [];
        const currentOrg = entitlement[0].owner;

        await Promise.all(
          // for each ecb owner
          ecbOwners.map(async (owner) => {
            // get department of owner
            const ownerDepartment = await GraphService.getUserDepartment(ctx, owner);
            // if the department is the current org from the project, push to array
            if (ownerDepartment === currentOrg) {
              ownersFromProjectOrg.push(owner.id);
            }
          }),
        );

        if (ownersFromProjectOrg.length === 1 && ownersFromProjectOrg.includes(oid)) {
          const message = `The last owner from the BA org of a project cannot be removed`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // check last owner of project
        const isLastOwner = project.owners.length === 1 && project.owners.includes(oid);
        if (isLastOwner) {
          const message = `The last owner of a project cannot be removed`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // non-escb projects must have at least 1 non-guest owner
        const projectOwners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
          "id",
          "userType",
        ]);
        const escbOwnerCount = projectOwners.filter(
          ({ id, userType }) => userType === "Member" && id !== oid,
        ).length;

        if (project.isNonEscbProject && escbOwnerCount === 0) {
          const message = `The last ESCB owner of a non-ESCB project cannot be removed`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        const allOwners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
          "id",
          "userType",
          "mail",
          "otherMails",
          "displayName",
          "userPrincipalName",
          "identities",
        ]);
        const owners = allOwners.filter(({ id }) => id !== oid);
        const removedOwner = allOwners.find(({ id }) => id === oid);

        if (!removedOwner) {
          const message = `User is not a project owner`;
          ctx.log(message);

          // if user is not in group, update DB if needed
          if (project.owners.includes(oid)) {
            await ProjectModel.updateOne({ _id: project._id }, { $pull: { owners: oid } });
          }

          // return success since user is already gone
          ctx.res = { status: 200, body: { message } };
          return;
        }

        ctx.log(`Removing owner from project`);
        await removeUserFromProject(ctx, project, oid);

        if (rolesAndEntitlements?.length) {
          const { passed, analysis } = await ProjectService.checkRolesAndEntitlements(
            ctx,
            [removedOwner],
            {
              ...project,
              rolesAndEntitlements,
            },
          );

          if (!passed) {
            await EntitlementsNotificationService.notifyUsers(
              ctx,
              [removedOwner],
              analysis,
              EmailType.USERS_REMOVED,
              project,
            );
            ctx.log(`Missing roles or entitlements for project ${project._id}, returning 400`);
            ctx.res = {
              status: 200,
              body: {
                message: "User notified of missing roles or entitlements",
              },
            };
            return;
          }
        }

        ctx.log(`Notifying all owners`);
        await UserNotificationService.notifyUsers(ctx, owners, {
          type: ActionType.REMOVE_OWNER,
          target: { id: removedOwner.id, name: removedOwner.displayName },
          project: { id: pid, name: projectName },
          triggerer: { id: session.oid, displayName: session.name },
        });

        const ownersToEmail = owners.filter(({ id }) => id !== removedOwner.id);
        // notify remaining owners
        await OwnersNotificationService.sendOwnerRemovedEmail(ctx, {
          projectName: project.name,
          userEmail: removedOwner.displayName,
          bcc: ownersToEmail.map((user) => getEmailOfUser(user)),
        });

        // notify removed owner
        await OwnersNotificationService.sendUserRemovedEmail(ctx, {
          projectName: project.name,
          userEmail: getEmailOfUser(removedOwner),
        });
      }, ActionType.REMOVE_OWNER),
    ),
  ),
  { allowNonEscb: true },
);

export const mainHandler = app;
