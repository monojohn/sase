import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./user-entitlements";

const ctx = getCtx({ name: "User entitlements", authorization: global.adminJwt });

const oid = "202eb6a9-e030-474c-ab26-5864a99b7a52";
describe("User entitlements", () => {
  it("Returns 200 when a user is found", async () => {
    ctx.req.params = { oid };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(200);
    expect(ctx.res.body.entitlements.length).toBeGreaterThanOrEqual(1);
  });

  it("Returns 404 when a user is not found", async () => {
    ctx.req.params = { oid: "123uhi123" };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(404);
  });
});
