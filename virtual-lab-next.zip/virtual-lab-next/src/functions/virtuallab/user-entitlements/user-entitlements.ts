import { AxiosError } from "axios";
import GraphService from "../../../services/graphService/graphService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { withPermissions } from "../../../middleware/withPermissions";

const app = HttpTriggerFunction();

type HeadProps = {
  params: {
    oid: string;
  };
};

app.get<HeadProps>(
  withPermissions(async (ctx) => {
    const oid = ctx.req.params?.oid;

    ctx.log(`Getting user by oid "${oid}"`);
    try {
      const user = await GraphService.getUser(ctx, oid);
      const emailDomain = user.userPrincipalName.split("@")[1];
      ctx.log(`Getting user entitlements of ${oid} by upn ******@${emailDomain}`);

      const entitlements = await EntitlementsService.getUserEntitlements(
        ctx,
        user.userPrincipalName,
      );

      ctx.log(`Found ${entitlements.length} entitlements`);
      ctx.res = {
        status: 200,
        body: {
          entitlements: entitlements.map(({ displayName }) => displayName),
        },
      };
    } catch (e) {
      // assume graph errors are 404's
      const err = e as AxiosError<unknown>;
      const prettyError = JSON.stringify(err?.response?.data ?? {}, null, 2);
      const error = `Couldn't get user with oid ${oid}`;
      ctx.log(error, prettyError);
      ctx.res = {
        status: 404,
        body: {
          message: `User with oid ${oid} not found`,
        },
      };
    }
  }),
);

export const mainHandler = app;
