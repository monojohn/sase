import { jest } from "@jest/globals";

import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./user-entitlements";
import GraphService from "../../../services/graphService/graphService";
import EntitlementsService from "../../../services/igamService/entitlementsService";

const ctx = getCtx({ name: "User entitlements", authorization: global.adminJwt });

describe("User entitlements", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest
      .spyOn(GraphService, "getUser")
      .mockImplementation(async () => ({ userPrincipalName: global.testEmail }) as any);
    jest
      .spyOn(EntitlementsService, "getUserEntitlements")
      .mockImplementation(async () => [{ displayName: "ent" }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUser").mockRestore();
    jest.spyOn(EntitlementsService, "getUserEntitlements").mockRestore();
  });
  it("Returns 200 when a user is found", async () => {
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(200);
    expect(ctx.res.body.entitlements.length).toBeGreaterThanOrEqual(1);
  });

  it("Returns 404 when a user is not found", async () => {
    jest.spyOn(GraphService, "getUser").mockRejectedValueOnce(undefined);

    await mainHandler(ctx);

    expect(ctx.res.status).toBe(404);
  });
});
