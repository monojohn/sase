import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { AccessibilityLevel, ConfidentialityLevel } from "../../../services/dbConnector/enums";
import ProjectService from "../../../services/projectService/projectService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

const confidentialityToAccessibilityMap: Record<ConfidentialityLevel, AccessibilityLevel[]> = {
  "ECB-PUBLIC": [
    AccessibilityLevel.Public,
    AccessibilityLevel.Private,
    AccessibilityLevel.Protected,
  ],
  "ECB-UNRESTRICTED": [
    AccessibilityLevel.Public,
    AccessibilityLevel.Private,
    AccessibilityLevel.Protected,
  ],
  "ECB-RESTRICTED": [AccessibilityLevel.Private, AccessibilityLevel.Protected],
  "ECB-CONFIDENTIAL": [AccessibilityLevel.Private, AccessibilityLevel.Protected],
  "ECB-SECRET": [AccessibilityLevel.Private, AccessibilityLevel.Protected],
};

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = {
        status: 200,
        body: { accessibilityLevel: project.accessibilityLevel },
      };
    }),
  ),
);

type PatchProps = {
  body?: { accessibilityLevel?: AccessibilityLevel };
  params: { pid: string };
};

const allowedValues: AccessibilityLevel[] = [
  AccessibilityLevel.Public,
  AccessibilityLevel.Private,
  AccessibilityLevel.Protected,
];

app.patch<PatchProps>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        const body = ctx.req.body as { accessibilityLevel: AccessibilityLevel };
        const accessibilityLevel = body?.accessibilityLevel;
        const projectTitle = project.name;
        const pid = project._id;

        ctx.log(`Updating accessibility of ${pid} to ${accessibilityLevel}`);

        const confidentialityPending = await ProjectService.isConfidentialityPending(pid);

        if (confidentialityPending.length) {
          const message = `Error updating accessibility: there is a pending confidentiality ${confidentialityPending[0].confidentialityLevel}`;
          ctx.log(message, { accessibilityLevel });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        if (!allowedValues.includes(accessibilityLevel)) {
          const message = `Error updating project #${pid} ${projectTitle}: "${typeof accessibilityLevel}" "${accessibilityLevel}" is invalid. Use one of ${allowedValues.join()}`;

          ctx.log(message, { value: accessibilityLevel });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // Some projects have value with Pascal case, force uppercase
        const confLevel = project.confidentialityLevel.toLocaleUpperCase() as ConfidentialityLevel;
        const allowedAccessibilityLevels = confidentialityToAccessibilityMap[confLevel];
        if (!allowedAccessibilityLevels.includes(accessibilityLevel)) {
          const message = `${accessibilityLevel} is invalid for a ${confLevel} project. Use one of ${allowedAccessibilityLevels.join(
            ", ",
          )}`;

          ctx.log(message, { value: accessibilityLevel });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        await ProjectService.setAccessibilityLevel(ctx, project, accessibilityLevel);

        // notify team users
        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          type: ActionType.UPDATE_ACCESSIBILITY,
          project: { id: project._id, name: project.name },
          target: { id: "ProjectType", name: accessibilityLevel },
          triggerer: { id: session.oid, displayName: session.name },
        });
      }, ActionType.UPDATE_ACCESSIBILITY),
    ),
  ),
);

export const mainHandler = app;
