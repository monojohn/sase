import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import NotificationService from "../../../features/projectAccessibilityModification/notificationService";
import {
  AccessibilityLevel,
  RequestStatus,
  RequestType,
} from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import projectAccessLevelService from "../../../services/projectService/projectAccessLevelService";
import { mainHandler } from "./project-accessibility";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";

const ctx = getCtx({ name: "Project accessibility" });

describe("Project accessibility", () => {
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(NotificationService, "sendSuccessEmail").mockImplementation(async () => void 0);
    jest.spyOn(projectAccessLevelService, "allowVisitors").mockImplementation(async () => void 0);
    jest
      .spyOn(projectAccessLevelService, "disallowVisitors")
      .mockImplementation(async () => void 0);

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params = { pid: testProject._id };
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(NotificationService, "sendSuccessEmail").mockRestore();
    jest.spyOn(projectAccessLevelService, "allowVisitors").mockRestore();
    jest.spyOn(projectAccessLevelService, "disallowVisitors").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
  });

  describe("GET project accessibility", () => {
    it("Returns project accessibility", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body?.accessibilityLevel).toBe(testProject.accessibilityLevel);
    });
  });

  describe("PATCH project accessibility", () => {
    it("Returns 400 when there's an open request on confidentiality", async () => {
      await IgamRequestModel.create({
        pid: testProject._id,
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requesterId: "me",
      });
      ctx.req.method = "PATCH";
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      await IgamRequestModel.deleteMany();
    });

    it("Returns 400 when invalid accessibility type is passed", async () => {
      ctx.req.method = "PATCH";
      ctx.req.body = { ProjectType: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Updates project accessibility", async () => {
      ctx.req.method = "PATCH";
      const newType = AccessibilityLevel.Protected;
      ctx.req.body = { accessibilityLevel: newType };
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined); // represents success

      // check project was updated
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.accessibilityLevel).toBe(newType);
    });
  });
});
