import { EmailType } from "../../../features/notificationEntitlements/enums";
import NotificationService from "../../../features/notificationEntitlements/notificationService";
import { withPermissions } from "../../../middleware/withPermissions";
import { RolesAndEntitlementsStrings } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import IamService from "../../../services/iamService/iamService";
import RolesService from "../../../services/igamService/rolesService";
import ProjectService from "../../../services/projectService/projectService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { isStringArray } from "../../../utils/typeValidator";

const app = HttpTriggerFunction();

type Body = {
  rolesAndEntitlements: RolesAndEntitlementsStrings[];
  oids: string[];
  pid: string;
  type: EmailType;
};

type Props = {
  params: { id: string };
  body: Body;
};

/**
 * ensure the oids are a string[]
 *
 * @param oids unknown
 * @returns
 */
const hasInvalidOids = (oids: string[]) => {
  const uniqueOids = oids?.reduce?.((acc, oid) => {
    if (!acc.includes(oid)) {
      acc.push(oid);
    }

    return acc;
  }, [] as string[]);

  return (
    !Array.isArray(oids) ||
    oids.some((entry) => typeof entry !== "string") ||
    oids?.length === 0 ||
    uniqueOids.length !== oids.length
  );
};

/**
 * Ask users to request entitlements
 */
app.post<Props>(
  withPermissions(async (ctx) => {
    const { oid } = ctx.session;
    const { oids = [], rolesAndEntitlements = [], pid, type } = ctx.req.body as Body;

    // ensure types are correct
    if (hasInvalidOids(oids)) {
      const message = `oids must be a string[] with length >= 1`;
      ctx.res = { status: 400, body: { error: message, message } };
      return;
    }

    if (!EmailType[type]) {
      const types = Object.values(EmailType).join();
      const message = `type must be one of ${types}`;
      ctx.res = { status: 400, body: { error: message, message } };
      return;
    }

    if (!Array.isArray(rolesAndEntitlements)) {
      const message = `rolesAndEntitlements must be an object array`;
      ctx.res = {
        status: 400,
        body: { error: message, message },
      };
      return;
    }

    if (!rolesAndEntitlements.every(({ entitlements }) => isStringArray(entitlements))) {
      const message = `entitlements must be a string[]`;
      ctx.res = { status: 400, body: { error: message, message } };
      return;
    }

    if (!rolesAndEntitlements.every(({ roles }) => isStringArray(roles))) {
      const message = `roles must be a string[]`;
      ctx.res = { status: 400, body: { error: message, message } };
      return;
    }

    if (!rolesAndEntitlements.every(({ iamRoles }) => isStringArray(iamRoles))) {
      const message = `iamRoles must be a string[]`;
      ctx.res = { status: 400, body: { error: message, message } };
      return;
    }

    // ensure project exists
    const project = await ProjectModel.findById(pid);
    const message = `Project with id ${pid} not found`;
    if (!project) {
      ctx.res = { status: 400, body: { error: message, message } };
      return;
    }

    if (!project.owners.includes(oid) && !ctx.permissions.isAdmin) {
      const error = `User ${oid} is not an owner of project ${pid}`;
      ctx.res = {
        status: 403,
        body: { error, message: error },
      };
      return;
    }

    // fetch users
    const users = await Promise.all(
      oids.map((id) =>
        GraphService.getUserProps(ctx, id, [
          "id",
          "userPrincipalName",
          "mail",
          "otherMails",
          "userType",
          "identities",
        ]),
      ),
    );

    ctx.log("Get roles using roleNames");
    const rolesArray = await Promise.all(
      rolesAndEntitlements
        ?.flatMap(({ roles }) => roles)
        .map(async (roleName) => {
          const [role] = await RolesService.searchByName(ctx, roleName);
          return role;
        }),
    );

    const iamRolesArray = await Promise.all(
      rolesAndEntitlements
        ?.flatMap(({ iamRoles }) => iamRoles)
        .map(async (roleName) => {
          const [role] = await IamService.getRoles(ctx, roleName);
          return role;
        }),
    );

    // only ESCB (non-guest) users must have IGAM roles / entitlements

    // get missing entitlements per user
    const { analysis, passed } = await ProjectService.checkRolesAndEntitlements(ctx, users, {
      rolesAndEntitlements: rolesAndEntitlements.map(({ roles, entitlements, iamRoles }) => ({
        entitlements,
        roles: rolesArray.filter(({ roleName }) => roles.includes(roleName)),
        iamRoles: iamRolesArray.filter(({ roleName }) => iamRoles.includes(roleName)),
      })),
    });

    if (passed) {
      // if users DO have entitlements, send back an error
      const error = `No missing users, entitlements or roles detected`;
      ctx.res = {
        status: 400,
        body: { error, message: error },
      };
      return;
    }

    await NotificationService.notifyUsers(ctx, users, analysis, type, project);
  }),
);

export const mainHandler = app;
