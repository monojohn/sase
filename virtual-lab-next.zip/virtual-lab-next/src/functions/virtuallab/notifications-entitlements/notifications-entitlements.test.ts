import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import IamService from "../../../services/iamService/iamService";
import RolesService from "../../../services/igamService/rolesService";
import ProjectService from "../../../services/projectService/projectService";
import { mainHandler } from "./notifications-entitlements";
import { Analysis } from "../../../services/projectService/types";

const ctx = getCtx({ method: "POST", name: "Notifications entitlements" });

describe("Notifications entitlements", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(async () => ({ id: "id", identities: [], mail: "mail" }) as any);
    jest
      .spyOn(RolesService, "searchByName")
      .mockImplementation(async () => [{ displayName: "test_role", roleName: "test_role" } as any]);
    jest
      .spyOn(IamService, "getRoles")
      .mockImplementation(async () => [
        { displayName: "test_iam_role", roleName: "test_iam_role" } as any,
      ]);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(RolesService, "searchByName").mockRestore();
    jest.spyOn(IamService, "getRoles").mockRestore();
    jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.params = {};
    ctx.req.body = {};
  });

  describe("POST errors", () => {
    it("Returns 400 when oids are not sent", async () => {
      ctx.req.body = {};
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual("oids must be a string[] with length >= 1");
    });

    it("Returns 400 when type is missing", async () => {
      ctx.req.body = { oids: ["123"] };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual("type must be one of NEW_USERS,USERS_REMOVED");
    });

    it("Returns 400 when rolesAndEntitlements is not object array", async () => {
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: {},
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual("rolesAndEntitlements must be an object array");
    });

    it("Returns 400 when entitlements are a number array", async () => {
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: [1],
            roles: [],
            iamRoles: [],
          },
        ],
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual("entitlements must be a string[]");
    });

    it("Returns 400 when roles are a string", async () => {
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: "",
            iamRoles: [],
          },
        ],
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual("roles must be a string[]");
    });

    it("Returns 400 when iamRoles are a string", async () => {
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: ["test_role"],
            iamRoles: "",
          },
        ],
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual("iamRoles must be a string[]");
    });

    it("Returns 400 when project does not exist", async () => {
      const pid = genId();
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: ["test_role"],
            iamRoles: ["test_iam_role"],
          },
        ],
        pid,
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.error).toEqual(`Project with id ${pid} not found`);
    });

    it("Returns 403 when non-owner sends request", async () => {
      // create project to notify
      const project = await createTestProject();
      const pid = project._id.toString();
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: ["test_role"],
            iamRoles: ["test_iam_role"],
          },
        ],
        pid,
      };

      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(403);
      expect(ctx.res.body.error).toEqual(`User ${ctx.authOid} is not an owner of project ${pid}`);
    });

    it("Returns 400 when all users have entitlements", async () => {
      jest
        .spyOn(ProjectService, "checkRolesAndEntitlements")
        .mockImplementationOnce(async () => ({ passed: true }) as any);

      // create project to notify
      const project = await createTestProject({ owners: [ctx.authOid] });
      const pid = project._id.toString();
      ctx.req.body = {
        oids: ["123"],
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: ["test_role"],
            iamRoles: ["test_iam_role"],
          },
        ],
        pid,
      };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: {
          error: `No missing users, entitlements or roles detected`,
          message: `No missing users, entitlements or roles detected`,
        },
      });
    });
  });

  describe("POST success", () => {
    it("Notifies new users", async () => {
      const oids = [genId(), genId(), genId(), genId(), genId()];
      const [missingEmail, withAll, missingRoles, missingEnt, missingIamRoles] = oids;

      const analysis: Analysis = {
        missingRolesAndEntitlements: {
          [withAll]: [],
          [missingEnt]: [
            {
              entitlements: ["ent"],
              roles: [],
              iamRoles: [],
            },
          ],

          [missingRoles]: [
            {
              entitlements: [],
              roles: [{ id: "role", displayName: "role", roleName: "role" }],
              iamRoles: [],
            },
          ],

          [missingIamRoles]: [
            {
              entitlements: [],
              roles: [],
              iamRoles: [{ key: "role", displayName: "role", roleName: "role" }],
            },
          ],
        },
        missingUsers: [],
        missingConditions: {
          Guest: [],
          Member: [],
        },
        errors: [],
        errorUsers: [],
      };

      jest
        .spyOn(ProjectService, "checkRolesAndEntitlements")
        .mockImplementationOnce(async () => ({ passed: false, analysis }));

      jest
        .spyOn(GraphService, "getUserProps")
        // will trigger email error
        .mockImplementationOnce(
          async () =>
            ({ id: missingEmail, userPrincipalName: missingEmail, identities: [] }) as any,
        )
        // will trigger entitlement error
        .mockImplementationOnce(
          async () =>
            ({
              mail: global.testEmail,
              id: withAll,
              userPrincipalName: withAll,
              identities: [],
            }) as any,
        )
        // will succeed
        .mockImplementationOnce(
          async () =>
            ({
              mail: global.testEmail,
              id: missingRoles,
              userPrincipalName: missingRoles,
              identities: [],
            }) as any,
        )
        .mockImplementationOnce(
          async () =>
            ({
              mail: global.testEmail,
              id: missingEnt,
              userPrincipalName: missingEnt,
              identities: [],
            }) as any,
        );

      const project = await createTestProject({ owners: [ctx.authOid] });
      const pid = project._id.toString();
      ctx.req.body = {
        pid,
        oids,
        type: "NEW_USERS",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: ["test_role"],
            iamRoles: ["test_iam_role"],
          },
        ],
      };

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);
    });

    it("Notifies removed users", async () => {
      const oids = [genId(), genId(), genId(), genId(), genId()];
      const [missingEmail, withAll, missingRoles, missingEnt, missingIamRoles] = oids;

      const analysis: Analysis = {
        missingRolesAndEntitlements: {
          [withAll]: [],
          [missingEnt]: [
            {
              entitlements: ["ent"],
              roles: [],
              iamRoles: [],
            },
          ],

          [missingRoles]: [
            {
              entitlements: [],
              roles: [{ id: "role", displayName: "role", roleName: "role" }],
              iamRoles: [],
            },
          ],

          [missingIamRoles]: [
            {
              entitlements: [],
              roles: [],
              iamRoles: [{ key: "role", displayName: "role", roleName: "role" }],
            },
          ],
        },
        missingUsers: [],
        missingConditions: {
          Guest: [],
          Member: [],
        },
        errors: [],
        errorUsers: [],
      };

      jest
        .spyOn(ProjectService, "checkRolesAndEntitlements")
        .mockImplementationOnce(async () => ({ passed: false, analysis }));

      jest
        .spyOn(GraphService, "getUserProps")
        // will trigger email error
        .mockImplementationOnce(
          async () =>
            ({ id: missingEmail, userPrincipalName: missingEmail, identities: [] }) as any,
        )
        // will trigger entitlement error
        .mockImplementationOnce(
          async () =>
            ({
              mail: global.testEmail,
              id: withAll,
              userPrincipalName: withAll,
              identities: [],
            }) as any,
        )
        // will succeed
        .mockImplementationOnce(
          async () =>
            ({
              mail: global.testEmail,
              id: missingRoles,
              userPrincipalName: missingRoles,
              identities: [],
            }) as any,
        )
        .mockImplementationOnce(
          async () =>
            ({
              mail: global.testEmail,
              identities: [],
              id: missingEnt,
              userPrincipalName: missingEnt,
              userType: "Member",
            }) as any,
        );

      const project = await createTestProject({ owners: [ctx.authOid] });
      const pid = project._id.toString();
      ctx.req.body = {
        pid,
        oids,
        type: "USERS_REMOVED",
        rolesAndEntitlements: [
          {
            entitlements: ["test_ent"],
            roles: ["test_role"],
            iamRoles: ["test_iam_role"],
          },
        ],
      };

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);
    });
  });
});
