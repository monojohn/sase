import { withPermissions } from "../../../middleware/withPermissions";
import GraphService from "../../../services/graphService/graphService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type HeadProps = {
  query: {
    q?: string;
  };
};

app.get<HeadProps>(
  withPermissions(async (ctx) => {
    const { q } = ctx.req.query ?? {};
    const { isAdmin } = ctx.permissions;

    ctx.log(`Searching user by query`);

    if (typeof q !== "string" || q.length < 3) {
      const message = `"q" must be a string with length >= 3, received "${typeof q}"`;
      ctx.log(message);
      ctx.res = { status: 400, body: { message } };
      return;
    }

    // if user is admin, also search non-escb group
    ctx.res = { body: await GraphService.searchUsers(ctx, q, isAdmin) };
  }),
);

export const mainHandler = app;
