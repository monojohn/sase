import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./users";
import GraphService from "../../../services/graphService/graphService";

const ctx = getCtx({ name: "Users", authorization: global.adminJwt });

describe("User search", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "searchUsers").mockImplementation(async () => [{ id: "user" }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "searchUsers").mockRestore();
  });
  beforeEach(() => {
    ctx.req.query = {};
    ctx.res = undefined;
  });

  it("Returns 400 when no q param is sent", async () => {
    await mainHandler(ctx);

    expect(ctx.res).toEqual({
      status: 400,
      body: {
        message: `"q" must be a string with length >= 3, received "undefined"`,
      },
    });
  });

  it("Returns 400 when q param is a len 2 string", async () => {
    ctx.req.query.q = "aa";

    await mainHandler(ctx);

    expect(ctx.res).toEqual({
      status: 400,
      body: {
        message: `"q" must be a string with length >= 3, received "string"`,
      },
    });
  });

  it("Returns a user[] when a correct query is sent", async () => {
    const q = "mar";
    ctx.req.query = { q };

    await mainHandler(ctx);

    expect(ctx.res.status).toBe(undefined);
    expect(Array.isArray(ctx.res.body)).toBe(true);

    expect(ctx.res.body.length).toEqual(1);
  });
});
