import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./users";

const ctx = getCtx({ name: "Users", authorization: global.adminJwt });

describe("User search", () => {
  beforeEach(() => {
    ctx.req.query = {};
    ctx.res = undefined;
  });

  it("Returns 400 when no q param is sent", async () => {
    await mainHandler(ctx);

    expect(ctx.res).toEqual({
      status: 400,
      body: {
        message: `"q" must be a string with length >= 3, received "undefined"`,
      },
    });
  });

  it("Returns 400 when q param is a len 2 string", async () => {
    ctx.req.query.q = "aa";

    await mainHandler(ctx);

    expect(ctx.res).toEqual({
      status: 400,
      body: {
        message: `"q" must be a string with length >= 3, received "string"`,
      },
    });
  });

  it("Returns a user[] when a correct query is sent", async () => {
    const q = "mar";
    ctx.req.query = { q };

    await mainHandler(ctx);

    expect(ctx.res.status).toBe(undefined);
    expect(Array.isArray(ctx.res.body)).toBe(true);

    // expect at least 1 user to be found
    expect(ctx.res.body.length).toBeGreaterThanOrEqual(1);
  });
});
