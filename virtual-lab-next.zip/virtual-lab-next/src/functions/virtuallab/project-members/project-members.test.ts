import { jest } from "@jest/globals";
import jwt from "jsonwebtoken";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import { mainHandler } from "./project-members";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import { AccessibilityLevel } from "../../../services/dbConnector/enums";
import NotificationService from "../../../features/openAIUseCase/notificationService";
import OwnerNotificationService from "../../../features/projectOwners/emails";
import { VL_MEMBERS_GROUP_ID } from "../../../utils/config";

const testMember = genId();

const ctx = getCtx({ method: "PATCH", name: "Project access requests" });

describe("Project members error cases", () => {
  const openAiMailMock = jest.fn(async () => void 0);
  const memberRemovalMailMock = jest.fn(async () => void 0);
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(async () => ({ identities: [], mail: "mail" }) as any);
    jest
      .spyOn(GraphService, "getGroupUsers")
      .mockImplementation(
        async () =>
          [{ id: VL_MEMBERS_GROUP_ID, identities: [], mail: "mail", userType: "Member" }] as any,
      );
    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementation(async () => ({ passed: true }) as any);

    jest.spyOn(EntitlementsService, "addUser").mockImplementation(async () => ({}) as any);

    jest.spyOn(EntitlementsService, "removeUser").mockImplementation(async () => ({}) as any);
    jest.spyOn(EntitlementsService, "get").mockImplementation(async () => [{ id: "123" }] as any);
    jest
      .spyOn(NotificationService, "sendLlmAwarenessInfoToUsers")
      .mockImplementation(openAiMailMock);
    jest
      .spyOn(OwnerNotificationService, "sendUserRemovedEmail")
      .mockImplementation(memberRemovalMailMock);

    testProject = await createTestProject({
      owners: [ctx.authOid],
      members: [testMember],
      rolesAndEntitlements: [{ entitlements: ["ent"], roles: [], iamRoles: [] }],
      accessibilityLevel: AccessibilityLevel.Private,
      aiUseCaseId: "123",
      aiUsage: true,
    });
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockRestore();
    jest.spyOn(EntitlementsService, "addUser").mockRestore();
    jest.spyOn(EntitlementsService, "removeUser").mockRestore();
    jest.spyOn(EntitlementsService, "get").mockRestore();
    jest.spyOn(NotificationService, "sendLlmAwarenessInfoToUsers").mockRestore();
    jest.spyOn(OwnerNotificationService, "sendUserRemovedEmail").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
    ctx.req.params = { pid: testProject._id };
  });

  describe("PATCH Project members", () => {
    it("Returns 400 when role & ent check fails", async () => {
      const analysis = {
        missingUsers: [],
        missingRolesAndEntitlements: {},
        missingConditions: {
          Guest: [],
          Member: [],
        },
        errors: ["error"],
        errorUsers: [],
      };
      jest
        .spyOn(ProjectService, "checkRolesAndEntitlements")
        .mockImplementationOnce(async () => ({ passed: false, analysis }) as any);
      ctx.req.body = { oid: genId() };

      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual("error");
    });

    it("Returns 400 when user is already a member", async () => {
      ctx.req.body = { oid: testMember };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Following invitees are already members: ${testMember}`,
        },
      });
    });

    it("Returns 400 when last owner would be removed", async () => {
      ctx.req.body = { oid: ctx.authOid };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: "Project would be left without owners with this change" },
      });
    });

    it("Throws error when last ESCB owner of non-ESCB would be removed", async () => {
      const newProject = await createTestProject({
        owners: [ctx.authOid],
        members: [testMember],
        rolesAndEntitlements: [{ entitlements: ["ent"], roles: [], iamRoles: [] }],
        isNonEscbProject: true,
      });

      ctx.req.params = { pid: newProject._id };
      ctx.req.body = { oid: genId() };

      jest.spyOn(GraphService, "getGroupUsers").mockImplementationOnce(async () => []);

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: "The last ESCB owner of a non-ESCB project cannot be removed" },
      });
    });

    it("Adds user and notifies of OpenAI use case", async () => {
      ctx.req.body = { oid: genId() };

      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);
      expect(openAiMailMock).toHaveBeenCalledTimes(1);
    });
  });

  describe("DELETE Project members", () => {
    beforeAll(() => {
      ctx.req.method = "DELETE";
    });

    it("Removes user", async () => {
      ctx.req.body = { oid: genId() };

      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined);
      expect(memberRemovalMailMock).toHaveBeenCalledTimes(1);
    });

    it("Returns 403 when Member tries to remove another member", async () => {
      ctx.req.headers.authorization = jwt.sign({ upn: "test", oid: testMember }, "secret");
      ctx.req.body = { oid: genId() };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 403,
        body: { message: `Non-owner/admin ${testMember} tried to remove other member` },
      });
    });
  });
});
