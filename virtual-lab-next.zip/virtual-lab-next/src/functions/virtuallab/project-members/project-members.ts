import { EmailType } from "../../../features/notificationEntitlements/enums";
import NotificationService from "../../../features/notificationEntitlements/notificationService";
import OwnersNotificationService from "../../../features/projectOwners/emails";
import { ActionType } from "../../../features/userActions/enums";
import { updateActionTarget } from "../../../features/userActions/userActions";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { RolesAndEntitlements } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { removeUserFromProject } from "../../../services/projectService/projectModificationService/removeUser";
import ProjectService from "../../../services/projectService/projectService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import { getEmailOfUser } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type DefaultBody = {
  oid: string;
  rolesAndEntitlements?: RolesAndEntitlements[];
};

type AddMemberBody = {
  oid: string | string[];
};

type DefaultProps = {
  pid: string;
  body: DefaultBody;
};

/**
 * Add member to project
 */
app.patch<AddMemberBody>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { oid: inviteeOid } = ctx.req.body as AddMemberBody;
        const { members, rolesAndEntitlements } = project;

        const useBulkAdd = Array.isArray(inviteeOid);
        const oids = useBulkAdd ? inviteeOid : [inviteeOid];

        const inviteesAlreadyMembers = oids.filter((oid) => members.includes(oid));
        if (inviteesAlreadyMembers.length) {
          ctx.res = {
            status: 400,
            body: {
              message: `Following invitees are already members: ${inviteesAlreadyMembers.join(",")}`,
            },
          };
          return;
        }

        await updateActionTarget(ctx, oids.join());
        const users = await GraphService.getUsersProps(ctx, oids, [
          "id",
          "displayName",
          "userPrincipalName",
          "userType",
          "mail",
          "otherMails",
          "identities",
        ]);

        if (rolesAndEntitlements?.length) {
          const { passed, analysis } = await ProjectService.checkRolesAndEntitlements(
            ctx,
            users,
            project,
          );

          if (!passed) {
            await NotificationService.notifyUsers(
              ctx,
              users,
              analysis,
              EmailType.NEW_USERS,
              project,
            );
            ctx.log(`Missing roles or entitlements for project ${project._id}, returning 400`);
            ctx.res = {
              status: 400,
              body: {
                ...analysis,
                message: analysis.errors.length
                  ? analysis.errors.join(". ")
                  : "Roles and entitlements check did not pass",
              },
            };
            return;
          }
        }

        const projectOwnersAfterChange = project.owners.filter(
          (ownerOid) => !oids.includes(ownerOid),
        );

        ctx.log({ projectOwnersAfterChange });
        if (projectOwnersAfterChange.length <= 0) {
          const message = `Project would be left without owners with this change`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // non-escb projects must have at least 1 non-guest owner
        const projectOwners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
          "id",
          "userType",
        ]);

        const escbOwnerCount = projectOwners.filter(
          ({ id, userType }) => userType === "Member" && id !== inviteeOid,
        ).length;

        if (project.isNonEscbProject && escbOwnerCount === 0) {
          const message = `The last ESCB owner of a non-ESCB project cannot be removed`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        await ProjectService.addMember(
          ctx,
          oids,
          project,
          inviteeOid,
          users,
          session.oid,
          session.name,
        );
      }, ActionType.ADD_MEMBER),
    ),
  ),
);

/**
 * Remove member from project
 */
app.delete<DefaultProps>(
  withProject(
    withMemberPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { oid, rolesAndEntitlements } = ctx.req.body as DefaultBody;
        const { isOwnerOrAdmin } = ctx.permissions;

        ctx.log(`Body: ${ctx.req.body}`);

        await updateActionTarget(ctx, oid);

        // members can only remove self
        if (!isOwnerOrAdmin && oid !== ctx.session.oid) {
          const message = `Non-owner/admin ${ctx.session.oid} tried to remove other member`;
          ctx.log(message);
          ctx.res = { status: 403, body: { message } };
          return;
        }

        const user = await GraphService.getUserProps(ctx, oid, [
          "mail",
          "otherMails",
          "displayName",
          "userPrincipalName",
          "identities",
          "id",
          "userType",
        ]);

        await removeUserFromProject(ctx, ctx.project, oid);

        if (rolesAndEntitlements?.length) {
          ctx.log(`Checking roles and entitlements`);
          const { passed, analysis } = await ProjectService.checkRolesAndEntitlements(ctx, [user], {
            ...project,
            rolesAndEntitlements,
          });

          ctx.log({ passed, analysis });

          if (!passed) {
            await NotificationService.notifyUsers(
              ctx,
              [user],
              analysis,
              EmailType.USERS_REMOVED,
              project,
            );
            ctx.log(`Missing roles or entitlements for project ${project._id}, returning 400`);
            ctx.res = {
              status: 200,
              body: {
                message: "User notified of missing roles or entitlements",
              },
            };
            return;
          }
        }

        // remove user who removed member + removed user
        const usersToNotify = [{ id: oid }];

        // prevent creating 2 notifications when removing self
        if (oid !== session.oid) {
          usersToNotify.push({ id: session.oid });
        }

        await Promise.all([
          UserNotificationService.notifyUsers(ctx, usersToNotify, {
            type: ActionType.REMOVE_MEMBER,
            target: { id: oid, name: user.displayName },
            project: { id: project._id, name: project.name },
            triggerer: { id: session.oid, displayName: session.name },
          }),

          OwnersNotificationService.sendUserRemovedEmail(ctx, {
            projectName: project.name,
            userEmail: getEmailOfUser(user),
          }),
        ]);
      }, ActionType.REMOVE_MEMBER),
    ),
  ),
  { allowNonEscb: true },
);

export const mainHandler = app;
