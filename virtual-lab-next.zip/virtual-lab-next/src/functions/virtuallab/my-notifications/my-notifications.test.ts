import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import UserNotificationModel from "../../../services/dbConnector/models/userNotificationModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-notifications";
import { ActionType } from "../../../features/userActions/enums";

const ctx = getCtx({ name: "My notifications" });

describe("My notifications", () => {
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    // insert 5 entries
    for (let index = 0; index < 5; index++) {
      await UserNotificationModel.create({
        oid: ctx.authOid,
        pid: "pid",
        projectName: "projectName",
        triggeredBy: "triggeredBy",
        triggeredByName: "triggeredByName",
        type: ActionType.ACCEPT_MEMBERSHIP,
      });
    }
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("GET my notifications", () => {
    it("Returns notifications array", async () => {
      ctx.req.query = { read: false };
      await mainHandler(ctx);
      expect(ctx.res.body?.length).toBeGreaterThanOrEqual(5);
    });

    it("Respects limit param", async () => {
      ctx.req.query = { limit: 2 };
      await mainHandler(ctx);
      expect(ctx.res.body?.length).toBe(2);
    });

    it("Respects skip param", async () => {
      ctx.req.query = { skip: 3 };
      const count = await UserNotificationModel.countDocuments({ oid: ctx.authOid });
      await mainHandler(ctx);
      expect(ctx.res.body?.length).toBe(count - 3);
    });

    it("Respects read param", async () => {
      ctx.req.query = { read: true };
      const readCount = await UserNotificationModel.countDocuments({
        read: true,
        oid: ctx.authOid,
      });
      await mainHandler(ctx);
      expect(ctx.res.body?.length).toBe(readCount);
    });
  });
});
