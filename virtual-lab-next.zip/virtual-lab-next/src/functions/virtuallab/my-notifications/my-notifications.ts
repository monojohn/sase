import { FilterQuery } from "mongoose";
import { UserNotification } from "../../../services/dbConnector/models/userNotification";
import UserNotificationModel from "../../../services/dbConnector/models/userNotificationModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { withPermissions } from "../../../middleware/withPermissions";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
  query: { limit: number; skip: number; read: boolean | undefined };
};

/**
 * Get all user notifications
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { limit = 20, skip = 0, read } = ctx.req.query;
    const { oid } = ctx.session;
    const filters: FilterQuery<UserNotification> = { oid };

    if (read !== undefined) {
      filters.read = read;
    }

    ctx.res = {
      body: await UserNotificationModel.find(filters).limit(limit).skip(skip),
    };
  }),
);

export const mainHandler = app;
