import { v2 } from "@datadog/datadog-api-client";
import MLMetrics from "../../../features/mlMetrics/mlMetrics";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { getProjectByWorkspaceName } from "./helpers";

const app = HttpTriggerFunction();

app.post(async (ctx) => {
  // get workspace name from url
  const { workspaceName } = ctx.session;

  if (!workspaceName) {
    const message = `invalid or missing xms_mirid field in session`;
    ctx.log(message);
    ctx.res = { status: 400, body: { message } };
    return;
  }

  // datadog will validate parameters
  const body = ctx.req.body as v2.MetricsApiSubmitMetricsRequest;
  if (!body) {
    ctx.res = { status: 400, body: { message: `No data received in request body` } };
    return;
  }

  // ensure metric name is correct
  const expectMetricPrefix = `vl-metrics.${workspaceName}`;
  // find all metrics with the wrong name
  const metricNameMismatch = body.body.series
    .filter(({ metric }) => !metric.startsWith(expectMetricPrefix))
    .map(({ metric }) => metric);

  if (metricNameMismatch.length > 0) {
    ctx.res = {
      status: 400,
      body: {
        message: `Incorrect metric name detected: ${metricNameMismatch.join(
          ", ",
        )}. Expected name to start with '${expectMetricPrefix}'`,
      },
    };
    return;
  }

  // get project by ml workspace URL
  const project = await getProjectByWorkspaceName(workspaceName);
  if (!project) {
    ctx.res = {
      status: 404,
      body: { message: `No project found for workspace '${workspaceName}'` },
    };
    return;
  }

  ctx.log(`Creating log entry for workspace ${workspaceName} of ${project.name}`);

  // get logging service
  try {
    await MLMetrics.submitMetrics(ctx, workspaceName, body);
    ctx.log("Metrics successfully submitted to datadog");
  } catch (e) {
    ctx.log(`Error submitting metrics`, e);
    ctx.res = { status: 500, body: { message: e as Error } };
    return;
  }

  // end request
  ctx.res = {
    body: {
      message: `Log entry created for workspace ${workspaceName} of project ${project.name}`,
    },
  };
});

export const mainHandler = app;
