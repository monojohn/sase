import escapeRegex from "escape-string-regexp";
import ProjectModel from "../../../services/dbConnector/models/projectModel";

export const getProjectByWorkspaceName = async (workspaceName: string) =>
  ProjectModel.findOne({ workspaceUrl: new RegExp(`${escapeRegex(workspaceName)}$`, "i") }).lean();
