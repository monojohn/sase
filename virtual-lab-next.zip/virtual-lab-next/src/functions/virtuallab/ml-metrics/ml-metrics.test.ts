import { jest } from "@jest/globals";
import jwt from "jsonwebtoken";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import MLMetrics from "../../../features/mlMetrics/mlMetrics";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./ml-metrics";

const TEST_WORKSPACE_NAME = "mlw-testWorkspace";
const authorization = jwt.sign(
  { upn: "upn", oid: "oid", xms_mirid: `/${TEST_WORKSPACE_NAME}` },
  "secret",
);

const ctx = getCtx({ method: "POST", authorization, name: "ML Metrics" });

describe("ML Metrics", () => {
  beforeAll(() => {
    jest.spyOn(MLMetrics, "getClient").mockImplementation(
      () =>
        new (class Test {
          // eslint-disable-next-line class-methods-use-this
          submitMetrics() {}
        })() as any,
    );
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(MLMetrics, "getClient").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("POST ml metrics", () => {
    beforeEach(() => {
      ctx.req.body = undefined;
      ctx.res = undefined;
    });

    it("Returns 400 when body is xms_mirid is missing from session", async () => {
      const authHeader = ctx.req.headers.authorization;
      ctx.req.headers.authorization = jwt.sign({ upn: "upn", oid: "oid" }, "secret");

      await mainHandler(ctx);

      // restore header
      ctx.req.headers.authorization = authHeader;

      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual("invalid or missing xms_mirid field in session");
    });

    it("Returns 400 when body is undefined", async () => {
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual("No data received in request body");
    });

    it("Returns 400 when metrics names are not correct", async () => {
      ctx.req.body = { body: { series: [{ metric: "test" }] } };

      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual(
        `Incorrect metric name detected: test. Expected name to start with 'vl-metrics.${TEST_WORKSPACE_NAME}'`,
      );
    });

    it("Returns 404 when workspace is not provided", async () => {
      ctx.req.body = { body: { series: [{ metric: `vl-metrics.${TEST_WORKSPACE_NAME}` }] } };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(404);
      expect(ctx.res.body.message).toEqual(
        `No project found for workspace '${TEST_WORKSPACE_NAME}'`,
      );
    });

    it("Returns 500 when metric submission fails", async () => {
      jest.spyOn(MLMetrics, "submitMetrics").mockImplementation(async () => {
        throw new Error("Fake error");
      });

      await createTestProject({ workspaceUrl: TEST_WORKSPACE_NAME });

      ctx.req.body = { body: { series: [{ metric: `vl-metrics.${TEST_WORKSPACE_NAME}` }] } };
      await mainHandler(ctx);

      jest.spyOn(MLMetrics, "submitMetrics").mockRestore();

      expect(ctx.res.status).toEqual(500);
      expect(ctx.res.body?.message).not.toBeUndefined();
    });

    it("Returns 200 when metric submission succeeds", async () => {
      await createTestProject({ workspaceUrl: TEST_WORKSPACE_NAME });

      ctx.req.body = { body: { series: [{ metric: `vl-metrics.${TEST_WORKSPACE_NAME}` }] } };
      await mainHandler(ctx);

      const result = ctx.res.body?.message as string;
      expect(result?.startsWith("Log entry created")).toBe(true);
    });
  });
});
