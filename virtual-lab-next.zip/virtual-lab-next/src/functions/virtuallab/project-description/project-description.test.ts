import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-description";

const ctx = getCtx({ name: "Project description" });

describe("Project description", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params.pid = testProject._id;
  });

  describe("GET project description", () => {
    it("Returns project description", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body?.description).toBe(testProject.description);
    });
  });

  describe("PATCH project description", () => {
    beforeEach(() => {
      ctx.req.method = "PATCH";
    });

    it("Returns 400 when invalid description type is passed", async () => {
      ctx.req.body = { description: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Updates project description", async () => {
      const description = "desc test";
      ctx.req.body = { description };

      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined); // represents success

      // check project was updated
      const proj = await ProjectModel.findById(testProject?._id);
      expect(proj?.description).toBe(description);
    });
  });
});
