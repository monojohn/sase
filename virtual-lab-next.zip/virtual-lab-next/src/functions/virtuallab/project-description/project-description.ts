/* eslint-disable consistent-return */
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = { status: 200, body: { description: project.description } };
    }),
  ),

  { allowNonEscb: true },
);

type PatchProps = {
  body?: Partial<Project>;
  params: { pid: string };
};

app.patch<PatchProps>(
  withProject(
    withMemberPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        const body = ctx.req.body as Partial<Project> | undefined;
        const description = body?.description;
        const { _id: pid, name: projectName } = project;

        ctx.log(`Updating description of ${projectName}`);

        if (typeof description !== "string") {
          const message = `Error updating description of ${projectName}: "${typeof description}" is invalid`;
          ctx.log(message, { value: description });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        await ProjectModel.updateOne({ _id: pid }, { $set: { description } });

        // notify team users
        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          type: ActionType.UPDATE_DESCRIPTION,
          project: { id: pid, name: projectName },
          target: { id: "ProjectDescription", name: description },
          triggerer: { id: session.oid, displayName: session.name },
        });
      }, ActionType.UPDATE_DESCRIPTION),
    ),
  ),
  { allowNonEscb: true },
);
export const mainHandler = app;
