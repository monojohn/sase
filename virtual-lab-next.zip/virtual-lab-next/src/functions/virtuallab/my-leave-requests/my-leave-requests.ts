import { withPermissions } from "../../../middleware/withPermissions";
import LeaveProjectRequestModel from "../../../services/dbConnector/models/leaveProjectRequestModel";
import { ProjectRequest } from "../../../services/dbConnector/models/projectRequest";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
};

/**
 * Get my leave requests
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { oid } = ctx.session;
    let body: ProjectRequest | ProjectRequest[];

    if (id) {
      const item = await LeaveProjectRequestModel.findOne({ _id: id, oid }).lean();
      if (!item) {
        // return 404 when item is not found
        ctx.res = { status: 404, body: { message: `Request with Id ${id} not found` } };
        return;
      }

      body = item;
    } else {
      body = await LeaveProjectRequestModel.find({ oid }).lean();
    }

    ctx.res = { body };
  }),
  { allowNonEscb: true },
);

/**
 * remove leave request
 */
app.delete<Props>(
  withPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { oid } = ctx.session;

    await LeaveProjectRequestModel.deleteOne({ _id: id, oid }).lean();
  }),
);

export const mainHandler = app;
