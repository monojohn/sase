import { jest } from "@jest/globals";
import { genId, getCtx } from "../../../../jest/helpers";
import LeaveProjectRequestModel from "../../../services/dbConnector/models/leaveProjectRequestModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-leave-requests";

const ctx = getCtx({ name: "My leave requests" });

describe("My leave requests", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.params = {};
    ctx.res = undefined;
  });

  describe("GET my leave requests", () => {
    it("Returns all requests", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual([]);
    });

    it("Returns 404 when an id is sent but not found", async () => {
      ctx.req.params.id = genId();
      ctx.req.params.pid = await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 404,
        body: { message: `Request with Id ${ctx.req.params.id} not found` },
      });
    });

    it("Returns favorite by id", async () => {
      const request = await LeaveProjectRequestModel.create({
        oid: ctx.authOid,
        pid: "pid",
        name: "name",
      });

      ctx.req.params.id = request._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual(request.toObject());
    });
  });

  describe("DELETE leave request", () => {
    it("Returns 200 when request does not exist", async () => {
      ctx.req.method = "DELETE";
      ctx.req.params.id = genId();

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);
    });

    it("Returns 200 when favorite exists and is deleted", async () => {
      ctx.req.method = "DELETE";

      const request = await LeaveProjectRequestModel.create({
        oid: ctx.authOid,
        pid: "pid2",
        name: "name",
      });

      const reqId = request._id.toString();
      ctx.req.params.id = reqId;

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      expect(await LeaveProjectRequestModel.findById(reqId)).toBeNull();
    });
  });
});
