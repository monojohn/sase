/* eslint-disable consistent-return */
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { Resource } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { isResourceArray } from "../../../utils/typeValidator";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = { body: { resources: project.resources } };
    }),
  ),
  { allowNonEscb: true },
);

type PutProps = {
  body: { resources: Resource[] };
  params: { pid: string };
};

app.put<PutProps>(
  withProject(
    withMemberPermissions(
      withActionLogging(async (ctx) => {
        const { project } = ctx;
        const request = ctx.req as PutProps;
        const resources = request.body?.resources;

        if (!isResourceArray(resources)) {
          ctx.res = {
            status: 400,
            body: {
              message:
                "Invalid resource(s) sent. body must be { resources: { text: string, url: string }[] }",
            },
          };
          return;
        }

        await ProjectModel.updateOne({ _id: project._id }, { $set: { resources } });
      }, ActionType.EDIT_PROJECT_RESOURCES),
    ),
  ),
  { allowNonEscb: true },
);
export const mainHandler = app;
