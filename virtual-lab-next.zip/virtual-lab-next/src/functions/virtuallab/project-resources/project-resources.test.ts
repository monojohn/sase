import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project, Resource } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-resources";

const ctx = getCtx({ name: "Project resources" });

describe("Project resources", () => {
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  describe("GET project resources", () => {
    it("Returns the project's resources", async () => {
      await mainHandler(ctx);

      expect(ctx.res).toEqual({ body: { resources: [] } });
    });
  });

  describe("PUT project resources", () => {
    beforeAll(async () => {
      ctx.req.method = "PUT";
    });

    it("Returns 400 when invalid resource is passed", async () => {
      ctx.req.body = { resources: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Updates project resource", async () => {
      const resource: Resource = { text: "text", url: "url" };
      ctx.req.body = { resources: [resource] };

      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined); // represents success

      // check project was updated
      const proj = await ProjectModel.findById(testProject?._id);
      const [projResource] = proj!.resources;
      expect(projResource.text).toEqual(resource.text);
      expect(projResource.url).toEqual(resource.url);
    });
  });
});
