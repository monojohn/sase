import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-users";
import { Project } from "../../../services/dbConnector/models/project";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";

const ctx = getCtx({ name: "Project users" });

describe("Project users", () => {
  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getAllGroupUsers").mockImplementation(
      async () =>
        [
          { displayName: "user1", mail: testEmail, identities: [], id: "user1" },
          { displayName: "user2", mail: testEmail, identities: [], id: "user2" },
        ] as any,
    );
    jest
      .spyOn(GraphService, "getUsersProps")
      .mockImplementation(
        async () => [{ displayName: "user3", mail: testEmail, identities: [], id: "user3" }] as any,
      );
    jest.spyOn(GraphService, "getUserDepartment").mockImplementation(async () => "org");
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getAllGroupUsers").mockRestore();
    jest.spyOn(GraphService, "getUserDepartment").mockRestore();
    jest.spyOn(GraphService, "getUsersProps").mockRestore();
  });

  it("Returns all users", async () => {
    await OwnershipInviteModel.create({
      invitee: "user3",
      projectName: "project",
      inviterName: "owner",
      inviter: "inviter",
      pid: testProject._id,
    });

    await JoinProjectRequestModel.create({
      oid: "user3",
      pid: testProject._id,
      name: "name",
    });

    ctx.req.params = { pid: testProject._id };
    await mainHandler(ctx);

    expect(ctx.res.body.accessRequests.length).toBe(1);
    expect(ctx.res.body.ownershipInvitations.length).toBe(1);
    expect(ctx.res.body.owners.length).toBe(2);
    expect(ctx.res.body.members.length).toBe(2);
  });
});
