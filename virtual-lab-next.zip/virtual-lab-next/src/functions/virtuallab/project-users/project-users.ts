import { withViewPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { ProjectInvitationStatus } from "../../../services/dbConnector/enums";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import GraphService from "../../../services/graphService/graphService";
import { formatUser } from "../../../services/graphService/helpers";
import { GraphUser, SimpleGraphUser } from "../../../services/graphService/types";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

export type GetProjects = {
  query: {
    select?: string;
  };
};

/**
 * Get project users
 */
app.get<GetProjects>(
  withProject(
    withViewPermissions(async (ctx) => {
      const { _id: pid } = ctx.project;
      const props: (keyof GraphUser)[] = [
        "displayName",
        "userType",
        "mail",
        "otherMails",
        "identities",
        "id",
        "department",
      ];

      const [accessRequestsDocs, ownershipInvitationsDocs] = await Promise.all([
        JoinProjectRequestModel.find({ pid }),
        OwnershipInviteModel.find({
          pid,
          status: {
            $in: [
              ProjectInvitationStatus.OPEN,
              ProjectInvitationStatus.ACCEPTING,
              ProjectInvitationStatus.AWAITING_APPROVAL,
            ],
          },
        }),
      ]);

      function mapAccessRequest(accessRequestUser: SimpleGraphUser) {
        const request = accessRequestsDocs.find(({ oid }) => oid === accessRequestUser.id);
        if (request) {
          return {
            ...formatUser(accessRequestUser),
            message: request.message,
            id: request._id,
          };
        }
      }

      function mapOwnershipInvitation(ownerhipInvitationUser: SimpleGraphUser) {
        const invite = ownershipInvitationsDocs.find(
          ({ invitee }) => invitee === ownerhipInvitationUser.id,
        );
        if (invite) {
          return {
            ...formatUser(ownerhipInvitationUser),
            status: invite.status ?? ProjectInvitationStatus.OPEN,
            id: invite._id,
          };
        }
      }

      const [owners, members, accessRequests, ownershipInvitations] = await Promise.all([
        GraphService.getAllGroupUsers(ctx, ctx.project.ownersGroupId, props),
        GraphService.getAllGroupUsers(ctx, ctx.project.membersGroupId, props),
        GraphService.getUsersProps(
          ctx,
          accessRequestsDocs.map(({ oid }) => oid),
          props,
        ),
        GraphService.getUsersProps(
          ctx,
          ownershipInvitationsDocs.map(({ invitee }) => invitee),
          props,
        ),
      ]);

      const ownersWithOrg = await Promise.all(
        owners
          .toSorted((a, b) => a.displayName.localeCompare(b.displayName))
          .map(async (user) => ({
            ...formatUser(user),
            org: await GraphService.getUserDepartment(ctx, user),
          })),
      );

      const body = {
        owners: ownersWithOrg,
        members: members
          .toSorted((a, b) => a.displayName.localeCompare(b.displayName))
          .map((user) => formatUser(user)),
        accessRequests: accessRequests
          .filter(({ id }) => !owners.map(({ id: ownerId }) => ownerId).includes(id))
          .sort((a, b) => a.displayName.localeCompare(b.displayName))
          .map((user) => mapAccessRequest(user)),
        ownershipInvitations: ownershipInvitations
          .filter(({ id }) => !owners.map(({ id: ownerId }) => ownerId).includes(id))
          .sort((a, b) => a.displayName.localeCompare(b.displayName))
          .map((user) => mapOwnershipInvitation(user)),
      };

      ctx.res = {
        body,
      };
    }),
  ),
);

export const mainHandler = app;
