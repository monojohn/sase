import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { isStringArray } from "../../../utils/typeValidator";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = { body: { tags: project.tags } };
    }),
  ),
  { allowNonEscb: true },
);

type PutProps = {
  body: { tags: string[] };
  params: { pid: string };
};

app.put<PutProps>(
  withProject(
    withMemberPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        const request = ctx.req as PutProps;
        const tags = request.body?.tags;

        if (!isStringArray(tags)) {
          ctx.res = {
            status: 400,
            body: { message: "Invalid resource(s) sent. body must be { tags: string[] }" },
          };
          return;
        }

        await ProjectModel.updateOne({ _id: project._id }, { $set: { tags } });

        // notify team users
        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          type: ActionType.UPDATE_TAGS,
          project: { id: project._id, name: project.name },
          target: { id: "tags", name: JSON.stringify(tags) },
          triggerer: { id: session.oid, displayName: session.name },
        });
      }, ActionType.UPDATE_TAGS),
    ),
  ),
  { allowNonEscb: true },
);
export const mainHandler = app;
