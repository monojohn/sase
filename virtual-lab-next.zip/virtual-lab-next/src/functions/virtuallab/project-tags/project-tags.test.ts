import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-tags";

const ctx = getCtx({ name: "Project tags" });

describe("Project tags", () => {
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  describe("GET project tags", () => {
    it("Returns the project's tags", async () => {
      await mainHandler(ctx);
      expect(ctx.res).toEqual({ body: { tags: [] } });
    });
  });

  describe("PUT project tags", () => {
    beforeAll(async () => {
      ctx.req.method = "PUT";
    });

    it("Returns 400 when invalid tags are passed", async () => {
      ctx.req.body = { tags: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Updates project tags", async () => {
      const tags = ["tag1", "tag2"];
      ctx.req.body = { tags };

      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined); // represents success

      // check project was updated
      const proj = await ProjectModel.findById(testProject?._id);
      expect(proj!.tags).toEqual(tags);
    });
  });
});
