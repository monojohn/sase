import { EmailType } from "../../../features/notificationEntitlements/enums";
import NotificationService from "../../../features/notificationEntitlements/notificationService";
import {
  acceptProjectInvitation,
  acceptProjectInvitationWithApproval,
} from "../../../features/projectInvitations/acceptProjectInvitation";
import { sendRejectOwnershipNotifications } from "../../../features/projectInvitations/notificationService";
import { ActionType } from "../../../features/userActions/enums";
import { updateAction } from "../../../features/userActions/userActions";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withPermissions } from "../../../middleware/withPermissions";
import { ProjectInvitationStatus, UpdateStatus } from "../../../services/dbConnector/enums";
import { OwnershipInvite } from "../../../services/dbConnector/models/ownershipInvite";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import { requiresManagerApproval } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
};

const getMinutesSince = (modified: Date) => (Date.now() - modified.getTime()) / 1000 / 60;

/**
 * Get my project invitations
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { oid } = ctx.session;
    let body: OwnershipInvite | OwnershipInvite[];

    if (id) {
      const item = await OwnershipInviteModel.findOne({ _id: id, invitee: oid }).lean();
      if (!item) {
        // return 404 when item is not found
        ctx.res = { status: 404, body: { message: `Request with Id ${id} not found` } };
        return;
      }

      body = item;
    } else {
      body = await OwnershipInviteModel.find({
        invitee: oid,
        status: { $in: [ProjectInvitationStatus.OPEN, ProjectInvitationStatus.ACCEPTING] },
      });
    }

    ctx.res = { body };
  }),
);

/**
 * Accept project invitation
 */
app.patch<Props>(
  withPermissions(
    // prettier-ignore
    withActionLogging(async (ctx) => { // NOSONAR
    const { id } = ctx.req.params;
    const { oid } = ctx.session;

    ctx.log(`Accepting invitation #${id}`);
    const invite = await OwnershipInviteModel.findOne({ _id: id, invitee: oid }).lean();
    if (!invite) {
      // return 404 when item is not found or if user doesn't have permissions to see it
      ctx.res = { status: 404, body: { message: `Invitation with Id ${id} not found` } };
      return;
    }

    // if the invitation status is not open
    if (invite.status !== ProjectInvitationStatus.OPEN) {
      if (invite.status === ProjectInvitationStatus.ACCEPTED) {
        // prevent double accepts
        ctx.res = { status: 200 };
        return;
      }

      if (invite.status !== ProjectInvitationStatus.ACCEPTING) {
        // return 400 when status is immutable
        ctx.res = {
          status: 400,
          body: { message: `Invalid invitation state: ${invite.status}` },
        };
        return;
      }

      // if ACCEPTING state has been set less than 5 min ago, prevent a 2nd acceptance
      if (getMinutesSince(invite.updatedAt) < 5) {
        ctx.res = { status: 200 };
        return;
      }
      // otherwise allow acceptance to happen again
    }

    const { pid } = invite;
    const project = await ProjectModel.findById(invite.pid);
    if (!project) {
      const error = `Project ${pid} not found, invalidating request.`;
      ctx.log(error);
      // invalidate invitation if project does not exist
      await OwnershipInviteModel.updateOne(
        { pid },
        { $set: { status: ProjectInvitationStatus.INVALID } },
      );

      ctx.res = { status: 400, body: { error, message: error } };
      return;
    }

    if (project.rolesAndEntitlements?.length) {
      // only check if there is something to check
      const { analysis, passed } = await ProjectService.checkProjectRolesAndEntitlementsByOid(
        ctx,
        [oid],
        project,
      );

      if (!passed) {
        const user = await GraphService.getUserProps(ctx, oid, ["id", "displayName", "mail", "otherMails", "identities", "userPrincipalName", "userType"]);
        await NotificationService.notifyUsers(ctx, [user], analysis, EmailType.NEW_USERS, project);
        ctx.res = { status: 400, body: {...analysis, message: analysis.errors.join(". ") } };
        return;
      }
    }

    // update action
    ctx.log(`Updating action`);
    await updateAction(ctx, { target: oid, pid });

    const { ownersGroupId } = project;
    const [ecbOwners, invitee] = await Promise.all([GraphService.getGroupMemberUsers(ctx, ownersGroupId, ["id"]), GraphService.getUserProps(ctx, invite.invitee, ["userType"])])
    const userType = (ecbOwners.length || invitee.userType === "Member") ? "Member" : "Guest";

    // if it requires approval, create request in IGAM
    if (requiresManagerApproval(project.confidentialityLevel, userType)) {
      const status = await acceptProjectInvitationWithApproval(ctx, invite, project, oid);
      ctx.res = {
        status: 200,
        body: { status },
      };
      return;
    }

    // accept invitation if all is well
    ctx.log(`Accepting invitation`);
    await acceptProjectInvitation(ctx, invite, project);
    ctx.res = {
      status: 200,
      body: { status: UpdateStatus.DONE },
    }

  }, ActionType.ACCEPT_OWNERSHIP),
  ),
);

/**
 * Reject invite
 */
app.delete<Props>(
  withPermissions(
    withActionLogging(async (ctx) => {
      const { id } = ctx.req.params;
      const { oid } = ctx.session;

      const invite = await OwnershipInviteModel.findOne({ _id: id, invitee: oid }).lean();
      if (!invite) {
        // return 404 when item is not found or if user doesn't have permissions to see it
        ctx.res = { status: 404, body: { message: `Invitation with Id ${id} not found` } };
        return;
      }

      // if invitation status is not open, reject change
      if (invite.status !== ProjectInvitationStatus.OPEN) {
        ctx.res = {
          status: 400,
          body: { message: `Invitation ${id} already has status ${invite.status}` },
        };
        return;
      }

      const project = await ProjectModel.findById(invite.pid);
      if (!project) {
        // invalidate all invitations if project does not exist
        await OwnershipInviteModel.updateOne(
          { pid: invite.pid },
          { $set: { status: ProjectInvitationStatus.INVALID } },
        );

        ctx.res = {
          status: 400,
          body: { message: `Project with id ${invite.pid} does not exist` },
        };
        return;
      }

      ctx.log(`Setting request ${id} to rejected`);
      await OwnershipInviteModel.updateOne(
        { _id: id },
        { $set: { status: ProjectInvitationStatus.REJECTED } },
      );

      // update action targets
      ctx.log(`Updating action`);
      await updateAction(ctx, { target: ctx.session.oid, pid: project._id });

      // notify users
      ctx.log(`Notifying users`);
      await sendRejectOwnershipNotifications(ctx, invite.invitee, project);
    }, ActionType.REJECT_OWNERSHIP),
  ),
);

export const mainHandler = app;
