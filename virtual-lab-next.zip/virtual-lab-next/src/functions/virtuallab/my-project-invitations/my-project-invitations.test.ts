import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import {
  ConfidentialityLevel,
  ProjectInvitationStatus,
  RequestStatus,
  RequestType,
  UpdateStatus,
} from "../../../services/dbConnector/enums";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import { mainHandler } from "./my-project-invitations";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import OrgService from "../../../services/igamService/orgService";

const { testEmail } = global;
const ctx = getCtx({ name: "My project invite" });

describe("My project invite", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(GraphService, "getSimpleUser").mockImplementation(async () => ({
      id: "id",
      displayName: "test user",
      mail: testEmail,
      otherMails: ["otherMails"],
      identities: [],
    }));
    jest.spyOn(GraphService, "getGroupMemberUsers").mockImplementation(async () => [] as any);
    jest.spyOn(GraphService, "getUserProps").mockImplementation(
      async () =>
        ({
          identities: [],
          mail: "mail",
          displayName: "name",
        }) as any,
    );
    jest.spyOn(EntitlementsService, "get").mockImplementation(async () => [{ owner: "vl" }] as any);
    jest
      .spyOn(EntitlementsService, "addUser")
      .mockImplementation(async () => [[{ requestId: "123" }]] as any);
    jest.spyOn(OrgService, "getApproversEmails").mockImplementation(async () => ["mail"]);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(GraphService, "getSimpleUser").mockRestore();
    jest.spyOn(GraphService, "getGroupMemberUsers").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(EntitlementsService, "get").mockRestore();
    jest.spyOn(EntitlementsService, "addUser").mockRestore();
    jest.spyOn(OrgService, "getApproversEmails").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.params = {};
    ctx.req.body = {};
  });

  describe("GET project invite(s)", () => {
    it("Returns all project invites", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual([]);
    });

    it("Returns 404 if invite does not exist", async () => {
      ctx.req.params.id = genId();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(404);
    });

    it("Returns invite by id", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: "pid",
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual(invite.toObject());
    });
  });

  describe("PATCH project invite", () => {
    beforeAll(() => {
      ctx.req.method = "PATCH";
    });

    afterAll(() => {});

    it("Returns 404 if no invite exists", async () => {
      ctx.req.params.id = genId();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(404);
    });

    it("Returns 400 if project does not exist", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: genId(),
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);

      // expect status to be invalidated
      const updatedInvite = await OwnershipInviteModel.findById(invite._id);
      expect(updatedInvite?.status).toEqual(ProjectInvitationStatus.INVALID);
    });

    it("Returns 400 if invite status is CANCELLED", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: genId(),
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
        status: ProjectInvitationStatus.CANCELLED,
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `Invalid invitation state: ${invite.status}` },
      });
    });

    it("Returns 200 if invite status is ACCEPTED", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: genId(),
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
        status: ProjectInvitationStatus.ACCEPTED,
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
    });

    it("Returns 200 if invite status is ACCEPTING and 5min haven't passed", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: genId(),
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
        status: ProjectInvitationStatus.ACCEPTING,
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
    });

    it("Returns 400 if Entitlement check failed", async () => {
      const analysis = {
        missingUsers: [],
        missingRolesAndEntitlements: {},
        missingConditions: {
          Guest: [],
          Member: [],
        },
        errors: ["error"],
        errorUsers: [],
      };
      jest
        .spyOn(ProjectService, "checkProjectRolesAndEntitlementsByOid")
        .mockImplementationOnce(async () => ({ passed: false, analysis }));

      const project = await createTestProject({
        rolesAndEntitlements: [{ entitlements: ["ent"], roles: [], iamRoles: [] }],
      });
      const pid = project._id.toString();

      // create invite to accept
      const invite = await OwnershipInviteModel.create({
        pid,
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res.body.message).toBe("error");
    });

    it("Returns 200 if acceptance worked", async () => {
      jest
        .spyOn(ProjectService, "checkProjectRolesAndEntitlementsByOid")
        .mockImplementationOnce(async () => ({ passed: true }) as any);

      jest.spyOn(ProjectService, "addUser").mockImplementationOnce(async () => undefined);

      const project = await createTestProject();
      const pid = project._id.toString();

      // create invite to accept
      const invite = await OwnershipInviteModel.create({
        pid,
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.body.status).toBe(UpdateStatus.DONE);
    });

    it("Returns 200 if acceptance worked with pending approval", async () => {
      jest
        .spyOn(ProjectService, "checkProjectRolesAndEntitlementsByOid")
        .mockImplementationOnce(async () => ({ passed: true }) as any);

      jest.spyOn(ProjectService, "addUser").mockImplementationOnce(async () => undefined);
      jest
        .spyOn(GraphService, "getUserProps")
        .mockImplementationOnce(async () => ({ userType: "Member" }) as any);

      const project = await createTestProject({
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      });
      const pid = project._id.toString();

      // create invite to accept
      const invite = await OwnershipInviteModel.create({
        pid,
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.body.status).toBe(UpdateStatus.PENDING_APPROVAL);
    });

    it("Returns 200 if acceptance worked with pending request creation", async () => {
      jest
        .spyOn(ProjectService, "checkProjectRolesAndEntitlementsByOid")
        .mockImplementationOnce(async () => ({ passed: true }) as any);

      jest.spyOn(ProjectService, "addUser").mockImplementationOnce(async () => undefined);
      jest
        .spyOn(GraphService, "getUserProps")
        .mockImplementationOnce(async () => ({ userType: "Member" }) as any);

      const project = await createTestProject({
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      });
      const pid = project._id.toString();

      // create invite to accept
      const invite = await OwnershipInviteModel.create({
        pid,
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: project._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.body.status).toBe(UpdateStatus.PENDING_REQUEST_CREATION);
    });
  });

  describe("DELETE project invite", () => {
    beforeAll(() => {
      ctx.req.method = "DELETE";
    });

    it("Returns 404 if no invite exists", async () => {
      ctx.req.params.id = genId();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(404);
    });

    it("Returns 400 if invite status not null", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: "pid2",
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
        status: ProjectInvitationStatus.ACCEPTED,
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 if project does not exist", async () => {
      const invite = await OwnershipInviteModel.create({
        pid: "41224d776a326fb40f000002",
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);

      // expect status to be invalidated
      const updatedInvite = await OwnershipInviteModel.findById(invite._id);
      expect(updatedInvite?.status).toEqual(ProjectInvitationStatus.INVALID);
    });

    it("Successfully handles a valid rejection", async () => {
      const project = await createTestProject();
      const pid = project._id.toString();

      // create invite to reject
      const invite = await OwnershipInviteModel.create({
        pid,
        invitee: ctx.authOid,
        inviter: "inviter",
        inviterName: "inviterName",
        projectName: "projectName",
      });

      ctx.req.params.id = invite._id.toString();
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);

      const updatedInvite = await OwnershipInviteModel.findById(invite._id);
      expect(updatedInvite?.status).toEqual(ProjectInvitationStatus.REJECTED);
    });
  });
});
