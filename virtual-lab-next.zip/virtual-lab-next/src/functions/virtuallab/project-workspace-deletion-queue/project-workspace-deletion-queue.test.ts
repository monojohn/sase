import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { DeleteWorkspaceProps, mainHandler } from "./project-workspace-deletion-queue";
import WorkspaceDeletionService from "../../../features/machineLearningDeletion";

const ctx = getCtx({ name: "Project workspace deletion queue" });

describe("Project workspace deletion queue", () => {
  describe("Data validation", () => {
    let testProject: Project;
    const props: DeleteWorkspaceProps = { oid: ctx.authOid, pid: "" };
    const deletionMock = jest.fn(async () => void 0);

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({ owners: [ctx.authOid] });
      props.pid = testProject._id;
      jest
        .spyOn(GraphService, "getUser")
        .mockImplementation(
          async () => ({ displayName: "user", userPrincipalName: "user" }) as any,
        );
      jest.spyOn(WorkspaceDeletionService, "delete").mockImplementation(deletionMock);
      jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    });

    afterAll(() => {
      jest.spyOn(GraphService, "getUser").mockRestore();
      jest.spyOn(WorkspaceDeletionService, "delete").mockRestore();
      jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    });

    it("Returns early when project doesn't exists", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logWarning").mockImplementationOnce(slackMock);
      const pid = genId();
      await mainHandler(ctx, { ...props, pid });

      expect(slackMock).toHaveBeenLastCalledWith(
        ctx,
        new Error(`No ML Workspace exists for project ${pid}: undefined. Skipping deletion`),
      );
    });

    it("Returns early when project doesn't have a workspace", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logWarning").mockImplementationOnce(slackMock);

      await mainHandler(ctx, props);

      expect(slackMock).toHaveBeenLastCalledWith(
        ctx,
        new Error(
          `No ML Workspace exists for project ${props.pid}: ${testProject.name}. Skipping deletion`,
        ),
      );
    });

    it("Triggers workspace deletion", async () => {
      testProject = await createTestProject({
        owners: [ctx.authOid],
        workspaceUrl: "workspaceUrl",
      });
      props.pid = testProject._id;
      await mainHandler(ctx, props);
      expect(deletionMock).toHaveBeenCalledTimes(1);
    });
  });

  describe("Error handling", () => {
    let testProject: Project;
    const props: DeleteWorkspaceProps = { oid: ctx.authOid, pid: "" };

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({
        owners: [ctx.authOid],
        workspaceUrl: "workspaceUrl",
      });
      props.pid = testProject._id;
    });

    it("Handles errors", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logError").mockImplementationOnce(slackMock);

      const graphMock = jest.fn(async () => {
        throw new Error("error");
      });
      jest.spyOn(GraphService, "getUser").mockImplementationOnce(graphMock);

      await mainHandler(ctx, props);

      expect(slackMock).toHaveBeenLastCalledWith(
        ctx,
        new Error(`Failed to delete ML workspace of project #${props.pid}`),
      );
    });
  });
});
