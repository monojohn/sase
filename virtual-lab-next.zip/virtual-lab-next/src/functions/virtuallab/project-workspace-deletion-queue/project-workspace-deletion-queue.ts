import { AxiosError } from "axios";
import { MainHandler } from "../../../../@types/types";
import WorkspaceDeletionService from "../../../features/machineLearningDeletion/index";
import { sendWorkspaceDeletedNotifications } from "../../../features/projectWorkspace/workspaceNotifications";
import { Session } from "../../../middleware/withHttpSession";
import { withParamCheck } from "../../../middleware/withParamCheck";
import { withRequestLogging } from "../../../middleware/withRequestLogging";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";

export type DeleteWorkspaceProps = {
  pid: string; // project id for which the workspace should be created
  oid: string; // oid of user who triggered creation
};

const mandatoryProps: (keyof DeleteWorkspaceProps)[] = ["pid", "oid"];

const funcName = "project-workspace-deletion-queue-v2";

const deleteWorkspaceQueue: MainHandler<DeleteWorkspaceProps> = async (ctx, props) => {
  const { pid, oid } = props;
  let project: Project | null = null;

  try {
    ctx.log(`Fetching project by id ${pid}`);
    project = await ProjectModel.findById(pid);
    if (!project?.workspaceUrl) {
      const warning = `No ML Workspace exists for project ${pid}: ${project?.name}. Skipping deletion`;
      ctx.log(warning);
      await SlackService.logWarning(ctx, new Error(warning));
      return true;
    }

    // for notification creation
    const user = await GraphService.getUser(ctx, oid);
    const session: Session = {
      oid,
      name: user.displayName,
      upn: user.userPrincipalName,
    };

    await WorkspaceDeletionService.delete(ctx, project);

    // send notifications
    await sendWorkspaceDeletedNotifications(ctx, project, session);
    return true;
  } catch (e) {
    const err = e as AxiosError<unknown>;
    const prettyError = JSON.stringify(err?.response?.data ?? {}, null, 2);
    const error = `Failed to delete ML workspace of project #${pid}`;
    ctx.log(error, prettyError);

    await SlackService.logError(ctx, new Error(error));
  }
  return false;
};

export const mainHandler = withRequestLogging(
  funcName,
  withParamCheck(funcName, mandatoryProps, deleteWorkspaceQueue),
);
