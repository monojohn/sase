import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { WorkspaceType } from "../../../features/machineLearningCreation/index";
import WorkspaceDeletionService from "../../../features/machineLearningDeletion/index";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { CreateWorkspaceProps, mainHandler } from "./project-workspace-queue";

const ctx = getCtx({ name: "Project workspace creation queue" });

describe("Project workspace creation queue", () => {
  describe("Data validation", () => {
    let testProject: Project;
    const props: CreateWorkspaceProps = {
      oid: ctx.authOid,
      pid: "",
      workspaceType: WorkspaceType.SECURED,
      aiUsage: false,
    };

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({
        owners: [ctx.authOid],
        workspaceUrl: "https://workspaceUrl",
      });

      props.pid = testProject._id;
    });

    it("Returns early when project doesn't exists", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logWarning").mockImplementationOnce(slackMock);
      const pid = genId();
      await mainHandler(ctx, { ...props, pid });

      expect(slackMock).toHaveBeenLastCalledWith(
        ctx,
        new Error(`Project with id ${pid} not found, skipping creation`),
      );
    });

    it("Returns early when project doesn't have a workspace", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logWarning").mockImplementationOnce(slackMock);

      await mainHandler(ctx, props);

      expect(slackMock).toHaveBeenLastCalledWith(
        ctx,
        new Error(
          `ML Workspace already exists for project ${props.pid}: ${testProject.name}. Skipping creation`,
        ),
      );
    });
  });

  describe("Error handling", () => {
    let testProject: Project;

    const props: CreateWorkspaceProps = {
      oid: ctx.authOid,
      pid: "",
      workspaceType: WorkspaceType.SECURED,
      aiUsage: false,
    };

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({
        owners: [ctx.authOid],
        workspaceUrl: "workspaceUrl",
      });
      props.pid = testProject._id;
    });

    it("Handles errors", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logError").mockImplementationOnce(slackMock);
      jest.spyOn(WorkspaceDeletionService, "delete").mockImplementationOnce(async () => void 0);

      const graphMock = jest.fn(async () => {
        throw new Error("error");
      });
      jest.spyOn(GraphService, "getUser").mockImplementationOnce(graphMock);

      await mainHandler(ctx, props);

      expect(slackMock).toHaveBeenLastCalledWith(
        ctx,
        new Error(`Failed to create ML workspace for project #${props.pid}`),
      );
    });
  });
});
