import { AxiosError } from "axios";
import { MainHandler } from "../../../../@types/types";
import { WorkspaceType, createMlWorkspace } from "../../../features/machineLearningCreation/index";
import WorkspaceDeletionService from "../../../features/machineLearningDeletion/index";
import { sendWorkspaceCreatedNotifications } from "../../../features/projectWorkspace/workspaceNotifications";
import { Session } from "../../../middleware/withHttpSession";
import { withParamCheck } from "../../../middleware/withParamCheck";
import { withRequestLogging } from "../../../middleware/withRequestLogging";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { AiAct, BusinessRisk, GdprAssessment } from "../../../services/dbConnector/enums";
import NotificationService from "../../../features/openAIUseCase/notificationService";
import { getEmailOfUser } from "../../../utils/helpers";
import ProjectService from "../../../services/projectService/projectService";

export type CreateWorkspaceProps = {
  pid: string; // project id for which the workspace should be created
  oid: string; // oid of user who triggered creation
  workspaceType: WorkspaceType;
  workspaceExploratoryJustification?: string;
  aiUsage: boolean;
  aiModels?: string;
  openAiConnection?: boolean;
  ecbContact?: boolean;
  aiUseCaseId?: string;
  gdpr?: GdprAssessment;
  aiAct?: AiAct;
  businessRisk?: BusinessRisk;
};

const mandatoryProps: (keyof CreateWorkspaceProps)[] = ["pid"];

const funcName = "project-workspace-queue";

const createWorkspace: MainHandler<CreateWorkspaceProps> = async (ctx, props) => {
  const {
    pid,
    oid,
    workspaceType,
    workspaceExploratoryJustification,
    aiUsage,
    aiModels,
    openAiConnection,
    ecbContact,
    aiUseCaseId,
    gdpr,
    aiAct,
    businessRisk,
  } = props;

  ctx.log(`Fetching project by id ${pid}`);
  const project = await ProjectModel.findById(pid);
  if (!project) {
    const warning = `Project with id ${pid} not found, skipping creation`;
    ctx.log(warning);
    await SlackService.logWarning(ctx, new Error(warning));
    return true;
  }

  try {
    if (project?.workspaceUrl?.startsWith("http")) {
      const warning = `ML Workspace already exists for project ${pid}: ${project.name}. Skipping creation`;
      ctx.log(warning);
      await SlackService.logWarning(ctx, new Error(warning));
      return true;
    }

    // for notification creation
    const user = await GraphService.getUserProps(ctx, oid, [
      "displayName",
      "userPrincipalName",
      "mail",
      "otherMails",
      "identities",
      "userType",
    ]);
    const session: Session = { oid, name: user.displayName, upn: user.userPrincipalName };

    // set prop so UI can show
    await ProjectModel.updateOne({ _id: pid }, { $set: { workspaceUrl: "BeingCreated" } });

    ctx.log(`Creating ML Workspace`);
    const workspaceUrl = await createMlWorkspace(ctx, {
      workspaceType,
      pid: project._id,
      workspaceExploratoryJustification,
      projectName: project.name,
      aiUsage,
      aiModels,
      openAiConnection,
      ecbContact,
      aiUseCaseId,
      gdpr,
      aiAct,
      businessRisk,
    });

    // send notifications
    if (!aiUsage) {
      await sendWorkspaceCreatedNotifications(ctx, project, workspaceUrl, session);
      return true;
    }

    const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
      "displayName",
      "mail",
      "otherMails",
      "identities",
      "id",
    ]);

    if (!openAiConnection) {
      await NotificationService.sendLlmAwarenessInfoToUsers(ctx, {
        projectName: project.name,
        projectUrl: ProjectService.getProjectUrl(project),
        confidentialityLevel: project.confidentialityLevel,
        emails: users.map((member) => getEmailOfUser(member)),
        created: true,
      });
      return true;
    }

    await NotificationService.sendLlmAwarenessInfoWithOpenAI(ctx, {
      projectName: project.name,
      projectUrl: ProjectService.getProjectUrl(project),
      confidentialityLevel: project.confidentialityLevel,
      emails: users.map((member) => getEmailOfUser(member)),
      created: true,
      ecbContact: user.userType === "Member" || ecbContact || false,
    });

    await NotificationService.sendSubmittedOpenAiUseCaseEmail(ctx, {
      ownerName: user.displayName,
      ownerEmail: getEmailOfUser(user),
      projectName: project.name,
      openAiUseCaseId: aiUseCaseId ?? "N/A",
    });

    return true;
  } catch (e) {
    const err = e as AxiosError<unknown>;
    const prettyError = JSON.stringify(err?.response?.data ?? {}, null, 2);
    const error = `Failed to create ML workspace for project #${pid}`;
    ctx.log(error, prettyError);
    await SlackService.logError(ctx, new Error(error));
    await WorkspaceDeletionService.delete(ctx, project);
  }
  return false;
};

export const mainHandler = withRequestLogging(
  funcName,
  withParamCheck(funcName, mandatoryProps, createWorkspace),
);
