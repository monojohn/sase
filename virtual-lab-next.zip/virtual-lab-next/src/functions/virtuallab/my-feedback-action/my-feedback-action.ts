import { withPermissions } from "../../../middleware/withPermissions";
import UserFeedbackActionModel from "../../../services/dbConnector/models/userFeedbackActionModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type HeadProps = {
  query: {
    survey?: boolean;
  };
};

/**
 * Return 200 if there's at least 1 user feedback entry,
 * otherwise 404
 */
app.head<HeadProps>(
  withPermissions(async (ctx) => {
    const { oid } = ctx.session;
    const survey = ctx.req.query?.survey ?? false;

    ctx.log(`Getting ${survey ? "survey" : "feedback"} action entry for ${oid}`);

    const interaction = await UserFeedbackActionModel.findOne({
      oid: ctx.session.oid,
      survey: survey ? true : { $ne: true },
    }).lean();

    ctx.res = { status: interaction ? 200 : 404 };
  }),
);

type PostProps = {
  survey?: boolean;
};

/**
 * Used for survey, normal feedback action is created in `my-feedback`
 */
app.post<PostProps>(
  withPermissions(async (ctx) => {
    const survey = (ctx.req.body as PostProps)?.survey ?? false;
    ctx.log(`Creating ${survey ? "survey" : "feedback"} action entry`);
    await UserFeedbackActionModel.create({ oid: ctx.session.oid, survey });
  }),
);

export const mainHandler = app;
