import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import UserFeedbackActionModel from "../../../services/dbConnector/models/userFeedbackActionModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-feedback-action";

const ctx = getCtx({ name: "My feedback actions" });
describe("My feedback actions", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.params = {};
    ctx.req.body = {};
    ctx.res = undefined;
  });

  describe("HEAD feedback action", () => {
    beforeAll(() => {
      ctx.req.method = "HEAD";
    });

    it("Returns 404 when no user action exists", async () => {
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(404);
    });

    it("Returns 200 when a user action exists", async () => {
      await UserFeedbackActionModel.create({ oid: ctx.authOid });
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
    });

    it("Returns 200 when a user action exists for survey", async () => {
      await UserFeedbackActionModel.create({ oid: ctx.authOid, survey: true });
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
    });
  });

  describe("POST feedback action", () => {
    beforeAll(() => {
      ctx.req.method = "POST";
    });

    it("Returns 200 when a record is inserted", async () => {
      ctx.req.body = { survey: true };

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      const record = await UserFeedbackActionModel.findOne({
        oid: ctx.authOid,
        survey: true,
      }).lean();
      expect(record).not.toBeNull();
    });
  });
});
