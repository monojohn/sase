import { MlWhitelistRequest } from "../../../features/mlWhitelist/types";
import { withAdminPermissions } from "../../../middleware/withPermissions";
import MlWhitelistRequestModel, {
  WhitelistRequestStatus,
} from "../../../services/dbConnector/models/mlWhitelistRequestModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

const isValidStatus = (status: WhitelistRequestStatus) =>
  Object.values(WhitelistRequestStatus).includes(status);

/**
 * Updates the status of a ML whitelist request and returns the updated item
 */
app.patch<void>(
  withAdminPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { status } = (ctx.req.body ?? {}) as { status?: WhitelistRequestStatus };

    if (!status || !isValidStatus(status)) {
      ctx.res = {
        status: 400,
        body: {
          message: `Invalid status "${status}" received, expected one of ${Object.values(
            WhitelistRequestStatus,
          ).join()}`,
        },
      };
      return;
    }

    const itemToUpdate = await MlWhitelistRequestModel.findById(id);
    if (!itemToUpdate) {
      ctx.res = {
        status: 400,
        body: { message: `Item ${id} not found` },
      };
      return;
    }

    // update and save item
    itemToUpdate.status = status;
    await itemToUpdate.save();

    // return updated item
    ctx.res = {
      body: itemToUpdate.toObject<MlWhitelistRequest>(),
    };
  }),
);

app.delete(
  withAdminPermissions(async (ctx) => {
    const { id } = ctx.req.params;

    const itemToUpdate = await MlWhitelistRequestModel.findById(id);
    if (!itemToUpdate) {
      ctx.res = {
        status: 400,
        body: { message: `Item ${id} not found` },
      };
      return;
    }

    await itemToUpdate.deleteOne();
  }),
);

export const mainHandler = app;
