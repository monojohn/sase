import { jest } from "@jest/globals";
import { genId, getCtx } from "../../../../jest/helpers";
import MlWhitelistRequestModel, {
  MlWhitelistRequest,
  WhitelistRequestStatus,
} from "../../../services/dbConnector/models/mlWhitelistRequestModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./ml-whitelist-requests-id";

describe("ML Whitelist Requests ID", () => {
  const testData: MlWhitelistRequest[] = [
    {
      _id: genId(),
      justification: "justification",
      oid: "oid1",
      urls: "urls",
      pid: "pid",
      status: WhitelistRequestStatus.PENDING,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      _id: genId(),
      justification: "justification",
      oid: "oid2",
      urls: "urls",
      pid: "pid",
      status: WhitelistRequestStatus.PENDING,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: true,
      isNonEscb: false,
      isVlUser: true,
    }));

    // create test entries
    await MlWhitelistRequestModel.create(testData);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("PATCH ml Whitelist Requests", () => {
    const ctx = getCtx({ method: "PATCH", name: "ml-whitelist-request-id" });

    beforeEach(() => {
      ctx.req.params = {};
      ctx.req.body = {};
      ctx.res = undefined;
    });

    it("Returns 400 when an no status is sent", async () => {
      ctx.req.params = { id: testData[0]._id };
      ctx.req.body = undefined;

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Invalid status "${undefined}" received, expected one of ${Object.values(
            WhitelistRequestStatus,
          ).join()}`,
        },
      });
    });

    it("Returns 400 when an invalid status is sent", async () => {
      ctx.req.params = { id: testData[0]._id };
      const badStatus = "badStatus";
      ctx.req.body = { status: badStatus };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Invalid status "${badStatus}" received, expected one of ${Object.values(
            WhitelistRequestStatus,
          ).join()}`,
        },
      });
    });

    it("Returns 400 when an invalid ID is sent", async () => {
      const badId = genId();
      ctx.req.params = { id: badId };
      ctx.req.body = { status: WhitelistRequestStatus.APPROVED };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `Item ${badId} not found` },
      });
    });

    it("Updates the status to Approved", async () => {
      ctx.req.params = { id: testData[0]._id };
      ctx.req.body = { status: WhitelistRequestStatus.APPROVED };

      await mainHandler(ctx);
      expect(`${ctx.res.body._id}`).toEqual(testData[0]._id);
      expect(ctx.res.body.status).toEqual(WhitelistRequestStatus.APPROVED);
    });
  });

  describe("DELETE ml Whitelist Requests", () => {
    const ctx = getCtx({ method: "DELETE", name: "ml-whitelist-request-id" });

    beforeEach(() => {
      ctx.req.params = {};
    });

    it("Returns 400 when an no match is found", async () => {
      const id = genId();
      ctx.req.params = { id };

      await mainHandler(ctx);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `Item ${id} not found` },
      });
    });

    it("Deletes an item", async () => {
      ctx.req.params = { id: testData[0]._id };

      await mainHandler(ctx);

      const deletedItem = await MlWhitelistRequestModel.findById(testData[0]._id);
      expect(deletedItem).toBeNull();
    });
  });
});
