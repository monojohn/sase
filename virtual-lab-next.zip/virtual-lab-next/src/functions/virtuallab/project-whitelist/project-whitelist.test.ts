import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import EmailService from "../../../services/emailService/emailService";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-whitelist";

const ctx = getCtx({ method: "POST", name: "Project ML Whitelist" });

describe("Project ML Whitelist", () => {
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(EmailService, "sendSimpleEmail").mockImplementation(async () => void 0);

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(EmailService, "sendSimpleEmail").mockRestore();
  });

  describe("POST ml Whitelist", () => {
    beforeEach(() => {
      ctx.res = undefined;
      ctx.req.body = {};
    });

    it("Returns 400 when body is missing", async () => {
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Returns 400 when urls are empty", async () => {
      ctx.req.body = { justification: "", urls: "" };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Returns 400 when justification is missing", async () => {
      ctx.req.body = { urls: "https://google.com" };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Creates a dummy request", async () => {
      ctx.req.body = {
        justification: "Unit test",
        urls: "https://google.com, https://google.com,https://google.com,https://google.com,https://google.com,https://google.com",
      };

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);
    });
  });
});
