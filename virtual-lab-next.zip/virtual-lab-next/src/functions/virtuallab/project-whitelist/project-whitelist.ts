import MlWhitelistService from "../../../features/mlWhitelist/mlWhitelistService";
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type PostProps = {
  urls: string;
  justification: string;
};

const isBodyValid = (body: PostProps) => {
  const { urls, justification } = body;
  return (
    typeof justification === "string" &&
    typeof urls === "string" &&
    justification.length > 0 &&
    urls.length > 0
  );
};

/**
 * Request whitelisting for 1+ urls
 * urls can point to packages or domains
 */
app.post<void>(
  withProject(
    withMemberPermissions(
      withActionLogging(async (ctx) => {
        const body = ctx.req.body as PostProps;
        const { urls, justification } = body;

        ctx.log(`Validating body`);
        if (!isBodyValid(body)) {
          const message = `Invalid params received. Expected { urls: string, justification: string }`;
          ctx.log(`Invalid body detected`);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        ctx.log(`Requesting whitelist approval`);
        await MlWhitelistService.requestApproval(
          ctx,
          ctx.session,
          ctx.project._id,
          urls,
          justification,
        );
      }, ActionType.REQUEST_WHITELIST),
    ),
  ),
);

export const mainHandler = app;
