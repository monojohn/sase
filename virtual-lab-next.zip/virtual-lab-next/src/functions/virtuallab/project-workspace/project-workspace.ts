import { validateMlProps, WorkspaceType } from "../../../features/machineLearningCreation/index";
import NotificationService from "../../../features/openAIUseCase/notificationService";
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { AiAct, BusinessRisk, GdprAssessment } from "../../../services/dbConnector/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import QueueService, { QUEUE } from "../../../services/queueService";
import { getEmailOfUser } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { DeleteWorkspaceProps } from "../project-workspace-deletion-queue/project-workspace-deletion-queue";
import { CreateWorkspaceProps } from "../project-workspace-queue/project-workspace-queue";

const app = HttpTriggerFunction();

type GetProps = {
  params: {
    name: string;
  };
};

/**
 * Get project's workspace
 */
app.get<GetProps>(
  withProject(
    withMemberPermissions((ctx) => {
      ctx.res = {
        body: {
          workspace: ctx.project.workspaceUrl,
        },
      };
    }),
  ),
);

type Body = {
  workspaceType: WorkspaceType;
  workspaceExploratoryJustification?: string;
  aiUsage: boolean;
  aiModels?: string;
  openAiConnection?: boolean;
  ecbContact?: boolean;
  aiUseCaseId?: string;
  gdpr?: GdprAssessment;
  aiAct?: AiAct;
  businessRisk?: BusinessRisk;
};

const keys: (keyof Body)[] = [
  "workspaceExploratoryJustification",
  "aiUsage",
  "aiModels",
  "openAiConnection",
  "ecbContact",
  "aiUseCaseId",
  "gdpr",
  "aiAct",
  "businessRisk",
];

/**
 * Create workspace
 */
app.post<Body>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { oid } = session;
        const { _id: pid } = project;
        const body = ctx.req.body as Body;
        const {
          workspaceType,
          workspaceExploratoryJustification,
          aiUsage,
          aiModels,
          openAiConnection,
          ecbContact,
          aiUseCaseId,
          gdpr,
          aiAct,
          businessRisk,
        } = body;

        const { passed, message } = await validateMlProps(
          ctx,
          { ...body, pid: project._id, projectName: project.name },
          project,
          oid,
        );
        if (!passed) {
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // prevent re-creating project if it exists
        if (project.workspaceUrl) {
          ctx.res = { status: 400, body: { message: "Workspace already created" } };
          return;
        }

        await ProjectModel.updateOne({ _id: pid }, { $set: { workspaceUrl: "BeingCreated" } });

        const queueContent: CreateWorkspaceProps = {
          pid: pid?.toString(),
          oid,
          workspaceType,
          workspaceExploratoryJustification,
          aiUsage,
          aiModels,
          openAiConnection,
          ecbContact,
          aiUseCaseId,
          gdpr,
          aiAct,
          businessRisk,
        };

        ctx.log("Adding item to queue", queueContent);
        await QueueService.put(QUEUE.ML_CREATION, queueContent);
      }, ActionType.CREATE_WORKSPACE),
    ),
  ),
);

app.patch<Partial<Body>>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { project } = ctx;
        const { _id: pid } = project;
        const { oid } = ctx.session;
        const body = (ctx.req.body ?? {}) as Body;

        // ensure a project exists
        if (!project.workspaceUrl) {
          ctx.res = {
            status: 400,
            body: { message: `Project ${project.name} does not have a ML Workspace` },
          };
          return;
        }

        const { passed, message } = await validateMlProps(
          ctx,
          {
            ...body,
            workspaceType: project.workspaceType,
            pid: project._id,
            projectName: project.name,
          },
          project,
          oid,
        );
        if (!passed) {
          ctx.res = { status: 400, body: { message } };
          return;
        }

        if (
          (project.aiUsage && body.aiUsage === false) ||
          (project.openAiConnection && body.openAiConnection === false)
        ) {
          ctx.res = {
            status: 400,
            body: {
              message: `AI Usage and OpenAI connection cannot be changed from true to false`,
            },
          };
          return;
        }

        const { setFields, unsetFields } = keys.reduce(
          (acc, key) => {
            const value = body[key];
            if (value === undefined) {
              acc.unsetFields[key] = "";
            } else {
              acc.setFields[key] = value;
            }
            return acc;
          },
          {
            setFields: {} as Record<string, string | boolean>,
            unsetFields: {} as Record<string, "">,
          },
        );

        // update project
        await ProjectModel.findOneAndUpdate(
          { _id: pid },
          {
            $set: setFields,
            $unset: unsetFields,
          },
          { runValidators: true, upsert: false, new: true, lean: true },
        );

        const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
          "displayName",
          "mail",
          "otherMails",
          "identities",
          "id",
          "userType",
        ]);
        const owner = users.find(({ id }) => id === oid);
        if (!owner) {
          ctx.res = {
            status: 400,
            body: { message: "Owner is missing from group" },
          };
          return;
        }

        // if ai usage was false and now it is true, notify users of llm awareness
        if (body.aiUsage && project.aiUsage === false && !body.openAiConnection) {
          await NotificationService.sendLlmAwarenessInfoToUsers(ctx, {
            projectName: project.name,
            projectUrl: ProjectService.getProjectUrl(project),
            confidentialityLevel: project.confidentialityLevel,
            emails: users.map((user) => getEmailOfUser(user)),
            created: false,
          });
          ctx.res = {
            status: 200,
            body: { message: "Updated workspace successfully!" },
          };
          return;
        }

        if (!body.openAiConnection) {
          // no other emails necessary
          ctx.res = {
            status: 200,
            body: { message: "Updated workspace successfully!" },
          };
          return;
        }

        // if open ai connection was false, notify users and VL team
        if (!project.openAiConnection) {
          await NotificationService.sendLlmAwarenessInfoWithOpenAI(ctx, {
            projectName: project.name,
            projectUrl: ProjectService.getProjectUrl(project),
            confidentialityLevel: project.confidentialityLevel,
            emails: users.map((user) => getEmailOfUser(user)),
            created: false,
            ecbContact: owner.userType === "Member" || body.ecbContact || false,
          });

          await NotificationService.sendSubmittedOpenAiUseCaseEmail(ctx, {
            ownerName: owner.displayName,
            ownerEmail: getEmailOfUser(owner),
            projectName: project.name,
            openAiUseCaseId: body.aiUseCaseId ?? "N/A",
          });
          ctx.res = {
            status: 200,
            body: { message: "Updated workspace successfully!" },
          };
          return;
        }

        // if ai use case id changed, notify VL team
        if (body.aiUseCaseId && body.aiUseCaseId !== project.aiUseCaseId) {
          await NotificationService.sendUpdatedOpenAiUseCaseEmail(ctx, {
            ownerName: owner.displayName,
            ownerEmail: getEmailOfUser(owner),
            projectName: project.name,
            openAiUseCaseId: project.aiUseCaseId ?? "N/A",
            updateOpenAiUseCaseId: body.aiUseCaseId,
          });
        }

        ctx.res = {
          status: 200,
          body: { message: "Updated workspace successfully!" },
        };
      }, ActionType.UPDATE_WORKSPACE),
    ),
  ),
);

/**
 * Delete workspace
 */
app.delete(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { _id: pid } = project;
        const { oid } = session;

        if (!project.workspaceUrl) {
          ctx.res = {
            status: 400,
            body: { message: "No workspace to delete" },
          };
          return;
        }

        const queueContent: DeleteWorkspaceProps = { pid, oid };

        // set prop so UI can show
        await ProjectModel.updateOne({ _id: pid }, { $set: { workspaceUrl: "BeingDeleted" } });

        ctx.log("Adding item to queue", queueContent);
        await QueueService.put(QUEUE.ML_DELETION, queueContent);
      }, ActionType.DELETE_WORKSPACE),
    ),
  ),
);

export const mainHandler = app;
