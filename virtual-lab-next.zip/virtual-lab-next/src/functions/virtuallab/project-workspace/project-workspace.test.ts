import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { WorkspaceType } from "../../../features/machineLearningCreation/index";
import { AiAct, DataSensitivityLevel, GdprAssessment } from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import QueueService from "../../../services/queueService";
import { mainHandler } from "./project-workspace";

const ctx = getCtx({ name: "Project workspace" });

describe("Project workspace", () => {
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(QueueService, "put").mockImplementation(async () => void 0);
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(async () => ({ userType: "Guest", identities: [], mail: "mail" }) as any);
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(
      async () =>
        [
          { identities: [], mail: "mail", id: ctx.authOid },
          { identities: [], mail: "mail", id: "id" },
        ] as any,
    );
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    // create test project
    testProject = await createTestProject({ owners: [ctx.authOid] });

    ctx.req.params.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(QueueService, "put").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  describe("GET workspace", () => {
    it("Returns null when no workspace exists", async () => {
      await mainHandler(ctx);
      expect(ctx.res).toEqual({ body: { workspace: undefined } });
    });
  });

  describe("POST workspace", () => {
    beforeAll(() => {
      ctx.req.method = "POST";
    });

    it("Returns 400 when wrong 'workspaceType' is sent", async () => {
      const workspaceType = "invalid workspaceType";
      const types = Object.values(WorkspaceType);

      ctx.req.body = { workspaceType };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Invalid workspace type: '${workspaceType}' is invalid. Expected one of ${types.join(
            ", ",
          )}`,
        },
      });
    });

    it("Returns 400 when EXPLORATORY workspace doesn't have workspaceExploratoryJustification'", async () => {
      const workspaceExploratoryJustification = true;
      ctx.req.body = {
        workspaceType: WorkspaceType.EXPLORATORY,
        workspaceExploratoryJustification,
      };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Invalid workspaceExploratoryJustification: '${typeof workspaceExploratoryJustification}' is invalid. Expected a string with >0 length`,
        },
      });
    });

    it("Returns 400 when EXPLORATORY workspace has an empty workspaceExploratoryJustification", async () => {
      const workspaceExploratoryJustification = "";
      ctx.req.body = {
        workspaceType: WorkspaceType.EXPLORATORY,
        workspaceExploratoryJustification,
      };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Invalid workspaceExploratoryJustification: '${typeof workspaceExploratoryJustification}' is invalid. Expected a string with >0 length`,
        },
      });
    });

    it("Returns 400 when workspace workspaceType is explortory and data sensitivity level is CSI", async () => {
      const project = await createTestProject({
        owners: [ctx.authOid],
        dataSensitivityLevel: DataSensitivityLevel.CSI,
      });

      ctx.req.body = {
        workspaceType: WorkspaceType.EXPLORATORY,
        workspaceExploratoryJustification: "justification",
      };
      ctx.req.params.pid = project._id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Invalid workspaceType ${WorkspaceType.EXPLORATORY} for a ${DataSensitivityLevel.CSI} data sensitivity level. Expected workspaceType ${WorkspaceType.SECURED}`,
        },
      });
    });

    it("Returns 400 when aiUsage is true and it is missing openAiConnection", async () => {
      ctx.req.body = { workspaceType: WorkspaceType.SECURED, aiUsage: true, aiModels: "models" };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Missing aiModels or openAiConnection when aiUsage is true`,
        },
      });
    });

    it("Returns 400 when aiUsage is true, user is Guest and there's no ecbContact", async () => {
      ctx.req.body = {
        workspaceType: WorkspaceType.SECURED,
        aiUsage: true,
        aiModels: "models",
        openAiConnection: true,
      };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Missing ecbContact when user creating the workspace is guest`,
        },
      });
    });

    it("Returns 400 when aiUsage is true, there is an ecb contact, but aiUseCaseId is missing", async () => {
      ctx.req.body = {
        workspaceType: WorkspaceType.SECURED,
        aiUsage: true,
        aiModels: "models",
        openAiConnection: true,
        ecbContact: true,
      };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Missing aiUseCaseId when user is ECB or there is an ecbContact in the project`,
        },
      });
    });

    it("Returns 400 when aiUsage is true, there is no ecb user and gdpr, aiAct or businessRisk are missing", async () => {
      ctx.req.body = {
        workspaceType: WorkspaceType.SECURED,
        aiUsage: true,
        aiModels: "models",
        openAiConnection: true,
        ecbContact: false,
        gdpr: GdprAssessment.LOW,
        aiAct: AiAct.LOW,
      };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: {
          message: `Missing gdpr, aiAct or businessRisk when user is not ECB and there is no ecbContact in the project`,
        },
      });
    });

    it("Returns 400 a workspace already exists", async () => {
      const project = await createTestProject({
        workspaceUrl: "workspaceUrl",
        owners: [ctx.authOid],
      });

      ctx.req.body = { workspaceType: WorkspaceType.SECURED, aiUsage: false };
      ctx.req.params.pid = project._id;

      await ProjectModel.updateOne(
        { _id: testProject._id },
        { $set: { workspaceUrl: "workspaceUrl" } },
      );

      await mainHandler(ctx);

      expect(ctx.res).toEqual({ status: 400, body: { message: "Workspace already created" } });
    });
  });

  describe("PATCH workspace", () => {
    let patchProject: Project;

    beforeAll(async () => {
      ctx.req.method = "PATCH";
      patchProject = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.params.pid = patchProject._id;
    });

    beforeAll(() => {
      ctx.req.method = "PATCH";
    });

    it("Returns 400 when no workspace exists", async () => {
      ctx.req.body = {} as const satisfies Partial<Project>;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `Project ${patchProject.name} does not have a ML Workspace` },
      });
    });

    it("Returns 400 when patching aiUsage to true without passing the other required values", async () => {
      await ProjectModel.updateOne(
        { _id: patchProject._id },
        {
          $set: {
            workspaceUrl: "workspaceUrl",
            workspaceType: WorkspaceType.SECURED,
            aiUsage: false,
          },
        },
      );

      const body = { aiUsage: true } as const;
      ctx.req.body = { ...body };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `Missing aiModels or openAiConnection when aiUsage is true` },
      });
    });

    it("Returns 400 when patching aiUsage to false if before it was true", async () => {
      await ProjectModel.updateOne(
        { _id: patchProject._id },
        {
          $set: {
            workspaceUrl: "workspaceUrl",
            workspaceType: WorkspaceType.SECURED,
            aiUsage: true,
          },
        },
      );

      const body = { aiUsage: false } as const;
      ctx.req.body = { ...body };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res).toEqual({
        status: 400,
        body: { message: `AI Usage and OpenAI connection cannot be changed from true to false` },
      });

      await ProjectModel.updateOne(
        { _id: patchProject._id },
        {
          $set: {
            aiUsage: false,
            aiUseCaseId: "12",
          },
        },
      );
    });

    it("Returns 200 when patching aiUsage to true with passing the other required values", async () => {
      jest
        .spyOn(GraphService, "getUserProps")
        .mockImplementationOnce(async () => ({ userType: "Member" }) as any);
      const body = {
        aiUsage: true,
        aiModels: "model",
        openAiConnection: false,
        aiUseCaseId: "123",
      } as const;
      ctx.req.body = { ...body };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);

      // expect project to have been updated
      const project = await ProjectModel.findById(patchProject._id);
      expect(project?.aiUsage).toBe(true);
      expect(project?.aiModels).toBe("model");
      expect(project?.openAiConnection).toBe(false);
      expect(project?.aiUseCaseId).toBe("123");

      ctx.req.body = { ...body, openAiConnection: false, ecbContact: true };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);

      ctx.req.body = { ...body, openAiConnection: true, ecbContact: true };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);

      ctx.req.body = { ...body, openAiConnection: true, ecbContact: true, aiUseCaseId: "1234" };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
    });

    it("Returns 400 when owner is missing from group", async () => {
      jest.spyOn(GraphService, "getGroupUsers").mockImplementationOnce(async () => []);
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res.body.message).toBe("Owner is missing from group");
    });

    it("Returns 403 when patching workspaceExploratoryJustification as a member", async () => {
      const testPatchMemberProject = await createTestProject({
        owners: [genId()],
        members: [ctx.authOid],
        workspaceUrl: "workspaceUrl",
      });

      const body = { workspaceExploratoryJustification: "test 3" } as const;

      ctx.req.params.pid = testPatchMemberProject._id;
      ctx.req.body = { ...body };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(403);

      // expect project to not have been updated
      const project = await ProjectModel.findById(testPatchMemberProject._id);
      expect(project?.workspaceExploratoryJustification).toBeUndefined();
    });
  });

  describe("DELETE workspace", () => {
    let testDeleteProject: Project;

    beforeAll(async () => {
      ctx.req.method = "DELETE";
      testDeleteProject = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.params.pid = testDeleteProject._id;
    });

    it("Returns 400 when there's no workspace", async () => {
      await mainHandler(ctx);
      expect(ctx.res).toEqual({ status: 400, body: { message: "No workspace to delete" } });
    });

    it("Returns 200 when call succeeded", async () => {
      // update project
      await ProjectModel.updateOne(
        { _id: testDeleteProject._id },
        { $set: { workspaceUrl: "workspaceUrl" } },
      );

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      // expect project to have been updated
      const project = await ProjectModel.findById(testDeleteProject._id);
      expect(project?.workspaceUrl).toBe("BeingDeleted");
    });
  });
});
