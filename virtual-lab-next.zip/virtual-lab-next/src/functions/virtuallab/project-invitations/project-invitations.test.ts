import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import { mainHandler } from "./project-invitations";

const ctx = getCtx({ name: "Project invitations" });

describe("Project invitations", () => {
  let testProject: Project;

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  describe("GET project invitations", () => {
    it("Returns an array", async () => {
      await mainHandler(ctx);
      expect(Array.isArray(ctx.res.body)).toEqual(true);
    });
  });

  describe("CREATE project invitation", () => {
    beforeAll(() => {
      ctx.req.method = "POST";
    });

    it("Returns 400 when oid is not present in body", async () => {
      ctx.req.body = { oid: null };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Returns 400 when user is missing entitlements", async () => {
      jest
        .spyOn(ProjectService, "checkProjectRolesAndEntitlementsByOid")
        .mockImplementation(
          async () => ({ passed: false, analysis: { errors: ["error"] } }) as any,
        );

      const oid = genId();
      ctx.req.body = { oid };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Returns empty when created successfully", async () => {
      jest
        .spyOn(ProjectService, "checkProjectRolesAndEntitlementsByOid")
        .mockImplementation(async () => ({ passed: true }) as any);

      const oid = genId();
      ctx.req.body = { oid };
      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      // expect invite to exist
      const invite = await OwnershipInviteModel.findOne({ invitee: oid }).lean();
      expect(invite).not.toBeNull();
    });
  });
});
