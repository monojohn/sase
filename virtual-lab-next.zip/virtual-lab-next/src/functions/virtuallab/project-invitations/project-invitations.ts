import { withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { PendingInvitationStatus } from "../../../services/dbConnector/enums";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import ProjectService from "../../../services/projectService/projectService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type GetProps = {
  params: {
    pid: string;
  };
};

/**
 * Get project invitations
 */
app.get<GetProps>(
  withProject(
    withOwnerPermissions(async (ctx) => {
      ctx.res = {
        body: await OwnershipInviteModel.find({
          pid: ctx.project._id,
          status: { $in: Object.values(PendingInvitationStatus) },
        }),
      };
    }),
  ),
);

type Props = {
  params: {
    pid: string;
    id: string;
  };
};

/**
 * Create ownership invitation
 */
app.post<Props>(
  withProject(
    withOwnerPermissions(async (ctx) => {
      const { _id: pid, name: projectName } = ctx.project;
      const { oid: inviter, name: inviterName } = ctx.session;
      const body = (ctx.req.body ?? {}) as { message?: string; oid: string };
      const { oid: invitee } = body;

      if (!invitee || typeof invitee !== "string") {
        const message = "invitee not present in body";
        ctx.res = { status: 400, body: { error: message, message } };
        return;
      }

      const { analysis, passed } = await ProjectService.checkProjectRolesAndEntitlementsByOid(
        ctx,
        [invitee],
        ctx.project,
      );

      if (!passed) {
        ctx.res = {
          status: 400,
          body: {
            ...analysis,
            message: analysis.errors.length
              ? analysis.errors.join(". ")
              : "Roles and entitlements check did not pass",
          },
        };
        return;
      }

      await OwnershipInviteModel.create({
        pid,
        invitee,
        inviter,
        inviterName,
        projectName,
      });
    }),
  ),
);

export const mainHandler = app;
