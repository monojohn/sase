import { jest } from "@jest/globals";
import { Document } from "mongoose";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { DataGovernance } from "../../../features/dataGovernance/types";
import DataGovernanceModel from "../../../services/dbConnector/models/dataGovernanceModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./data-governance";
import ProjectModel from "../../../services/dbConnector/models/projectModel";

const ctx = getCtx({ name: "Data governance" });

describe("Data governance", () => {
  beforeAll(async () => {
    await DataGovernanceModel.deleteMany();
    await ProjectModel.deleteMany();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
  });

  describe("GET data governance", () => {
    beforeAll(() => {
      ctx.req.method = "GET";
    });

    it("Returns an empty array when there are no non-escb projects", async () => {
      await createTestProject({ owners: [ctx.authOid] });

      await mainHandler(ctx);

      expect(ctx.res.body).toEqual([]);
    });

    it("Returns a project with an empty data governance doc", async () => {
      const proj = await createTestProject({ owners: [ctx.authOid], isNonEscbProject: true });

      await mainHandler(ctx);

      expect(ctx.res.body?.length).toBe(1);
      expect(ctx.res.body[0]?.project?.name).toBe(proj.name);
      expect(ctx.res.body[0]?.dataGovernance).toEqual(null);
    });

    it("Returns a project with an existing data governance doc", async () => {
      const project = await createTestProject({ owners: [ctx.authOid], isNonEscbProject: true });
      await DataGovernanceModel.create({ pid: project._id, oid: ctx.authOid });

      await mainHandler(ctx);

      expect(ctx.res.body?.length).toBe(2);
      expect(ctx.res.body[1]?.project?.name).toBe(project.name);
      expect(ctx.res.body[1]?.dataGovernance.pid).toBe(project._id.toString());
    });

    it("Returns the latest governance entry", async () => {
      const project = await createTestProject({ owners: [ctx.authOid], isNonEscbProject: true });

      await DataGovernanceModel.create({ pid: project._id, oid: ctx.authOid });
      const dataGov2 = await DataGovernanceModel.create({ pid: project._id, oid: ctx.authOid });
      await mainHandler(ctx);

      const result = ctx.res.body[2]?.dataGovernance as Document<unknown, DataGovernance>;

      expect(ctx.res.body?.length).toBe(3);
      expect(ctx.res.body[2]?.project?.name).toBe(project.name);
      expect(result?._id?.toString()).toBe(dataGov2._id.toString());
    });
  });

  describe("POST data governance", () => {
    beforeAll(() => {
      ctx.req.method = "POST";
    });

    it("Returns 400 when project does not need data governance", async () => {
      const { _id } = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.params.pid = _id;

      await mainHandler(ctx);

      expect(ctx.res.status).toEqual(400);
    });

    it("Returns 200 when a record is inserted", async () => {
      const { _id } = await createTestProject({ owners: [ctx.authOid], isNonEscbProject: true });
      ctx.req.params.pid = _id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual(undefined);

      const record = await DataGovernanceModel.findOne({ pid: _id }).lean();
      expect(record).not.toBeNull();
    });
  });
});
