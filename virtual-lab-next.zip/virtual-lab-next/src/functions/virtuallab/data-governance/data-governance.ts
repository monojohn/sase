import {
  withAdminBlock,
  withOwnerPermissions,
  withPermissions,
} from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import DataGovernanceModel from "../../../services/dbConnector/models/dataGovernanceModel";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = { params: { pid: string } };

/**
 * Get user's data governance requirements
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { oid } = ctx.session;
    const matchingProjects = await ProjectModel.find({ owners: oid, isNonEscbProject: true });

    ctx.log(`User ${oid} has ${matchingProjects.length} matching projects`);
    const dataGovernance = await Promise.all(
      matchingProjects.map(({ _id }) =>
        DataGovernanceModel.findOne({ pid: _id }).sort({ createdAt: -1 }).lean(),
      ),
    );

    ctx.res = {
      body: matchingProjects.map((project, index) => ({
        project,
        dataGovernance: dataGovernance[index],
      })),
    };
  }),
);

/**
 * Create data governance review entry
 */
app.post<Props>(
  withProject(
    withOwnerPermissions(
      withAdminBlock(async (ctx) => {
        const { oid } = ctx.session;
        const { _id, name, isNonEscbProject } = ctx.project;

        if (!isNonEscbProject) {
          const message = `Project #${_id} (${name}) does not require data governance`;
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // create entry
        await DataGovernanceModel.create({ pid: _id, oid });
      }),
    ),
  ),
);

export const mainHandler = app;
