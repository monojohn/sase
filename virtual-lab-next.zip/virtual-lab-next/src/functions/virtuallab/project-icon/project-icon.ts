import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = { status: 200, body: { iconName: project.icon } };
    }),
  ),
  { allowNonEscb: true },
);

type PatchProps = {
  body: { icon: string };
  params: { pid: string };
};

app.patch<PatchProps>(
  withProject(
    withMemberPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        const request = ctx.req as PatchProps;
        const icon = request.body?.icon;
        const { _id: pid, name: projectName } = project;

        ctx.log(`Updating iconName of ${project.name}`);

        if (typeof icon !== "string") {
          const message = `Error updating project ${pid} - ${projectName}: "${typeof icon}" is invalid`;
          ctx.log(message, { iconName: icon });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // update project
        await ProjectModel.updateOne({ _id: pid }, { $set: { icon } });

        // notify team users
        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          target: { id: "iconName", name: icon },
          type: ActionType.UPDATE_ICON,
          project: { id: pid, name: projectName },
          triggerer: { id: session.oid, displayName: session.name },
        });
      }, ActionType.UPDATE_ICON),
    ),
  ),
  { allowNonEscb: true },
);

export const mainHandler = app;
