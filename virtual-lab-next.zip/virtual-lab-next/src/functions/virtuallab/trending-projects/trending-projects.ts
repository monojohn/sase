import { withPermissions } from "../../../middleware/withPermissions";
import ProjectService from "../../../services/projectService/projectService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();
type GetProjects = {
  query: {
    limit?: string;
  };
};

app.get<GetProjects>(
  withPermissions(async (ctx) => {
    ctx.log(`Getting trending projects`);
    const { limit = 10 } = ctx.req.query;
    const max = +limit;

    // limit number of projects to return
    if (!max || max > 50) {
      ctx.res = {
        status: 400,
        body: { message: `Max limit value is 50, received '${max}'` },
      };
      return;
    }

    // get trending projects
    const body = await ProjectService.getTrendingProjects(ctx, max);
    ctx.res = { body };
  }),
);

export const mainHandler = app;
