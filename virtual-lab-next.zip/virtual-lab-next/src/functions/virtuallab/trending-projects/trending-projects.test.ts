import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { FavoriteProject } from "../../../services/dbConnector/models/favoriteProject";
import FavoriteProjectModel from "../../../services/dbConnector/models/favoriteProjectModel";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./trending-projects";

const ctx = getCtx({ name: "Trending projects" });

describe("Trending projects", () => {
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    // create 50 projects
    const promises: Promise<Project>[] = [];
    for (let index = 0; index < 50; index++) {
      promises.push(
        createTestProject({ name: `trending project ${index}`, owners: [ctx.authOid] }),
      );
    }
    await Promise.all(promises);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.method = undefined;
    ctx.req.params = {};
    ctx.req.query = {};
  });

  it("GETs trending projects without limit", async () => {
    ctx.req.method = "GET";
    ctx.req.params.id = "trending";

    await mainHandler(ctx);

    expect(Array.isArray(ctx.res.body)).toBe(true);
  });

  it("GETs trending projects with valid limit", async () => {
    ctx.req.method = "GET";
    ctx.req.params.id = "trending";
    ctx.req.query.limit = 20;
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(undefined);
    expect(Array.isArray(ctx.res.body)).toBe(true);
    expect(ctx.res.body.length).toBeGreaterThanOrEqual(0);
  });

  it("GETs most favorited project as first result", async () => {
    const localCtx = getCtx({ name: "Trending projects" });
    const favProject = await createTestProject({ name: "Most fav project" });
    const lessFavProject = await createTestProject({ name: "Less fav project" });

    // creates 50 favorites to bump this project
    const favs: Partial<FavoriteProject>[] = [{ oid: genId(), pid: lessFavProject._id }];
    for (let index = 0; index < 50; index++) {
      favs.push({ oid: genId(), pid: favProject._id });
    }
    await FavoriteProjectModel.create(favs);

    localCtx.req.method = "GET";
    localCtx.req.params.id = "trending";
    localCtx.req.query = { limit: 20 };
    await mainHandler(localCtx);

    expect(localCtx.res.status).toBe(undefined);
    expect(Array.isArray(localCtx.res.body)).toBe(true);
    expect(localCtx.res.body[0]?.name).toBe(favProject.name);
    expect(localCtx.res.body.length).toBeGreaterThanOrEqual(2);
  });

  it("GETs trending projects with invalid limit", async () => {
    ctx.req.method = "GET";
    ctx.req.params.id = "trending";
    ctx.req.query.limit = 70;
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(400);
  });
});
