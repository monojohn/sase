import { jest } from "@jest/globals";
import { Document } from "mongoose";
import { createTestProject, genId, genString, getCtx } from "../../../../jest/helpers";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import { Project } from "../../../services/dbConnector/models/project";
import { ProjectRequest } from "../../../services/dbConnector/models/projectRequest";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-access-requests";
import ProjectService from "../../../services/projectService/projectService";
import NotificationService from "../../../features/openAIUseCase/notificationService";

const ctx = getCtx({ name: "Project access requests" });

describe("Project access requests", () => {
  const openAiMailMock = jest.fn(async () => void 0);

  beforeAll(() => {
    jest.spyOn(GraphService, "getUser").mockImplementation(async () => ({}) as any);
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getUserEmail").mockImplementation(async () => global.testEmail);
    jest
      .spyOn(GraphService, "getGroupUsersEmails")
      .mockImplementation(async () => [{ mail: global.testEmail } as any]);
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(async () => ({ mail: global.testEmail, identities: [] }) as any);
    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementation(async () => ({ passed: true }) as any);
    jest.spyOn(ProjectService, "addUser").mockImplementation(async () => undefined);
    jest
      .spyOn(NotificationService, "sendLlmAwarenessInfoToUsers")
      .mockImplementation(openAiMailMock);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUser").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserEmail").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockRestore();
    jest.spyOn(ProjectService, "addUser").mockRestore();
    jest.spyOn(NotificationService, "sendLlmAwarenessInfoToUsers").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
    ctx.req.params = {};
  });

  describe("GET project access requests", () => {
    let testProject: Project;

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({ owners: [ctx.authOid] });
    });

    it("Returns an array when no id is sent", async () => {
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      expect(ctx.res.body).toEqual([]);
    });

    it("Returns 404 when an id is sent but not found", async () => {
      ctx.req.params.id = genId();
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 404,
        body: { message: `Item with Id ${ctx.req.params.id} not found` },
      });
    });

    it("Returns 200 when an existing id is sent", async () => {
      const testRequest = await JoinProjectRequestModel.create({
        oid: ctx.authOid,
        pid: testProject._id,
        name: testProject.name,
      });

      ctx.req.params.id = testRequest._id;
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      const body = ctx.res.body as Document<ProjectRequest>;
      expect(body).toEqual(testRequest.toObject());
    });
  });

  describe("POST project access requests", () => {
    let testProject: Project;

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject();
      ctx.req.method = "POST";
    });

    it("Returns 400 when message is over 350 characters", async () => {
      ctx.req.params.pid = testProject._id;
      ctx.req.body = { message: genString(400) };
      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: "Message field length must be <= 350 characters" },
      });
    });

    it("Returns 200 when user is already owner", async () => {
      const project = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.params.pid = project._id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 200,
        body: { message: "User already in project" },
      });
    });

    it("Returns 200 when user is member", async () => {
      const project = await createTestProject({ members: [ctx.authOid] });

      ctx.req.params.pid = project._id;
      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 200,
        body: { message: "User already in project" },
      });
    });

    it("Returns 200 when a request already exists", async () => {
      const { _id: pid, name } = testProject;
      ctx.req.params.pid = pid;

      await JoinProjectRequestModel.create({ oid: ctx.authOid, pid, name });

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 200,
        body: { message: "Duplicate request" },
      });
    });

    it("Returns 200 when a request is created", async () => {
      const project = await createTestProject();

      const pid = project._id;
      ctx.req.params.pid = pid;

      await mainHandler(ctx);

      expect(ctx.res).toBeUndefined();

      const request = await JoinProjectRequestModel.findOne({ pid });

      expect(request).not.toBeNull();
    });
  });

  describe("PATCH project access requests", () => {
    let testProject: Project;

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({ owners: [ctx.authOid] });

      // create test request
      await JoinProjectRequestModel.create({
        oid: ctx.authOid,
        pid: testProject._id,
        name: testProject.name,
      });

      ctx.req.method = "PATCH";
    });

    it("Returns 404 when an id is sent but not found", async () => {
      ctx.req.params.id = genId();
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 404,
        body: { message: `Request ${ctx.req.params.id} not found` },
      });
    });

    it("Returns 200 when user is member", async () => {
      const project = await createTestProject({ owners: [ctx.authOid], members: [ctx.authOid] });

      const { _id: pid, name } = project;
      const req = await JoinProjectRequestModel.create({ oid: ctx.authOid, pid, name });

      ctx.req.params.pid = project._id;
      ctx.req.params.id = req._id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 200,
        body: { message: "User already in project" },
      });

      // expect request to have been deleted
      const req2 = await JoinProjectRequestModel.findById(req._id);
      expect(req2).toBeNull();
    });

    it("Returns 400 when roles check fails", async () => {
      const project = await createTestProject({
        owners: [ctx.authOid],
        rolesAndEntitlements: [{ roles: [], entitlements: ["ent"], iamRoles: [] }],
      });

      jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockImplementationOnce(
        async () =>
          ({
            passed: false,
            analysis: {
              missingRolesAndEntitlements: {},
              missingUsers: [],
              missingConditions: {
                Guest: [],
                Member: [],
              },
              errors: [],
              errorUsers: [],
            },
          }) as any,
      );

      const { _id: pid, name } = project;
      const req = await JoinProjectRequestModel.create({ oid: "another oid", pid, name });

      ctx.req.params.pid = project._id;
      ctx.req.params.id = req._id;

      await mainHandler(ctx);

      expect(ctx.res.status).toEqual(400);
      expect(ctx.res.body.message).toEqual("Roles and entitlements check did not pass");
    });

    it("Adds user and sends llm awareness email", async () => {
      const project = await createTestProject({
        owners: [ctx.authOid],
        aiUsage: true,
        rolesAndEntitlements: [{ roles: [], entitlements: ["ent"], iamRoles: [] }],
      });

      const { _id: pid, name } = project;
      const req = await JoinProjectRequestModel.create({ oid: "another oid", pid, name });

      ctx.req.params.pid = project._id;
      ctx.req.params.id = req._id;

      await mainHandler(ctx);

      expect(openAiMailMock).toHaveBeenCalledTimes(1);
    });
  });

  describe("DELETE project access requests", () => {
    let testProject: Project;
    let testRequest: ProjectRequest;

    beforeAll(async () => {
      // create test project
      testProject = await createTestProject({ owners: [ctx.authOid] });
      const { _id: pid, name } = testProject;

      testRequest = await JoinProjectRequestModel.create({ oid: ctx.authOid, pid, name });

      ctx.req.method = "DELETE";
    });

    it("Returns 404 when an id is sent but not found", async () => {
      ctx.req.params.id = genId();
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 404,
        body: { message: `Request ${ctx.req.params.id} not found` },
      });
    });

    it("Returns 400 when message is not a string", async () => {
      ctx.req.params.id = testRequest._id;
      ctx.req.params.pid = testProject._id;
      ctx.req.body = { message: true };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: "Message must be a string and under 350 characters" },
      });
    });

    it("Returns 400 message is too large", async () => {
      ctx.req.params.id = testRequest._id;
      ctx.req.params.pid = testProject._id;
      ctx.req.body = { message: genString(500) };

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 400,
        body: { message: "Message must be a string and under 350 characters" },
      });
    });

    it("Returns 200 when rejection is successful", async () => {
      ctx.req.params.id = testRequest._id;
      ctx.req.params.pid = testProject._id;

      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined);
    });
  });
});
