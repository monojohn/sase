import { EmailType } from "../../../features/notificationEntitlements/enums";
import NotificationService from "../../../features/notificationEntitlements/notificationService";
import LlmNotificationService from "../../../features/openAIUseCase/notificationService";
import { ActionType } from "../../../features/userActions/enums";
import { updateActionTarget } from "../../../features/userActions/userActions";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withAdminBlock, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import GraphService from "../../../services/graphService/graphService";
import AccessRequestNotificationService from "../../../services/projectService/accessRequestNotificationService";
import ProjectService from "../../../services/projectService/projectService";
import { getEmailOfUser } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: {
    pid: string;
    id: string;
  };
};

/**
 * A project owner gets all project access requests
 */
app.get<Props>(
  withProject(
    withOwnerPermissions(async (ctx) => {
      const { id } = ctx.req.params;
      const { _id: pid } = ctx.project;

      // return single item if id is specified
      if (id) {
        const item = await JoinProjectRequestModel.findOne({ _id: id, pid }).lean();
        if (!item) {
          // return 404 when item is not found
          ctx.res = { status: 404, body: { message: `Item with Id ${id} not found` } };
          return;
        }

        ctx.res = { body: item };
        return;
      }

      // otherwise return the whole collection
      ctx.res = {
        body: await JoinProjectRequestModel.find({ pid }).lean(),
      };
    }),
  ),
);

/**
 * A user requests project access
 */
app.post<Props>(
  withAdminBlock(
    withProject(
      withActionLogging(async (ctx) => {
        const { oid } = ctx.session;
        const request = ctx.req.body as { message: string };
        const { project } = ctx;
        const pid = ctx.project._id;

        if (request?.message && request.message.length > 350) {
          ctx.res = {
            status: 400,
            body: { message: "Message field length must be <= 350 characters" },
          };
          return;
        }

        const userIsInProject = [...project.owners, ...project.members].includes(oid);
        if (userIsInProject) {
          // user is already in project, don't create invite
          ctx.res = { status: 200, body: { message: "User already in project" } };
          return;
        }

        // prevent duplicates
        const existingRequest = await JoinProjectRequestModel.findOne({ oid, pid }).lean();
        if (existingRequest) {
          // join request already exists, skip creation
          ctx.res = { status: 200, body: { message: "Duplicate request" } };
          return;
        }

        // create join request
        await JoinProjectRequestModel.create({
          oid,
          pid,
          name: project.name,
          message: request?.message,
        });

        // notify owners
        await ProjectService.sendAccessRequestNotification(ctx, {
          senderName: ctx.session.name,
          message: request?.message,
          ownersGroupId: project.ownersGroupId,
          project,
        });
      }, ActionType.REQUEST_MEMBERSHIP),
    ),
  ),
);

/**
 * A project owner accepts a users' membership request
 */
app.patch<Props>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { id } = ctx.req.params;
        const { project } = ctx;
        const { _id: pid } = project;

        const request = await JoinProjectRequestModel.findOne({ _id: id, pid }).lean();

        // if the item doesn't exist, return a 404
        if (!request) {
          ctx.res = { status: 404, body: { message: `Request ${id} not found` } };
          return;
        }

        await updateActionTarget(ctx, request.oid);

        // if the user is already a member, remove it from the request list and do nothing
        const userIsMember = project.members.includes(request.oid);
        if (userIsMember) {
          await JoinProjectRequestModel.deleteOne({ _id: id }).lean();
          ctx.res = { status: 200, body: { message: `User already in project` } };
          return;
        }

        const user = await GraphService.getUserProps(ctx, request.oid, [
          "id",
          "userPrincipalName",
          "userType",
          "mail",
          "otherMails",
          "identities",
        ]);

        if (project.rolesAndEntitlements?.length) {
          // only check if there is something to check

          const { analysis, passed } = await ProjectService.checkRolesAndEntitlements(
            ctx,
            [user],
            project,
          );

          if (!passed) {
            await NotificationService.notifyUsers(
              ctx,
              [user],
              analysis,
              EmailType.NEW_USERS,
              project,
            );
            ctx.res = {
              status: 400,
              body: {
                ...analysis,
                message: analysis.errors.length
                  ? analysis.errors.join(". ")
                  : "Roles and entitlements check did not pass",
              },
            };
            return;
          }
        }

        await ProjectService.addUser(ctx, project, request.oid, false);

        await AccessRequestNotificationService.sendAccessApprovedEmail(
          ctx,
          getEmailOfUser(user),
          ProjectService.getProjectUrl(project),
          project.name,
        );

        // Wait for previous one to finish before sending this
        if (project.aiUsage) {
          void LlmNotificationService.sendLlmAwarenessInfoToUsers(ctx, {
            projectName: project.name,
            projectUrl: ProjectService.getProjectUrl(project),
            confidentialityLevel: project.confidentialityLevel,
            emails: [getEmailOfUser(user)],
            created: false,
          });
        }
      }, ActionType.ACCEPT_MEMBERSHIP),
    ),
  ),
);

/**
 * Reject membership request
 */
app.delete<Props>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { id } = ctx.req.params;
        const { _id: pid, name } = ctx.project;

        const { message = "" } = (ctx.req.body ?? {}) as { message: string };
        const request = await JoinProjectRequestModel.findOne({ _id: id, pid }).lean();

        if (!request) {
          // if the item doesn't exist, return a 404
          ctx.res = {
            status: 404,
            body: { message: `Request ${id} not found` },
          };
          return;
        }

        if (message && (typeof message !== "string" || message.length > 350)) {
          ctx.res = {
            status: 400,
            body: { message: "Message must be a string and under 350 characters" },
          };
          return;
        }

        await updateActionTarget(ctx, request.oid);
        await ProjectService.rejectAccessRequest(ctx, request, name, ctx.session, message);
      }, ActionType.REJECT_MEMBERSHIP),
    ),
  ),
);

export const mainHandler = app;
