import { jest } from "@jest/globals";
import { Document } from "mongoose";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-projects";

const ctx = getCtx({ name: "My projects" });

describe("My projects", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.params = {};
    ctx.res = undefined;
  });

  describe("GET my projects", () => {
    it("Returns empty arrays when user has no projects", async () => {
      await mainHandler(ctx);
      expect(Array.isArray(ctx.res.body.member)).toBe(true);
      expect(Array.isArray(ctx.res.body.owner)).toBe(true);
      expect(ctx.res.body.member.length).toBe(0);
      expect(ctx.res.body.owner.length).toBe(0);
    });

    it("Correctly returns projects", async () => {
      const memberProject = await createTestProject({ members: [ctx.authOid] });
      const ownerProject = await createTestProject({ owners: [ctx.authOid] });

      await mainHandler(ctx);
      expect(Array.isArray(ctx.res.body.member)).toBe(true);
      expect(Array.isArray(ctx.res.body.owner)).toBe(true);

      const member = ctx.res.body.member as Document<Project>[];
      const owner = ctx.res.body.owner as Document<Project>[];

      expect(member.length).toBe(1);
      expect(owner.length).toBe(1);

      expect(member[0]?._id?.toString()).toBe(memberProject._id.toString());
      expect(owner[0]?._id?.toString()).toBe(ownerProject._id.toString());
    });
  });
});
