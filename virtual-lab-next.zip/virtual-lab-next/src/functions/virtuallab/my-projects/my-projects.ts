import { withPermissions } from "../../../middleware/withPermissions";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
};

/**
 * Get all projects the users belongs to
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { oid } = ctx.session;

    const projects = await ProjectModel.find({ $or: [{ owners: oid }, { members: oid }] }).sort({
      updatedAt: 1,
    });
    const rsp = { member: [] as Project[], owner: [] as Project[] };

    ctx.res = {
      body: projects.reduce((acc, project) => {
        if (project.owners.includes(oid)) {
          acc.owner.push(project);
        } else {
          acc.member.push(project);
        }
        return acc;
      }, rsp),
    };
  }),
  { allowNonEscb: true },
);

export const mainHandler = app;
