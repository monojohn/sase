import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-invitation";

const ctx = getCtx({ method: "DELETE", name: "Project invitation" });

describe("Project invitation", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.body = {};
    ctx.res = undefined;
  });

  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params.pid = testProject._id;
  });

  describe("DELETE project invite", () => {
    it("Returns 404 when invite is not found", async () => {
      ctx.req.params.id = genId();
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(404);
    });

    it("Returns 200 when the invite is deleted", async () => {
      // create test invite
      const invite = await OwnershipInviteModel.create({
        pid: testProject._id,
        projectName: testProject.name,
        invitee: ctx.authOid,
        inviter: "invitee",
        inviterName: "inviteeName",
      });

      ctx.req.params.id = invite._id;
      await mainHandler(ctx);

      expect(ctx.res).toBe(undefined); // represents success

      // check invite was deleted
      const oldInvite = await OwnershipInviteModel.findById(invite._id);
      expect(oldInvite).toBeNull();
    });
  });
});
