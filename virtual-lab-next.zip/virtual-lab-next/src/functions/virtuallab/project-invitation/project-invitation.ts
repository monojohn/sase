import { withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: {
    pid: string;
    id: string;
  };
};

/**
 * Allows owners to cancel ownership invitations
 */
app.delete<Props>(
  withProject(
    withOwnerPermissions(async (ctx) => {
      const { id } = ctx.req.params;
      const invitation = await OwnershipInviteModel.findOne({
        _id: id,
        pid: ctx.project._id,
      }).lean();

      if (!invitation) {
        const error = `Project invitation ${id} not found`;
        ctx.log(error);
        // if the request doesn't exist for this project, return 404
        ctx.res = { status: 404, body: { error, message: error } };
        return;
      }

      await OwnershipInviteModel.deleteOne({ _id: id });
    }),
  ),
);

export const mainHandler = app;
