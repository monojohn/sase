import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import IamService from "../../../services/iamService/iamService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import RolesService from "../../../services/igamService/rolesService";
import ProjectService from "../../../services/projectService/projectService";
import { mainHandler } from "./project-roles-and-entitlements";

const ctx = getCtx({ method: "POST", name: "Project roles and entitlements" });

describe("Project roles and entitlements", () => {
  let testProject: Project;
  const condition = {
    roles: [{ id: "test-role", displayName: "test-role", roleName: "test-role" }],
    entitlements: ["test-ent"],
    iamRoles: [{ key: "test-iam-role", displayName: "test-iam-role", roleName: "test-iam-role" }],
  };

  const additionalCondition = {
    roles: ["test-role1"],
    entitlements: ["test-ent1"],
    iamRoles: ["test-iam-role1"],
  };

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(IamService, "getRole").mockImplementation(
      async () =>
        ({
          displayName: additionalCondition.iamRoles[0],
          roleName: additionalCondition.iamRoles[0],
        }) as any,
    );
    jest.spyOn(RolesService, "searchByName").mockImplementation(async () => [
      {
        displayName: additionalCondition.roles[0],
        roleName: additionalCondition.roles[0],
      } as any,
    ]);
    jest
      .spyOn(EntitlementsService, "searchByName")
      .mockImplementation(async () => [
        { displayName: additionalCondition.entitlements[0] } as any,
      ]);

    testProject = await createTestProject({
      owners: [ctx.authOid],
      rolesAndEntitlements: [condition],
    });
    ctx.req.params = { pid: testProject._id };
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
    ctx.req.query = {};
  });

  it("Returns 400 when no body is sent", async () => {
    await mainHandler(ctx);
    expect(ctx.res).toEqual({
      status: 400,
      body: { message: "rolesAndEntitlements must be an object array" },
    });
  });

  it("Returns 400 when entitlements are not an array of strings", async () => {
    ctx.req.body = [
      {
        entitlements: [1, 2],
        roles: [],
        iamRoles: [],
      },
    ];
    await mainHandler(ctx);
    expect(ctx.res).toEqual({ status: 400, body: { message: "entitlements must be a string[]" } });
  });

  it("Returns 400 when roles are not an array of strings", async () => {
    ctx.req.body = [
      {
        entitlements: condition.entitlements,
        roles: [1],
        iamRoles: [],
      },
    ];
    await mainHandler(ctx);
    expect(ctx.res).toEqual({ status: 400, body: { message: "roles must be a string[]" } });
  });

  it("Returns 400 when iam roles are not an array of strings", async () => {
    ctx.req.body = [
      {
        entitlements: condition.entitlements,
        roles: additionalCondition.roles,
        iamRoles: 12,
      },
    ];
    await mainHandler(ctx);
    expect(ctx.res).toEqual({ status: 400, body: { message: "iamRoles must be a string[]" } });
  });

  it("Returns 400 when role / entitlement is not found", async () => {
    ctx.req.body = [additionalCondition];

    jest.spyOn(IamService, "getRole").mockImplementationOnce(async () => ({}) as any);

    await mainHandler(ctx);
    expect(ctx.res).toEqual({
      status: 400,
      body: { message: `Roles or entitlements not found: ${additionalCondition.iamRoles[0]}` },
    });
  });

  it("Returns 200 for duplicate conditions when just checking", async () => {
    ctx.req.body = [
      {
        roles: [],
        entitlements: [],
        iamRoles: [],
      },
      {
        roles: condition.roles.map(({ roleName }) => roleName),
        entitlements: condition.entitlements,
        iamRoles: condition.iamRoles.map(({ roleName }) => roleName),
      },
      {
        roles: condition.roles.map(({ roleName }) => roleName),
        entitlements: condition.entitlements,
        iamRoles: condition.iamRoles.map(({ roleName }) => roleName),
      },
    ];
    ctx.req.query.check = "true";
    jest
      .spyOn(EntitlementsService, "searchByName")
      .mockImplementationOnce(async () => [{ displayName: condition.entitlements[0] } as any]);

    jest.spyOn(RolesService, "searchByName").mockImplementationOnce(async () => [
      {
        displayName: condition.roles[0].displayName,
        roleName: condition.roles[0].roleName,
      } as any,
    ]);

    jest.spyOn(IamService, "getRole").mockImplementationOnce(
      async () =>
        ({
          displayName: condition.iamRoles[0].displayName,
          roleName: condition.iamRoles[0].roleName,
        }) as any,
    );
    await mainHandler(ctx);
    delete ctx.req.query.check;
    expect(ctx.res).toEqual({
      status: 200,
      body: {
        passed: false,
        message: `Duplicate conditions found: ${[
          condition.roles[0].roleName,
          condition.entitlements[0],
          condition.iamRoles[0].roleName,
        ].join(" or ")}`,
      },
    });
  });

  it("Returns 400 for duplicate conditions", async () => {
    ctx.req.body = [
      {
        roles: [],
        entitlements: [],
        iamRoles: [],
      },
      {
        roles: condition.roles.map(({ roleName }) => roleName),
        entitlements: condition.entitlements,
        iamRoles: condition.iamRoles.map(({ roleName }) => roleName),
      },
      {
        roles: condition.roles.map(({ roleName }) => roleName),
        entitlements: condition.entitlements,
        iamRoles: condition.iamRoles.map(({ roleName }) => roleName),
      },
    ];
    jest
      .spyOn(EntitlementsService, "searchByName")
      .mockImplementationOnce(async () => [{ displayName: condition.entitlements[0] } as any]);

    jest.spyOn(RolesService, "searchByName").mockImplementationOnce(async () => [
      {
        displayName: condition.roles[0].displayName,
        roleName: condition.roles[0].roleName,
      } as any,
    ]);

    jest.spyOn(IamService, "getRole").mockImplementationOnce(
      async () =>
        ({
          displayName: condition.iamRoles[0].displayName,
          roleName: condition.iamRoles[0].roleName,
        }) as any,
    );
    await mainHandler(ctx);
    expect(ctx.res).toEqual({
      status: 400,
      body: {
        message: `Duplicate conditions found: ${[
          condition.roles[0].roleName,
          condition.entitlements[0],
          condition.iamRoles[0].roleName,
        ].join(" or ")}`,
      },
    });
  });

  it("Returns 200 when new condition doesn't pass but it's just check", async () => {
    ctx.req.body = [
      {
        roles: [],
        entitlements: [],
        iamRoles: [],
      },
      additionalCondition,
    ];

    const analysis = {
      missingUsers: [],
      missingRolesAndEntitlements: {},
      missingConditions: {
        Guest: [],
        Member: [],
      },
      errors: [],
      errorUsers: [],
    };
    ctx.req.query.check = "true";

    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementationOnce(async () => ({ passed: false, analysis }));

    await mainHandler(ctx);
    delete ctx.req.query.check;
    expect(ctx.res.status).toBe(200);
    expect(ctx.res.body.passed).toBe(false);
  });

  it("Returns 400 when new condition doesn't pass check", async () => {
    ctx.req.body = [
      {
        roles: [],
        entitlements: [],
        iamRoles: [],
      },
      additionalCondition,
    ];

    const analysis = {
      missingUsers: [],
      missingRolesAndEntitlements: {},
      missingConditions: {
        Guest: [],
        Member: [],
      },
      errors: ["error"],
      errorUsers: [],
    };

    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementationOnce(async () => ({ passed: false, analysis }));

    await mainHandler(ctx);
    expect(ctx.res.status).toBe(400);
    expect(ctx.res.body.messages).toContain("error");
  });

  it("Returns 200 when new condition is added", async () => {
    ctx.req.body = [
      {
        roles: [],
        entitlements: [],
        iamRoles: [],
      },
      additionalCondition,
    ];

    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementationOnce(async () => ({ passed: true }) as any);

    await mainHandler(ctx);
    expect(ctx.res).toBe(undefined);

    const proj = await ProjectModel.findById(ctx.req.params.pid);
    expect(proj?.rolesAndEntitlements[1].roles[0].roleName).toEqual(additionalCondition.roles[0]);
    expect(proj?.rolesAndEntitlements[1].entitlements[0]).toEqual(
      additionalCondition.entitlements[0],
    );
    expect(proj?.rolesAndEntitlements[1].iamRoles[0].roleName).toEqual(
      additionalCondition.iamRoles[0],
    );
  });
});
