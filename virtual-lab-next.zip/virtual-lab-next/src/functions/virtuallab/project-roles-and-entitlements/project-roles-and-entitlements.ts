import { ActionType } from "../../../features/userActions/enums";
import { updateActionTarget } from "../../../features/userActions/userActions";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import {
  RolesAndEntitlements,
  RolesAndEntitlementsStrings,
} from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import IamService from "../../../services/iamService/iamService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import RolesService from "../../../services/igamService/rolesService";
import ProjectService from "../../../services/projectService/projectService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { areStringArraysEqual, isStringArray } from "../../../utils/typeValidator";

const app = HttpTriggerFunction();

type AddProjectRolesAndEntitlements = {
  params: {
    pid: string;
  };
  query: {
    check?: "true" | "false";
  };
};

const getRolesAndEntitlementsAsString = (rolesAndEntitlments: RolesAndEntitlementsStrings[]) =>
  rolesAndEntitlments
    .map(({ roles, entitlements, iamRoles }) =>
      [...roles, ...entitlements, ...iamRoles].join(" or "),
    )
    .join(", ");

app.post<AddProjectRolesAndEntitlements>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { pid } = ctx.req.params;
        const { check: checkParam } = ctx.req.query;
        const rolesAndEntitlements = ctx.req.body as RolesAndEntitlementsStrings[];
        const check = checkParam === "true";

        // check data format
        if (!Array.isArray(rolesAndEntitlements)) {
          ctx.res = {
            status: 400,
            body: { message: `rolesAndEntitlements must be an object array` },
          };
          return;
        }

        if (!rolesAndEntitlements.every(({ entitlements }) => isStringArray(entitlements))) {
          ctx.res = { status: 400, body: { message: `entitlements must be a string[]` } };
          return;
        }

        if (!rolesAndEntitlements.every(({ roles }) => isStringArray(roles))) {
          ctx.res = { status: 400, body: { message: `roles must be a string[]` } };
          return;
        }

        if (!rolesAndEntitlements.every(({ iamRoles }) => isStringArray(iamRoles))) {
          ctx.res = { status: 400, body: { message: `iamRoles must be a string[]` } };
          return;
        }

        const rolesAndEntitlementsAsString = getRolesAndEntitlementsAsString(rolesAndEntitlements);
        await updateActionTarget(ctx, rolesAndEntitlementsAsString);

        // ensure roles and entitlements exits
        ctx.log("Checking new roles and entitlements are valid");

        const allEntitlements = [
          ...new Set(rolesAndEntitlements.flatMap(({ entitlements }) => entitlements)),
        ];
        const allRoles = [...new Set(rolesAndEntitlements.flatMap(({ roles }) => roles))];
        const allIamRoles = [...new Set(rolesAndEntitlements.flatMap(({ iamRoles }) => iamRoles))];

        const entitlementsObj = await Promise.all(
          allEntitlements.map(async (entName) => {
            const ent = await EntitlementsService.searchByName(ctx, entName);
            return ent[0]?.displayName;
          }),
        );

        const rolesArray = await Promise.all(
          allRoles.map(async (roleName) => {
            const role = await RolesService.searchByName(ctx, roleName);
            return role[0];
          }),
        );

        const iamRolesArray = await Promise.all(
          allIamRoles.map(async (roleName) => {
            const iamRole = await IamService.getRole(ctx, roleName);
            return iamRole;
          }),
        );

        const missingEntitlements = allEntitlements.filter((ent) => !entitlementsObj.includes(ent));

        const roleNames = new Set(rolesArray.map((role) => role?.roleName));
        const missingRoles = allRoles.filter((roleName) => !roleNames.has(roleName));

        const iamRoleNames = new Set(iamRolesArray.map((role) => role?.roleName));
        const missingIamRoles = allIamRoles.filter((roleName) => !iamRoleNames.has(roleName));

        if (
          missingEntitlements.length > 0 ||
          missingRoles.length > 0 ||
          missingIamRoles.length > 0
        ) {
          const message = `Roles or entitlements not found: ${[
            ...missingEntitlements,
            ...missingRoles,
            ...missingIamRoles,
          ].join(", ")}`;
          ctx.log(message);
          ctx.res = { status: 400, body: { message } };
          return;
        }

        // build roles and entitlements object to be updated
        const rolesAndEntitlementsObject: RolesAndEntitlements[] = rolesAndEntitlements.map(
          ({ roles, entitlements, iamRoles }) => {
            const condition: RolesAndEntitlements = {
              entitlements: [],
              roles: [],
              iamRoles: [],
            };
            return {
              entitlements: [...condition.entitlements, ...entitlements],
              roles: [
                ...condition.roles,
                ...rolesArray.filter(({ roleName }) => roles.includes(roleName)),
              ],
              iamRoles: [
                ...condition.iamRoles,
                ...iamRolesArray
                  .map((role) => ({
                    key: role!.key,
                    roleName: role!.roleName,
                    displayName: role!.displayName,
                  }))
                  .filter(({ roleName }) => iamRoles.includes(roleName)),
              ],
            };
          },
        );

        // ensure it's not duplicated
        ctx.log("Checking for duplicate conditions");
        const duplicatedConditions = rolesAndEntitlementsObject
          .map(({ entitlements, roles, iamRoles }) => ({
            entitlements,
            roles: roles.map(({ roleName }) => roleName),
            iamRoles: iamRoles.map(({ roleName }) => roleName),
          }))
          .filter(
            ({ entitlements, roles, iamRoles }, index, self) =>
              self.findIndex(
                (condition) =>
                  areStringArraysEqual(condition.entitlements, entitlements) &&
                  areStringArraysEqual(condition.roles, roles) &&
                  areStringArraysEqual(condition.iamRoles, iamRoles),
              ) !== index,
          );
        if (duplicatedConditions.length > 0) {
          const message = `Duplicate conditions found: ${getRolesAndEntitlementsAsString(
            duplicatedConditions,
          )}`;
          ctx.log(message);
          if (check) {
            ctx.res = { status: 200, body: { passed: false, message } };
            return;
          }

          ctx.res = { status: 400, body: { message } };
          return;
        }

        // get all users
        const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
          "id",
          "userPrincipalName",
          "userType",
          "mail",
        ]);

        // check new roles and entitlements agains users
        const { analysis, passed } = await ProjectService.checkRolesAndEntitlements(ctx, users, {
          ...project,
          rolesAndEntitlements: rolesAndEntitlementsObject,
        });

        if (check) {
          ctx.res = {
            status: 200,
            body: {
              passed,
              ...analysis,
              messages: analysis.errors,
              rolesAndEntitlements: rolesAndEntitlementsObject,
            },
          };
          return;
        }

        if (!passed) {
          ctx.res = {
            status: 400,
            body: {
              ...analysis,
              messages: analysis.errors,
            },
          };
          return;
        }

        // add entitlements / roles to project
        ctx.log(
          `Adding new roles and entitlements to project "${pid}": ${rolesAndEntitlementsAsString}`,
        );

        const permissionsChangedDate = new Date().toISOString();
        await ProjectModel.updateOne(
          { _id: pid },
          { $set: { rolesAndEntitlements: rolesAndEntitlementsObject, permissionsChangedDate } },
        );

        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          target: { id: rolesAndEntitlementsAsString },
          type: ActionType.ADD_ENTITLEMENTS_AND_ROLES,
          project: { id: pid, name: project.name },
          triggerer: { id: session.oid, displayName: session.name },
        });

        ctx.log("Entitlements added successfully");
      }, ActionType.ADD_ENTITLEMENTS_AND_ROLES),
    ),
  ),
);

export const mainHandler = app;
