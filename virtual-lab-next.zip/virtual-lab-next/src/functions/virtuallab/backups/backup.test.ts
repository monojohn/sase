import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./backups";
import BackupService from "../../../services/backupService/backupService";

const ctx = getCtx({ name: "Backups" });

describe("Backups", () => {
  beforeAll(() => {
    jest.spyOn(BackupService, "listFiles").mockImplementation(async () => []);
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: true,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(BackupService, "listFiles").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("GET backups", () => {
    beforeEach(() => {
      ctx.req.body = {};
      ctx.res = undefined;
    });

    it("Returns list of backups", async () => {
      await mainHandler(ctx);

      expect(ctx.res.body).toEqual([]);
    });

    it("Returns error when user is not admin", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
        isAdmin: false,
        isNonEscb: false,
        isVlUser: true,
      }));
      await mainHandler(ctx);

      expect(ctx.res.body.message).toContain("does not have required permissions");
    });
  });
});
