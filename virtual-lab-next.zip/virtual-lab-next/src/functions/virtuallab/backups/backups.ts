import { withAdminPermissions } from "../../../middleware/withPermissions";
import BackupService from "../../../services/backupService/backupService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withAdminPermissions(async (ctx) => {
    const backupList = await BackupService.listFiles();
    ctx.res = { body: backupList };
  }),
);

export const mainHandler = app;
