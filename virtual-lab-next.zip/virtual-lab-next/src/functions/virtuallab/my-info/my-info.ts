import { withPermissions } from "../../../middleware/withPermissions";
import GraphService from "../../../services/graphService/graphService";
import { VL_ADMINS_GROUP_ID, VL_TEAM_GROUP_ID } from "../../../utils/config";
import { getEmailOfUser } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
};

/**
 * Get my info
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { oid } = ctx.session;

    const [user, isAdmin, msTeamsAccess] = await Promise.all([
      GraphService.getUserProps(ctx, oid, [
        "displayName",
        "userType",
        "mail",
        "identities",
        "otherMails",
      ]),
      GraphService.isUserInGroup(ctx, oid, VL_ADMINS_GROUP_ID),
      GraphService.isUserInGroup(ctx, oid, VL_TEAM_GROUP_ID),
    ]);

    const email = getEmailOfUser(user);
    const { displayName, userType } = user;

    ctx.res = { body: { isAdmin, email, displayName, userType, msTeamsAccess, oid } };
  }),
  { allowNonEscb: true },
);

export const mainHandler = app;
