import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-info";

const ctx = getCtx({ name: "My info" });

describe("My info", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    jest.spyOn(GraphService, "getUserProps").mockImplementation(
      async () =>
        ({
          identities: [],
          mail: "mail",
          displayName: "name",
        }) as any,
    );

    jest.spyOn(GraphService, "isUserInGroup").mockImplementation(async () => true);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(GraphService, "isUserInGroup").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.params = {};
    ctx.req.body = {};
  });

  it("Returns user info", async () => {
    await mainHandler(ctx);
    expect(ctx.res.body.isAdmin).toEqual(true);
    expect(ctx.res.body.msTeamsAccess).toEqual(true);
    expect(ctx.res.body.displayName).toEqual("name");
  });
});
