import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  RequestStatus,
  RequestType,
} from "../../../services/dbConnector/enums";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import { ActionType } from "../../../features/userActions/enums";
import ProjectService from "../../../services/projectService/projectService";
import { WorkspaceType } from "../../../services/sharepointService/enums";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import OrgService from "../../../services/igamService/orgService";

const ctx = getCtx({ name: "Project" });

describe("Project", () => {
  let testProject: Project;
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(ProjectService, "isConfidentialityPending").mockImplementation(async () => []);
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(
      async () =>
        [
          {
            id: ctx.authOid,
            displayName: "user",
            userPrincipalName: "user",
            mail: "mail",
            identities: [],
            userType: "Member",
          },
        ] as any,
    );
    jest
      .spyOn(EntitlementsService, "updateConfidentiality")
      .mockImplementation(async () => [{ requestId: "123" }]);
    jest.spyOn(OrgService, "getApproversEmails").mockImplementation(async () => ["mail"]);

    testProject = await createTestProject({
      owners: [ctx.authOid],
      rolesAndEntitlements: [{ roles: [], entitlements: ["ent"], iamRoles: [] }],
    });
    await IgamRequestModel.create({
      pid: testProject._id,
      requestType: RequestType.UPDATE_CONFIDENTIALITY,
      requestStatus: RequestStatus.AWAITING_APPROVAL,
      confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      dataSensitivityLevel: DataSensitivityLevel.CSI,
      requesterId: "me",
    });

    await IgamRequestModel.create({
      pid: testProject._id,
      requestType: RequestType.UPDATE_ORG,
      requestStatus: RequestStatus.AWAITING_APPROVAL,
      requesterId: "me",
      org: "org",
    });
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(ProjectService, "isConfidentialityPending").mockRestore();
    jest.spyOn(EntitlementsService, "updateConfidentiality").mockRestore();
    jest.spyOn(OrgService, "getApproversEmails").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
    ctx.req.params = {};
  });

  describe("GET", () => {
    it("Returns 404 when project doesn't exist", async () => {
      ctx.req.params.pid = genId();
      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 404,
        body: { message: `Project '${ctx.req.params.pid}' not found` },
      });
    });

    it("Returns 403 when user can't see project", async () => {
      const project = await createTestProject({ accessibilityLevel: AccessibilityLevel.Private });
      const pid = project._id.toString();
      ctx.req.params.pid = pid;

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 403,
        body: { message: `User ${ctx.authOid} does not have permissions to access project ${pid}` },
      });
    });

    it("Returns 403 when non-escb user tries to see a project they don't belong to", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementationOnce(async () => ({
        isAdmin: false,
        isNonEscb: true,
        isVlUser: true,
      }));

      const project = await createTestProject();
      const pid = project._id.toString();
      ctx.req.params.pid = pid;
      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 403,
        body: { message: `User ${ctx.authOid} does not have permissions to access project ${pid}` },
      });
    });

    it("Returns 200 when the user is an owner", async () => {
      const pid = testProject._id.toString();
      ctx.req.params.pid = pid;
      await mainHandler(ctx);

      expect(ctx.res.status).toBe(200);
    });

    it("Returns 200 when the user is an member", async () => {
      const pid = testProject._id.toString();
      ctx.req.params.pid = pid;
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
    });

    it("Returns more data for admins", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
        isAdmin: true,
        isNonEscb: false,
        isVlUser: true,
      }));
      const pid = testProject._id.toString();
      ctx.req.params.pid = pid;
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(200);
      expect(ctx.res.body.pendingOrg).toEqual("org");
    });
  });

  describe("PATCH", () => {
    it("Throws error for values which are non-string", async () => {
      ctx.req.params.pid = testProject._id;
      ctx.req.body = { description: 123 };
      ctx.req.method = "PATCH";
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Throws error for tags which are not string array", async () => {
      ctx.req.params.pid = testProject._id;
      ctx.req.body = { tags: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);

      ctx.req.body = { tags: [123] };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Updates description", async () => {
      await UserActionModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: testProject.icon,
        tags: testProject.tags,
        confidentialityLevel: testProject.confidentialityLevel,
        accessibilityLevel: testProject.accessibilityLevel,
        dataSensitivityLevel: testProject.dataSensitivityLevel,
      };
      await mainHandler(ctx);
      const updatedProject = await ProjectModel.findById(testProject._id);
      expect(updatedProject?.description).toBe("new description");
      const actionModel = await UserActionModel.find({ pid: testProject._id });
      expect(actionModel[0].action).toEqual(ActionType.UPDATE_DESCRIPTION);
    });

    it("Updates icon and tags", async () => {
      await UserActionModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: testProject.confidentialityLevel,
        accessibilityLevel: testProject.accessibilityLevel,
        dataSensitivityLevel: testProject.dataSensitivityLevel,
      };
      await mainHandler(ctx);
      const updatedProject = await ProjectModel.findById(testProject._id);
      expect(updatedProject?.icon).toBe("new icon");
      expect(updatedProject?.tags[0]).toBe("new tags");
      const actionModel = await UserActionModel.find({ pid: testProject._id });
      expect(actionModel.length).toEqual(2);
      expect(actionModel.find(({ action }) => action === ActionType.UPDATE_ICON)).toBeDefined();
      expect(actionModel.find(({ action }) => action === ActionType.UPDATE_TAGS)).toBeDefined();
    });

    it("Throws error in case of a pending confidentiality", async () => {
      await UserActionModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;
      jest
        .spyOn(ProjectService, "isConfidentialityPending")
        .mockImplementationOnce(
          async () => [{ confidentialityLevel: ConfidentialityLevel.RESTRICTED }] as any,
        );

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.SECRET,
        accessibilityLevel: testProject.accessibilityLevel,
        dataSensitivityLevel: testProject.dataSensitivityLevel,
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res.body.message).toBe(
        `Error updating confidentiality, accessibility or data sensitivity level: there is a pending confidentiality ${ConfidentialityLevel.RESTRICTED}`,
      );
    });

    it("Throws error in case confidentiality, accessibility and data sensitivity are not compatible", async () => {
      await UserActionModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.SECRET,
        accessibilityLevel: testProject.accessibilityLevel,
        dataSensitivityLevel: testProject.dataSensitivityLevel,
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res.body.message).toBe(
        `Error updating confidentiality, accessibility or data sensitivity level: the values are not valid`,
      );
    });

    it("Throws error if csi and workspace exploratory", async () => {
      await UserActionModel.deleteMany();
      const anotherProject = await createTestProject({
        owners: [ctx.authOid],
        workspaceType: WorkspaceType.EXPLORATORY,
        description: testProject.description,
        icon: testProject.icon,
        tags: testProject.tags,
        confidentialityLevel: testProject.confidentialityLevel,
        accessibilityLevel: testProject.accessibilityLevel,
        dataSensitivityLevel: testProject.dataSensitivityLevel,
      });
      ctx.req.params.pid = anotherProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        accessibilityLevel: AccessibilityLevel.Private,
        dataSensitivityLevel: DataSensitivityLevel.CSI,
      };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      expect(ctx.res.body.message).toBe(
        `Cannot set data sensitivity level to CSI when workspace type is exploratory`,
      );
    });

    it("Updates confidentiality, accessibility and data sensitivity in case of no approval needed", async () => {
      await UserActionModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.UNRESTRICTED,
        accessibilityLevel: AccessibilityLevel.Private,
        dataSensitivityLevel: DataSensitivityLevel.No,
      };
      await mainHandler(ctx);
      const updatedProject = await ProjectModel.findById(testProject._id);
      expect(updatedProject?.confidentialityLevel).toBe(ConfidentialityLevel.UNRESTRICTED);
      expect(updatedProject?.accessibilityLevel).toBe(AccessibilityLevel.Private);
      expect(updatedProject?.dataSensitivityLevel).toBe(DataSensitivityLevel.No);
      const actionModel = await UserActionModel.find({ pid: testProject._id });
      expect(actionModel.length).toEqual(2);
      expect(
        actionModel.find(({ action }) => action === ActionType.UPDATE_CONFIDENTIALITY),
      ).toBeDefined();
      expect(
        actionModel.find(({ action }) => action === ActionType.UPDATE_ACCESSIBILITY),
      ).toBeDefined();
    });

    it("Creates pending confidentiality", async () => {
      await UserActionModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        accessibilityLevel: AccessibilityLevel.Private,
        dataSensitivityLevel: DataSensitivityLevel.No,
      };

      await IgamRequestModel.create({
        requestType: RequestType.ADD_OWNER,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        oid: "you",
      });
      await mainHandler(ctx);
      const updatedProject = await ProjectModel.findById(testProject._id);
      expect(updatedProject?.confidentialityLevel).toBe(ConfidentialityLevel.UNRESTRICTED);
      expect(updatedProject?.accessibilityLevel).toBe(AccessibilityLevel.Private);
      expect(updatedProject?.dataSensitivityLevel).toBe(DataSensitivityLevel.No);
      const actionModel = await UserActionModel.find({ pid: testProject._id });
      expect(actionModel.length).toEqual(0);
      expect(ctx.res.body.status).toEqual("Pending request creation");
    });

    it("Throws error when IGAM does not give request id", async () => {
      await UserActionModel.deleteMany();
      await IgamRequestModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        accessibilityLevel: AccessibilityLevel.Private,
        dataSensitivityLevel: DataSensitivityLevel.No,
      };
      jest
        .spyOn(EntitlementsService, "updateConfidentiality")
        .mockImplementationOnce(async () => [{}]);

      await mainHandler(ctx);
      const updatedProject = await ProjectModel.findById(testProject._id);
      expect(updatedProject?.confidentialityLevel).toBe(ConfidentialityLevel.UNRESTRICTED);
      expect(updatedProject?.accessibilityLevel).toBe(AccessibilityLevel.Private);
      expect(updatedProject?.dataSensitivityLevel).toBe(DataSensitivityLevel.No);
      const actionModel = await UserActionModel.find({ pid: testProject._id });
      expect(actionModel.length).toEqual(0);
      expect(ctx.res.status).toEqual(500);
    });

    it("Triggers request in igam", async () => {
      await UserActionModel.deleteMany();
      await IgamRequestModel.deleteMany();
      ctx.req.params.pid = testProject._id;
      ctx.req.params.oid = ctx.authOid;

      ctx.req.body = {
        description: "new description",
        icon: "new icon",
        tags: ["new tags"],
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        accessibilityLevel: AccessibilityLevel.Private,
        dataSensitivityLevel: DataSensitivityLevel.No,
      };

      await mainHandler(ctx);
      const updatedProject = await ProjectModel.findById(testProject._id);
      expect(updatedProject?.confidentialityLevel).toBe(ConfidentialityLevel.UNRESTRICTED);
      expect(updatedProject?.accessibilityLevel).toBe(AccessibilityLevel.Private);
      expect(updatedProject?.dataSensitivityLevel).toBe(DataSensitivityLevel.No);
      const actionModel = await UserActionModel.find({ pid: testProject._id });
      expect(actionModel.length).toEqual(0);
      expect(ctx.res.body.status).toEqual("Pending approval");
    });
  });
});
