import { getCtx, getIntegrationProjects } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import { mainHandler } from "./project";

const authorization = global.robertaJwt;
const ctx = getCtx({ name: "Project", authorization });

describe("Project with users", () => {
  let testProject: Project;

  beforeAll(async () => {
    [testProject] = await getIntegrationProjects();
  });

  it("Returns a project with users", async () => {
    ctx.req.params.pid = testProject._id;
    await mainHandler(ctx);

    // expect project to be the same
    expect(ctx.res.body.name).toEqual(testProject.name);

    // expect owner to be equal to an id
    expect(ctx.res.body.owners[0]).toEqual(testProject.owners[0]);
  });
});
