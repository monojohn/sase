import { withVisitLogging } from "../../../features/userVisits/withVisitLogging";
import { withOwnerPermissions, withViewPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import {
  DataSensitivityLevel,
  RequestStatus,
  RequestType,
  UpdateStatus,
} from "../../../services/dbConnector/enums";
import { ExpandedProject, Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import ProjectService from "../../../services/projectService/projectService";
import { arraysAreEquivalent } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { WorkspaceType } from "../../../services/sharepointService/enums";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import NotificationService from "../../../services/projectService/notificationService";
import BudgetService from "../../../services/budgetService/budgetService";
import { getOpenAiUsage } from "../../../utils/openAIUsage";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withViewPermissions(
      withVisitLogging(async (ctx) => {
        // 404's are handled by the middleware
        let project = ctx.project as Project | ExpandedProject;

        ctx.log(`Getting project ${project.name} (${project._id})`);

        const pendingConfidentiality = await IgamRequestModel.findOne({
          pid: project._id,
          requestType: RequestType.UPDATE_CONFIDENTIALITY,
          requestStatus: { $in: [RequestStatus.AWAITING_APPROVAL, RequestStatus.PENDING] },
        });

        if (pendingConfidentiality) {
          project = {
            ...project,
            pendingConfidentialityLevel: pendingConfidentiality.confidentialityLevel,
          };
          if (pendingConfidentiality.dataSensitivityLevel) {
            project = {
              ...project,
              pendingDataSensitivityLevel: pendingConfidentiality.dataSensitivityLevel,
            };
          }
        }

        if (ctx.permissions.isAdmin) {
          // if user is admin, also get pending org and possible orgs of the owners
          const [pendingOrg, projectOwners] = await Promise.all([
            IgamRequestModel.findOne({
              pid: project._id,
              requestType: RequestType.UPDATE_ORG,
              requestStatus: { $in: [RequestStatus.AWAITING_APPROVAL, RequestStatus.PENDING] },
            }),
            GraphService.getGroupUsers(ctx, project.ownersGroupId, [
              "displayName",
              "department",
              "userType",
              "id",
            ]),
          ]);

          const ownersDepartments = await Promise.all(
            projectOwners.map(async (user) => {
              const department = await GraphService.getUserDepartment(ctx, user);
              return {
                displayName: user.displayName,
                department,
              };
            }),
          );

          project = {
            ...project,
            ownersDepartments,
          };

          if (pendingOrg) {
            project = {
              ...project,
              pendingOrg: pendingOrg.org,
            };
          }
        }

        if (
          project.workspaceUrl &&
          !["BeingCreated", "BeingDeleted"].includes(project.workspaceUrl)
        ) {
          const budgetService = new BudgetService(ctx);
          const [budget, openAiUsage] = await Promise.allSettled([
            budgetService.getProjectBudget(project.name),
            getOpenAiUsage(project.workspaceUrl),
          ]);
          if (budget.status === "fulfilled") {
            project = {
              ...project,
              budget: {
                limit: budget.value.properties.amount,
                consumed: budget.value.properties.currentSpend.amount,
              },
            };
          }
          project = {
            ...project,
            openAiUsage: openAiUsage.status === "fulfilled" ? openAiUsage.value : [],
          };
        }

        ctx.res = {
          status: 200,
          body: {
            ...project,
            filesUrl: project.url,
            rolesAndEntitlements: project.rolesAndEntitlements.map(
              ({ roles, iamRoles, entitlements }) => ({
                // mapping done with value and type for FE format
                roles: roles.map(({ roleName }) => roleName),
                iamRoles: iamRoles.map(({ roleName }) => roleName),
                entitlements,
              }),
            ),
          },
        };
      }),
    ),
  ),
  { allowNonEscb: true },
);

type ProjectProps = Pick<
  Project,
  | "description"
  | "dataSensitivityLevel"
  | "confidentialityLevel"
  | "accessibilityLevel"
  | "tags"
  | "icon"
>;

type PatchProps = {
  body: ProjectProps;
  params: { pid: string };
};

app.patch<PatchProps>(
  withProject(
    withOwnerPermissions(async (ctx) => {
      const { project } = ctx;
      const body = ctx.req.body as ProjectProps;
      const {
        description,
        icon,
        tags,
        confidentialityLevel,
        accessibilityLevel,
        dataSensitivityLevel,
      } = body;

      const keysToBeUpdated = (Object.keys(body) as (keyof ProjectProps)[]).filter(
        (key) =>
          (key === "tags" && !arraysAreEquivalent(project[key], body[key])) ||
          (key !== "tags" && project[key] !== body[key]),
      );

      // check types of values
      for (const key of keysToBeUpdated) {
        const value = body[key];
        // only tags are a string array, the others are string
        if (
          (key === "tags" && !Array.isArray(value)) || // tags are not array
          (key === "tags" &&
            Array.isArray(value) &&
            !value.every((tag) => typeof tag === "string")) || // tags are array but not array of strings
          (key !== "tags" && typeof value !== "string") // every other value is not string
        ) {
          const message = `Error updating project. Check types of input for ${keysToBeUpdated.join(", ")}`;
          ctx.log(message, { value });
          ctx.res = { status: 400, body: { message } };
          return;
        }
      }

      // update description, icon, tags if any are passed
      // we are updating these first in case the second set of updates cannot happen
      const easyPossibleKeys = new Set(["description", "icon", "tags"]);
      const easyKeys = keysToBeUpdated.filter((key) => easyPossibleKeys.has(key));
      if (easyKeys.length) {
        // update DB
        await ProjectModel.findOneAndUpdate(
          { _id: project._id },
          { $set: { description, icon, tags } },
        );

        await ProjectService.saveUpdateProjectUserActions(
          ctx,
          ctx.session.oid,
          { description, icon, tags },
          project,
        );
      }

      // additional checks needed for confidentiality, data sensitivity and accessibility
      if (!keysToBeUpdated.some((key) => !easyPossibleKeys.has(key))) {
        ctx.res = { status: 200 };
        return;
      }
      const confidentialityPending = await ProjectService.isConfidentialityPending(project._id);

      // checking for a pending confidentiality level
      if (confidentialityPending.length) {
        const message = `Error updating confidentiality, accessibility or data sensitivity level: there is a pending confidentiality ${confidentialityPending[0].confidentialityLevel}`;
        ctx.log(message);
        ctx.res = { status: 400, body: { message } };
        return;
      }

      // checking if the new values are compatible
      if (
        !ProjectService.isConfidentialityValid(
          body.accessibilityLevel,
          body.confidentialityLevel,
          body.dataSensitivityLevel,
        )
      ) {
        const message = `Error updating confidentiality, accessibility or data sensitivity level: the values are not valid`;
        ctx.log(message);
        ctx.res = { status: 400, body: { message } };
        return;
      }

      if (
        project.workspaceType === WorkspaceType.EXPLORATORY &&
        dataSensitivityLevel === DataSensitivityLevel.CSI
      ) {
        const message = `Cannot set data sensitivity level to CSI when workspace type is exploratory`;
        ctx.log(message);
        ctx.res = { status: 400, body: { message } };
        return;
      }

      const [updatedProject] = await Promise.all([
        ProjectModel.findOneAndUpdate(
          { _id: project._id },
          { $set: { accessibilityLevel } },
          { new: true },
        ),
        ProjectService.saveUpdateProjectUserActions(
          ctx,
          ctx.session.oid,
          { accessibilityLevel },
          project,
        ),
      ]);

      if (!updatedProject) {
        const error = `Missing project with id ${project._id}`;
        ctx.res = { status: 400, body: { message: error } };
        return;
      }

      const status = await ProjectService.setConfidentialityLevel(
        ctx,
        updatedProject,
        ctx.session.oid,
        ctx.session.name,
        confidentialityLevel,
        dataSensitivityLevel,
      );

      if (status === UpdateStatus.DONE) {
        const [bcc] = await Promise.all([
          GraphService.getGroupUsersEmails(ctx, project.teamGroupId),
          ProjectModel.updateOne({ _id: project._id }, { $set: { dataSensitivityLevel } }),
        ]);

        // notify owners
        await Promise.all([
          NotificationService.sendDataSensitivityChangeEmail(ctx, {
            projectName: project.name,
            bcc,
            dataSensitivityLevel,
            ctaUrl: ProjectService.getProjectUrl(project),
          }),
          ProjectService.saveUpdateProjectUserActions(
            ctx,
            ctx.session.oid,
            { confidentialityLevel, dataSensitivityLevel },
            project,
          ),
        ]);
      }
      ctx.res = { status: 200, body: { status } };
    }),
  ),
);

export const mainHandler = app;
