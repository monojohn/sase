import { ProjectFilter } from "../../../features/projectSearch/enums";
import { searchProjects } from "../../../features/projectSearch/projectSearch";
import { withVisitLogging } from "../../../features/userVisits/withVisitLogging";
import { withPermissions } from "../../../middleware/withPermissions";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import { SortOrder } from "../../../services/projectService/types";
import { getTeamGroupName } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

const FilterableProjectProps: (keyof Project)[] = ["_id", "name", "siteId", "status"];

export type GetProjects = {
  query: {
    skip?: number;
    limit?: number;
    search?: string;
    sort?: keyof Project;
    order?: SortOrder;
    select?: string;
    filter?: ProjectFilter;
  };
};

app.get<GetProjects>(
  withPermissions(
    withVisitLogging(async (ctx) => {
      const { session, permissions } = ctx;
      const { oid } = session;
      const {
        skip = 0,
        limit = 10,
        search = "",
        sort = "updatedAt",
        order = "desc",
        select,
        filter,
        ...query
      } = ctx.req.query;

      // force cast
      const queryLimit = +limit;
      if (typeof queryLimit !== "number" || !queryLimit) {
        ctx.res = {
          status: 400,
          body: { message: `Invalid limit: ${limit} (${queryLimit})` },
        };
        return;
      }

      // force number conversion
      ctx.log(`Getting all projects`, permissions);
      const keys = Object.keys(query) as (keyof Project)[];
      // check fields being filtered
      for (let index = 0; index < keys.length; index++) {
        // check if field is whitelisted
        if (!FilterableProjectProps.includes(keys[index])) {
          ctx.res = {
            status: 400,
            body: { message: `Can only filter: ${FilterableProjectProps.join(", ")}` },
          };
          return;
        }
      }

      ctx.log("Filtering project with", {
        query,
        permissions,
        skip,
        queryLimit,
        search,
        sort,
        order,
      });

      ctx.res = {
        body: await searchProjects(ctx, oid, permissions, {
          skip,
          limit: queryLimit,
          filters: query,
          sortProp: sort,
          sortOrder: order,
          searchTerm: search,
          select: select?.split(",") as (keyof Project)[],
          filterType: filter,
        }),
      };
    }),
  ),
  { allowNonEscb: true },
);

type HeadProps = {
  query: {
    name?: string;
  };
};

/**
 * Search for a project name without restrictions
 *
 * Returns 200 when a project with the same name is found, otherwise 404
 */
app.head<HeadProps>(
  withPermissions(async (ctx) => {
    let { name } = ctx.req.query;
    name = name?.trim?.(); // defensively trim

    if (typeof name !== "string" || name.length < 3) {
      const message = `"name" must be a string with length >= 3, received "${name}"`;
      ctx.log(message);
      ctx.res = { status: 400, body: { message } };
      return;
    }

    const teamGroupName = getTeamGroupName(name);

    // find project by name or teamGroupName
    const project = await ProjectModel.findOne({ $or: [{ name }, { teamGroupName }] }).lean();

    // if project exists, return 200, otherwise 404
    ctx.res = {
      status: project ? 200 : 404,
    };
  }),
);

export const mainHandler = app;

export default mainHandler;
