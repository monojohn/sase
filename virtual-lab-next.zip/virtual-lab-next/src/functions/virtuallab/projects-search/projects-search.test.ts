import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { GetProjects, mainHandler } from "./projects-search";
import { ProjectFilter } from "../../../features/projectSearch/enums";
import FavoriteProjectModel from "../../../services/dbConnector/models/favoriteProjectModel";
import OwnershipInviteModel from "../../../services/dbConnector/models/ownershipInviteModel";

const ctx = getCtx({ name: "Project search" });

describe("Project search", () => {
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));

    jest.spyOn(GraphService, "getGroupOwnersEmails").mockImplementation(async () => ["email"]);

    // create 50 projects
    const promises: Promise<Project>[] = [];
    for (let index = 0; index < 50; index++) {
      promises.push(
        createTestProject({ name: `project-search proj ${index}`, owners: [ctx.authOid] }),
      );
    }
    await Promise.all(promises);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupOwnersEmails").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.params = {};
    ctx.req.query = {};
  });

  describe("GET projects", () => {
    it("Returns 400 when bad filters are passed", async () => {
      ctx.req.query.owners = ["ownerId"];

      await mainHandler(ctx);

      expect(ctx.res.status).toBe(400);
    });

    it("Returns [] when there are no projects", async () => {
      ctx.req.query.search = genId();

      await mainHandler(ctx);

      expect(ctx.res.body).toEqual({ total: 0, data: [] });
    });

    it("Defaults to 10 limit", async () => {
      await mainHandler(ctx);

      expect(ctx.res.body.data.length).toBe(10);
      expect(ctx.res.body.total).toBeGreaterThanOrEqual(50);
    });

    it("Respects user set limit", async () => {
      ctx.req.query.limit = 16;

      await mainHandler(ctx);

      expect(ctx.res.body.data.length).toBe(16);
      expect(ctx.res.body.total).toBeGreaterThanOrEqual(50);
    });

    it("GETs projects sorted alphabetically in asc order", async () => {
      const p1Name = `project-search_AAAAA`;
      const p1 = await createTestProject({ name: p1Name, owners: [ctx.authOid] });
      const p2Name = `project-search_BBBBB`;
      const p2 = await createTestProject({ name: p2Name, owners: [ctx.authOid] });

      const projectData: GetProjects = {
        query: {
          sort: "name",
          order: "asc",
          search: "project-search_",
        },
      };
      ctx.req.query = projectData.query;
      await mainHandler(ctx);

      const body = ctx.res.body.data as Project[];

      expect(ctx.res.status).toBe(undefined);
      expect(body[0].name).toEqual(p1.name);
      expect(body[1].name).toEqual(p2.name);
    });

    it("GETs projects sorted alphabetically in desc order", async () => {
      const p1Name = `project-search_ZZZZ`;
      const p1 = await createTestProject({ name: p1Name, owners: [ctx.authOid] });
      const p2Name = `project-search_YYYY`;
      const p2 = await createTestProject({ name: p2Name, owners: [ctx.authOid] });

      const projectData: GetProjects = {
        query: {
          sort: "name",
          order: "desc",
          search: "project-search_",
        },
      };
      ctx.req.query = projectData.query;

      await mainHandler(ctx);

      const body = ctx.res.body.data as Project[];

      expect(ctx.res.status).toBe(undefined);
      expect(body[0].name).toEqual(p1.name);
      expect(body[1].name).toEqual(p2.name);
    });

    it("GETs projects sorted in asc created order", async () => {
      const p1Name = `project-search_ASC_1`;
      const p1 = await createTestProject({ name: p1Name, owners: [ctx.authOid] });
      const p2Name = `project-search_ASC_2`;
      const p2 = await createTestProject({ name: p2Name, owners: [ctx.authOid] });

      ctx.req.query.sort = "createdAt";
      ctx.req.query.search = "project-search_ASC";
      ctx.req.query.order = "asc";

      await mainHandler(ctx);

      const body = ctx.res.body.data as Project[];

      expect(ctx.res.status).toBe(undefined);
      expect(body[0].name).toEqual(p1?.name);
      expect(body[1].name).toEqual(p2?.name);
      expect(ctx.res.body.total).toBe(2);
    });

    it("GETs projects sorted in desc order", async () => {
      const p1Name = `project-search_DESC_1`;
      const p1 = await createTestProject({ name: p1Name, owners: [ctx.authOid] });

      const p2Name = `project-search_DESC_2`;
      const p2 = await createTestProject({ name: p2Name, owners: [ctx.authOid] });

      ctx.req.query.search = "project-search";
      ctx.req.query.sort = "createdAt";
      ctx.req.query.order = "desc";

      await mainHandler(ctx);

      const body = ctx.res.body.data as Project[];

      expect(ctx.res.status).toBe(undefined);
      expect(body[0].name).toBe(p2.name);
      expect(body[1].name).toBe(p1.name);
    });

    it("Filters project by _id correctly", async () => {
      const project = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.query._id = project._id;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body[0].name).toEqual(project.name);
      expect(body.length).toBe(1);
    });

    it("Filters project by name correctly", async () => {
      const project = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.query.name = project.name;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body[0]._id).toEqual(project._id);
      expect(body.length).toBe(1);
    });

    it("Searches project correctly with multiple terms", async () => {
      // finds project when all terms are found, even spread across
      const project = await createTestProject({
        owners: [ctx.authOid],
        name: "abcd",
        description: "efgh",
      });
      ctx.req.query.search = "abcd efgh";

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body[0]._id).toEqual(project._id);
      expect(body.length).toBe(1);

      // doesn't find project when not all terms are found
      ctx.req.query.search = "abcd efgh ijkl";

      await mainHandler(ctx);
      const data = ctx.res.body.data as Project[];

      expect(data.length).toBe(0);
    });

    it("Selects only name of the project", async () => {
      ctx.req.query.select = "name";

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body[0].name).toBeDefined();
      expect(body[0].description).toBeUndefined();
    });

    it("Filters by type ownership", async () => {
      const ownerProject = await createTestProject({ owners: [ctx.authOid] });
      const memberProject = await createTestProject({ members: [ctx.authOid] });
      ctx.req.query.filter = ProjectFilter.ownership;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body.map(({ name }) => name)).toContain(ownerProject.name);
      expect(body.map(({ name }) => name)).not.toContain(memberProject.name);
    });

    it("Filters by type membership", async () => {
      const ownerProject = await createTestProject({ owners: [ctx.authOid] });
      const memberProject = await createTestProject({ members: [ctx.authOid] });
      ctx.req.query.filter = ProjectFilter.membership;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body.map(({ name }) => name)).not.toContain(ownerProject.name);
      expect(body.map(({ name }) => name)).toContain(memberProject.name);
    });

    it("Filters by type my projects", async () => {
      const ownerProject = await createTestProject({ owners: [ctx.authOid] });
      const memberProject = await createTestProject({ members: [ctx.authOid] });
      ctx.req.query.filter = ProjectFilter.myProjects;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body.map(({ name }) => name)).toContain(ownerProject.name);
      expect(body.map(({ name }) => name)).toContain(memberProject.name);
    });

    it("Filters by type favorites", async () => {
      const project = await createTestProject({});
      await FavoriteProjectModel.create({
        oid: ctx.authOid,
        pid: project._id,
      });
      ctx.req.query.filter = ProjectFilter.favorites;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body.map(({ name }) => name)).toContain(project.name);
    });

    it("Filters by type invitations", async () => {
      const project = await createTestProject({ owners: ["other-owner"] });
      await OwnershipInviteModel.create({
        pid: project._id,
        projectName: project.name,
        invitee: ctx.authOid,
        inviter: "other-owner",
        inviterName: "owner",
      });
      ctx.req.query.filter = ProjectFilter.invitations;

      await mainHandler(ctx);
      const body = ctx.res.body.data as Project[];

      expect(body.map(({ name }) => name)).toContain(project.name);
    });
  });

  describe("HEAD projects", () => {
    beforeAll(() => {
      ctx.req.method = "HEAD";
    });

    it("Returns 400 when name is not string", async () => {
      ctx.req.query.name = 12;

      await mainHandler(ctx);

      expect(ctx.res.status).toBe(400);
    });

    it("Returns 400 when name is string but less than 3 characters", async () => {
      ctx.req.query.name = "ab";

      await mainHandler(ctx);

      expect(ctx.res.status).toBe(400);
    });

    it("Returns 200 when name is string and at least 3 characters and project is found", async () => {
      ctx.req.query.name = "abc";
      await createTestProject({ name: "abc" });

      await mainHandler(ctx);

      expect(ctx.res.status).toBe(200);
    });

    it("Returns 404 when name is string and at least 3 characters and project is not found", async () => {
      ctx.req.query.name = "abcdef";

      await mainHandler(ctx);

      expect(ctx.res.status).toBe(404);
    });
  });
});
