import projectCreation from "../../../features/projectCreation/projectCreation";
import { CreateProjectProps } from "../../../features/projectCreation/types";
import { withParamCheck } from "../../../middleware/withParamCheck";
import { withRequestLogging } from "../../../middleware/withRequestLogging";

const mandatoryProps: (keyof CreateProjectProps)[] = ["owner", "project", "projectCreationType"];

const funcName = "project-creation-queue";

export const mainHandler = withRequestLogging(
  funcName,
  withParamCheck(funcName, mandatoryProps, projectCreation),
);
