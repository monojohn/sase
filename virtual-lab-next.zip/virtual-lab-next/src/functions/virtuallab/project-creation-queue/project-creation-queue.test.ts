import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { ProjectCreationType } from "../../../services/projectService/enums";
import { mainHandler } from "./project-creation-queue";

const ctx = getCtx({ name: "Project creation" });

describe("Project creation", () => {
  beforeAll(() => {
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementation(async () => ({ id: "id", identities: [], mail: "mail" }) as any);
    jest
      .spyOn(GraphService, "getGroupByName")
      .mockImplementation(async () => [{ id: "id" }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(GraphService, "getGroupByName").mockRestore();
  });

  it("Returns false when group already exists", async () => {
    const testProject = await createTestProject();
    expect(
      await mainHandler(ctx, {
        project: testProject,
        owner: "userid",
        projectCreationType: ProjectCreationType.NO_APPROVAL,
      }),
    ).toBe(false);

    expect(ctx.res).toBe(undefined);
  });
});
