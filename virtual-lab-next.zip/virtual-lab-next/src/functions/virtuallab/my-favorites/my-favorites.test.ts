import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import FavoriteProjectModel from "../../../services/dbConnector/models/favoriteProjectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-favorites";

const ctx = getCtx({ name: "My favorites" });

describe("My favorites", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.params = {};
    ctx.req.body = {};
  });

  describe("Get favorites", () => {
    it("Returns all favorites", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual([]);
    });

    it("Returns 404 when an id is sent but not found", async () => {
      ctx.req.params.id = genId();

      await mainHandler(ctx);

      expect(ctx.res).toEqual({
        status: 404,
        body: { message: `Request with Id ${ctx.req.params.id} not found` },
      });
    });

    it("Returns favorite by id", async () => {
      const fav = await FavoriteProjectModel.create({ oid: ctx.authOid, pid: genId() });

      ctx.req.params.id = fav._id.toString();
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual(fav.toObject());
    });
  });

  describe("Create favorite", () => {
    beforeAll(() => {
      ctx.req.method = "POST";
    });

    it("Returns 400 when the project does not exist", async () => {
      ctx.req.method = "POST";
      ctx.req.body.pid = genId();

      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(400);
    });

    it("Returns 200 when fav is added", async () => {
      // create project to favorite
      const project = await createTestProject({ owners: [ctx.authOid] });

      const pid = project._id.toString();
      ctx.req.method = "POST";
      ctx.req.body.pid = pid;

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      const fav = await FavoriteProjectModel.findOne({ pid }).lean();
      expect(fav).not.toBeNull();
    });

    it("Returns 200 when fav is added twice", async () => {
      const project = await createTestProject();

      const pid = project._id.toString();
      ctx.req.method = "POST";
      ctx.req.body.pid = pid;

      // add it once
      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      // add it again
      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      // only 1 entry created
      const fav = await FavoriteProjectModel.find({ pid });
      expect(fav.length).toBe(1);
    });
  });

  describe("Delete favorite", () => {
    it("Returns 200 when favorite does not exist", async () => {
      ctx.req.method = "DELETE";
      ctx.req.params.id = genId();

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);
    });

    it("Returns 200 when favorite exists and is deleted", async () => {
      ctx.req.method = "DELETE";

      const fav = await FavoriteProjectModel.create({ oid: ctx.authOid, pid: "pid2" });
      const favId = fav._id.toString();
      ctx.req.params.id = favId;

      await mainHandler(ctx);
      expect(ctx.res).toEqual(undefined);

      expect(await FavoriteProjectModel.findById(favId)).toBeNull();
    });
  });
});
