import {
  canUserViewProject,
  getUserPermissions,
  withPermissions,
} from "../../../middleware/withPermissions";
import { FavoriteProject } from "../../../services/dbConnector/models/favoriteProject";
import FavoriteProjectModel from "../../../services/dbConnector/models/favoriteProjectModel";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
};

/**
 * Get my favorites
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { oid } = ctx.session;
    let body: FavoriteProject | FavoriteProject[];

    if (id) {
      const item = await FavoriteProjectModel.findOne({ _id: id, oid }).lean();

      if (!item) {
        // return 404 when item is not found
        ctx.res = {
          status: 404,
          body: { message: `Request with Id ${id} not found` },
        };
        return;
      }

      body = item;
    } else {
      body = await FavoriteProjectModel.find({ oid }).lean();
    }

    ctx.res = { body };
  }),
  { allowNonEscb: true },
);

type PostProps = {
  params: { id: string };
  body: { pid: string };
};

/**
 * Add favorite
 */
app.post<PostProps>(
  withPermissions(async (ctx) => {
    const { pid } = ctx.req.body as { pid: string };
    const { oid } = ctx.session;

    const [project, favorite] = await Promise.all([
      ProjectModel.findById(pid),
      FavoriteProjectModel.findOne({ oid, pid }).lean(),
    ]);

    // error if project does not exist
    if (!project) {
      const message = `Project with id '${pid}' not found`;
      ctx.log(message);
      ctx.res = { status: 400, body: { message } };
      return;
    }

    const permissions = await getUserPermissions(ctx, oid, project);

    if (!canUserViewProject(project, permissions)) {
      const message = `User does not have read access to project "${project.name}" (${pid})`;
      ctx.log(message, permissions);
      ctx.res = { status: 400, body: { message } };
      return;
    }

    if (favorite) {
      // ignore if favorite already added
      return ctx.log(`favorite with same props exits, skipping creation`);
    }

    // otherwise add favorite
    ctx.log(`Adding project ${project.name} to favorites of ${oid}`);
    await FavoriteProjectModel.create({ oid, pid });
  }),
  { allowNonEscb: true },
);

/**
 * remove favorite
 */
app.delete<Props>(
  withPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { oid } = ctx.session;

    await FavoriteProjectModel.deleteOne({ _id: id, oid }).lean();
  }),
  { allowNonEscb: true },
);

export const mainHandler = app;
