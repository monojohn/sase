import { withAdminPermissions } from "../../../middleware/withPermissions";
import MlWhitelistRequestModel from "../../../services/dbConnector/models/mlWhitelistRequestModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get<void>(
  withAdminPermissions(async (ctx) => {
    ctx.res = {
      body: await MlWhitelistRequestModel.find({}).lean(),
    };
  }),
);

export const mainHandler = app;
