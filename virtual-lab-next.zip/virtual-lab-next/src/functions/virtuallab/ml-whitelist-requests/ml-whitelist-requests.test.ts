import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./ml-whitelist-requests";

const ctx = getCtx({ name: "ml-whitelist-requests" });

describe("ML Whitelist", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: true,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("GET ml Whitelist Requests", () => {
    beforeEach(() => {
      ctx.req.body = {};
      ctx.res = undefined;
    });

    it("Returns an [] in the body", async () => {
      await mainHandler(ctx);
      expect(Array.isArray(ctx.res.body)).toEqual(true);
    });
  });
});
