/* eslint-disable consistent-return */
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { DataSensitivityLevel } from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectService from "../../../services/projectService/projectService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions((ctx) => {
      const { project } = ctx;
      ctx.res = {
        status: 200,
        body: { dataSensitivityLevel: project.dataSensitivityLevel },
      };
    }),
  ),
);

type PatchProps = {
  body: Pick<Project, "dataSensitivityLevel">;
  params: { pid: string };
};

app.patch<PatchProps>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        const body = ctx.req.body as Partial<Project>;
        const value = body.dataSensitivityLevel as DataSensitivityLevel;
        const { name } = project;

        ctx.log(`Updating data sensitivity of ${name}`);

        const confidentialityPending = await ProjectService.isConfidentialityPending(project._id);

        if (confidentialityPending.length) {
          const message = `Error updating data sensitivity: there is a pending confidentiality ${confidentialityPending[0].confidentialityLevel}`;
          ctx.log(message, { value });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        if (typeof value !== "string") {
          const message = `Error updating data sensitivity of ${name}: "${typeof value}" is invalid`;
          ctx.log(message, { value });
          ctx.res = { status: 400, body: { message } };
          return;
        }

        await ProjectService.setDataSensitivityLevel(ctx, project, value);

        // notify team users
        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          type: ActionType.UPDATE_DATA_SENSITIVITY,
          project: { id: project._id, name },
          target: { id: "dataSensitivityLevel", name: value },
          triggerer: { id: session.oid, displayName: session.name },
        });
      }, ActionType.UPDATE_DATA_SENSITIVITY),
    ),
  ),
);

export const mainHandler = app;
