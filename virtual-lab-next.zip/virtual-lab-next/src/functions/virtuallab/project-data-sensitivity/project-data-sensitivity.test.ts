import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  RequestStatus,
  RequestType,
} from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { WorkspaceType } from "../../../services/sharepointService/enums";
import { mainHandler } from "./project-data-sensitivity";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";

const ctx = getCtx({ name: "Project data sensitivity" });

describe("Project data sensitivity", () => {
  let testProject: Project;
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(GraphService, "getGroupIdByName").mockImplementation(async () => "id");
    jest
      .spyOn(GraphService, "getGroupUsersEmails")
      .mockImplementation(async () => [{ mail: global.testEmail } as any]);

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params = { pid: testProject._id };
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(GraphService, "getGroupIdByName").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
  });

  describe("GET project data sensitivity", () => {
    it("Returns project data sensitivity", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body?.dataSensitivityLevel).toBe(testProject.dataSensitivityLevel);
    });
  });

  describe("PATCH project data sensitivity", () => {
    beforeAll(() => {
      ctx.req.method = "PATCH";
    });

    it("Returns 400 when there's an open request on confidentiality", async () => {
      await IgamRequestModel.create({
        pid: testProject._id,
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requesterId: "me",
      });
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      await IgamRequestModel.deleteMany();
    });

    it("Returns 400 when invalid data sensitivity type is passed", async () => {
      ctx.req.body = { dataSensitivityLevel: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Throws error when data sensitivity does not match confidentiality", async () => {
      const newLevel = DataSensitivityLevel.CSI;
      ctx.req.body = { dataSensitivityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(500);
      expect(ctx.res.body.error).toEqual(
        `${DataSensitivityLevel.CSI} is invalid for a ${ConfidentialityLevel.PUBLIC} project`,
      );
    });

    it("Throws error when data sensitivity does not match workspace type", async () => {
      const newTestProject = await createTestProject({
        owners: [ctx.authOid],
        accessibilityLevel: AccessibilityLevel.Protected,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        workspaceType: WorkspaceType.EXPLORATORY,
      });
      ctx.req.params = { pid: newTestProject._id };

      const newLevel = DataSensitivityLevel.CSI;
      ctx.req.body = { dataSensitivityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(500);
      expect(ctx.res.body.error).toEqual(
        `${DataSensitivityLevel.CSI} is invalid for a ${WorkspaceType.EXPLORATORY} ML workspace`,
      );
    });

    it("Updates project data sensitivity level", async () => {
      const newTestProject = await createTestProject({
        owners: [ctx.authOid],
        accessibilityLevel: AccessibilityLevel.Protected,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      });
      ctx.req.params = { pid: newTestProject._id };

      const newLevel = DataSensitivityLevel.CSI;
      ctx.req.body = { dataSensitivityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);

      // check project was updated
      let proj = await ProjectModel.findById(ctx.req.params.pid);
      expect(proj?.dataSensitivityLevel).toBe(newLevel);

      // update to previous value
      const oldLevel = DataSensitivityLevel.No;
      ctx.req.body = { dataSensitivityLevel: oldLevel };
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);

      // check project was updated
      proj = await ProjectModel.findById(ctx.req.params.pid);
      expect(proj?.dataSensitivityLevel).toBe(oldLevel);
    });
  });
});
