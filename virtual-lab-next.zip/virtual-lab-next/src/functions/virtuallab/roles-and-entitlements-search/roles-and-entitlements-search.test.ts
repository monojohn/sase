import { jest } from "@jest/globals";

import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./roles-and-entitlements-search";
import GraphService from "../../../services/graphService/graphService";
import RolesService from "../../../services/igamService/rolesService";
import IamService from "../../../services/iamService/iamService";
import EntitlementsService from "../../../services/igamService/entitlementsService";

const ctx = getCtx({ name: "Roles search", authorization: global.adminJwt });

describe("Roles search", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest
      .spyOn(RolesService, "searchByName")
      .mockImplementation(async () => [{ displayName: "role", roleName: "role" }] as any);
    jest
      .spyOn(IamService, "getRoles")
      .mockImplementation(async () => [{ displayName: "ent" }] as any);
    jest
      .spyOn(EntitlementsService, "searchByName")
      .mockImplementation(async () => [{ displayName: "ent" }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(RolesService, "searchByName").mockRestore();
    jest.spyOn(IamService, "getRoles").mockRestore();
    jest.spyOn(EntitlementsService, "searchByName").mockRestore();
  });
  it("Returns 400 when no name is sent", async () => {
    ctx.req.query = {
      name: undefined,
    };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(400);
  });

  it("Returns 400 when name is not a string", async () => {
    ctx.req.query = {
      name: ["ECBPROD-DSS-USG-SEC-CA-P-Consultants"],
    };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(400);
  });

  it("Returns 400 when name is 2 chars length", async () => {
    ctx.req.query = {
      name: "AD",
    };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(400);
  });

  it("Returns roles, iamRoles and entitlements as arrays", async () => {
    ctx.req.query = {
      name: "ECBPROD-DSS-USG-SEC-CA-P-Consultants",
    };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(200);
    expect(ctx.res.body.roles.length).toBeGreaterThan(0);
    expect(ctx.res.body.iamRoles.length).toBeGreaterThan(0);
    expect(ctx.res.body.entitlements.length).toBeGreaterThan(0);
  });
});
