import { withPermissions } from "../../../middleware/withPermissions";
import IamService from "../../../services/iamService/iamService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import RolesService from "../../../services/igamService/rolesService";
import { stripInvalidChars } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type GetProps = {
  query: {
    name: string;
  };
};

app.get<GetProps>(
  withPermissions(async (ctx) => {
    const name = ctx.req.query?.name;
    ctx.log(`Searching roles with '${name}'`);

    // validate request params
    if (!name || typeof name !== "string" || name?.length < 3) {
      ctx.res = {
        status: 400,
        body: {
          message: `name query param is a required string and must have at least 3 valid chars`,
        },
      };
      return;
    }

    const cleanName = stripInvalidChars(name);

    if (cleanName.length < 3) {
      ctx.res = {
        status: 400,
        body: {
          message: `name query param is a required string and must have at least 3 valid chars`,
        },
      };
    }

    // get role by name
    const rolesAndEntitlements = await Promise.allSettled([
      RolesService.searchByName(ctx, `*${cleanName}*`),
      IamService.getRoles(ctx, cleanName),
      EntitlementsService.searchByName(ctx, `*${cleanName}*`),
    ]);

    const roles =
      rolesAndEntitlements[0].status === "fulfilled" ? rolesAndEntitlements[0].value : [];
    const iamRoles =
      rolesAndEntitlements[1].status === "fulfilled" ? rolesAndEntitlements[1].value : [];
    const entitlements =
      rolesAndEntitlements[2].status === "fulfilled" ? rolesAndEntitlements[2].value : [];
    ctx.log(
      `Found ${roles.length ?? 0} roles, ${iamRoles.length ?? 0} IAM roles and ${entitlements.length ?? 0} entitlements with (clean) name ${cleanName}`,
    );

    ctx.res = {
      status: 200,
      body: {
        roles: roles.map((role) => role.roleName),
        iamRoles: iamRoles.map((role) => role.roleName),
        entitlements: entitlements.map((entitlement) => entitlement.displayName),
      },
    };
  }),
);

export const mainHandler = app;
