import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { ProjectStatus } from "../../../services/dbConnector/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import QueueService, { QUEUE } from "../../../services/queueService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { DeleteProjectProps } from "../project-deletion-queue/project-deletion-queue";

const app = HttpTriggerFunction();

app.delete<{ params: { id: string } }>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        ctx.log(`Deleting project by id: ${project._id}`);

        await ProjectModel.updateOne(
          { _id: project._id },
          { $set: { status: ProjectStatus.BeingDeleted } },
        );

        const message: DeleteProjectProps = { pid: project._id, oid: session.oid };

        // add item to queue
        await QueueService.put(QUEUE.DELETE_PROJECT, message);
      }, ActionType.DELETE_PROJECT),
    ),
  ),
);

export const mainHandler = app;
