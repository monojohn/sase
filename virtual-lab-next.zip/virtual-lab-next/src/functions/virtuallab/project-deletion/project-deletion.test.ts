import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import QueueService, { QUEUE } from "../../../services/queueService";
import { mainHandler } from "./project-deletion";

const ctx = getCtx({ method: "DELETE", name: "Project deletion" });

describe("Project deletion", () => {
  const mockFn = jest.fn(async () => void 0);

  beforeAll(() => {
    jest.spyOn(QueueService, "put").mockImplementation(mockFn);
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(QueueService, "put").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("DELETE project", () => {
    let testProject: Project;

    beforeAll(async () => {
      testProject = await createTestProject({ owners: [ctx.authOid] });
      ctx.req.params = { pid: testProject._id };
    });

    it("Adds a delete project queue message", async () => {
      await mainHandler(ctx);

      expect(mockFn).toHaveBeenCalledWith(QUEUE.DELETE_PROJECT, {
        pid: ctx.req.params.pid,
        oid: ctx.authOid,
      });
    });
  });
});
