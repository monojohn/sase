import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-project-access";
import { AccessibilityLevel } from "../../../services/dbConnector/enums";

const ctx = getCtx({ name: "My project access" });

describe("My project access", () => {
  let testProject: Project;
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    testProject = await createTestProject({ accessibilityLevel: AccessibilityLevel.Private });
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  beforeEach(() => {
    ctx.req.params = {};
    ctx.res = undefined;
  });

  describe("GET my project access", () => {
    it("Returns false when project does not exist", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual(false);
    });

    it("Returns true when user is admin", async () => {
      ctx.req.params.pid = testProject._id;
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementationOnce(async () => ({
        isAdmin: true,
        isNonEscb: false,
        isVlUser: true,
      }));
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual(true);
    });

    it("Returns false when none of the conditions are met", async () => {
      ctx.req.params.pid = testProject._id;
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual(false);
    });
  });
});
