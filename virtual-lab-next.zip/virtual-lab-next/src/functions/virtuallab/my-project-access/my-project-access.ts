import { withPermissions } from "../../../middleware/withPermissions";
import { AccessibilityLevel } from "../../../services/dbConnector/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { pid: string };
};

/**
 * Get all projects the users belongs to
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { oid } = ctx.session;
    const { pid } = ctx.req.params;
    const { isAdmin } = ctx.permissions;

    const project = await ProjectModel.findOne({ _id: pid });
    if (!project) {
      ctx.res = { body: false };
      return;
    }

    if (
      project.owners.includes(oid) ||
      project.members.includes(oid) ||
      project.accessibilityLevel === AccessibilityLevel.Public ||
      isAdmin
    ) {
      ctx.res = { body: true };
      return;
    }

    ctx.res = {
      body: false,
    };
  }),
  { allowNonEscb: true },
);

export const mainHandler = app;
