import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withAdminPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { RequestStatus, RequestType, UpdateStatus } from "../../../services/dbConnector/enums";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import { activeRequestsExist, buildJustification } from "../../../services/igamService/helpers";
import OrgService from "../../../services/igamService/orgService";
import NotificationService from "../../../services/projectService/notificationService";
import { requiresManagerApproval } from "../../../utils/helpers";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type DefaultBody = {
  org: string;
};

type DefaultProps = {
  pid: string;
  body: DefaultBody;
};

/**
 * Get org of project
 */
app.get(
  withProject(
    withOwnerPermissions(async (ctx) => {
      const { project } = ctx;

      const orgPending = await IgamRequestModel.find({
        pid: project._id,
        requestType: RequestType.UPDATE_ORG,
        requestStatus: { $in: [RequestStatus.AWAITING_APPROVAL, RequestStatus.PENDING] },
      });

      const { org } = project;

      // get departments of ECB owners
      const ecbOwners = await GraphService.getGroupMemberUsers(ctx, project.ownersGroupId, [
        "displayName",
        "department",
        "userType",
        "id",
      ]);

      const ownersDetails = await Promise.all(
        ecbOwners.map(async (user) => {
          const department = await GraphService.getUserDepartment(ctx, user);
          return {
            ...user,
            department,
          };
        }),
      );

      if (orgPending.length) {
        const { requestStatus, requestId, org: pendingOrg } = orgPending[0];
        ctx.res = {
          status: 200,
          body: {
            org,
            ecbOwners: ownersDetails,
            pendingOrg,
            status:
              requestStatus === RequestStatus.PENDING
                ? "Pending request"
                : `Awaiting approval for ${requestId}`,
          },
        };
        return;
      }

      ctx.res = {
        status: 200,
        body: { org, ecbOwners: ownersDetails },
      };
    }),
  ),
);

/**
 * Update org of project
 */
app.patch<DefaultProps>(
  withProject(
    withAdminPermissions(
      withActionLogging(async (ctx) => {
        const { session, project } = ctx;
        const { org } = ctx.req.body as DefaultBody;
        const { oid } = session;

        ctx.log(`New org: ${org}`);

        const ecbOwners = await GraphService.getGroupMemberUsers(ctx, project.ownersGroupId, [
          "id",
        ]);
        const userType = ecbOwners.length ? "Member" : "Guest";

        const requiresApproval = requiresManagerApproval(project.confidentialityLevel, userType);

        const { ownersGroupName, membersGroupName, teamGroupName, _id: pid } = project;

        // if no approval necessary, update org
        if (!requiresApproval) {
          await EntitlementsService.updateOrg(
            ctx,
            [ownersGroupName, membersGroupName, teamGroupName],
            org,
            false,
          );
          await ProjectModel.updateOne({ _id: project._id }, { $set: { org } });
          ctx.res = {
            status: 200,
            body: { status: UpdateStatus.DONE },
          };
          return;
        }

        // check if other requests are currently active
        const requestExists = await activeRequestsExist(pid);
        if (requestExists) {
          // create pending request
          const [userEmail] = await Promise.all([
            GraphService.getUserEmail(ctx, oid),
            IgamRequestModel.create({
              requestType: RequestType.UPDATE_ORG,
              requestStatus: RequestStatus.PENDING,
              pid,
              requesterId: oid,
              org,
            }),
          ]);
          await NotificationService.sendPendingRequestEmail(ctx, project.name, [userEmail]);
          ctx.res = {
            status: 200,
            body: { status: UpdateStatus.PENDING_REQUEST_CREATION },
          };
          return;
        }

        const [{ requestId }] = await EntitlementsService.updateOrg(
          ctx,
          [ownersGroupName],
          org,
          requiresApproval,
          buildJustification(project, session.name),
        );

        if (!requestId) {
          throw new Error(`Did not receive requestId when updating org for ${project.name}`);
        }
        const ownersEmails = await GraphService.getGroupUsersEmails(ctx, project.ownersGroupId);

        const approvers = await OrgService.getApproversEmails(ctx, org);
        await IgamRequestModel.create({
          requestType: RequestType.UPDATE_ORG,
          requestStatus: RequestStatus.AWAITING_APPROVAL,
          pid,
          requesterId: oid,
          org,
          requestId,
        });
        await NotificationService.sendOrgUpdateRequestedEmail(
          ctx,
          project.name,
          ownersEmails,
          requestId,
          org,
          approvers,
        );
        ctx.res = {
          status: 200,
          body: { status: UpdateStatus.PENDING_APPROVAL },
        };
      }, ActionType.UPDATE_ORG),
    ),
  ),
);

export const mainHandler = app;
