import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-organization";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import { Entitlement } from "../../../services/igamService/types";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import {
  ConfidentialityLevel,
  RequestStatus,
  RequestType,
  UpdateStatus,
} from "../../../services/dbConnector/enums";
import OrgService from "../../../services/igamService/orgService";

const ctx = getCtx({ name: "Project org" });

describe("Project org", () => {
  let testProject: Project;
  const entitlement: Entitlement = {
    id: "1",
    appInstance: "AADproduction",
    entType: "AAD-Team",
    owner: "owner",
    entCode: "123",
    approvalModel: "3",
    displayName: "name",
    members: [],
    criticality: "Low",
    description: "description",
    requestable: true,
    requestableBy: "",
  };
  beforeAll(async () => {
    jest
      .spyOn(GraphService, "getGroupMemberUsers")
      .mockImplementation(async () => [{ id: "user1" } as any]);
    jest
      .spyOn(EntitlementsService, "updateOrg")
      .mockImplementation(async () => [{ requestId: "123" }]);
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: true,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(GraphService, "getUserEmail").mockImplementation(async () => "mail");
    jest.spyOn(GraphService, "getGroupUsersEmails").mockImplementation(async () => ["mail"]);
    jest.spyOn(OrgService, "getApproversEmails").mockImplementation(async () => ["mail"]);

    testProject = await createTestProject({
      owners: [ctx.authOid],
      confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      org: entitlement.owner,
    });
    ctx.req.params = { pid: testProject._id };
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupMemberUsers").mockRestore();
    jest.spyOn(EntitlementsService, "updateOrg").mockRestore();
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserEmail").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
    jest.spyOn(OrgService, "getApproversEmails").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
  });

  describe("GET Project org", () => {
    beforeAll(() => {
      ctx.req.method = "GET";
    });
    it("Retrieves current org", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body?.org).toEqual(entitlement.owner);
    });

    it("Retrieves current org and org pending approval", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_ORG,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requestId: "1234",
        org: "new org",
      });
      await mainHandler(ctx);
      expect(ctx.res.body?.org).toBe(entitlement.owner);
      expect(ctx.res.body?.pendingOrg).toBe("new org");
      expect(ctx.res.body?.status).toBe("Awaiting approval for 1234");
      await IgamRequestModel.deleteOne({ _id: request._id });
    });

    it("Retrieves current org and org pending request creation", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_ORG,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.PENDING,
        org: "new org",
      });
      await mainHandler(ctx);
      expect(ctx.res.body?.org).toBe(entitlement.owner);
      expect(ctx.res.body?.pendingOrg).toBe("new org");
      expect(ctx.res.body?.status).toBe("Pending request");
      await IgamRequestModel.deleteOne({ _id: request._id });
    });
  });

  describe("PATCH Project org", () => {
    beforeAll(() => {
      ctx.req.method = "PATCH";
    });
    it("Updates org when no approval required", async () => {
      jest.spyOn(GraphService, "getGroupMemberUsers").mockImplementationOnce(async () => []);
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual(UpdateStatus.DONE);
    });

    it("Creates pending request when a different request is active", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_ORG,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requestId: "1234",
        org: "new org",
      });
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual(UpdateStatus.PENDING_REQUEST_CREATION);
      await IgamRequestModel.deleteOne({ _id: request._id });
    });

    it("Creates request in IGAM when no request is active", async () => {
      await IgamRequestModel.deleteMany({});
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual(UpdateStatus.PENDING_APPROVAL);
    });

    it("Throws error when requestId is missing", async () => {
      await IgamRequestModel.deleteMany({});
      jest.spyOn(EntitlementsService, "updateOrg").mockImplementationOnce(async () => [{}]);
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(500);
    });
  });
});
