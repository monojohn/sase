import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-planner";
import PlannerService from "../../../services/plannerService/plannerService";
import { PlannerTaskStatus } from "../../../services/plannerService/enums";

describe("Project planner", () => {
  const ctx = getCtx({ name: "Project planner" });

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockImplementation(
      async () =>
        [
          {
            title: "test 1",
            percentComplete: 0,
            dueDateTime: null,
          },
          {
            title: "test 2",
            percentComplete: 0,
            dueDateTime: "2025-11-19T10:00:00Z",
          },
          {
            title: "test 3",
            percentComplete: 50,
            dueDateTime: null,
          },
          {
            title: "test 4",
            percentComplete: 100,
            dueDateTime: null,
          },
        ] as any,
    );

    const testProject = await createTestProject({
      owners: [ctx.authOid],
      repositoryUrl: "repositoryUrl",
    });
    ctx.req.params.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockRestore();
  });

  it("Returns project planner tasks", async () => {
    await mainHandler(ctx);
    expect(ctx.res.body.tasks).toEqual([
      {
        title: "test 1",
        percentComplete: 0,
        dueDateTime: null,
        status: PlannerTaskStatus.notStarted,
      },
      {
        title: "test 2",
        percentComplete: 0,
        dueDateTime: "2025-11-19T10:00:00Z",
        status: PlannerTaskStatus.late,
      },
      {
        title: "test 3",
        percentComplete: 50,
        dueDateTime: null,
        status: PlannerTaskStatus.inProgress,
      },
      {
        title: "test 4",
        percentComplete: 100,
        dueDateTime: null,
        status: PlannerTaskStatus.completed,
      },
    ]);
  });
});
