import moment from "moment";
import { withMemberPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import PlannerService from "../../../services/plannerService/plannerService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";
import { PlannerTaskStatus } from "../../../services/plannerService/enums";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions(async (ctx) => {
      const { project } = ctx;
      const plannerTasks = await PlannerService.getAllPlannerTasks(ctx, project.teamGroupId);
      const tasks = plannerTasks.flat(1).map((task) => {
        let status: PlannerTaskStatus;
        if (task.dueDateTime && moment(task.dueDateTime).isBefore(moment())) {
          status = PlannerTaskStatus.late;
        } else if (task.percentComplete === 0) {
          status = PlannerTaskStatus.notStarted;
        } else if (task.percentComplete === 100) {
          status = PlannerTaskStatus.completed;
        } else {
          status = PlannerTaskStatus.inProgress;
        }
        return { ...task, status };
      });
      ctx.res = {
        body: {
          tasks,
        },
      };
    }),
  ),
);

export const mainHandler = app;
