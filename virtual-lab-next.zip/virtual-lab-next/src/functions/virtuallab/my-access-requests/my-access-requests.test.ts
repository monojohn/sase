import { jest } from "@jest/globals";
import { genId, getCtx } from "../../../../jest/helpers";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./my-access-requests";

const ctx = getCtx({ name: "My access requests" });

describe("My access requests", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });
  beforeEach(() => {
    ctx.req.params = {};
    ctx.res = undefined;
  });

  describe("GET my access requests", () => {
    it("Returns an array when no id is sent", async () => {
      await mainHandler(ctx);
      expect(Array.isArray(ctx.res.body)).toBe(true);
    });

    it("Returns 404 when a valid but missing id is sent", async () => {
      ctx.req.params = { id: genId() };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(404);
    });

    it("Returns 200 when a valid and existing item is sent", async () => {
      const baseData = { oid: ctx.authOid, pid: "pid", name: "name" };
      const entry = await JoinProjectRequestModel.create(baseData);
      ctx.req.params = { id: entry._id };
      await mainHandler(ctx);

      expect(ctx.res.body).toEqual(entry.toObject());
    });
  });

  describe("DELETE my access requests", () => {
    it("Returns 200 when the request is processed", async () => {
      ctx.req.params = { id: genId() };
      ctx.req.method = "DELETE";
      await mainHandler(ctx);
      expect(ctx.res).toBe(undefined);
    });
  });
});
