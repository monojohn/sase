import { withPermissions } from "../../../middleware/withPermissions";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import { ProjectRequest } from "../../../services/dbConnector/models/projectRequest";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type Props = {
  params: { id: string };
};

/**
 * Get my access/membership requests
 */
app.get<Props>(
  withPermissions(async (ctx) => {
    const { id } = ctx.req.params;
    const { oid } = ctx.session;
    let body: ProjectRequest | ProjectRequest[];

    if (id) {
      const item = await JoinProjectRequestModel.findOne({ _id: id, oid }).lean();

      if (!item) {
        // return 404 when item is not found
        ctx.res = {
          status: 404,
          body: { message: `Request with Id ${id} not found` },
        };
        return;
      }

      body = item;
    } else {
      body = await JoinProjectRequestModel.find({ oid });
    }

    ctx.res = { body };
  }),
  { allowNonEscb: true },
);

/**
 * Cancel access/membership request
 */
app.delete<Props>(
  withPermissions(async (ctx) => {
    const { id: _id } = ctx.req.params;
    const { oid } = ctx.session;

    await JoinProjectRequestModel.deleteOne({ _id, oid }).lean();
  }),
);

export const mainHandler = app;
