import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./statistics";
import StatisticsModel from "../../../services/dbConnector/models/statistics";
import GraphService from "../../../services/graphService/graphService";

const ctx = getCtx({ name: "Statistics", authorization: global.adminJwt });

describe("Statistics", () => {
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  it("Returns latest statistics", async () => {
    await StatisticsModel.create({
      registeredUsers: 2,
      projects: 10,
      activeUsers: 1,
      siteVisits: 3,
    });

    await StatisticsModel.create({
      registeredUsers: 7,
      projects: 10,
      activeUsers: 1,
      siteVisits: 3,
    });

    await mainHandler(ctx);

    expect(ctx.res.status).toEqual(200);
    expect(ctx.res.body.registeredUsers).toEqual(7);
  });
});
