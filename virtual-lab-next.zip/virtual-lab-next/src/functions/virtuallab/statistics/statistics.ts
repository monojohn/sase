import { withPermissions } from "../../../middleware/withPermissions";
import StatisticsModel from "../../../services/dbConnector/models/statistics";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withPermissions(async (ctx) => {
    ctx.res = {
      status: 200,
      body: (await StatisticsModel.find().sort({ updatedAt: -1 }).limit(1))[0],
    };
  }),
);

export const mainHandler = app;
