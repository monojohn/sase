import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  RequestStatus,
  RequestType,
} from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-confidentiality";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import OrgService from "../../../services/igamService/orgService";

const ctx = getCtx({ name: "Project confidentiality" });

describe("Project confidentiality", () => {
  let testProject: Project;
  beforeAll(async () => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest
      .spyOn(GraphService, "getGroupUsers")
      .mockImplementation(async () => [{ identities: [], mail: "mail", id: "123" }] as any);
    jest
      .spyOn(GraphService, "getGroupMemberUsers")
      .mockImplementation(async () => [{ id: "user1" } as any]);
    jest
      .spyOn(EntitlementsService, "updateConfidentiality")
      .mockImplementation(async () => [{ requestId: "123" }]);
    jest.spyOn(OrgService, "getApproversEmails").mockImplementation(async () => ["mail"]);

    testProject = await createTestProject({ owners: [ctx.authOid] });
    ctx.req.params = { pid: testProject._id };
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(GraphService, "getGroupMemberUsers").mockRestore();
    jest.spyOn(EntitlementsService, "updateConfidentiality").mockRestore();
    jest.spyOn(OrgService, "getApproversEmails").mockRestore();
  });

  beforeEach(() => {
    ctx.res = undefined;
    ctx.req.body = {};
  });

  describe("GET project confidentiality", () => {
    it("Returns project confidentiality", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body?.confidentialityLevel).toBe(testProject.confidentialityLevel);
    });

    it("Returns project confidentiality and pending confidentiality including request id", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requestId: "1234",
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      });
      await mainHandler(ctx);
      expect(ctx.res.body?.confidentialityLevel).toBe(testProject.confidentialityLevel);
      expect(ctx.res.body?.pendingConfidentiality).toBe(ConfidentialityLevel.CONFIDENTIAL);
      await IgamRequestModel.deleteOne({ _id: request._id });
    });

    it("Returns project confidentiality and pending confidentiality request", async () => {
      await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.PENDING,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      });
      await mainHandler(ctx);
      expect(ctx.res.body?.confidentialityLevel).toBe(testProject.confidentialityLevel);
      expect(ctx.res.body?.pendingConfidentiality).toBe(ConfidentialityLevel.CONFIDENTIAL);
    });
  });

  describe("PATCH project confidentiality", () => {
    beforeAll(() => {
      ctx.req.method = "PATCH";
    });

    it("Returns 400 when there's an open request on confidentiality", async () => {
      await IgamRequestModel.create({
        pid: testProject._id,
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requesterId: "me",
      });
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
      await IgamRequestModel.deleteMany();
    });

    it("Returns 400 when invalid confidentiality type is passed", async () => {
      ctx.req.body = { confidentialityLevel: 123 };
      await mainHandler(ctx);
      expect(ctx.res.status).toBe(400);
    });

    it("Throws error when confidentiality does not match accessibility", async () => {
      const newLevel = ConfidentialityLevel.SECRET;
      ctx.req.body = { confidentialityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(500);
      expect(ctx.res.body.error).toEqual(
        `${ConfidentialityLevel.SECRET} is invalid for a Public project with ${DataSensitivityLevel.No} data sensitivity level`,
      );
    });

    it("Updates project confidentiality", async () => {
      const newLevel = ConfidentialityLevel.UNRESTRICTED;
      ctx.req.body = { confidentialityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual("Done"); // represents success

      // check project was updated
      let proj = await ProjectModel.findById(ctx.req.params.pid);
      expect(proj?.confidentialityLevel).toBe(newLevel);

      // update to previous value
      const oldLevel = ConfidentialityLevel.PUBLIC;
      ctx.req.body = { confidentialityLevel: oldLevel };
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual("Done"); // represents success

      // check project was updated
      proj = await ProjectModel.findById(ctx.req.params.pid);
      expect(proj?.confidentialityLevel).toBe(oldLevel);
    });

    it("Creates request in IGAM", async () => {
      const newTestProject = await createTestProject({
        owners: [ctx.authOid],
        accessibilityLevel: AccessibilityLevel.Protected,
        confidentialityLevel: ConfidentialityLevel.RESTRICTED,
        dataSensitivityLevel: DataSensitivityLevel.No,
      });
      ctx.req.params = { pid: newTestProject._id };

      jest
        .spyOn(GraphService, "getGroupUsers")
        .mockImplementation(
          async () => [{ identities: [], mail: "mail", id: "123", userType: "Member" }] as any,
        );

      const newLevel = ConfidentialityLevel.CONFIDENTIAL;
      ctx.req.body = { confidentialityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual("Pending approval");
    });

    it("Creates pending request", async () => {
      const newTestProject = await createTestProject({
        owners: [ctx.authOid],
        accessibilityLevel: AccessibilityLevel.Protected,
        confidentialityLevel: ConfidentialityLevel.RESTRICTED,
        dataSensitivityLevel: DataSensitivityLevel.No,
      });
      ctx.req.params = { pid: newTestProject._id };

      await IgamRequestModel.create({
        requestType: RequestType.ADD_OWNER,
        requesterId: "me",
        pid: newTestProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        oid: "you",
      });

      jest
        .spyOn(GraphService, "getGroupUsers")
        .mockImplementation(
          async () => [{ identities: [], mail: "mail", id: "123", userType: "Member" }] as any,
        );

      const newLevel = ConfidentialityLevel.CONFIDENTIAL;
      ctx.req.body = { confidentialityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.body.status).toEqual("Pending request creation");
    });

    it("Throws error when confidentiality does not match data sensitivity", async () => {
      const newTestProject = await createTestProject({
        owners: [ctx.authOid],
        accessibilityLevel: AccessibilityLevel.Protected,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        dataSensitivityLevel: DataSensitivityLevel.CSI,
      });
      ctx.req.params = { pid: newTestProject._id };

      const newLevel = ConfidentialityLevel.SECRET;
      ctx.req.body = { confidentialityLevel: newLevel };
      await mainHandler(ctx);
      expect(ctx.res.status).toEqual(500);
      expect(ctx.res.body.error).toEqual(
        `${ConfidentialityLevel.SECRET} is invalid for a Protected project with ${DataSensitivityLevel.CSI} data sensitivity level`,
      );
    });
  });
});
