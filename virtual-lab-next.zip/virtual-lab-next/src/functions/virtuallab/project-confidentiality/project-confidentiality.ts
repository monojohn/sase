/* eslint-disable consistent-return */
import { ActionType } from "../../../features/userActions/enums";
import { withActionLogging } from "../../../features/userActions/withActionLogging";
import { withMemberPermissions, withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import { ConfidentialityLevel, RequestStatus } from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import ProjectService from "../../../services/projectService/projectService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get(
  withProject(
    withMemberPermissions(async (ctx) => {
      const { project } = ctx;

      const confidentialityPending = await ProjectService.isConfidentialityPending(project._id);

      if (confidentialityPending.length) {
        const { confidentialityLevel, requestStatus, requestId } = confidentialityPending[0];
        ctx.res = {
          status: 200,
          body: {
            confidentialityLevel: project.confidentialityLevel,
            pendingConfidentiality: confidentialityLevel,
            status:
              requestStatus === RequestStatus.PENDING
                ? "Pending request"
                : `Awaiting approval for ${requestId}`,
          },
        };
        return;
      }

      ctx.res = {
        status: 200,
        body: { confidentialityLevel: project.confidentialityLevel },
      };
    }),
  ),
);

type PatchProps = {
  body: Pick<Project, "confidentialityLevel" | "description">;
  params: { pid: string };
};

app.patch<PatchProps>(
  withProject(
    withOwnerPermissions(
      withActionLogging(async (ctx) => {
        const { project, session } = ctx;
        const body = ctx.req.body as {
          confidentialityLevel: ConfidentialityLevel;
          description: string;
        };
        const { description, confidentialityLevel } = body;
        const { name, _id: id } = project;

        ctx.log(`Updating confidentiality of ${name}`);

        const existingConfidentialityPending = await ProjectService.isConfidentialityPending(
          project._id,
        );

        if (existingConfidentialityPending.length) {
          const error = `Error updating confidentiality: there is a pending confidentiality already ${existingConfidentialityPending[0].confidentialityLevel}`;
          ctx.log(error, { confidentialityLevel });
          ctx.res = { status: 400, body: { message: error } };
          return;
        }

        if (typeof confidentialityLevel !== "string") {
          const error = `Error updating confidentiality of ${name}: "${typeof confidentialityLevel}" is invalid`;
          ctx.log(error, { confidentialityLevel });
          ctx.res = { status: 400, body: { message: error } };
          return;
        }

        const updatedProject = await ProjectModel.findOneAndUpdate(
          { _id: project._id },
          { $set: { description } },
          { new: true },
        );

        if (!updatedProject) {
          const error = `Missing project with id ${project._id}`;
          ctx.log(error, { confidentialityLevel });
          ctx.res = { status: 400, body: { message: error } };
          return;
        }

        const status = await ProjectService.setConfidentialityLevel(
          ctx,
          updatedProject,
          session.oid,
          session.name,
          confidentialityLevel,
        );

        // notify team users - to be updated when needed
        const { oid, name: displayName } = session;
        await UserNotificationService.notifyGroup(ctx, project.teamGroupId, {
          type: ActionType.UPDATE_CONFIDENTIALITY,
          project: { id, name },
          target: { id: "confidentialityLevel", name: confidentialityLevel },
          triggerer: { id: oid, displayName },
        });

        ctx.res = {
          status: 200,
          body: { status },
        };
      }, ActionType.UPDATE_CONFIDENTIALITY),
    ),
  ),
);

export const mainHandler = app;
