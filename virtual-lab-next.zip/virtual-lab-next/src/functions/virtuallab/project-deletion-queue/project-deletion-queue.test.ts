import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import GraphService from "../../../services/graphService/graphService";
import ProjectDeletionService from "../../../services/projectService/projectDeletionService";
import SlackService from "../../../services/slackService";
import { DeleteProjectProps, mainHandler } from "./project-deletion-queue";

const ctx = getCtx({ name: "Project deletion queue" });

describe("Project deletion queue", () => {
  let testProject: Project;
  const props: DeleteProjectProps = { oid: ctx.authOid, pid: "" };
  const deletionMock = jest.fn(async () => void 0);

  beforeAll(async () => {
    jest.spyOn(GraphService, "getUser").mockImplementation(async () => ({}) as any);
    jest.spyOn(GraphService, "getGroupOwnersEmails").mockImplementation(async () => []);
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(ProjectDeletionService, "deleteProject").mockImplementation(deletionMock);

    // create test project
    testProject = await createTestProject({ owners: [ctx.authOid] });
    props.pid = testProject._id;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUser").mockRestore();
    jest.spyOn(GraphService, "getGroupOwnersEmails").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(ProjectDeletionService, "deleteProject").mockRestore();
  });

  it("Returns early when project doesn't exists", async () => {
    const slackMock = jest.fn(async () => void 0);
    jest.spyOn(SlackService, "logError").mockImplementationOnce(slackMock);
    const pid = genId();

    await mainHandler(ctx, { ...props, pid });

    expect(slackMock).toHaveBeenLastCalledWith(ctx, new Error(`Project ${pid} does not exist`));
  });

  it("Deletes project", async () => {
    await mainHandler(ctx, props);
    expect(deletionMock).toHaveBeenCalledTimes(1);
  });

  it("Handles errors", async () => {
    const slackMock = jest.fn(async () => void 0);
    jest.spyOn(SlackService, "logError").mockImplementationOnce(slackMock);

    const graphMock = jest.fn(async () => {
      throw new Error("error");
    });
    jest.spyOn(GraphService, "getGroupUsers").mockImplementationOnce(graphMock);

    await mainHandler(ctx, props);

    expect(slackMock).toHaveBeenLastCalledWith(
      ctx,
      new Error(`Failed to delete project #${props.pid}, triggered by user ${props.oid}`),
    );
  });
});
