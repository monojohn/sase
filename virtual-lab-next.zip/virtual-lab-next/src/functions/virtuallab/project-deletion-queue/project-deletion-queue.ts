import { MainHandler } from "../../../../@types/types";
import { ActionType } from "../../../features/userActions/enums";
import { withParamCheck } from "../../../middleware/withParamCheck";
import { withRequestLogging } from "../../../middleware/withRequestLogging";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import ProjectDeletionNotificationService from "../../../services/projectService/projectDeletionNotificationService";
import ProjectDeletionService from "../../../services/projectService/projectDeletionService";
import SlackService from "../../../services/slackService";
import UserNotificationService from "../../../services/userNotificationService/userNotificationService";
import { getEmailOfUser } from "../../../utils/helpers";

export type DeleteProjectProps = {
  pid: string; // project id to delete
  oid: string; // oid of user who triggered deletion
};

const mandatoryProps: (keyof DeleteProjectProps)[] = ["pid", "oid"];

const deleteProject: MainHandler<DeleteProjectProps> = async (ctx, props) => {
  const { pid, oid } = props;

  const [project, caller] = await Promise.all([
    ProjectModel.findById(pid),
    GraphService.getUser(ctx, oid),
  ]);

  ctx.log(`Deleting project by id: ${project?._id}, triggered by user ${oid}`);
  if (!project) {
    await SlackService.logError(ctx, new Error(`Project ${pid} does not exist`));
    return true;
  }

  try {
    ctx.log("Getting group users and deleting project");
    const [users] = await Promise.all([
      // user groups will be deleted afterwards so must be fetched before deletion
      GraphService.getGroupUsers(ctx, project.teamGroupId, [
        "id",
        "mail",
        "otherMails",
        "identities",
      ]),
      ProjectDeletionService.deleteProject(ctx, project),
    ]);

    ctx.log(`Notifying ${users.length} users`);
    await UserNotificationService.notifyUsers(ctx, users, {
      project: { id: project._id, name: project.name },
      type: ActionType.DELETE_PROJECT,
      triggerer: { id: oid, displayName: caller.displayName },
    });

    ctx.log(`Emailing ${users.length} users`);
    await ProjectDeletionNotificationService.sendSuccessEmail(ctx, {
      bcc: users.map((user) => getEmailOfUser(user)),
      projectName: project.name,
    });
    ctx.log(`Project ${project._id} (${project.name}) successfully deleted`);
    return true;
  } catch (e) {
    await SlackService.logError(
      ctx,
      new Error(`Failed to delete project #${pid}, triggered by user ${oid}`),
    );
    ctx.log(`Error caught in project deletion`, e);
    // emails owners if deletion fails
    const owners = await GraphService.getGroupOwnersEmails(ctx, project.name);

    ctx.log(`Sending error email to ${caller.id}`);
    await ProjectDeletionNotificationService.sendErrorEmail(
      ctx,
      project.name,
      owners,
      caller.userPrincipalName,
    );

    ctx.log(`Project ${project._id} (${project.name}) deletion failed.`);
    // throw error to show up in slack
  }
  return false;
};

const funcName = "project-deletion-queue";
export const mainHandler = withRequestLogging(
  funcName,
  withParamCheck(funcName, mandatoryProps, deleteProject),
);
