import { withPermissions } from "../../../middleware/withPermissions";
import GraphService from "../../../services/graphService/graphService";
import IamService from "../../../services/iamService/iamService";
import { IamRole } from "../../../services/iamService/iamService.types";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import { Role } from "../../../services/igamService/types";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type HeadProps = {
  params: {
    oid: string;
  };
};

app.get<HeadProps>(
  withPermissions(async (ctx) => {
    const oid = ctx.req.params?.oid;

    ctx.log(`Getting user by oid "${oid}"`);
    const user = await GraphService.getUserProps(ctx, oid, [
      "userPrincipalName",
      "userType",
      "mail",
    ]);
    const isIgamUser = user.userType === "Member";

    const emailDomain = user.userPrincipalName.split("@")[1];
    ctx.log(`Getting user roles of ${oid} by upn ******@${emailDomain}`);

    let roles: IamRole[] | Role[];
    if (isIgamUser) {
      // check IGAM
      const data = await EntitlementsService.getUser(ctx, user.userPrincipalName);
      roles = data.roles;
      ctx.log(`Fetched IGAM roles`, { roles });
    } else {
      // check IAM
      roles = await IamService.getUserRoles(ctx, user);
      ctx.log(`Fetched IAM roles`, { roles });
    }

    ctx.log(`Found ${roles.length} roles`);
    ctx.res = {
      body: {
        roles: roles.map(({ displayName, roleName }) => (isIgamUser ? displayName : roleName)),
      },
    };
  }),
);

export const mainHandler = app;
