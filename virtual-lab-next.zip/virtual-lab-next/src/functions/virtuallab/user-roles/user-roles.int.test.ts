import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./user-roles";

const ctx = getCtx({ name: "User roles", authorization: global.adminJwt });

describe("User roles", () => {
  it("Returns 200 when a user is found", async () => {
    ctx.req.params = { oid: "202eb6a9-e030-474c-ab26-5864a99b7a52" };
    await mainHandler(ctx);

    expect(ctx.res.body.roles.length).toBeGreaterThanOrEqual(1);
  });

  it("Returns 404 when a user is not found", async () => {
    ctx.req.params = { oid: "123uhi123" };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(500);
  });
});
