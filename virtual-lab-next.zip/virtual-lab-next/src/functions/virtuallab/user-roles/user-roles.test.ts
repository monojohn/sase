import { jest } from "@jest/globals";

import { getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./user-roles";
import GraphService from "../../../services/graphService/graphService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import IamService from "../../../services/iamService/iamService";

const ctx = getCtx({ name: "User roles" });

describe("User roles", () => {
  const mail = global.testEmail;
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
    jest
      .spyOn(EntitlementsService, "getUser")
      .mockImplementation(async () => ({ roles: ["role"] }) as any);
    jest
      .spyOn(IamService, "getUserRoles")
      .mockImplementation(async () => [{ displayName: "role", roleName: "role" }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(EntitlementsService, "searchByName").mockRestore();
    jest.spyOn(IamService, "getUserRoles").mockRestore();
  });
  it("Returns 200 when IGAM user is found", async () => {
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementationOnce(
        async () => ({ userPrincipalName: mail, mail, userType: "Member" }) as any,
      );

    await mainHandler(ctx);

    expect(ctx.res.body.roles.length).toEqual(1);
  });

  it("Returns 200 when IAM user is found", async () => {
    jest
      .spyOn(GraphService, "getUserProps")
      .mockImplementationOnce(
        async () => ({ userPrincipalName: mail, mail, userType: "Guest" }) as any,
      );

    await mainHandler(ctx);

    expect(ctx.res.body.roles.length).toEqual(1);
  });

  it("Returns 404 when a user is not found", async () => {
    ctx.req.params = { oid: "123uhi123" };
    await mainHandler(ctx);

    expect(ctx.res.status).toBe(500);
  });
});
