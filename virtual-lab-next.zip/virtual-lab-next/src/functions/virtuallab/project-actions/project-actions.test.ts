import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { ActionStatus, ActionType } from "../../../features/userActions/enums";
import { Project } from "../../../services/dbConnector/models/project";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./project-actions";

describe("Project actions", () => {
  const ctx = getCtx({ name: "Project actions" });

  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  let testProject: Project;

  beforeAll(async () => {
    // create test project
    testProject = await createTestProject({ owners: [ctx.authOid] });

    // create test action
    await UserActionModel.create({
      pid: testProject._id,
      oid: "system",
      status: ActionStatus.DONE,
      action: ActionType.ADD_MEMBER,
      invocationId: ctx.invocationId,
    });

    ctx.req.params = { pid: testProject._id };
  });

  describe("GET project actions", () => {
    it("Returns an array", async () => {
      await mainHandler(ctx);
      const { body } = ctx.res;
      expect(Array.isArray(body)).toEqual(true);
      expect(body.length).toBe(1);
    });
  });
});
