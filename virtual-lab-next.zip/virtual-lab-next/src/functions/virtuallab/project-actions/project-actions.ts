/* eslint-disable no-duplicate-case, no-fallthrough */
import { withOwnerPermissions } from "../../../middleware/withPermissions";
import { withProject } from "../../../middleware/withProject";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

type DefaultProps = {
  pid: string;
};

/**
 * Get all project actions
 */
app.get<DefaultProps>(
  withProject(
    withOwnerPermissions(async (ctx) => {
      ctx.res = {
        body: await UserActionModel.find({ pid: ctx.project._id }),
      };
    }),
  ),
);

export const mainHandler = app;
