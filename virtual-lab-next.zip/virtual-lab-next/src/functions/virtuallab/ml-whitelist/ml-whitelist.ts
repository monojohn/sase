import { withPermissions } from "../../../middleware/withPermissions";
import MlWhitelistModel from "../../../services/dbConnector/models/mlWhitelistModel";
import HttpTriggerFunction from "../../../utils/httpTriggerFunction";

const app = HttpTriggerFunction();

app.get<void>(
  withPermissions(async (ctx) => {
    ctx.res = {
      body: (await MlWhitelistModel.find({}).lean()).sort((a, b) => a.url.localeCompare(b.url)),
    };
  }),
);

export const mainHandler = app;
