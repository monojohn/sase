import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./ml-whitelist";

const ctx = getCtx({ name: "ml-whitelist" });

describe("ML Whitelist", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
      isAdmin: false,
      isNonEscb: false,
      isVlUser: true,
    }));
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("GET ml Whitelist", () => {
    beforeEach(() => {
      ctx.req.body = {};
      ctx.res = undefined;
    });

    it("Returns an [] in the body", async () => {
      await mainHandler(ctx);
      expect(ctx.res.body).toEqual([]);
    });
  });
});
