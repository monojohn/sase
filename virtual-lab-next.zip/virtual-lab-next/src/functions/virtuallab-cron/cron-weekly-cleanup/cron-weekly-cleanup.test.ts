import { jest } from "@jest/globals";
import { genId, getCtx } from "../../../../jest/helpers";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-weekly-cleanup";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import OrgService from "../../../services/igamService/orgService";
import NotificationService from "../../../features/cleanup/notificationService";

const { testEmail } = global;
const ctx = getCtx({ name: "Cron: weekly cleanup check" });

describe("Weekly cleanup check", () => {
  const slackMock = jest.fn(async () => void 0);
  const orgEmailMock = jest.fn(async () => void 0);
  const missingOwnersEmailMock = jest.fn(async () => void 0);
  beforeAll(() => {
    jest.spyOn(GraphService, "getGroupMembersEmails").mockImplementation(async () => [testEmail]);
    jest
      .spyOn(GraphService, "getGroupMemberUsers")
      .mockImplementation(async () => [{ department: "org" }] as any);
    jest.spyOn(SlackService, "logInfo").mockImplementation(slackMock);
    jest.spyOn(NotificationService, "sendMissingOrgOwnersEmails").mockImplementation(orgEmailMock);
    jest
      .spyOn(NotificationService, "sendProjectWithoutOwnersEmail")
      .mockImplementation(missingOwnersEmailMock);
    jest
      .spyOn(EntitlementsService, "get")
      .mockImplementation(async () => [{ displayName: "abc", owner: "org2" }] as any);
    jest.spyOn(EntitlementsService, "isProjectOrgVlOrg").mockImplementation(async () => false);
    jest
      .spyOn(OrgService, "getOrgByName")
      .mockImplementation(
        async () => ({ deputies: [{ email: testEmail }], manager: { email: "manager" } }) as any,
      );
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupMembersEmails").mockRestore();
    jest.spyOn(GraphService, "getGroupMemberUsers").mockRestore();
    jest.spyOn(SlackService, "logInfo").mockRestore();
    jest.spyOn(NotificationService, "sendMissingOrgOwnersEmails").mockRestore();
    jest.spyOn(NotificationService, "sendProjectWithoutOwnersEmail").mockRestore();
    jest.spyOn(EntitlementsService, "get").mockRestore();
    jest.spyOn(EntitlementsService, "isProjectOrgVlOrg").mockRestore();
    jest.spyOn(OrgService, "getOrgByName").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
    orgEmailMock.mockReset();
  });

  const message = `---Weekly cleanup---

---Projects without owners---
test project name found`;

  it("Sending notifications to members for first retrieval", async () => {
    jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
      {
        _id: genId(),
        name: "test project name",
      },
    ]);

    await mainHandler(ctx);
    expect(slackMock).toHaveBeenLastCalledWith(ctx, { message: `${message} 1 time` });
    expect(orgEmailMock).toHaveBeenCalledTimes(1);
    jest.spyOn(ProjectModel, "find").mockRestore();
  });

  it("Doesn't send notifications if project has exception", async () => {
    jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
      {
        _id: genId(),
        name: "test project name",
        hasException: true,
      },
    ]);
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenLastCalledWith(ctx, {
      message: `${message} 1 time - has exception`,
    });
    expect(orgEmailMock).toHaveBeenCalledTimes(0);
    jest.spyOn(ProjectModel, "find").mockRestore();
  });

  it("Marks the project to be deleted at 4th encounter", async () => {
    jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
      {
        _id: genId(),
        name: "test project name",
        foundWithoutOwners: 3,
      },
    ]);
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenLastCalledWith(ctx, {
      message: `${message} 4 times - to be deleted`,
    });
    expect(orgEmailMock).toHaveBeenCalledTimes(0);
    jest.spyOn(ProjectModel, "find").mockRestore();
  });

  it("Cleans up previously marked projects", async () => {
    jest
      .spyOn(ProjectModel, "find")
      .mockResolvedValueOnce([
        {
          name: "test project name",
          _id: genId(),
        },
      ]) // first search of projects
      .mockResolvedValueOnce([
        {
          name: "test project name 2",
          _id: genId(),
        },
      ]) // for projects without owners
      .mockResolvedValueOnce([
        {
          name: "test project name 3",
          _id: genId(),
        },
      ]); // for cleaning up previously marked projects

    const updateSpy = jest.spyOn(ProjectModel, "updateOne");
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenLastCalledWith(ctx, {
      message: `${message} 1 time
test project name 2 found 1 time`,
    });
    expect(orgEmailMock).toHaveBeenCalledTimes(1);
    expect(missingOwnersEmailMock).toHaveBeenCalledTimes(1);
    expect(updateSpy).toHaveBeenCalledTimes(3);
    jest.spyOn(ProjectModel, "find").mockRestore();
  });
});
