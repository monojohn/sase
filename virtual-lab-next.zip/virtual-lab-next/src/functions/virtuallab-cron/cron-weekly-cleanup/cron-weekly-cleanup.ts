import { AzureFunction, Context, Timer } from "@azure/functions";
import Cleanup from "../../../features/cleanup/cleanup";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);
  await Cleanup.weeklyCleanup(ctx);
  ctx.log(`Timer finished`, timer);
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
