import { AzureFunction, Context, Timer } from "@azure/functions";
import { deleteInactiveComputes } from "../../../features/mlComputeDeletion/index";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);
  await deleteInactiveComputes(ctx);
  ctx.log(`Timer finished`, timer);
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
