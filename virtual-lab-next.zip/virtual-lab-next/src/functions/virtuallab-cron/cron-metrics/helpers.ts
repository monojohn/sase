import { Workspace } from "@azure/arm-machinelearning";
import { Context } from "@azure/functions";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
} from "../../../services/dbConnector/enums";
import { GraphUser } from "../../../services/graphService/types";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";

export type VLUser = Pick<GraphUser, "id">;
export type ECBUser = Pick<
  GraphUser,
  "id" | "department" | "displayName" | "mail" | "otherMails" | "identities"
>;
export type GuestUser = Pick<
  GraphUser,
  "id" | "mail" | "otherMails" | "displayName" | "identities"
>;
export type ComputeInstanceDistribution = {
  [oid: string]: {
    cpu: number;
    gpu: number;
  };
};

export type UserDetails = {
  oid: string;
  institution: string;
  businessArea: string;
  division: string;
  section: string;
  countryCode: string;
  ecbUser: boolean;
  teamsAccess: boolean;
  partOfVLProject: boolean;
  partOfActiveVLProject: boolean;
  partOfActivePlanner: boolean;
  partOfActiveTeams: boolean;
  partOfActiveFiles: boolean;
  mlWorkspace: boolean;
  gitRepo: boolean;
  projectOwner: boolean;
};

export type ProjectDetails = {
  name: string;
  valid: boolean;
  dataSensitivityLevel: DataSensitivityLevel;
  accessibilityLevel: AccessibilityLevel;
  confidentialityLevel: ConfidentialityLevel;
  mlWorkspace: boolean;
  secureWorkspace: boolean;
  activeML: boolean;
  mlEndpointsCount: number;
  computeInstanceDistribution: ComputeInstanceDistribution;
  gitRepo: boolean;
  activeGit: boolean;
  activeFiles: boolean;
  activePlanner: boolean;
  activeTeams: boolean;
  vlTestProject: boolean;
  vlDemoProject: boolean;
  projectOwners: VLUser[];
  projectMembers: VLUser[];
  projectDescription: string;
  creationDate: string;
  modifiedDate: string;
  tags: string;
  projectResources: boolean;
  rolesAndEntitlements: boolean;
};

export const getWorkspaceInstancesDistribution = async (ctx: Context, workspace: Workspace) => {
  const workspaceName = workspace.name!;

  const computes = await MachineLearningService.getComputes(ctx, workspaceName);
  const computeInstances = computes.filter(
    ({ properties }) => properties.computeType === "ComputeInstance",
  );

  const computeDistribution = computeInstances.reduce((acc, compute) => {
    const oid = compute.properties.properties.createdBy.userId;
    acc[oid] ??= {
      cpu: 0,
      gpu: 0,
    };

    if (MachineLearningService.isComputeInstanceGPU(compute)) {
      acc[oid].gpu += 1;
    } else {
      acc[oid].cpu += 1;
    }

    return acc;
  }, {} as ComputeInstanceDistribution);

  return computeDistribution;
};

export const isUserInProject = (project: ProjectDetails, id: string) =>
  project.projectOwners.map((user) => user.id).includes(id) ||
  project.projectMembers.map((user) => user.id).includes(id);

export const getTeamComposition = (
  ecbUsersInProject: ECBUser[],
  guestUsersInProject: GuestUser[],
) => {
  if (ecbUsersInProject.length && guestUsersInProject.length) {
    return "mixed team";
  }
  if (ecbUsersInProject.length) {
    return "ECB Only";
  }
  return "ESCB & SSM only";
};

export const isEcbUser = (user: ECBUser | GuestUser): user is ECBUser => "department" in user;

/**
 * @param row
 * @returns
 */
export const formatValuesForWorkbook = <T extends ProjectDetails | UserDetails>(row: T) => {
  const updatedRow = { ...row };
  for (const key of Object.keys(updatedRow)) {
    const typeKey = key as keyof T;

    // true and false values should be replaced with "Yes" and "No"
    if (typeof updatedRow[typeKey] === "boolean") {
      updatedRow[typeKey] =
        updatedRow[typeKey] === true ? ("Yes" as T[keyof T]) : ("No" as T[keyof T]);
    }
  }
  return updatedRow;
};
