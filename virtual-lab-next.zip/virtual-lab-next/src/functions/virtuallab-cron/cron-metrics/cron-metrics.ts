import { AzureFunction, Context, Timer } from "@azure/functions";
import moment from "moment";
import XLSX from "xlsx";
import MetricsService from "../../../services/metricsService/metricsService";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import { ProjectStatus } from "../../../services/dbConnector/enums";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import SlackService from "../../../services/slackService";
import { chunkArray } from "../../../utils/chunkArray";
import {
  VL_GUESTS_GROUP_ID,
  VL_MEMBERS_GROUP_ID,
  VL_SITE_ID,
  VL_TEAM_GROUP_ID,
} from "../../../utils/config";
import {
  endOfLastMonth,
  fetchCollectionInChunks,
  getEmailOfUser,
  startOfLastMonth,
  wait,
  withRetry,
} from "../../../utils/helpers";
import { isTechnicalAccount } from "../../../utils/isTechnicalAccount";
import {
  ComputeInstanceDistribution,
  ECBUser,
  formatValuesForWorkbook,
  getTeamComposition,
  getWorkspaceInstancesDistribution,
  GuestUser,
  isEcbUser,
  isUserInProject,
  ProjectDetails,
  UserDetails,
  VLUser,
} from "./helpers";
import { WorkspaceType } from "../../../services/sharepointService/enums";
import SpFolderService from "../../../services/sharepointService/spFolderService";
import { institutionsToCountryMap } from "../../../services/graphService/constants";
import TeamsService from "../../../services/teamService/teamsService";
import { ReportEntry } from "../../../services/teamService/types";
import { Institution } from "../../../services/graphService/types";
import { UserAction } from "../../../services/dbConnector/models/userAction";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import {
  getBusinessAreaSplit,
  getWorkspaceEndpointsCount,
  replaceKeysWithColumnNames,
} from "../../../features/export/helpers";

const timePeriod = 30;

const projectDetailsSheetColumnNames = {
  name: "Project Name",
  valid: "Valid Project",
  dataSensitivityLevel: "Data Sensitivity",
  accessibilityLevel: "Accessibility",
  confidentialityLevel: "Confidentiality",
  teamComposition: "Team composition",
  mlWorkspace: "ML Workspace",
  secureWorkspace: "Secure ML Workspace",
  activeML: "Active ML workspace",
  mlEndpointsCount: "Endpoints count",
  cpuInstances: "CPU Compute Instances",
  gpuInstances: "GPU Compute Instances",
  gitRepo: "GIT repo",
  activeGit: "Active GIT repo",
  activeFiles: "Active files",
  activePlanner: "Active Planner",
  activeTeams: "Active Teams",
  lastMonthCosts: "Costs (last month)",
  thisYearCosts: "Costs (this year)",
  vlTestProject: "VL test project",
  vlDemoProject: "VL demo project",
  institutionOrBusinessArea: "Institution / Business area of owner",
  projectOwners: "Project Owners count",
  projectMembers: "Project Members count",
  projectDescription: "Project Description",
  creationDate: "Date of creation",
  modifiedDate: "Last Update",
  tags: "Tags",
  projectResources: "Project Resources",
  rolesAndEntitlements: "Roles / Entitlements",
  timestamp: "Timestamp",
};

const userDetailsSheetColumnNames = {
  oid: "OID",
  institution: "Institution acronym",
  businessArea: "Business Area",
  division: "Division",
  section: "Section",
  countryCode: "Country Code",
  ecbUser: "ECB user",
  teamsAccess: "Teams access",
  partOfVLProject: "Part of a VL project",
  partOfActiveVLProject: "Part of an active project",
  partOfActivePlanner: "Part of active Planner",
  partOfActiveTeams: "Part of active Teams",
  partOfActiveFiles: "Part of active Files",
  mlWorkspace: "ML workspace",
  mlWorkspacesCount: "ML workspaces count",
  cpuInstances: "CPU Compute Instances",
  gpuInstances: "GPU Compute Instances",
  gitRepo: "GIT repo",
  projectOwner: "Project owner",
  timestamp: "Timestamp",
};

const usageSheetColumnNames = {
  actionCount: "Site visits",
  actorCount: "Unique viewers",
};

const getProjectDetails = async (
  ctx: Context,
  project: Project,
  teamsReport: ReportEntry[],
  projectActions: UserAction[],
) => {
  const { teamGroupId } = project;

  const activeTeams = TeamsService.isTeamActive(teamsReport, teamGroupId);
  const [activeFiles, owners, members] = await Promise.all([
    MetricsService.areFilesActive(ctx, project, startOfLastMonth(), endOfLastMonth()),
    GraphService.getGroupUsers(ctx, project.ownersGroupId, ["id"]),
    GraphService.getGroupUsers(ctx, project.membersGroupId, ["id"]),
  ]);

  const lastProjectActivity =
    [...projectActions].sort((a, b) => moment.utc(b.createdAt).diff(moment.utc(a.createdAt)))[0]
      ?.createdAt ?? project.createdAt;

  // getting planner data fails when sending too many requests
  await wait(10);
  const activePlanner = await MetricsService.isPlannerActive(
    ctx,
    teamGroupId,
    startOfLastMonth(),
    endOfLastMonth(),
  );
  const { tags } = project;

  let mlWorkspace = false;
  let secureWorkspace = false;
  let activeMl = false;
  let computeInstanceDistribution: ComputeInstanceDistribution = {};
  let userMails: string[] = [];
  let mlEndpointsCount = 0;
  if (project.workspaceUrl?.startsWith("http")) {
    const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
    if (!workspace?.id || !workspace?.name) {
      throw new Error(`ML workspace missing properties for project ${project.name}`);
    }
    mlWorkspace = true;
    if (project.workspaceType === WorkspaceType.SECURED) {
      secureWorkspace = true;
    }
    [userMails, computeInstanceDistribution, mlEndpointsCount] = await Promise.all([
      GraphService.getProjectUsersMails(ctx, project.name),
      getWorkspaceInstancesDistribution(ctx, workspace),
      getWorkspaceEndpointsCount(ctx, workspace),
    ]);
    activeMl = await MetricsService.isMachineLearningWorkspaceActive(
      ctx,
      workspace,
      userMails,
      startOfLastMonth(),
      endOfLastMonth(),
    );
  }

  let gitRepo = false;
  let activeGit = false;
  if (project.repositoryUrl?.startsWith("http")) {
    const { repositories } = await RepositoryService.getCommitsForAllRepos(ctx, project);

    gitRepo = true;
    if (
      repositories.some((repo) =>
        moment(repo.last_activity_at).isBetween(startOfLastMonth(), endOfLastMonth(), null, "[]"),
      )
    ) {
      activeGit = true;
    }
  }

  return {
    name: project.name,
    valid: project.status === ProjectStatus.Active,
    dataSensitivityLevel: project.dataSensitivityLevel,
    accessibilityLevel: project.accessibilityLevel,
    confidentialityLevel: project.confidentialityLevel,
    mlWorkspace,
    secureWorkspace,
    activeML: activeMl,
    computeInstanceDistribution,
    mlEndpointsCount,
    gitRepo,
    activeGit,
    activeFiles,
    activePlanner,
    activeTeams,
    vlTestProject: tags.includes("VL_internal_test"),
    vlDemoProject: tags.includes("VL_demo"),
    projectOwners: owners,
    projectMembers: members,
    projectDescription: project.description,
    creationDate: moment.utc(project.createdAt).format("YYYY-MM-DD"),
    modifiedDate: moment.utc(lastProjectActivity).format("YYYY-MM-DD"),
    tags: tags.join(", "),
    projectResources: project.resources.length > 0,
    rolesAndEntitlements: project.rolesAndEntitlements?.length > 0,
  } as ProjectDetails;
};

const getUserDetails = (
  user: ECBUser | GuestUser,
  projectsDetails: ProjectDetails[],
  teamUsers: VLUser[],
) => {
  const projectsUserIsPartOf = projectsDetails.filter(({ projectOwners, projectMembers }) =>
    [...projectOwners, ...projectMembers].find(({ id }) => id === user.id),
  );

  let businessArea: string | undefined;
  let division: string | undefined;
  let section: string | undefined;
  let ecbUser: boolean;

  const emailSuffix = (getEmailOfUser(user)?.split("@")[1] ?? "").toLowerCase() as Institution;
  const institutionInfo = institutionsToCountryMap[emailSuffix];

  if (isEcbUser(user)) {
    const split = getBusinessAreaSplit(user.department);
    businessArea = split.businessArea;
    division = split.division ?? "";
    section = split.section ?? "";
    ecbUser = true;
  } else {
    ecbUser = false;
  }
  return {
    oid: user.id,
    institution: institutionInfo?.institutionAcronym ?? "",
    businessArea,
    division,
    section,
    countryCode: institutionInfo?.countryCode ?? "",
    ecbUser,
    teamsAccess: teamUsers.some(({ id }) => user.id === id),
    partOfVLProject: projectsUserIsPartOf.length > 0,
    partOfActiveVLProject: projectsUserIsPartOf.some(
      (project) =>
        project.activeML ||
        project.activePlanner ||
        project.activeGit ||
        project.activeTeams ||
        moment(project.modifiedDate).isBetween(startOfLastMonth(), endOfLastMonth(), null, "[]"),
    ),
    partOfActivePlanner: projectsUserIsPartOf.some((project) => project.activePlanner),
    partOfActiveFiles: projectsUserIsPartOf.some((project) => project.activeFiles),
    partOfActiveTeams: projectsUserIsPartOf.some((project) => project.activeTeams),
    mlWorkspace: projectsUserIsPartOf.some(({ mlWorkspace }) => mlWorkspace),
    mlWorkspacesCount: projectsUserIsPartOf.filter(({ mlWorkspace }) => mlWorkspace).length,
    cpuInstances: projectsUserIsPartOf
      .filter(({ computeInstanceDistribution }) => computeInstanceDistribution[user.id])
      .reduce((acc, project) => acc + project.computeInstanceDistribution[user.id].cpu, 0),
    gpuInstances: projectsUserIsPartOf
      .filter(({ computeInstanceDistribution }) => computeInstanceDistribution[user.id])
      .reduce((acc, project) => acc + project.computeInstanceDistribution[user.id].gpu, 0),
    gitRepo: projectsUserIsPartOf.some(({ gitRepo }) => gitRepo),
    projectOwner: projectsUserIsPartOf.some(({ projectOwners }) =>
      projectOwners.find(({ id }) => id === user.id),
    ),
  } as UserDetails;
};

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  if (!VL_TEAM_GROUP_ID || !VL_GUESTS_GROUP_ID || !VL_MEMBERS_GROUP_ID) {
    throw new Error("VL_TEAM_GROUP_ID, VL_GUTESTS_GROUP_ID or VL_MEMBERS_GROUP_ID is not defined");
  }

  const projects = await ProjectModel.find({ status: ProjectStatus.Active }).lean();
  const errors: string[] = [];
  const projectsDetails: ProjectDetails[] = [];
  const usersDetails: UserDetails[] = [];

  const [teamsReport, userActions] = await Promise.all([
    TeamsService.getReport(ctx, timePeriod),
    fetchCollectionInChunks(UserActionModel, { oid: { $ne: "system" } }),
  ]);

  // get project details
  const projectChunks = chunkArray(projects);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        await withRetry(
          async () => {
            projectsDetails.push(
              await getProjectDetails(
                ctx,
                project,
                teamsReport,
                userActions.filter(({ pid }) => pid === project._id.toString()),
              ),
            );
            await wait(10);
          },
          ctx,
          10,
        );
      }),
    );
    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(
          `Error for project ${chunk[ind].name}: ${(promiseResult.reason as Error).toString()}`,
        );
      }
    }
  }

  try {
    // get costs which are grouped by project tag
    const now = moment.utc();
    const lastMonth = moment.utc().subtract(1, "month");
    const timestamp = now.format("YYYY-MM-DD");
    const [lastMonthCosts, thisYearCosts] = await Promise.all([
      MachineLearningService.getCosts(
        ctx,
        lastMonth.startOf("month").toISOString(),
        lastMonth.endOf("month").toISOString(),
      ),
      MachineLearningService.getCosts(
        ctx,
        lastMonth.startOf("year").toISOString(),
        lastMonth.endOf("month").toISOString(),
      ),
    ]);

    // get all time Sharepoint usage
    const sharepointUsage = await GraphService.getAllTimeUsage(ctx, VL_SITE_ID);

    // get users
    const [teamUsers, ecbUsers, guestUsers] = await Promise.all([
      GraphService.getGroupUsers(ctx, VL_TEAM_GROUP_ID, ["id"]),
      GraphService.getGroupUsers(ctx, VL_MEMBERS_GROUP_ID, [
        "id",
        "department",
        "displayName",
        "mail",
        "otherMails",
        "identities",
      ]),
      GraphService.getGroupUsers(ctx, VL_GUESTS_GROUP_ID, [
        "id",
        "mail",
        "otherMails",
        "displayName",
        "identities",
      ]),
    ]);

    // get user details
    for (const user of [...ecbUsers, ...guestUsers].filter(
      ({ displayName }) => !isTechnicalAccount(displayName),
    )) {
      usersDetails.push(getUserDetails(user, projectsDetails, teamUsers));
    }

    // add user details, costs and timestamp to project data
    const projectData = projectsDetails.map((project) => {
      const ecbUsersInProject = ecbUsers.filter(({ id }) => isUserInProject(project, id));
      const guestUsersInProject = guestUsers.filter(({ id }) => isUserInProject(project, id));

      const teamComposition = getTeamComposition(ecbUsersInProject, guestUsersInProject);

      const institutions: string[] = [];
      for (const user of guestUsersInProject) {
        const userInstitution = usersDetails.find(({ oid }) => user.id === oid)?.institution;

        if (userInstitution) {
          institutions.push(userInstitution);
        }
      }

      const businessAreas: string[] = [];
      for (const user of ecbUsersInProject) {
        const userDetails = usersDetails.find(({ oid }) => user.id === oid);

        if (userDetails?.businessArea) {
          businessAreas.push(userDetails?.businessArea);
        }

        if (userDetails?.institution) {
          institutions.push(userDetails?.institution);
        }
      }

      const institutionOrBusinessArea: string[] = [];
      if (institutions.length) {
        institutionOrBusinessArea.push(
          `Institution: ${Array.from(new Set(institutions)).filter(Boolean).join(", ")}`,
        );
      }
      if (businessAreas.length) {
        institutionOrBusinessArea.push(
          `Business area: ${Array.from(new Set(businessAreas)).filter(Boolean).join(", ")}`,
        );
      }

      const lastMonthCost = lastMonthCosts.properties.rows.find(
        (array) => array[2] === project.name.toLowerCase(),
      )?.[0];
      const thisYearCost = thisYearCosts.properties.rows.find(
        (array) => array[2] === project.name.toLowerCase(),
      )?.[0];

      return {
        ...formatValuesForWorkbook(project),
        teamComposition,
        institutionOrBusinessArea: institutionOrBusinessArea.join(" / "),
        projectOwners: project.projectOwners.length,
        projectMembers: project.projectMembers.length,
        lastMonthCosts: lastMonthCost ?? "N/A",
        thisYearCosts: thisYearCost ?? "N/A",
        cpuInstances: Object.keys(project.computeInstanceDistribution).reduce(
          (acc, oid) => acc + project.computeInstanceDistribution[oid].cpu,
          0,
        ),
        gpuInstances: Object.keys(project.computeInstanceDistribution).reduce(
          (acc, oid) => acc + project.computeInstanceDistribution[oid].gpu,
          0,
        ),
        timestamp,
      };
    });

    // add timestamp to user data
    const userData = usersDetails.map((user) => ({
      ...formatValuesForWorkbook(user),
      timestamp,
    }));

    // create worksheets
    const userWorkSheet = XLSX.utils.json_to_sheet(
      replaceKeysWithColumnNames(userData, userDetailsSheetColumnNames),
    );
    const projectWorkSheet = XLSX.utils.json_to_sheet(
      replaceKeysWithColumnNames(projectData, projectDetailsSheetColumnNames),
    );
    const usageWorkSheet = XLSX.utils.json_to_sheet(
      replaceKeysWithColumnNames([sharepointUsage.access], usageSheetColumnNames),
    );

    // create workbook and upload
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, userWorkSheet, "User Details");
    XLSX.utils.book_append_sheet(workbook, projectWorkSheet, "Project Details");
    XLSX.utils.book_append_sheet(workbook, usageWorkSheet, "Usage");

    await SpFolderService.uploadFile(ctx, workbook, "Metrics", `Metrics_${timestamp}.xlsx`);
  } catch (err) {
    ctx.log(err);
    await SlackService.logWarning(
      ctx,
      new Error(`Cron job for metrics failed with error ${err as string}`),
    );
  }

  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
