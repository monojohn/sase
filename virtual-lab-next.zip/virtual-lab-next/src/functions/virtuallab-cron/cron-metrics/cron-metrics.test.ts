import { jest } from "@jest/globals";
import moment from "moment";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./cron-metrics";
import SpFolderService from "../../../services/sharepointService/spFolderService";
import GraphService from "../../../services/graphService/graphService";
import TeamsService from "../../../services/teamService/teamsService";
import PlannerService from "../../../services/plannerService/plannerService";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import { Project } from "../../../services/dbConnector/models/project";
import SlackService from "../../../services/slackService";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import { WorkspaceType } from "../../../features/machineLearningCreation";

const ctx = getCtx({ name: "Cron: Metrics export" });

describe("Cron: metrics export", () => {
  let testProject: Project;
  const lastMonth = moment().subtract(1, "month");
  const slackMock = jest.fn(async () => void 0);
  const uploadMock = jest.fn(async () => void 0);
  const email = global.testEmail;

  beforeAll(async () => {
    testProject = await createTestProject({
      repositoryUrl: "https://repo.com",
      owners: ["id1"],
      members: ["id2"],
      workspaceUrl: "https://workspace.com",
      workspaceType: WorkspaceType.SECURED,
    });
    await createTestProject({
      owners: ["id1"],
      workspaceUrl: "https://workspace.com",
      workspaceType: WorkspaceType.SECURED,
    });
    await createTestProject({
      workspaceUrl: "https://workspace.com",
    });
    await createTestProject({
      workspaceUrl: "https://workspace.com",
    });
    jest.spyOn(SpFolderService, "getProjectFiles").mockImplementation(
      async () =>
        [
          {
            TimeLastModified: lastMonth,
          },
        ] as any,
    );
    jest.spyOn(SpFolderService, "uploadFile").mockImplementation(uploadMock);
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(
      async () =>
        [
          {
            displayName: "user",
            id: "id1",
            identities: [],
            mail: email,
            userType: "Member",
            department: "x",
          },
          { displayName: "user", id: "id2", identities: [], mail: "email@ecb.europa.eu" },
        ] as any,
    );
    jest.spyOn(TeamsService, "getReport").mockImplementation(async () => []);
    jest
      .spyOn(PlannerService, "getAllPlannerTasks")
      .mockImplementation(async () => [[{ completedDateTime: lastMonth }]] as any);
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockResolvedValue({
      name: "workspace-name",
      id: "workspace-id",
    });
    jest.spyOn(MachineLearningService, "getWorkspaceProperties").mockResolvedValue({
      properties: {
        v1LegacyMode: false,
      },
    });
    jest.spyOn(MachineLearningService, "hasUserActivityLogs").mockImplementation(async () => false);
    jest
      .spyOn(MachineLearningService, "getOnlineEndpoints")
      .mockImplementation(async () => [
        { name: "end1", properties: { modifiedOn: moment() } } as any,
      ]);
    jest.spyOn(MachineLearningService, "getBatchEndpoints").mockImplementation(async () => []);
    jest.spyOn(MachineLearningService, "getOnlineDeployments").mockImplementation(async () => []);
    jest
      .spyOn(MachineLearningService, "getEndpointMetrics")
      .mockImplementation(async () => ({ value: [{ data: { RequestsPerMinute: 3 } }] }) as any);
    jest.spyOn(MachineLearningService, "getServerlessEndpoints").mockImplementation(async () => []);
    jest
      .spyOn(MachineLearningService, "getCosts")
      .mockImplementation(async () => ({ properties: { rows: [[0, 0, testProject.name]] } }));
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest
      .spyOn(RepositoryService, "getCommitsForAllRepos")
      .mockImplementation(
        async () => ({ commitDetails: [], repositories: [{ last_activity_at: lastMonth }] }) as any,
      );
    jest.spyOn(GraphService, "getProjectUsersMails").mockImplementation(async () => [email]);
    jest
      .spyOn(GraphService, "getAllTimeUsage")
      .mockImplementation(async () => ({ access: { actionCount: 2, actorCount: 1 } }));
    jest.spyOn(MachineLearningService, "getComputes").mockImplementation(
      async () =>
        [
          {
            properties: {
              computeType: "ComputeInstance",
              properties: {
                status: "Running",
                createdBy: {
                  userId: "id1",
                },
                vmSize: "standard_n1",
              },
            },
          },
          {
            properties: {
              computeType: "ComputeInstance",
              properties: {
                createdBy: {
                  userId: "id1",
                },
                vmSize: "standard_d1",
              },
            },
          },
        ] as any,
    );
  });

  afterAll(() => {
    jest.spyOn(SpFolderService, "getProjectFiles").mockRestore();
    jest.spyOn(SpFolderService, "uploadFile").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(TeamsService, "getReport").mockRestore();
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockRestore();
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockRestore();
    jest.spyOn(MachineLearningService, "getWorkspaceProperties").mockRestore();
    jest.spyOn(MachineLearningService, "hasUserActivityLogs").mockRestore();
    jest.spyOn(MachineLearningService, "getOnlineEndpoints").mockRestore();
    jest.spyOn(MachineLearningService, "getOnlineDeployments").mockRestore();
    jest.spyOn(MachineLearningService, "getEndpointMetrics").mockRestore();
    jest.spyOn(MachineLearningService, "getServerlessEndpoints").mockRestore();
    jest.spyOn(MachineLearningService, "getBatchEndpoints").mockRestore();
    jest.spyOn(MachineLearningService, "getCosts").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(RepositoryService, "getCommitsForAllRepos").mockRestore();
    jest.spyOn(GraphService, "getProjectUsersMails").mockRestore();
    jest.spyOn(MachineLearningService, "getComputes").mockRestore();
    jest.spyOn(GraphService, "getAllTimeUsage").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
    uploadMock.mockReset();
  });

  it("Throws error on upload", async () => {
    jest.spyOn(SpFolderService, "uploadFile").mockRejectedValueOnce("some error");
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error("Cron job for metrics failed with error some error"),
    );
  });

  it("Returns no endpoints for v1 legacy mode workspace", async () => {
    jest
      .spyOn(MachineLearningService, "getWorkspaceByProjectName")
      .mockImplementationOnce(async () => ({
        name: "workspace-name",
      }));

    jest
      .spyOn(MachineLearningService, "getWorkspaceProperties")
      .mockImplementationOnce(async () => ({
        properties: {
          v1LegacyMode: true,
        },
      }));

    const newWorkspace = {
      name: "workspace-name",
      id: "workspace-id",
      systemData: {
        lastModifiedAt: lastMonth.toDate(),
      },
    };
    jest
      .spyOn(MachineLearningService, "getWorkspaceByProjectName")
      .mockImplementationOnce(async () => newWorkspace);

    jest
      .spyOn(MachineLearningService, "hasUserActivityLogs")
      .mockImplementationOnce(async () => true);

    await mainHandler(ctx);

    expect(uploadMock).toHaveBeenCalledTimes(1);
  });
});
