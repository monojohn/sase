import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./cron-sensitivity-label-check";
import GraphService from "../../../services/graphService/graphService";
import EmailService from "../../../services/emailService/emailService";

const ctx = getCtx({ name: "Cron: Sensitivity label check" });

describe("Cron: Sensitivity label check", () => {
  const emailMock = jest.fn(async () => void 0);

  beforeAll(() => {
    jest.spyOn(GraphService, "getFilesInFolder").mockResolvedValue([
      {
        sensitivityLabel: {
          displayName: "  ECB-CONFIDENTIAL",
          id: "1",
          protectionEnabled: false,
        },
      },
    ]);
    jest
      .spyOn(GraphService, "getGroupUsers")
      .mockResolvedValueOnce([
        { mail: testEmail, identities: [{ signInType: "federated", issuer: "test" }] } as any,
      ]);
    jest.spyOn(EmailService, "sendInformationWithMessageEmail").mockImplementation(emailMock);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getFilesInFolder").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(EmailService, "sendInformationWithMessageEmail").mockRestore();
  });

  it("sends emails to non-compliant projects", async () => {
    await createTestProject();
    await mainHandler(ctx);
    expect(emailMock).toHaveBeenCalledTimes(1);
  });
});
