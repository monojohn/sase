import { Context } from "@azure/functions";
import { Project } from "../../../services/dbConnector/models/project";
import EmailService from "../../../services/emailService/emailService";

export type NonComplaintFile = {
  name: string;
  path: string;
  webUrl: string;
  sensitivityLabel: string;
};

const NotificationService = {
  async sendFilesSensitivityInfoEmail(
    ctx: Context,
    project: Project,
    nonComplaintFiles: NonComplaintFile[],
    ownerEmails: string[],
  ) {
    const hasMultipleFiles = nonComplaintFiles.length > 1;
    const filesWord = hasMultipleFiles ? "Files" : "File";

    const mappedFilesToLi = nonComplaintFiles.map(
      (file) =>
        `<li><a href="${file.webUrl}" target="_blank" rel="noopener">${file.name}</a> <strong>(${file.sensitivityLabel})</strong></li>`,
    );

    const message = [
      `<p style='text-align: left'><strong>Non-Compliant ${filesWord}:</strong></p>`,
      "<ul style='text-align: left'>",
      ...mappedFilesToLi,
      "</ul>",
      "<br>",
      "<p style='text-align: left'>Thank you for your attention to this matter.<br>Best regards,<br>Your Virtual Lab Team</p>",
    ].join("");

    return EmailService.sendInformationWithMessageEmail(ctx, {
      bcc: ownerEmails,
      subject: `[Action required] ${nonComplaintFiles.length} Non-Compliant ${filesWord} Detected in Your Virtual Lab Project: ${project.name}`,
      templateData: {
        projectName: project.name,
        senderName: "",
        preHeadline: "",
        postHeadline: `<p style="text-align: left">
Dear Project Owner,<br>
please find below a list of file(s) that do not adhere to your current project confidentiality settings, as they exceed your project's designated confidentiality label <strong>${project.confidentialityLevel}</strong> specified in your project settings. Please note that those files require your immediate action.
<br>
We kindly ask you to either remove ${hasMultipleFiles ? "these files" : "this file"} or consider updating the sensitivity label of your project to accommodate them.
</p>`,
        message,
      },
    });
  },
};
export default NotificationService;
