import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { GraphDriveItem } from "../../../services/graphService/types";
import SlackService from "../../../services/slackService";
import { chunkArray } from "../../../utils/chunkArray";
import {
  isConfidentialityHigher,
  getEmailOfUser,
  isConfidentialityLabel,
} from "../../../utils/helpers";
import NotificationService, { NonComplaintFile } from "./email";
import { ProjectStatus } from "../../../services/dbConnector/enums";

const filesData = [
  "id",
  "name",
  "file",
  "folder",
  "webUrl",
  "parentReference",
  "sensitivityLabel",
] as const satisfies Partial<keyof GraphDriveItem>[];
type FileInProject = Pick<GraphDriveItem, (typeof filesData)[number]>;

const checkSensitivityLabelOfFiles = async (ctx: Context, project: Project) => {
  const { confidentialityLevel } = project;

  const projectFiles = (await GraphService.getFilesInFolder(
    ctx,
    project.siteId,
    null,
    filesData,
    true,
  )) as FileInProject[];

  const nonComplaintFiles: NonComplaintFile[] = [];

  for (const file of projectFiles) {
    // Sensitivity label may have e.g. the prefix " \ Label" or " \ Business"
    const [sensitivityLabel] = file.sensitivityLabel?.displayName
      ?.split("\\")
      .map((item) => item.trim()) ?? [""];

    const isNonComplaint =
      isConfidentialityLabel(sensitivityLabel) &&
      isConfidentialityHigher(sensitivityLabel, confidentialityLevel);

    if (isNonComplaint) {
      // Extract path in case the file is not on root folder
      const [, filePath] = file.parentReference?.path.split("/root:") ?? ["", ""];

      nonComplaintFiles.push({
        name: file.name,
        path: filePath,
        webUrl: file.webUrl,
        sensitivityLabel: file.sensitivityLabel?.displayName ?? "",
      });
    }
  }

  return nonComplaintFiles;
};

const sendEmailToOwners = async (
  ctx: Context,
  project: Project,
  nonComplaintFiles: NonComplaintFile[],
) => {
  const owners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
    "id",
    "mail",
    "otherMails",
    "identities",
  ]);
  const ownerEmails = owners.map(getEmailOfUser);

  const message = `Sending email to: ${ownerEmails.length} owners of project: '${project.name}' about ${nonComplaintFiles.length} non-complaint files!`;

  ctx.log(message);

  await NotificationService.sendFilesSensitivityInfoEmail(
    ctx,
    project,
    nonComplaintFiles,
    ownerEmails,
  );
  return message;
};

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);
  const projects = await ProjectModel.find({ status: ProjectStatus.Active }).lean();
  const messages: string[] = [];

  const projectChunks = chunkArray(projects);
  for (const projectChunk of projectChunks) {
    const settled = await Promise.allSettled(
      projectChunk.map(async (project) => {
        const nonComplaintFiles = await checkSensitivityLabelOfFiles(ctx, project);

        if (nonComplaintFiles?.length) {
          messages.push(await sendEmailToOwners(ctx, project, nonComplaintFiles));
        }
      }),
    );

    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        const message = `Failed to check sensitivity labels or send email for project: '${projectChunk[ind].name}', { cause: promiseResult.reason }`;
        ctx.log.error(message);
        messages.push(message);
      }
    }
  }
  if (messages.length) {
    await SlackService.logWarning(ctx, new Error(messages.join("\n")));
  }
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
