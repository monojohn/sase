import { AzureFunction, Context, Timer } from "@azure/functions";
import MachineLearningTaggingService from "../../../features/machineLearningTagging/machineLearningTaggingService";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: Context, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);

    await MachineLearningTaggingService.tagStrayResources(ctx);

    ctx.log(`Timer finished`, timer);
  }),
);
