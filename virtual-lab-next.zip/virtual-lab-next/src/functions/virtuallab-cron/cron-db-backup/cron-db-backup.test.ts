import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import BackupService from "../../../services/backupService/backupService";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-db-backup";

const ctx = getCtx({ name: "Cron: Db backup" });

describe("Cron: DB Backup", () => {
  const slackMock = jest.fn(async () => void 0);

  beforeAll(() => {
    jest
      .spyOn(BackupService, "backupDb")
      .mockImplementation(async () => ["collection1", "collection2"]);
    jest.spyOn(BackupService, "listOldBackups").mockImplementation(async () => []);
    jest.spyOn(BackupService, "delete").mockImplementation(async () => []);
    jest.spyOn(SlackService, "logInfo").mockImplementation(slackMock);
  });

  afterAll(() => {
    jest.spyOn(BackupService, "backupDb").mockRestore();
    jest.spyOn(BackupService, "listOldBackups").mockRestore();
    jest.spyOn(BackupService, "delete").mockRestore();
    jest.spyOn(SlackService, "logInfo").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
  });

  it("Triggers backup", async () => {
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledTimes(1);
  });

  it("Deletes old backups", async () => {
    jest
      .spyOn(BackupService, "listOldBackups")
      .mockImplementationOnce(async () => [{ name: "old backup" } as any]);
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledTimes(2);
  });
});
