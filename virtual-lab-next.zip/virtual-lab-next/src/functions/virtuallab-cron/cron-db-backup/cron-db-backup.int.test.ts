import { createTestProject, getCtx } from "../../../../jest/helpers";
import BackupService from "../../../services/backupService/backupService";
import { Project } from "../../../services/dbConnector/models/project";
import MongoConnector from "../../../services/dbConnector/mongoDb";
import { BACKUP_PREFIX } from "../../../utils/config";
import { mainHandler } from "./cron-db-backup";

const ctx = getCtx({ name: "Cron: Db backup" });

describe("Cron: DB Backup", () => {
  const mockProjectName = "DB Backup Project";

  beforeAll(async () => {
    // ensure a prefix is setup for tests
    if (!BACKUP_PREFIX) {
      throw new Error(`No prefix defined.`);
    }

    // delete all mock stored files before the test
    const list = await BackupService.listFiles(BACKUP_PREFIX);
    await BackupService.delete(list.map(({ name }) => name));

    await createTestProject({ name: mockProjectName });
  });

  it("Uploads all files", async () => {
    // run the cron
    await mainHandler(ctx);

    // expect all collections to have a backup
    const list = await BackupService.listFiles(BACKUP_PREFIX);
    const mongoDriver = await MongoConnector.connect();
    const collections = await mongoDriver.connection.db.collections();
    expect(list.length).toBe(collections.length);

    // find "projects" backup
    const projectsBackup = list.find(({ name }) => name.toLocaleLowerCase().includes("-projects-"));
    expect(projectsBackup).toBeTruthy();

    // get backup
    const fileAsString = await BackupService.getFile(ctx, projectsBackup!.name);
    const projectJson = JSON.parse(fileAsString) as Project[];

    expect(projectJson.length).toBeGreaterThan(0);

    // expect mock project to be in the backup
    const mockProject = projectJson.find(({ name }) => name === mockProjectName);
    expect(mockProject).toBeTruthy();
  });

  it("Deletes all backups", async () => {
    // list all "old" backups
    let list = await BackupService.listOldBackups(BACKUP_PREFIX, 0);

    // there should be backups
    expect(list.length).toBeGreaterThan(0);

    // delete them
    await BackupService.delete(list.map(({ name }) => name));

    // re-fetch
    list = await BackupService.listFiles(BACKUP_PREFIX);
    expect(list.length).toBe(0);
  });
});
