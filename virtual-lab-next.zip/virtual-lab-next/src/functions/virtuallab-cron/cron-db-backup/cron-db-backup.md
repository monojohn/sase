# backup cron job

Check [Confluence](https://confluence.ecb.europa.eu/display/SUPTEC/Virtual+Lab+backup+management) for more details
