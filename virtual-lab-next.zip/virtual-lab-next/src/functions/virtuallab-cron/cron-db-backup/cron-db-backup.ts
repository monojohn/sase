import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import backupService from "../../../services/backupService/backupService";
import SlackService from "../../../services/slackService";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: Context, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);
    const collectionsBackedUp = await backupService.backupDb(ctx);

    await SlackService.logInfo(ctx, {
      message: `DB Collections successfully backed up: \n- ${collectionsBackedUp.join("\n- ")}`,
    });

    const list = await backupService.listOldBackups("20"); // get only files starting with the year
    const oldBackupsNames = list.map(({ name }) => name);
    ctx.log(`Found ${list.length} old backups to delete`, oldBackupsNames);

    if (list.length > 0) {
      await backupService.delete(oldBackupsNames);
      await SlackService.logInfo(ctx, {
        message: `Old backups deleted: \n- ${oldBackupsNames.join("\n- ")}`,
      });
    } else {
      ctx.log("No backups to delete");
    }

    ctx.log(`Timer finished`, timer);
  }),
);
