import { jest } from "@jest/globals";
import moment from "moment";
import { genId, getCtx } from "../../../../jest/helpers";
import MetricsService from "../../../services/metricsService/metricsService";
import Cleanup from "../../../features/cleanup/cleanup";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import EmailService from "../../../services/emailService/emailService";
import GraphService from "../../../services/graphService/graphService";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-monthly-cleanup";
import TeamsService from "../../../services/teamService/teamsService";
import { ReportEntry } from "../../../services/teamService/types";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import { ActionStatus, ActionType } from "../../../features/userActions/enums";
import PlannerService from "../../../services/plannerService/plannerService";
import {
  NON_ESCB_GUEST_GROUP,
  VL_GUESTS_GROUP_ID,
  VL_MEMBERS_GROUP_ID,
} from "../../../utils/config";

const ctx = getCtx({ name: "Cron: Monthly cleanup check" });

describe("Monthly cleanup check", () => {
  const projectName = "test project name";
  const id = genId();
  describe("Inactive projects and workspaces check", () => {
    const slackMock = jest.fn(async () => void 0);
    const emailMock = jest.fn(async () => void 0);
    const teamsReportEntry: ReportEntry = {
      "Report Refresh Date": "2025-05-04",
      "Team Id": "2d33fd79-9af2-4517-87b9-153b2f1ac412",
      "Team Name": "Demo Bidirectional sync",
      "Last Activity Date": "2024-10-29",
      "Team Type": "Private",
      "Is Deleted": "False",
      "Report Period": "90",
      "Active Users": "0",
      "Active Channels": "0",
      "Channel Messages": "0",
      Reactions: "0",
      "Meetings Organized": "0",
      "Post Messages": "0",
      "Reply Messages": "0",
      "Urgent Messages": "0",
      Mentions: "0",
      Guests: "0",
      "Active Shared Channels": "0",
      "Active External Users": "0",
    };
    beforeAll(async () => {
      jest.spyOn(Cleanup, "projectsWithoutUsersCheck").mockImplementation(async () => []);
      jest.spyOn(Cleanup, "userEntitlementCheck").mockImplementation(async () => []);
      jest.spyOn(SlackService, "logInfo").mockImplementation(slackMock);
      jest.spyOn(EmailService, "sendSuccessCtaLeftAlignEmail").mockImplementation(emailMock);
      jest.spyOn(GraphService, "getAllGroupUserEmails").mockImplementation(async () => [testEmail]);
      jest.spyOn(GraphService, "getGroupIdByName").mockImplementation(async () => "id");
      jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
      jest.spyOn(GraphService, "getSiteId").mockImplementation(async () => "id");
      jest.spyOn(GraphService, "getPageViews").mockResolvedValue(0);
      jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockResolvedValue({
        name: "workspace-name",
        id: "workspace-id",
      });
      jest.spyOn(MetricsService, "isMachineLearningWorkspaceActive").mockResolvedValue(false);
      jest.spyOn(MetricsService, "areFilesActive").mockResolvedValue(false);
      jest.spyOn(TeamsService, "getReport").mockResolvedValue([teamsReportEntry]);
      jest
        .spyOn(PlannerService, "getAllPlannerTasks")
        .mockImplementation(
          async () =>
            [[{ completedDateTime: moment.utc().subtract(12, "months").format() }]] as any,
        );

      await UserActionModel.create({
        pid: id,
        oid: "id",
        status: ActionStatus.DONE,
        action: ActionType.ADD_MEMBER,
        invocationId: ctx.invocationId,
      });
      jest.spyOn(ProjectModel, "find").mockResolvedValue([
        {
          _id: id,
          name: projectName,
          workspaceUrl: "https://ml",
          updatedAt: moment.utc().subtract(12, "months").format(),
          teamGroupId: "2d33fd79-9af2-4517-87b9-153b2f1ac412",
        },
      ]);
    });

    afterAll(() => {
      jest.spyOn(Cleanup, "projectsWithoutUsersCheck").mockRestore();
      jest.spyOn(Cleanup, "userEntitlementCheck").mockRestore();
      jest.spyOn(SlackService, "logInfo").mockRestore();
      jest.spyOn(EmailService, "sendSuccessCtaLeftAlignEmail").mockRestore();
      jest.spyOn(GraphService, "getAllGroupUserEmails").mockRestore();
      jest.spyOn(GraphService, "getGroupIdByName").mockRestore();
      jest.spyOn(GraphService, "getGroupUsers").mockRestore();
      jest.spyOn(GraphService, "getSiteId").mockRestore();
      jest.spyOn(GraphService, "getPageViews").mockRestore();
      jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockRestore();
      jest.spyOn(MetricsService, "isMachineLearningWorkspaceActive").mockRestore();
      jest.spyOn(MetricsService, "areFilesActive").mockRestore();
      jest.spyOn(TeamsService, "getReport").mockRestore();
      jest.spyOn(ProjectModel, "find").mockRestore();
      jest.spyOn(PlannerService, "getAllPlannerTasks").mockRestore();
    });

    beforeEach(() => {
      slackMock.mockReset();
      emailMock.mockReset();
    });

    it("Doesn't log the workspace when project doesn't have workspace", async () => {
      jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
        {
          _id: id,
          name: projectName,
        },
      ]);

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
---Inactive projects---`,
      });
    });

    it("Logs error when workspace is not configured properly", async () => {
      jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
        {
          _id: id,
          name: projectName,
          workspaceUrl: "https://ml",
        },
      ]);
      jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockResolvedValueOnce({
        name: "workspace-name",
      });

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `Failed checking project ${projectName} for inactivity: Error: Project test project name has missing workspace`,
      });
    });

    it("Doesn't log workspace when it is active", async () => {
      jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
        {
          _id: id,
          name: projectName,
          workspaceUrl: "https://ml",
        },
      ]);

      jest.spyOn(MetricsService, "isMachineLearningWorkspaceActive").mockResolvedValueOnce(true);

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
---Inactive projects---`,
      });
      expect(emailMock).toHaveBeenCalledTimes(0);
    });

    it("Logs workspace but not project when it was updated recently", async () => {
      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
${projectName} found 1 time
---Inactive projects---`,
      });
      expect(emailMock).toHaveBeenCalledTimes(1);
    });

    it("Doesn't log project when it has been accessed recently", async () => {
      await UserActionModel.deleteMany();
      jest.spyOn(GraphService, "getPageViews").mockResolvedValueOnce(1);

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
${projectName} found 1 time
---Inactive projects---`,
      });
      expect(emailMock).toHaveBeenCalledTimes(1);
    });

    it("Doesn't log project when files are active", async () => {
      jest.spyOn(MetricsService, "areFilesActive").mockResolvedValueOnce(true);

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
${projectName} found 1 time
---Inactive projects---`,
      });
      expect(emailMock).toHaveBeenCalledTimes(1);
    });

    it("Doesn't log project when Teams is active", async () => {
      jest
        .spyOn(TeamsService, "getReport")
        .mockResolvedValueOnce([{ ...teamsReportEntry, "Active Channels": "3" }]);

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
${projectName} found 1 time
---Inactive projects---`,
      });
      expect(emailMock).toHaveBeenCalledTimes(1);
    });

    it("Doesn't log project when planner is active", async () => {
      jest
        .spyOn(PlannerService, "getAllPlannerTasks")
        .mockImplementationOnce(
          async () => [[{ completedDateTime: moment.utc().subtract(2, "months").format() }]] as any,
        );
      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
${projectName} found 1 time
---Inactive projects---`,
      });
      expect(emailMock).toHaveBeenCalledTimes(1);
    });

    it("Logs project when no condition is met", async () => {
      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `---Inactive workspaces---
${projectName} found 1 time
---Inactive projects---
${projectName} found 1 time`,
      });
      expect(emailMock).toHaveBeenCalledTimes(2);
    });
  });

  describe("Projects without users check", () => {
    const slackMock = jest.fn(async () => void 0);
    beforeAll(() => {
      jest
        .spyOn(Cleanup, "inactiveProjectsAndWorkspacesCheck")
        .mockImplementation(async () => ({ logs: [], errors: [] }));
      jest.spyOn(Cleanup, "userEntitlementCheck").mockImplementation(async () => []);
      jest.spyOn(SlackService, "logInfo").mockImplementation(slackMock);
    });

    afterAll(() => {
      jest.spyOn(Cleanup, "inactiveProjectsAndWorkspacesCheck").mockRestore();
      jest.spyOn(Cleanup, "userEntitlementCheck").mockRestore();
      jest.spyOn(SlackService, "logInfo").mockRestore();
    });

    beforeEach(() => {
      slackMock.mockReset();
    });

    const message = `---Projects without users---
${projectName} found`;

    it("Logs to Slack when projects without users are found", async () => {
      jest.spyOn(ProjectModel, "find").mockResolvedValueOnce([
        {
          _id: id,
          name: projectName,
        },
      ]);

      await mainHandler(ctx);
      expect(slackMock).toHaveBeenCalledWith(ctx, { message: `${message} 1 time` });
      jest.spyOn(ProjectModel, "find").mockRestore();
    });
  });

  describe("User groups check", () => {
    beforeAll(() => {
      jest
        .spyOn(Cleanup, "inactiveProjectsAndWorkspacesCheck")
        .mockImplementation(async () => ({ logs: [], errors: [] }));
      jest.spyOn(Cleanup, "projectsWithoutUsersCheck").mockImplementation(async () => []);
    });

    afterAll(() => {
      jest.spyOn(Cleanup, "inactiveProjectsAndWorkspacesCheck").mockRestore();
      jest.spyOn(Cleanup, "projectsWithoutUsersCheck").mockRestore();
    });

    beforeEach(() => {
      jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
      jest.spyOn(GraphService, "getGroupIdByName").mockImplementation(async () => genId());
    });

    afterEach(() => {
      jest.spyOn(GraphService, "getGroupIdByName").mockRestore();
      jest.spyOn(GraphService, "getGroupUsers").mockRestore();
      jest.spyOn(SlackService, "logWarning").mockRestore();
      jest.spyOn(SlackService, "logError").mockRestore();
    });

    it("Logs nothing when all users are valid", async () => {
      const slackWarnMock = jest.fn(async () => void 0);
      const slackErrorMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logError").mockImplementationOnce(slackErrorMock);
      jest.spyOn(SlackService, "logWarning").mockImplementationOnce(slackWarnMock);

      await mainHandler(ctx);

      expect(slackWarnMock).toHaveBeenCalledTimes(0);
      expect(slackErrorMock).toHaveBeenCalledTimes(0);
    });

    it("Logs slack warning when user has 3 groups", async () => {
      const slackMock = jest.fn(async () => void 0);
      jest.spyOn(SlackService, "logInfo").mockImplementationOnce(slackMock);
      jest
        .spyOn(GraphService, "getGroupUsers")
        .mockImplementation(async () => [{ id: "user1" } as any]);

      await mainHandler(ctx);

      const expectedWarning = {
        message: `---User groups check---
User "user1" is in 3 groups:
${VL_MEMBERS_GROUP_ID},
${VL_GUESTS_GROUP_ID},
${NON_ESCB_GUEST_GROUP}`,
      };

      expect(slackMock).toHaveBeenCalledWith(ctx, expectedWarning);
    });
  });
});
