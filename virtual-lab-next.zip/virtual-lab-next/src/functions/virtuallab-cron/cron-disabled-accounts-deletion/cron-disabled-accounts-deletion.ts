import { AzureFunction, Context, Timer } from "@azure/functions";
import { SecurityCenter } from "@azure/arm-security";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import { SUBSCRIPTION_ID } from "../../../utils/config";
import GraphService from "../../../services/graphService/graphService";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import SlackService from "../../../services/slackService";
import { removeUserFromProject } from "../../../services/projectService/projectModificationService/removeUser";

const removeUserFromAllProjects = async (ctx: Context, userId: string) => {
  const { id } = await GraphService.getUser(ctx, userId);
  const projects = await ProjectModel.find({ $or: [{ owners: id }, { members: id }] });

  await Promise.all(projects.map(async (project) => removeUserFromProject(ctx, project, id)));
};

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  const credentials = MachineLearningService.connect();
  const securityCenterClient = new SecurityCenter(credentials, SUBSCRIPTION_ID);
  const assessmentDisplayName =
    "Disabled accounts with read and write permissions on Azure resources should be removed";
  const disabledAccountsAssessments = await MachineLearningService.getUnhealthyAssessments(
    securityCenterClient,
    assessmentDisplayName,
  );

  if (!disabledAccountsAssessments.length) {
    ctx.log("No disabled accounts, skipping");
    return;
  }

  const assessmentName = disabledAccountsAssessments[0].name!;
  const subAssessments = await MachineLearningService.getAllResources(
    securityCenterClient.subAssessments.list(`/subscriptions/${SUBSCRIPTION_ID}`, assessmentName),
  );

  const errors: string[] = [];
  await Promise.all(
    subAssessments.map(async (assessment) => {
      const userId = assessment.name;
      if (!userId) {
        errors.push(`User id not defined for ${assessment.id}`);
        return;
      }
      await removeUserFromAllProjects(ctx, userId);
    }),
  );
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }

  ctx.log(`Timer finished`, timer);
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
