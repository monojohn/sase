import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import { chunkArray } from "../../../utils/chunkArray";
import SlackService from "../../../services/slackService";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  const workspaces = await MachineLearningService.getAllProjects();
  const chunks = chunkArray(workspaces);

  const errors: string[] = [];
  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (workspace) => {
        if (!workspace.name) {
          throw new Error("Workspace name not defined");
        }
        const workspaceName = workspace.name;
        const computes = await MachineLearningService.getComputes(ctx, workspaceName);
        const computeInstancesToUpdate = computes.filter(
          ({ properties }) =>
            properties.computeType === "ComputeInstance" &&
            !["CreateFailed", "SetupFailed", "UserSetupFailed"].includes(
              properties.properties.state,
            ) &&
            !properties.properties.idleTimeBeforeShutdown,
        );
        await Promise.all(
          computeInstancesToUpdate.map(async (computeInstance) => {
            ctx.log(`Enabling idle shutdown for ${computeInstance.name} in ${workspaceName}`);
            await MachineLearningService.updateComputeIdleSchedule(
              ctx,
              workspaceName,
              computeInstance.name,
              "PT60M",
            );
          }),
        );
      }),
    );

    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        const error = `${chunk[ind].name} failed with ${promiseResult.reason}`;
        ctx.log(error);
        errors.push(error);
      }
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
