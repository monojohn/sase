# Cron: Data governance

## Intro

This cron job ensures data governance is up to date.

It should be followed up with `scrips/removeNonEscbProjectUsers.ts` to remove users from non-escb projects when required

## Schedule

This cron is scheduled to run once a day
