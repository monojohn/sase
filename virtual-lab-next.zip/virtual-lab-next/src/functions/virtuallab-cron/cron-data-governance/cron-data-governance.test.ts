import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import DataGovNotService from "../../../features/dataGovernance/dataGovernanceNotificationService";
import DataGovernanceModel from "../../../services/dbConnector/models/dataGovernanceModel";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-data-governance";

const ctx = getCtx({ name: "Cron: Data governance" });

describe("Cron: Data governance", () => {
  let testProject: Project;
  const slackMock = jest.fn(async () => void 0);
  const emailMock = jest.fn(async () => void 0);

  beforeAll(async () => {
    jest.spyOn(SlackService, "logInfo").mockImplementation(slackMock);
    jest.spyOn(GraphService, "getGroupUsersEmails").mockImplementation(async () => []);
    jest.spyOn(DataGovNotService, "sendWarningEmail").mockImplementation(emailMock);
    jest.spyOn(DataGovNotService, "sendFinalWarningEmail").mockImplementation(emailMock);

    // delete conflicting projects
    await ProjectModel.deleteMany({ isNonEscbProject: true }).lean();

    // create test project
    testProject = await createTestProject({ owners: [ctx.authOid], isNonEscbProject: true });
  });

  afterAll(() => {
    jest.spyOn(SlackService, "logInfo").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
    jest.spyOn(DataGovNotService, "sendWarningEmail").mockRestore();
    jest.spyOn(DataGovNotService, "sendFinalWarningEmail").mockRestore();
    jest.useRealTimers();
  });

  beforeEach(() => {
    slackMock.mockReset();
    emailMock.mockReset();
  });

  describe("Weekly warning", () => {
    it("Sends warning email on first Monday of month", async () => {
      jest.useFakeTimers({ doNotFake: ["nextTick"] }).setSystemTime(new Date("02 Jan 2023"));

      await mainHandler(ctx);

      expect(emailMock).toHaveBeenCalled();
      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `Data Governance not up to date for project #${testProject._id} - '${testProject.name}'\nSending Data Governance warning email to owners of '${testProject.name}'`,
      });
    });

    it("Sends warning email when old entry exists", async () => {
      jest.useFakeTimers({ doNotFake: ["nextTick"] }).setSystemTime(new Date("09 Jan 2023"));

      // create old entry
      await DataGovernanceModel.create({
        pid: testProject._id,
        oid: ctx.authOid,
        createdAt: new Date("09 Dec 2022"),
      });

      await mainHandler(ctx);

      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `Data Governance not up to date for project #${testProject._id} - '${testProject.name}'\nSending Data Governance warning email to owners of '${testProject.name}'`,
      });
    });
  });

  describe("Final warning", () => {
    it("Sends final warning email on last day of month", async () => {
      jest.useFakeTimers({ doNotFake: ["nextTick"] }).setSystemTime(new Date("28 Feb 2023"));

      await mainHandler(ctx);

      expect(emailMock).toHaveBeenCalled();

      expect(slackMock).toHaveBeenCalledWith(ctx, {
        message: `Data Governance not up to date for project #${testProject._id} - '${testProject.name}'\nSending Final Data Governance warning email to owners of '${testProject.name}'`,
      });
    });
  });
});
