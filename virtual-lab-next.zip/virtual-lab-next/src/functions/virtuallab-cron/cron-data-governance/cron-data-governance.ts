import { AzureFunction, Context, Timer } from "@azure/functions";
import DataGovernanceService from "../../../features/dataGovernance/dataGovernanceService";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: Context, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);
    await DataGovernanceService.notifyProjectsWithMissingDataGov(ctx);
    ctx.log(`Timer finished`, timer);
  }),
);
