# virtuallab-cron

This file gives an overview of all active cron jobs

### cron-data-governance

Non escb project owners have to provide a monthly confirmation of roles and entitlements.

This cron checks for non-escb projects without confirmations and emails the owners a weekly reminder.

```
Note: non-escb projects have the `nonEscbProject` flag set to `true` in the `Projects` collection
```

### cron-db-backup

Unsurprisingly, this cron takes a whole dump of our database and uploads it as a base64-encoded JSON file to Azure storage.

Scripts inside `scripts/backups` allow for recovery and checking.

### cron-disabled-accounts-deletion

This checks the accounts which are disabled and removes them from projects. Accounts that are disabled do not necessarily lose the access to our projects, so this step is necessary.

### cron-entitlements-and-roles-check

This cron goes over all projects and notifies owners in case a user is missing a role or entitlement.

### cron-file-expiration-check

Files can only be kept for a fixed period of time in sharepoint before they're automatically deleted.

This cron emails owners when a file is close to expiration so they can take action if required.

### cron-ifam-requests-check

Because of the governance policies we have in place right now, there are certain actions (like creating a confidential project by an ECB user, increasing confidentiality etc.) which require approval from the project's defined BA Org. The request in IGAM for the BA Org is created at the time the user requests it and then this cron job runs regularly to check the status of the requests so that it can be followed on.

### cron-join-request-reminder

This cron notifies project owners there are join requests awaiting decision.

### cron-logs

This cron fetches different logs about the users and uploads them to a Sharepoint folder. <- this is soon to be deprecated as it was replaced by cron-logs

### cron-metrics

This cron fetches several different VL metrics and uploads them to a Sharepoint folder for business to consume. <- this is soon to be deprecated as it was replaced by cron-logs

### cron-ml-compute-deletion

This job deletes inactive ML compute instances so they don't drain resources.

### cron-ml-compute-recreation-reminder

This job checks for compute instances that need to be recreated based on recommendations comming from Microsoft Defender.

### cron-ml-container-registry-updates

This cron moves the container registries to a dedicated resource group (which contains only container registries) because of Prisma alerts

### cron-ml-idle-schedule

This cron job enables the idle schedule for all compute instances which don't already have one.

### cron-ml-tag-check

This job checks that all ML resources created by users are correctly tagged.

This is required for cost calculations per project later on.

### cron-monthly-cleanup

This job checks for inactive projects, inactive workspaces projects without users and users who are part of more than 1 VL group and notifies the project members and the VL team in order to take action. Projects and workspaces which are not used can generate costs and having users present in more than one group creates problems during user searches as is unexpected.

### cron-monthly-export

This cron fetches several different VL metrics and uploads them to DEVO.

### cron-open-ai-limits-deletion

This cron cleans up the OpenAI limits defined for workspaces which no longer exist

### cron-open-ai-usage

This cron creates an export that is uploaded to a Sharepoint folder

### cron-permission-check

Notifies owners of projects to re-evaluate roles and entitlements when no changes were detected for over 90 days

### cron-project-users

Updates our `Projects` database collection with graph data, to ensure we have the correct members and owners.

To pick up user changes like a user leaving ECB and being removed from the group.

Also updates org of project in case the org of the entitlements is different and updates the OpenAI use case to reflect existing owners in the project.

### cron-repo-cleanup

Cleans up the Sofa repositories as they cannot be deleted on the spot, instead the Sofa pipeline has to run before this can be done.

### cron-sensitivity-label-check

This checks the confidentiality of the files compared to the confidentiality of the project and notifies the users in case the one of the files is higher.

### cron-weekly-cleanup

This cron job checks for projects that do not have owners but have members or have owners but not from the BA Org as defined at the project level. This is done more frequently than the other cleanup as it is a security concern.
