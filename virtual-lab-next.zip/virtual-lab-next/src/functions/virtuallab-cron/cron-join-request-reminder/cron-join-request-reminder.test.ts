import { jest } from "@jest/globals";
import { getCtx } from "../../../../jest/helpers";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./cron-join-request-reminder";
import SlackService from "../../../services/slackService";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import ProjectService from "../../../services/projectService/projectService";

const { testEmail } = global;
const ctx = getCtx({ name: "Cron: Join request reminder" });

describe("Cron: Join request reminder", () => {
  const slackMock = jest.fn(async () => void 0);
  const emailMock = jest.fn(async () => void 0);
  beforeAll(() => {
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest.spyOn(ProjectService, "sendAccessRequestNotification").mockImplementation(emailMock);
    jest.spyOn(JoinProjectRequestModel, "find").mockResolvedValue([
      {
        createdAt: new Date("20 Dec 2023"),
        oid: "oid",
        pid: "pid",
      },
    ]);
    jest.spyOn(GraphService, "getSimpleUser").mockImplementation(async () => ({
      id: "id",
      displayName: "test user",
      mail: testEmail,
      otherMails: ["otherMails"],
      identities: [
        {
          issuer: "ECB",
          signInType: "federated",
        },
      ],
    }));
    jest.spyOn(GraphService, "getGroupUsersEmails").mockImplementation(async () => [testEmail]);
  });

  afterAll(() => {
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(ProjectService, "sendAccessRequestNotification").mockRestore();
    jest.spyOn(GraphService, "getSimpleUser").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
    jest.spyOn(JoinProjectRequestModel, "find").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
    emailMock.mockReset();
  });

  it("Throws error when project does not exist", async () => {
    jest.spyOn(ProjectModel, "findById").mockResolvedValueOnce(null);
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledTimes(1);
    jest.spyOn(ProjectModel, "findById").mockRestore();
  });

  it("Sends email", async () => {
    jest.spyOn(ProjectModel, "findById").mockResolvedValueOnce({
      name: "test project name",
      url: "test project url",
      ownersGroupId: "id",
    });
    await mainHandler(ctx);
    expect(emailMock).toHaveBeenCalledTimes(1);
    jest.spyOn(ProjectModel, "findById").mockRestore();
  });
});
