import { AzureFunction, Context, Timer } from "@azure/functions";
import moment from "moment";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import JoinProjectRequestModel from "../../../services/dbConnector/models/joinProjectRequestModel";
import ProjectService from "../../../services/projectService/projectService";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  const joinRequests = await JoinProjectRequestModel.find();
  const oldJoinRequests = joinRequests.filter(
    ({ createdAt }) => moment.utc().diff(moment.utc(createdAt), "days") > 7,
  );

  const settled = await Promise.allSettled(
    oldJoinRequests.map(async ({ pid, oid, message }) => {
      const [project, user] = await Promise.all([
        ProjectModel.findById(pid),
        GraphService.getSimpleUser(ctx, oid),
      ]);

      if (!project) {
        throw new Error(`Project id ${pid} does not exist`);
      }

      // send email reminder
      await ProjectService.sendAccessRequestNotification(ctx, {
        project,
        senderName: user.displayName,
        ownersGroupId: project?.ownersGroupId,
        message,
      });
    }),
  );

  const errors: string[] = [];
  for (let index = 0; index < settled.length; index++) {
    const promiseResult = settled[index];
    if (promiseResult.status === "rejected") {
      const error = `Failed to send join request reminder for project ${oldJoinRequests[index].pid} user ${oldJoinRequests[index].oid}: ${promiseResult.reason}`;
      errors.push(error);
      ctx.log(error);
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
