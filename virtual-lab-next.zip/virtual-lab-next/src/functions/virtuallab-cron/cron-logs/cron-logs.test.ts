import { jest } from "@jest/globals";
import moment from "moment";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./cron-logs";
import SpFolderService from "../../../services/sharepointService/spFolderService";
import PlannerService from "../../../services/plannerService/plannerService";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { Project } from "../../../services/dbConnector/models/project";
import UserVisitModel from "../../../services/dbConnector/models/userVisitModel";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import { ActionStatus, ActionType } from "../../../features/userActions/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";

const ctx = getCtx({ name: "Cron: Logs export" });

describe("Cron: logs export", () => {
  let testProject: Project;
  const slackMock = jest.fn(async () => void 0);
  const uploadMock = jest.fn(async () => void 0);
  const lastMonth = moment().subtract(1, "month");
  const email = global.testEmail;

  beforeAll(async () => {
    await ProjectModel.deleteMany();
    testProject = await createTestProject({
      repositoryUrl: "https://repo.com",
      workspaceUrl: "https://workspace.com",
    });
    await createTestProject();
    jest
      .spyOn(GraphService, "getSiteById")
      .mockImplementation(async () => ({ name: "site name" }) as any);
    jest.spyOn(SpFolderService, "getProjectFiles").mockImplementation(async () => []);
    jest.spyOn(SpFolderService, "getFilesVersions").mockImplementation(async () => [
      {
        fileInfo: { TimeLastModified: lastMonth, ModifiedBy: { Email: "mail@abc.com" } },
        versions: [
          {
            Created: lastMonth,
            CreatedBy: { Email: email },
          },
        ],
      } as any,
    ]);
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockImplementation(async () => [
      [
        {
          assignments: {
            "12": {
              assignedBy: {
                user: {
                  id: email,
                },
              },
              assignedDateTime: lastMonth,
            },
          },
          createdBy: {
            user: {
              id: email,
            },
          },
          createdDateTime: lastMonth,
        },
      ] as any,
    ]);
    jest.spyOn(RepositoryService, "getCommitsForAllRepos").mockImplementation(
      async () =>
        ({
          commitDetails: [[{ author_email: email, authored_date: lastMonth }]],
          repositories: [],
        }) as any,
    );
    jest.spyOn(MachineLearningService, "getActivityLog").mockImplementation(
      async () =>
        [
          {
            caller: email,
            eventTimestamp: lastMonth,
          },
        ] as any,
    );
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockResolvedValue({
      name: "workspace-name",
      id: "workspace-id",
    });
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(
      async () =>
        [
          {
            id: "me",
            identities: [],
            mail: email,
            otherMails: [],
            userType: "Member",
            department: "x",
          },
          { id: "me", identities: [], mail: "another mail", otherMails: ["mail@abc.com"] },
        ] as any,
    );
    jest.spyOn(SpFolderService, "uploadFile").mockImplementation(uploadMock);
    jest.spyOn(SpFolderService, "downloadFile").mockImplementation(async () => new ArrayBuffer(8));
    jest
      .spyOn(SpFolderService, "getFiles")
      .mockImplementation(async () => [{ Name: "User_logs_2025-03.xlsx" }] as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getSiteById").mockRestore();
    jest.spyOn(SpFolderService, "getProjectFiles").mockRestore();
    jest.spyOn(SpFolderService, "getFilesVersions").mockRestore();
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockRestore();
    jest.spyOn(RepositoryService, "getCommitsForAllRepos").mockRestore();
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockRestore();
    jest.spyOn(MachineLearningService, "getActivityLog").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(SpFolderService, "uploadFile").mockRestore();
    jest.spyOn(SpFolderService, "downloadFile").mockRestore();
    jest.spyOn(SpFolderService, "getFiles").mockRestore();
    jest.spyOn(global, "setTimeout").mockRestore();
    jest.useRealTimers();
  });

  beforeEach(() => {
    slackMock.mockReset();
    uploadMock.mockReset();
  });

  it("Throws error for missing workspace id and missing institutions", async () => {
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockResolvedValueOnce({
      name: "workspace-name",
    });

    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      expect.objectContaining({
        message: expect.stringContaining(
          [
            `Errors during cron-logs: Error for project ${testProject.name}: Error: Project ${testProject.name} workspace is missing`,
            "Institution does not exist for abc.com",
            `Institution does not exist for ${email.split("@")[1]}`,
          ].join("\n"),
        ),
      }),
    );
  });

  it("Uploads file and generates quarter file", async () => {
    await UserVisitModel.create({
      oid: "me",
      sessionId: "123",
      createdAt: lastMonth,
    });
    await UserActionModel.create({
      action: ActionType.ADD_MEMBER,
      pid: "pid",
      oid: "me",
      invocationId: "id",
      status: ActionStatus.DONE,
      createdAt: lastMonth,
    });
    await mainHandler(ctx);
    expect(uploadMock).toHaveBeenCalled();
  });

  it("Generates quarter file", async () => {
    await UserVisitModel.create({
      oid: "me",
      sessionId: "123",
      createdAt: lastMonth,
    });
    await UserActionModel.create({
      action: ActionType.ADD_MEMBER,
      pid: "pid",
      oid: "me",
      invocationId: "id",
      status: ActionStatus.DONE,
      createdAt: lastMonth,
    });

    jest.useFakeTimers({ doNotFake: ["nextTick"] });
    jest.setSystemTime(new Date("2025-04-01"));
    jest.spyOn(global, "setTimeout").mockImplementation((callback) => {
      if (typeof callback === "function") {
        callback();
      }
      return { hasRef: () => false } as NodeJS.Timeout;
    });

    await mainHandler(ctx);
    await jest.runAllTimersAsync();
    expect(uploadMock).toHaveBeenCalledTimes(2);
  });
});
