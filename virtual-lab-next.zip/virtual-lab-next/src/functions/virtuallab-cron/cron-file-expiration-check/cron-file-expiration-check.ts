import { AzureFunction, Context, Timer } from "@azure/functions";
import {
  checkLoggedExpiringFiles,
  notifyOwnersOfFileExpiration,
} from "../../../features/fileExpiration/fileExpiration";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: Context, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);
    await notifyOwnersOfFileExpiration(ctx);
    await checkLoggedExpiringFiles(ctx);
    ctx.log(`Timer finished`, timer);
  }),
);
