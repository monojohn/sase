import { jest } from "@jest/globals";
import moment from "moment";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-file-expiration-check";
import GraphService from "../../../services/graphService/graphService";
import { Project } from "../../../services/dbConnector/models/project";
import SpFolderService from "../../../services/sharepointService/spFolderService";
import FileExpirationModel from "../../../services/dbConnector/models/fileExpirationModel";
import NotificationService from "../../../features/fileExpiration/notificationService";
import ProjectModel from "../../../services/dbConnector/models/projectModel";

const ctx = getCtx({ name: "Cron: file expiration check" });

describe("Cron: file expiration check", () => {
  const slackMock = jest.fn(async () => void 0);
  const slackErrorMock = jest.fn(async () => void 0);
  const mailMock = jest.fn(async () => void 0);
  let testProject: Project;

  beforeAll(async () => {
    await ProjectModel.deleteMany();
    testProject = await createTestProject();

    jest
      .spyOn(GraphService, "getSiteById")
      .mockImplementation(async () => ({ name: "site name" }) as any);
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest.spyOn(SlackService, "logError").mockImplementation(slackErrorMock);
    jest.spyOn(NotificationService, "sendFilesExpiringEmail").mockImplementation(mailMock);
    jest.spyOn(SpFolderService, "getProjectFiles").mockImplementation(async () => [
      {
        Name: "file1",
        UniqueId: "123",
        TimeLastModified: moment().subtract(361, "days"),
      } as any,
      {
        Name: "file2",
        UniqueId: "234",
        TimeLastModified: moment().subtract(364, "days"),
      } as any,
      {
        Name: "Wiki.one",
        TimeLastModified: moment(),
      } as any,
    ]);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getSiteById").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(SlackService, "logError").mockRestore();
    jest.spyOn(SpFolderService, "getProjectFiles").mockRestore();
    jest.spyOn(NotificationService, "sendFilesExpiringEmail").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
    slackErrorMock.mockReset();
    mailMock.mockReset();
  });

  it("Throws error for missing team group ids", async () => {
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(`Broken project detected, skipping file check: ${testProject.name}`),
    );
  });

  it("Catches error on getting project files", async () => {
    jest.spyOn(SpFolderService, "getProjectFiles").mockRejectedValueOnce(null);
    testProject = await createTestProject({
      teamGroupId: "123",
    });
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(`Failed to get expiring files of project #${testProject._id}: ${testProject.name}`),
    );
  });

  it("Throws error for missing emails", async () => {
    jest.spyOn(GraphService, "getGroupOwnersEmails").mockImplementation(async () => []);
    await mainHandler(ctx);
    expect(slackErrorMock).toHaveBeenCalledWith(
      ctx,
      new Error(`Had 1 failures when fetching projects with files close to expiration`),
    );
  });

  it("Sends emails to owners", async () => {
    jest
      .spyOn(GraphService, "getGroupOwnersEmails")
      .mockImplementation(async () => [global.testEmail]);
    await mainHandler(ctx);
    expect(mailMock).toHaveBeenCalledTimes(1);
  });

  it("Cleans up files in db", async () => {
    const file1 = await FileExpirationModel.create({
      pid: testProject._id,
      expirationTimestamp: moment().subtract(1, "day").format(),
      fileName: "file1",
      fileId: "123",
    });

    const file2 = await FileExpirationModel.create({
      pid: testProject._id,
      expirationTimestamp: moment().subtract(1, "day").format(),
      fileName: "file3",
      fileId: "1235",
    });
    await mainHandler(ctx);
    const files = await FileExpirationModel.find();
    expect(files.map(({ fileId }) => fileId)).not.toContain(file1.fileId);
    expect(files.map(({ fileId }) => fileId)).not.toContain(file2.fileId);
  });

  it("Catches error in getting project files in comparison function", async () => {
    await FileExpirationModel.create({
      pid: testProject._id,
      expirationTimestamp: moment().subtract(1, "day").format(),
      fileName: "file1",
      fileId: "123",
    });
    jest.spyOn(SpFolderService, "getProjectFiles").mockRejectedValue(null);
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(
        `Failed to compare expiring files to project files for project ${testProject.name}`,
      ),
    );
  });
});
