import { jest } from "@jest/globals";
import moment from "moment";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { mainHandler } from "./cron-monthly-export";
import SpFolderService from "../../../services/sharepointService/spFolderService";
import PlannerService from "../../../services/plannerService/plannerService";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import GraphService from "../../../services/graphService/graphService";
import SlackService from "../../../services/slackService";
import { Project } from "../../../services/dbConnector/models/project";
import UserVisitModel from "../../../services/dbConnector/models/userVisitModel";
import UserActionModel from "../../../services/dbConnector/models/userActionModel";
import { ActionStatus, ActionType } from "../../../features/userActions/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import TeamsService from "../../../services/teamService/teamsService";
import DevoService from "../../../services/devoService/devoService";

const ctx = getCtx({ name: "Cron: Monthly export" });

describe("Cron: Monthly export", () => {
  let testProject: Project;
  const slackMock = jest.fn(async () => void 0);
  const uploadMock = jest.fn(async () => void 0);
  const lastMonth = moment().subtract(1, "month");
  const email = global.testEmail;

  beforeAll(async () => {
    await ProjectModel.deleteMany();
    testProject = await createTestProject({
      repositoryUrl: "https://repo.com",
      workspaceUrl: "https://workspace.com",
      owners: ["owner"],
      members: ["member"],
    });
    await createTestProject();
    jest
      .spyOn(GraphService, "getSiteById")
      .mockImplementation(async () => ({ name: "site name" }) as any);
    jest.spyOn(GraphService, "getAllGroupUsers").mockImplementation(async () => []);
    jest.spyOn(SpFolderService, "getProjectFiles").mockImplementation(async () => []);
    jest.spyOn(SpFolderService, "getFilesVersions").mockImplementation(async () => [
      {
        fileInfo: { TimeLastModified: lastMonth, ModifiedBy: { Email: "mail@abc.com" } },
        versions: [
          {
            Created: lastMonth,
            CreatedBy: { Email: email },
          },
        ],
      } as any,
    ]);
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockImplementation(async () => [
      [
        {
          assignments: {
            "12": {
              assignedBy: {
                user: {
                  id: email,
                },
              },
              assignedDateTime: lastMonth,
            },
          },
          createdBy: {
            user: {
              id: email,
            },
          },
          createdDateTime: lastMonth,
        },
      ] as any,
    ]);
    jest.spyOn(RepositoryService, "getCommitsForAllRepos").mockImplementation(
      async () =>
        ({
          commitDetails: [[{ author_email: email, authored_date: lastMonth }]],
          repositories: [],
        }) as any,
    );
    jest.spyOn(MachineLearningService, "getActivityLog").mockImplementation(
      async () =>
        [
          {
            caller: email,
            eventTimestamp: lastMonth,
          },
        ] as any,
    );
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockResolvedValue({
      name: "workspace-name",
      id: "workspace-id",
    });
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(
      async () =>
        [
          {
            id: "me",
            identities: [],
            mail: email,
            otherMails: [],
            userType: "Member",
            department: "x",
          },
          { id: "me", identities: [], mail: "another mail", otherMails: ["mail@abc.com"] },
        ] as any,
    );
    jest.spyOn(DevoService, "uploadData").mockImplementation(uploadMock);
    jest
      .spyOn(SpFolderService, "getFiles")
      .mockImplementation(async () => [{ Name: "User_logs_2025-03.xlsx" }] as any);
    jest.spyOn(TeamsService, "getReport").mockImplementation(async () => []);
    jest
      .spyOn(MachineLearningService, "getCosts")
      .mockImplementation(async () => ({ properties: { rows: [[0, 0, testProject.name]] } }));
    jest.spyOn(MachineLearningService, "getComputes").mockImplementation(
      async () =>
        [
          {
            properties: {
              computeType: "ComputeInstance",
              properties: {
                status: "Running",
                createdBy: {
                  userId: "id1",
                },
                vmSize: "standard_n1",
              },
            },
          },
          {
            properties: {
              computeType: "ComputeInstance",
              properties: {
                createdBy: {
                  userId: "id1",
                },
                vmSize: "standard_d1",
              },
            },
          },
        ] as any,
    );
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getSiteById").mockRestore();
    jest.spyOn(GraphService, "getAllGroupUsers").mockRestore();
    jest.spyOn(SpFolderService, "getProjectFiles").mockRestore();
    jest.spyOn(SpFolderService, "getFilesVersions").mockRestore();
    jest.spyOn(PlannerService, "getAllPlannerTasks").mockRestore();
    jest.spyOn(RepositoryService, "getCommitsForAllRepos").mockRestore();
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockRestore();
    jest.spyOn(MachineLearningService, "getActivityLog").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(DevoService, "uploadData").mockRestore();
    jest.spyOn(SpFolderService, "getFiles").mockRestore();
    jest.spyOn(global, "setTimeout").mockRestore();
    jest.spyOn(TeamsService, "getReport").mockRestore();
    jest.spyOn(MachineLearningService, "getCosts").mockRestore();
    jest.spyOn(MachineLearningService, "getComputes").mockRestore();

    jest.useRealTimers();
  });

  beforeEach(() => {
    slackMock.mockReset();
    uploadMock.mockReset();
  });

  it("Uploads 4 files to devo", async () => {
    await UserVisitModel.create({
      oid: "me",
      sessionId: "123",
      createdAt: lastMonth,
    });
    await UserActionModel.create({
      action: ActionType.ADD_MEMBER,
      pid: testProject._id.toString(),
      oid: "me",
      invocationId: "id",
      status: ActionStatus.DONE,
      createdAt: lastMonth,
    });
    await UserActionModel.create({
      action: ActionType.CREATE_PROJECT,
      pid: testProject._id.toString(),
      oid: "me",
      invocationId: "id",
      status: ActionStatus.DONE,
      createdAt: lastMonth,
    });
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalled();
    expect(uploadMock).toHaveBeenCalledTimes(5);
  });
});
