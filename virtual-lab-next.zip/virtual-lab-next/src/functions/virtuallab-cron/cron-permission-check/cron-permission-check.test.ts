import { jest } from "@jest/globals";
import moment from "moment";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./cron-permission-check";
import SlackService from "../../../services/slackService";
import MachineLearningService from "../../../services/machineLearningService/machineLearningService";
import { Project } from "../../../services/dbConnector/models/project";
import NotificationService from "../../../features/permissionChecks/sendReviewPermissionsEmails";

const ctx = getCtx({ name: "Cron: Permission check" });

describe("Cron: Permission check", () => {
  const slackMock = jest.fn(async () => void 0);
  const permissionsMailMock = jest.fn(async () => void 0);
  const noPermissionsMailMock = jest.fn(async () => void 0);
  const lastYear = moment().subtract(1, "year");
  let testProject: Project;
  const email = global.testEmail;

  beforeAll(async () => {
    await ProjectModel.deleteMany();
    await createTestProject();
    testProject = await createTestProject({
      workspaceUrl: "https://workspace.com",
      openAiConnection: true,
      permissionsChangedDate: lastYear.toDate(),
    });
    jest
      .spyOn(MachineLearningService, "getWorkspaceByProjectName")
      .mockImplementation(async () => ({ id: "workspace id" }));
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest.spyOn(GraphService, "getGroupUsersEmails").mockImplementation(async () => [email]);
    jest
      .spyOn(MachineLearningService, "getActivityLog")
      .mockImplementation(async () => [{}] as any);
    jest
      .spyOn(NotificationService, "sendReviewExistingPermissionsEmail")
      .mockImplementation(permissionsMailMock);
    jest
      .spyOn(NotificationService, "sendReviewNoPermissionsEmail")
      .mockImplementation(noPermissionsMailMock);
  });

  afterAll(() => {
    jest.spyOn(MachineLearningService, "getWorkspaceByProjectName").mockRestore();
    jest.spyOn(MachineLearningService, "getActivityLog").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
    jest.spyOn(NotificationService, "sendReviewExistingPermissionsEmail").mockRestore();
    jest.spyOn(NotificationService, "sendReviewNoPermissionsEmail").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
    noPermissionsMailMock.mockReset();
    permissionsMailMock.mockReset();
  });

  it("Throws error when workspace is missing id", async () => {
    jest
      .spyOn(MachineLearningService, "getWorkspaceByProjectName")
      .mockImplementationOnce(async () => ({}));
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(
        `Failed to process 1 projects. Failed to handle workspace of project ${testProject.name}`,
      ),
    );
  });

  it("Skips workspace with no activity logs", async () => {
    jest.spyOn(MachineLearningService, "getActivityLog").mockImplementationOnce(async () => []);
    await mainHandler(ctx);
    expect(noPermissionsMailMock).toHaveBeenCalledTimes(0);
    expect(permissionsMailMock).toHaveBeenCalledTimes(0);
  });

  it("Throws error when call to graph fails", async () => {
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRejectedValueOnce("error");
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(`Failed to process 1 projects. Failed to process project ${testProject.name}`),
    );
  });

  it("Throws error when there are no emails defined", async () => {
    jest.spyOn(GraphService, "getGroupUsersEmails").mockImplementationOnce(async () => []);
    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(
        `Failed to process 1 projects. No owner emails found for project ${testProject.name}`,
      ),
    );
  });

  it("Sends email for no permissions", async () => {
    await mainHandler(ctx);
    expect(noPermissionsMailMock).toHaveBeenCalledTimes(1);
    expect(permissionsMailMock).toHaveBeenCalledTimes(0);
  });

  it("Sends email for permissions", async () => {
    await createTestProject({
      workspaceUrl: "https://workspace.com",
      openAiConnection: true,
      permissionsChangedDate: lastYear.toDate(),
      rolesAndEntitlements: [{ roles: [], iamRoles: [], entitlements: ["ent1"] }],
    });
    await mainHandler(ctx);
    expect(noPermissionsMailMock).toHaveBeenCalledTimes(1);
    expect(permissionsMailMock).toHaveBeenCalledTimes(1);
  });
});
