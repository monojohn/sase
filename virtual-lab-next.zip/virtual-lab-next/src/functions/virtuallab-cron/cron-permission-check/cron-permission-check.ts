import { AzureFunction, Context, Timer } from "@azure/functions";
import { notifyOwnersOfProjectsWithOldPermissions } from "../../../features/permissionChecks/notifyOwnersOfProjectsWithOldPermissions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: Context, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);

    await notifyOwnersOfProjectsWithOldPermissions(ctx);

    ctx.log(`Timer finished`, timer);
  }),
);
