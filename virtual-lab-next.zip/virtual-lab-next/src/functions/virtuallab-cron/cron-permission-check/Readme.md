# Cron: Permission check

## Intro

This cron job goes over all projects with ML Workspaces which haven't updated their permissions (entitlements + roles) for over 90 days and sends an email reminder to project owners.

## Schedule

This cron is scheduled to run once every quarter
