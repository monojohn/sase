import type { Timer } from "@azure/functions";
import OpenAILimitsModel, { OpenAILimits } from "../../../services/dbConnector/models/OpenAILimits";
import { handler } from "./cron-open-ai-limits-deletion";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import { Project } from "../../../services/dbConnector/models/project";

const limits: OpenAILimits[] = [
  {
    model: "GPT4-32K",
    workspace: "mlw-testworkspace45",
    limit: 30000,
  },
  {
    model: "text-embedding-3-large",
    workspace: "mlw-testsandbox6563",
    limit: 15000,
  },
  {
    model: "text-embedding-1-small",
    workspace: "mlw-testsandbox0404",
    limit: 100000,
  },
  {
    model: "text-embedding-23-small",
    workspace: "mlw-testsandbox0000",
    limit: 10000,
  },
] as const;

const ctx = getCtx({ name: "OpenAILimits deletion" });
const timer = {} as unknown as Timer;

const assignWorkspaceToProject = async (limitsToAssign: readonly OpenAILimits[]) =>
  Promise.all(
    limitsToAssign.map((limit) =>
      createTestProject({
        // This is how real workspace URL could look like in PROD
        workspaceUrl: `https://ml.azure.com/?tid=11111&wsid=/subscriptions/22222/resourcegroups/33333/workspaces/${limit.workspace}`,
      }),
    ),
  );

const removeProjects = async (projects: readonly Project[]) => {
  await ProjectModel.deleteMany({
    _id: { $in: projects.map((project) => project._id) },
  }).lean();
};

const getLimitsFromDb = () =>
  OpenAILimitsModel.find(
    {},
    {
      _id: 0,
      model: 1,
      workspace: 1,
      limit: 1,
    },
  ).lean();

describe("Cron OpenAILimits deletion", () => {
  beforeEach(async () => {
    await OpenAILimitsModel.insertMany(limits);
  });

  afterEach(async () => {
    await OpenAILimitsModel.deleteMany().lean();
  });

  it("Should remove all limits, because none of them is assigned to a workspaces", async () => {
    const limitToAssociateWithProject: OpenAILimits[] = [];

    const projects = await assignWorkspaceToProject(limitToAssociateWithProject);

    await handler(ctx, timer);

    const remainingLimits = await getLimitsFromDb();

    expect(remainingLimits).toStrictEqual(limitToAssociateWithProject);

    await removeProjects(projects);
  });

  it("Should not remove any limits, because all workspaces are assigned to a project", async () => {
    const limitToAssociateWithProject = limits;

    const projects = await assignWorkspaceToProject(limitToAssociateWithProject);

    await handler(ctx, timer);

    const remainingLimits = await getLimitsFromDb();

    expect(remainingLimits).toStrictEqual(limitToAssociateWithProject);

    await removeProjects(projects);
  });

  it("Should remove only those limits, that are not assigned to any workspace in project", async () => {
    const limitToAssociateWithProject = [limits[1], limits[2]] as const;

    const projects = await assignWorkspaceToProject(limitToAssociateWithProject);

    await handler(ctx, timer);

    const remainingLimits = await getLimitsFromDb();

    expect(remainingLimits).toStrictEqual(limitToAssociateWithProject);

    await removeProjects(projects);
  });
});
