import { AzureFunction, Context, Timer } from "@azure/functions";
import escapeRegex from "escape-string-regexp";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import SlackService from "../../../services/slackService";
import OpenAILimitsModel from "../../../services/dbConnector/models/OpenAILimits";
import ProjectModel from "../../../services/dbConnector/models/projectModel";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  try {
    const limits = await OpenAILimitsModel.find({}, { workspace: 1 }, { lean: true });
    const projects = await ProjectModel.find({ workspaceUrl: { $ne: null } });

    const limitsToDelete: (typeof limits)[number][] = [];

    for (const limit of limits) {
      const associatedProjectWithWorkspace = projects.find(({ workspaceUrl }) =>
        new RegExp(`${escapeRegex(limit.workspace)}$`, "i").test(workspaceUrl),
      );

      // If workspace that is defined limits is not associated to any project, then delete it
      if (!associatedProjectWithWorkspace) {
        limitsToDelete.push(limit);
      }
    }

    ctx.log(
      `${limitsToDelete.length} limits do not have any associated workspace in project, deleting: ${limitsToDelete.map(({ workspace }) => workspace).join(", ")}`,
    );

    await OpenAILimitsModel.deleteMany({
      workspace: { $in: limitsToDelete.map((limit) => limit.workspace) },
    }).lean();
  } catch (err) {
    ctx.log(err);
    await SlackService.logWarning(
      ctx,
      new Error(`Cron job for OpenAI limits deletion failed with error ${err as string}`),
    );
  }
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
