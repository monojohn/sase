import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import { updateContainerRegistries } from "../../../features/mlContainerRegistry/index";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);
  await updateContainerRegistries(ctx);
  ctx.log(`Timer finished`, timer);
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
