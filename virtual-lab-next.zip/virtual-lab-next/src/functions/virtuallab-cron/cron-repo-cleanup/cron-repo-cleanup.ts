import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import SlackService from "../../../services/slackService";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  const projectsWithRepository = await ProjectModel.find({
    repositoryUrl: /^http/,
  });
  const repositoryGroups = await RepositoryService.getAllRepositoryGroups();
  const projectRepositoryUrls = new Set(
    projectsWithRepository.map(({ repositoryUrl }) => repositoryUrl),
  );

  const promises: Promise<unknown>[] = [];

  // groups without matching project -> delete group
  for (const group of repositoryGroups.filter(
    ({ web_url }) => !projectRepositoryUrls.has(web_url),
  )) {
    promises.push(RepositoryService.permanentlyRemoveGroup(ctx, group));
  }

  const settled = await Promise.allSettled(promises);

  const errors: string[] = [];
  for (const promiseResult of settled) {
    if (promiseResult.status === "rejected") {
      const error = `Failure on repo cleanup: ${promiseResult.reason}`;
      ctx.log(error);
      errors.push(error);
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }

  ctx.log(`Timer finished`, timer);
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
