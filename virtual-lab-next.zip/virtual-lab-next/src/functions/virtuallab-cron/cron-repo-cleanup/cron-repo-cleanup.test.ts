import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import { Group } from "../../../services/repositoryService/types";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-repo-cleanup";

const ctx = getCtx({ name: "Cron: repository cleanup" });

const repositoryGroup: Group = {
  id: 123,
  full_path: "full_path",
  path: "path",
  web_url: "url",
  name: "name",
  marked_for_deletion_on: "some day",
};
describe("Cron: repository cleanup", () => {
  beforeAll(async () => {
    await createTestProject({
      repositoryUrl: "url",
    });
    await createTestProject({
      repositoryUrl: "url2",
    });
    jest.spyOn(RepositoryService, "getAllRepositoryGroups").mockResolvedValue([
      repositoryGroup,
      {
        ...repositoryGroup,
        id: 1234,
        full_path: "path/name2",
        web_url: "url3",
      },
    ]);
  });

  afterAll(() => {
    jest.spyOn(ProjectModel, "find").mockRestore();
    jest.spyOn(RepositoryService, "getAllRepositoryGroups").mockRestore();
    jest.spyOn(RepositoryService, "permanentlyRemoveGroup").mockRestore();
  });

  it("Deletes repositories marked for deletion", async () => {
    const repositoryServiceMock = jest.fn(async () => void 0);

    jest
      .spyOn(RepositoryService, "permanentlyRemoveGroup")
      .mockImplementation(repositoryServiceMock);
    await mainHandler(ctx);
    expect(ctx.res).toBe(undefined);
    expect(repositoryServiceMock).toHaveBeenCalled();
  });

  it("Throws error when a call fails", async () => {
    const slackMock = jest.fn(async () => void 0);
    jest.spyOn(SlackService, "logWarning").mockImplementationOnce(slackMock);

    const repositoryMock = jest.fn(async () => {
      throw new Error("error");
    });
    jest.spyOn(RepositoryService, "permanentlyRemoveGroup").mockImplementationOnce(repositoryMock);

    await mainHandler(ctx);
    expect(slackMock).toHaveBeenCalled();
  });
});
