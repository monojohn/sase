import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./cron-statistics";
import StatisticsModel from "../../../services/dbConnector/models/statistics";

const ctx = getCtx({ name: "Cron: Statistics" });

describe("Cron: Statistics", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getAllGroupUsers").mockImplementation(async () => []);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getAllGroupUsers").mockRestore();
  });

  it("Returns statistics", async () => {
    await createTestProject({ name: "project" });
    await StatisticsModel.create({
      registeredUsers: 2,
      projects: 10,
      activeUsers: 1,
      siteVisits: 3,
    });

    await mainHandler(ctx);

    // expect project to have 1 owner and 0 members
    const latestStatistics = await StatisticsModel.find().sort({ updatedAt: -1 }).limit(1);

    expect(latestStatistics[0]?.projects).toEqual(1);
    expect(latestStatistics[0]?.registeredUsers).toEqual(0);
  });
});
