import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import StatisticsModel from "../../../services/dbConnector/models/statistics";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import { ProjectStatus } from "../../../services/dbConnector/enums";
import GraphService from "../../../services/graphService/graphService";
import { VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../../../utils/config";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: Context, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);

    // update daily the total number of registered users and total number of projects
    const [latestStatistics, projects, ecbUsers, guestUsers] = await Promise.all([
      StatisticsModel.find().sort({ updatedAt: -1 }).limit(1),
      ProjectModel.find({ status: ProjectStatus.Active }),
      GraphService.getAllGroupUsers(ctx, VL_MEMBERS_GROUP_ID, ["id"]),
      GraphService.getAllGroupUsers(ctx, VL_GUESTS_GROUP_ID, ["id"]),
    ]);

    await StatisticsModel.updateOne(
      { _id: latestStatistics[0]._id },
      {
        $set: {
          projects: projects.length,
          registeredUsers: ecbUsers.length + guestUsers.length,
        },
      },
    );

    ctx.log(`Timer finished`, timer);
  }),
);
