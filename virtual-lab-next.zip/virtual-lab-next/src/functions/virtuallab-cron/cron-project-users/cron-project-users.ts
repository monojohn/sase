import { AzureFunction, Timer } from "@azure/functions";
import ProjectUsers, { ProjectUsersContext } from "../../../features/projectUsers/projectUsers";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";

export const mainHandler: AzureFunction = withCronErrorLogging(
  withCronLogging(async (ctx: ProjectUsersContext, timer: Timer) => {
    ctx.log(`Timer triggered`, timer);
    // NOTE: filterQuery is used by unit tests
    await ProjectUsers.validateProjectUsers(ctx, ctx.filterQuery);
    ctx.log(`Timer finished`, timer);
  }),
);
