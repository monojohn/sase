import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../../../jest/helpers";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { mainHandler } from "./cron-project-users";
import SlackService from "../../../services/slackService";
import EntitlementsService from "../../../services/igamService/entitlementsService";

const ctx = getCtx({ name: "Cron: Project Users" });
let projectCounter = 0;

describe("Cron: Project Users", () => {
  const slackMock = jest.fn(async () => void 0);
  beforeAll(() => {
    jest.spyOn(GraphService, "getGroupUsers").mockImplementation(async () => []);
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest
      .spyOn(EntitlementsService, "getUser")
      .mockResolvedValue({ userLogin: "different user" } as any);
    jest.spyOn(EntitlementsService, "getProjectEntitlements").mockResolvedValue({
      owners: { owner: "org" },
      members: { owner: "org" },
      team: { owner: "org" },
    } as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(EntitlementsService, "getUser").mockRestore();
    jest.spyOn(EntitlementsService, "getProjectEntitlements").mockRestore();
  });

  beforeEach(() => {
    // reset filterQuery between tests
    slackMock.mockReset();
    ctx.filterQuery = {};
  });

  it("Does nothing when project is up to date", async () => {
    const projectName = `Cron: Project Users ${projectCounter++}`;
    ctx.filterQuery = { name: projectName };
    const owners = [ctx.authOid];
    const testProject = await createTestProject({ name: projectName, owners });
    jest.spyOn(GraphService, "getGroupUsers").mockResolvedValueOnce([{ id: ctx.authOid } as any]);

    await mainHandler(ctx);

    // expect project to have 1 owner and 0 members
    const updatedProject = await ProjectModel.findById(testProject._id);

    expect(updatedProject?.owners).toEqual(owners);
    expect(updatedProject?.members).toEqual([]);
  });

  it("Updates members when necessary", async () => {
    const projectName = `Cron: Project Users ${projectCounter++}`;
    ctx.filterQuery = { name: projectName };
    const owners = [ctx.authOid];
    const newMember = genId();
    const testProject = await createTestProject({ name: projectName, owners });

    jest.spyOn(GraphService, "getGroupUsers").mockResolvedValueOnce([{ id: ctx.authOid } as any]);
    jest.spyOn(GraphService, "getGroupUsers").mockResolvedValueOnce([{ id: newMember } as any]);

    await mainHandler(ctx);

    // expect project to have 1 owner and 0 members
    const updatedProject = await ProjectModel.findById(testProject._id);

    expect(updatedProject?.owners).toEqual(owners);
    expect(updatedProject?.members).toEqual([newMember]);
  });

  it("Updates owners when necessary", async () => {
    const projectName = `Cron: Project Users ${projectCounter++}`;
    ctx.filterQuery = { name: projectName };
    const owners = [ctx.authOid];
    const newOwner = genId();
    const testProject = await createTestProject({ name: projectName, owners });

    jest
      .spyOn(GraphService, "getGroupUsers")
      .mockResolvedValueOnce([{ id: ctx.authOid } as any, { id: newOwner } as any]);

    await mainHandler(ctx);

    // expect project to have 1 owner and 0 members
    const updatedProject = await ProjectModel.findById(testProject._id);

    expect(updatedProject?.owners).toEqual([ctx.authOid, newOwner]);
    expect(updatedProject?.members).toEqual([]);
  });

  it("Updates members and owners when necessary", async () => {
    const projectName = `Cron: Project Users ${projectCounter++}`;
    ctx.filterQuery = { name: projectName };
    const owners = [ctx.authOid];
    const newOwner = genId();
    const newMember = genId();
    const testProject = await createTestProject({ name: projectName, owners });

    jest
      .spyOn(GraphService, "getGroupUsers")
      .mockResolvedValueOnce([{ id: ctx.authOid } as any, { id: newOwner } as any]);
    jest.spyOn(GraphService, "getGroupUsers").mockResolvedValueOnce([{ id: newMember } as any]);

    await mainHandler(ctx);

    // expect project to have 1 owner and 0 members
    const updatedProject = await ProjectModel.findById(testProject._id);

    expect(updatedProject?.owners).toEqual([ctx.authOid, newOwner]);
    expect(updatedProject?.members).toEqual([newMember]);
  });

  it("Throws error on missmatching owners of ent", async () => {
    const projectName = `Cron: Project Users ${projectCounter++}`;
    ctx.filterQuery = { name: projectName };
    const owners = [ctx.authOid];
    await createTestProject({ name: projectName, owners });
    jest.spyOn(EntitlementsService, "getProjectEntitlements").mockResolvedValueOnce({
      owners: { owner: "org" },
      members: { owner: "org" },
      team: { owner: "org2" },
    } as any);

    await mainHandler(ctx);

    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(
        "Project Cron: Project Users 4 could not be validated: Missmatching entitlements owners: owners org, members org, team org2",
      ),
    );
  });

  it("Skips org update if they are correct", async () => {
    const projectName = `Cron: Project Users ${projectCounter++}`;
    ctx.filterQuery = { name: projectName };
    const owners = [ctx.authOid];
    await createTestProject({
      name: projectName,
      owners,
      org: "org",
    });
    await mainHandler(ctx);

    expect(slackMock).toHaveBeenCalledTimes(0);
  });
});
