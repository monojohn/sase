import { AzureFunction, Context, Timer } from "@azure/functions";
import NotificationService from "../../../features/notificationEntitlements/notificationService";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import { Project } from "../../../services/dbConnector/models/project";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import GraphService from "../../../services/graphService/graphService";
import { MissingEntAndRoles } from "../../../services/igamService/types";
import { removeUserFromProject } from "../../../services/projectService/projectModificationService/removeUser";
import ProjectService from "../../../services/projectService/projectService";
import SlackService from "../../../services/slackService";
import { chunkArray } from "../../../utils/chunkArray";
import { getEmailOfUser } from "../../../utils/helpers";

export const checkProject = async (ctx: Context, project: Project) => {
  // reject broken projects
  if (!project.ownersGroupId || !project.teamGroupId) {
    throw new Error(`Project missing groups: ${project.name}`);
  }

  const users = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
    "id",
    "userPrincipalName",
    "userType",
    "mail",
  ]);

  const { passed, analysis } = await ProjectService.checkRolesAndEntitlements(ctx, users, project);

  if (passed) {
    // return null if analysis passed
    ctx.log(`Analysis passed for ${project.name}`);
    return null;
  }
  ctx.log(`Analysis failed for ${project.name}`);

  // fetch owners
  const owners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
    "id",
    "mail",
    "userPrincipalName",
    "otherMails",
    "identities",
  ]);

  const upns = Object.keys(analysis.missingRolesAndEntitlements);

  const check: MissingEntAndRoles = {
    projectName: project.name,
    missingRolesAndEntitlements: analysis.missingRolesAndEntitlements,
    upns,
    owners,
  };

  return check;
};

const removeUsers = async (
  ctx: Context,
  project: Project,
  missingEntAndRoles: MissingEntAndRoles,
) => {
  const { owners, missingRolesAndEntitlements, upns } = missingEntAndRoles;
  await Promise.all(
    upns.map(async (upn) => {
      await removeUserFromProject(ctx, project, upn);

      // send email to user that they have been removed
      const user = await GraphService.getSimpleUser(ctx, upn);
      const email = getEmailOfUser(user);
      await NotificationService.notifyRemovedUsersOfMissingRoles(ctx, {
        email,
        projectName: project.name,
        rolesAndEntitlements: missingRolesAndEntitlements[upn] ?? [],
      });
    }),
  );

  // send email to owners that have not been removed
  const ownersToNotify = owners.filter(
    ({ userPrincipalName }) => !upns.includes(userPrincipalName),
  );
  if (ownersToNotify.length) {
    const ownerEmails = ownersToNotify.map((owner) => getEmailOfUser(owner));
    await NotificationService.notifyOwners(ctx, missingEntAndRoles, ownerEmails);
  }
};

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);
  const projects = await ProjectModel.find().lean();

  const projectsWithEntitlementsOrRoles = projects.filter(
    ({ rolesAndEntitlements }) => rolesAndEntitlements?.length > 0,
  );

  const errors: string[] = [];
  const projectChunks = chunkArray(projectsWithEntitlementsOrRoles);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const check = await checkProject(ctx, project);
        if (check) {
          await removeUsers(ctx, project, check);
        }
      }),
    );

    for (const [ind, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        const error = `Failed checking entitlements and roles for project ${chunk[ind].name}`;
        ctx.log(error);
        errors.push(error);
      }
    }
  }
  if (errors.length) {
    await SlackService.logWarning(ctx, new Error(errors.join("\n")));
  }
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
