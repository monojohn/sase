import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import SlackService from "../../../services/slackService";
import { mainHandler } from "./cron-entitlements-and-roles-check";
import GraphService from "../../../services/graphService/graphService";
import NotificationService from "../../../features/notificationEntitlements/notificationService";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import IamService from "../../../services/iamService/iamService";
import RepositoryService from "../../../services/repositoryService/repositoryService";
import { AccessibilityLevel } from "../../../services/dbConnector/enums";
import ProjectModel from "../../../services/dbConnector/models/projectModel";

const ctx = getCtx({ name: "Cron: entitlements and roles check" });

describe("Cron: entitlements and roles check", () => {
  const slackMock = jest.fn(async () => void 0);
  const mailMock = jest.fn(async () => void 0);
  const ownerMailMock = jest.fn(async () => void 0);
  const rolesAndEntitlements = [
    {
      roles: [{ displayName: "role", roleName: "role", id: "12" }],
      iamRoles: [],
      entitlements: ["ent1"],
    },
    {
      roles: [],
      iamRoles: [{ displayName: "iamRole", roleName: "iamRole", key: "1" }],
      entitlements: [],
    },
  ];
  const mailDetails = { id: "id", identities: [], mail: "mail" };

  beforeAll(async () => {
    await ProjectModel.deleteMany();
    jest
      .spyOn(GraphService, "getGroupUsers")
      .mockImplementation(async () => [
        { ...mailDetails, userType: "Member", id: "1", userPrincipalName: "upn1" } as any,
        { ...mailDetails, userType: "Guest", id: "2", userPrincipalName: "upn2" } as any,
      ]);
    jest.spyOn(GraphService, "getSimpleUser").mockImplementation(async () => mailDetails as any);
    jest.spyOn(GraphService, "getUserProps").mockImplementation(async () => mailDetails as any);
    jest.spyOn(SlackService, "logWarning").mockImplementation(slackMock);
    jest
      .spyOn(NotificationService, "notifyRemovedUsersOfMissingRoles")
      .mockImplementation(mailMock);
    jest.spyOn(NotificationService, "notifyOwners").mockImplementation(ownerMailMock);
    jest.spyOn(IamService, "getUsers").mockImplementation(async () => [{ mail: "iam" } as any]);
    jest.spyOn(IamService, "getUserRoles").mockImplementation(async () => []);
    jest.spyOn(EntitlementsService, "getEntitlementsId").mockImplementation(async () => "123");
    jest.spyOn(EntitlementsService, "removeUser").mockResolvedValue({} as any);
    jest.spyOn(RepositoryService, "removeUser").mockImplementation(async () => {});
    jest.spyOn(EntitlementsService, "getUser").mockResolvedValue({ userLogin: "user" } as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getGroupUsers").mockRestore();
    jest.spyOn(GraphService, "getSimpleUser").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(SlackService, "logWarning").mockRestore();
    jest.spyOn(NotificationService, "notifyRemovedUsersOfMissingRoles").mockRestore();
    jest.spyOn(NotificationService, "notifyOwners").mockRestore();
    jest.spyOn(EntitlementsService, "getUser").mockRestore();
    jest.spyOn(IamService, "getUsers").mockRestore();
    jest.spyOn(IamService, "getUserRoles").mockRestore();
    jest.spyOn(EntitlementsService, "getEntitlementsId").mockRestore();
    jest.spyOn(EntitlementsService, "removeUser").mockRestore();
    jest.spyOn(RepositoryService, "removeUser").mockRestore();
  });

  beforeEach(() => {
    slackMock.mockReset();
    mailMock.mockReset();
    ownerMailMock.mockReset();
  });

  it("Throws error for missing group ids", async () => {
    const testProject = await createTestProject({
      rolesAndEntitlements,
    });
    await mainHandler(ctx);

    expect(slackMock).toHaveBeenCalledWith(
      ctx,
      new Error(`Failed checking entitlements and roles for project ${testProject.name}`),
    );
  });

  it("Passes analysis", async () => {
    jest.spyOn(GraphService, "getGroupUsers").mockImplementationOnce(async () => []);
    await createTestProject({
      rolesAndEntitlements,
      ownersGroupId: "123",
      teamGroupId: "234",
      accessibilityLevel: AccessibilityLevel.Private,
    });
    await mainHandler(ctx);
    expect(mailMock).toHaveBeenCalledTimes(0);
  });

  it("Sending emails when there are missing IGAM and IAM users", async () => {
    jest.spyOn(EntitlementsService, "getUser").mockResolvedValueOnce(null as any);
    jest.spyOn(IamService, "getUsers").mockImplementationOnce(async () => []);
    await mainHandler(ctx);
    expect(mailMock).toHaveBeenCalledTimes(1);
    expect(ownerMailMock).toHaveBeenCalledTimes(1);
  });

  it("Sending emails when there are missing conditions", async () => {
    await mainHandler(ctx);
    expect(mailMock).toHaveBeenCalledTimes(2); // 2 emails for the 2 different users
  });
});
