import { jest } from "@jest/globals";
import { createTestProject, getCtx } from "../../../../jest/helpers";
import { Project } from "../../../services/dbConnector/models/project";
import { mainHandler } from "./cron-igam-requests-check";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import {
  ConfidentialityLevel,
  ProjectStatus,
  RequestStatus,
  RequestType,
} from "../../../services/dbConnector/enums";
import RequestsService from "../../../services/igamService/requestsService";
import { IgamRequestStatus } from "../../../services/igamService/enums";
import EntitlementsService from "../../../services/igamService/entitlementsService";
import GraphService from "../../../services/graphService/graphService";
import ProjectModel from "../../../services/dbConnector/models/projectModel";
import OrgService from "../../../services/igamService/orgService";
import ProjectService from "../../../services/projectService/projectService";

const ctx = getCtx({ name: "Cron: IGAM requests check" });
const { testEmail } = global;

describe("Cron: IGAM requests check", () => {
  let testProject: Project;
  beforeAll(async () => {
    testProject = await createTestProject({ owners: [ctx.authOid] });
    jest
      .spyOn(RequestsService, "getRequestInfo")
      .mockImplementation(async () => ({ id: "1234", requestStatus: RequestStatus }) as any);
    jest.spyOn(GraphService, "getUserEmail").mockImplementation(async () => global.testEmail);
    jest
      .spyOn(GraphService, "getGroupUsersEmails")
      .mockImplementation(async () => [global.testEmail]);
    jest.spyOn(GraphService, "getUserProps").mockImplementation(
      async () =>
        ({
          mail: testEmail,
          identities: [],
          displayName: "user",
        }) as any,
    );
    jest
      .spyOn(EntitlementsService, "updateConfidentiality")
      .mockImplementation(async () => [{ requestId: "123" }]);
    jest
      .spyOn(EntitlementsService, "updateOrg")
      .mockImplementation(async () => [{ requestId: "124" }]);
    jest
      .spyOn(EntitlementsService, "addUser")
      .mockImplementation(async () => [[{ requestId: "125" }]]);
    jest.spyOn(EntitlementsService, "getEntitlementsId").mockImplementation(async () => "1");
    jest.spyOn(EntitlementsService, "delete").mockImplementation(async () => ({}) as any);
    jest
      .spyOn(EntitlementsService, "get")
      .mockImplementation(async () => [{ owner: "org" }] as any);
    jest.spyOn(OrgService, "getApproversEmails").mockImplementation(async () => ["mail"]);
    jest
      .spyOn(ProjectService, "checkRolesAndEntitlements")
      .mockImplementation(async () => ({ passed: true }) as any);
  });

  afterAll(() => {
    jest.spyOn(RequestsService, "getRequestInfo").mockRestore();
    jest.spyOn(GraphService, "getUserEmail").mockRestore();
    jest.spyOn(GraphService, "getGroupUsersEmails").mockRestore();
    jest.spyOn(GraphService, "getUserProps").mockRestore();
    jest.spyOn(EntitlementsService, "updateConfidentiality").mockImplementation(async () => []);
    jest.spyOn(EntitlementsService, "updateOrg").mockRestore();
    jest.spyOn(EntitlementsService, "addUser").mockRestore();
    jest.spyOn(EntitlementsService, "getEntitlementsId").mockRestore();
    jest.spyOn(EntitlementsService, "delete").mockRestore();
    jest.spyOn(EntitlementsService, "get").mockRestore();
    jest.spyOn(OrgService, "getApproversEmails").mockRestore();
    jest.spyOn(ProjectService, "checkRolesAndEntitlements").mockRestore();
  });

  beforeEach(() => {});

  describe("Handling of requests", () => {
    it("Skips request with no request id", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
      });
      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(request.requestStatus);
    });

    it("Doesn't update when ticket is still pending approval", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.AWAITING_APPROVAL }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(request.requestStatus);
    });
  });

  describe("Check status of confidentiality update", () => {
    it("Handles request rejection", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);
    });

    it("Triggers the next pending request", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      const requestPending1 = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.PENDING,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1235",
      });

      const requestPending2 = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.PENDING,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1236",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      // first request is rejected
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);

      // first pending request is now awaiting approval
      const requestPending1Updated = await IgamRequestModel.findOne({ _id: requestPending1._id });
      expect(requestPending1Updated?.requestStatus).toEqual(RequestStatus.AWAITING_APPROVAL);

      // last pending request is still pending
      const requestPending2Updated = await IgamRequestModel.findOne({ _id: requestPending2._id });
      expect(requestPending2Updated?.requestStatus).toEqual(RequestStatus.PENDING);
    });

    it("Completes updating confidentiality", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.COMPLETED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.COMPLETED);
    });
  });

  describe("Check status of project creation", () => {
    it("Handles request rejection", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.PROJECT_CREATION,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);
    });

    it("Triggers project creation completion", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.PROJECT_CREATION,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.COMPLETED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.COMPLETED);
      const project = await ProjectModel.findOne({ _id: request.pid });
      expect(project?.status).toEqual(ProjectStatus.BeingCreated);
    });
  });

  describe("Check status of org update", () => {
    it("Handles request rejection", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_ORG,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        org: "new org",
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);
    });

    it("Triggers the next pending request", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      const requestPending = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_ORG,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.PENDING,
        org: "new org",
        requestId: "1235",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      // first request is rejected
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);

      // pending request is now awaiting approval
      const requestPendingUpdated = await IgamRequestModel.findOne({ _id: requestPending._id });
      expect(requestPendingUpdated?.requestStatus).toEqual(RequestStatus.AWAITING_APPROVAL);
    });

    it("Triggers finish update org", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_ORG,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        org: "new org",
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.COMPLETED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.COMPLETED);
    });
  });

  describe("Check status of adding owner", () => {
    it("Handles request rejection", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.ADD_OWNER,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        oid: "you",
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);
    });

    it("Triggers the next pending request", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.UPDATE_CONFIDENTIALITY,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        confidentialityLevel: ConfidentialityLevel.CONFIDENTIAL,
        requestId: "1234",
      });

      const requestPending = await IgamRequestModel.create({
        requestType: RequestType.ADD_OWNER,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.PENDING,
        oid: "you",
        requestId: "1235",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.REJECTED }) as any,
        );

      await mainHandler(ctx);
      // first request is rejected
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.REJECTED);

      // pending request is now awaiting approval
      const requestPendingUpdated = await IgamRequestModel.findOne({ _id: requestPending._id });
      expect(requestPendingUpdated?.requestStatus).toEqual(RequestStatus.AWAITING_APPROVAL);
    });

    it("Triggers finish adding owner", async () => {
      const request = await IgamRequestModel.create({
        requestType: RequestType.ADD_OWNER,
        requesterId: "me",
        pid: testProject._id,
        requestStatus: RequestStatus.AWAITING_APPROVAL,
        oid: "you",
        requestId: "1234",
      });

      jest
        .spyOn(RequestsService, "getRequestInfo")
        .mockImplementation(
          async () => ({ id: "1234", status: IgamRequestStatus.COMPLETED }) as any,
        );

      await mainHandler(ctx);
      const requestUpdated = await IgamRequestModel.findOne({ _id: request._id });
      expect(requestUpdated?.requestStatus).toEqual(RequestStatus.COMPLETED);
    });
  });
});
