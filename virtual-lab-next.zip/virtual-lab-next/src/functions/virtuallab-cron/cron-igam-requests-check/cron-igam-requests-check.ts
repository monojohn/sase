import { AzureFunction, Context, Timer } from "@azure/functions";
import { withCronErrorLogging } from "../../../middleware/withErrorLogging";
import { withCronLogging } from "../../../middleware/withHttpLogging";
import IgamRequestModel from "../../../services/dbConnector/models/igamRequestModel";
import { chunkArray } from "../../../utils/chunkArray";
import RequestsService from "../../../services/igamService/requestsService";
import { RequestStatus } from "../../../services/dbConnector/enums";

export const handler = async (ctx: Context, timer: Timer) => {
  ctx.log(`Timer triggered`, timer);

  const pendingRequests = await IgamRequestModel.find({
    requestStatus: RequestStatus.AWAITING_APPROVAL,
  });

  const requestsChunks = chunkArray(pendingRequests);
  for (let index = 0; index < requestsChunks.length; index++) {
    const chunk = requestsChunks[index];

    await RequestsService.checkRequestsStatus(ctx, chunk);
  }

  ctx.log(`Timer finished`, timer);
};

export const mainHandler: AzureFunction = withCronErrorLogging(withCronLogging(handler));
