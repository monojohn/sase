import { jest } from "@jest/globals";
import { getCtx, getIntegrationProjects } from "../../jest/helpers";
import { AccessibilityLevel } from "../services/dbConnector/enums";
import { Project } from "../services/dbConnector/models/project";
import ProjectModel from "../services/dbConnector/models/projectModel";
import { getSiteIdFromUrl } from "../services/projectService/projectAccessLevelService";
import SharePointService from "../services/sharepointService/sharepointService";
import { WorkspaceType } from "../services/sharepointService/enums";
import { waitForProjectConstellation } from "../utils/waitForProjectConstellation";
import { mainHandler as projectAccessibilityHandler } from "./virtuallab/project-accessibility/project-accessibility";
import { mainHandler as memberHandler } from "./virtuallab/project-members/project-members";
import { mainHandler as ownerHandler } from "./virtuallab/project-owners/project-owners";
import { mainHandler as repositoryHandler } from "./virtuallab/project-repository/project-repository";
import { mainHandler as roleAndEntitlementsHandler } from "./virtuallab/project-roles-and-entitlements/project-roles-and-entitlements";
import { mainHandler as workspaceDeletionQueueHandler } from "./virtuallab/project-workspace-deletion-queue/project-workspace-deletion-queue";
import { mainHandler as workspaceQueueHandler } from "./virtuallab/project-workspace-queue/project-workspace-queue";

jest.setTimeout(60 * 20 * 1000);

const authorization = global.robertaJwt;
const adminAuth = global.adminJwt;
const memberOid = global.vidmanteOid;
const { cypressOid } = global;
const ownerOid = global.vidmanteOid;

describe("Project operations", () => {
  let testProject: Project;

  beforeAll(async () => {
    [testProject] = await getIntegrationProjects();
  });

  beforeEach(async () => {
    if (!testProject) {
      throw new Error("Test project not present");
    }
  });

  describe("Project accessibility", () => {
    let ctx: any;

    beforeAll(() => {
      ctx = getCtx({
        authorization,
        method: "PATCH",
        name: "Project accessibility",
        params: { pid: testProject?._id },
      });
    });

    it("Sets accessibility to Private", async () => {
      ctx.req.body = { accessibilityLevel: AccessibilityLevel.Private };
      await projectAccessibilityHandler(ctx);

      expect(ctx.res).toBe(undefined);
      const siteId = getSiteIdFromUrl(testProject.url);
      expect(await SharePointService.isProjectPublic(siteId)).toBe(false);
    });

    it("Sets accessibility to Public", async () => {
      ctx.req.body = { accessibilityLevel: AccessibilityLevel.Public };

      await projectAccessibilityHandler(ctx);

      expect(ctx.res).toBe(undefined);
      const siteId = getSiteIdFromUrl(testProject.url);
      expect(await SharePointService.isProjectPublic(siteId)).toBe(true);
    });

    it("Sets accessibility to Protected", async () => {
      ctx.req.body = { accessibilityLevel: AccessibilityLevel.Protected };
      await projectAccessibilityHandler(ctx);

      expect(ctx.res).toBe(undefined);
      const siteId = getSiteIdFromUrl(testProject.url);
      expect(await SharePointService.isProjectPublic(siteId)).toBe(false);
    });
  });

  describe("Project members", () => {
    const ctx = getCtx({ authorization, method: "PATCH", name: "Project members" });

    beforeAll(() => {
      ctx.req.params = { pid: testProject?._id };
      ctx.req.body = { oid: memberOid };
    });

    it("Adds a member", async () => {
      await memberHandler(ctx);
      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(memberOid)).toBe(true);
      expect(proj?.owners.includes(memberOid)).toBe(false);

      // expect user to be in members group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Removes member", async () => {
      ctx.req.method = "DELETE";

      await memberHandler(ctx);
      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(memberOid)).toBe(false);
      expect(proj?.owners.includes(memberOid)).toBe(false);

      // expect user to be removed from members group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });
  });

  describe("Project owners", () => {
    let ctx: any;

    beforeAll(() => {
      ctx = getCtx({
        authorization: adminAuth,
        method: "PATCH",
        name: "Project owners",
        params: { pid: testProject?._id },
        body: { oid: ownerOid },
      });
    });

    it("Admin adds an owner", async () => {
      await ownerHandler(ctx);
      // expect project to have owner
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.owners.includes(ownerOid)).toBe(true);
      expect(proj?.members.includes(memberOid)).toBe(false);

      // expect user to be in owners group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Admin removes an owner", async () => {
      ctx.req.method = "DELETE";

      await ownerHandler(ctx);
      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.owners.includes(ownerOid)).toBe(false);
      expect(proj?.members.includes(ownerOid)).toBe(false);

      // expect graph groups to be correct
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });
  });

  describe("Project member to owner", () => {
    let ctx: any;

    beforeAll(() => {
      ctx = getCtx({
        authorization: adminAuth,
        method: "PATCH",
        name: "Project member to owner",
        params: { pid: testProject?._id },
        body: { oid: ownerOid },
      });
    });

    it("Admin adds a member", async () => {
      let proj = await ProjectModel.findById(testProject._id);
      expect(proj?.owners.includes(ownerOid)).toBe(false);
      expect(proj?.members.includes(ownerOid)).toBe(false);

      await memberHandler(ctx);
      // expect project to have member
      proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(memberOid)).toBe(true);

      // expect user to be in members group
      let res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);

      await ownerHandler(ctx);
      // expect project to have owner
      proj = await ProjectModel.findById(testProject._id);
      expect(proj?.owners.includes(ownerOid)).toBe(true);
      expect(proj?.members.includes(ownerOid)).toBe(false);

      // expect graph groups to update
      res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Admin removes an owner", async () => {
      ctx.req.method = "DELETE";

      await ownerHandler(ctx);
      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.owners.includes(ownerOid)).toBe(false);

      // expect graph groups to update
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });
  });

  describe("Project repository", () => {
    let ctx: any;

    beforeAll(() => {
      ctx = getCtx({
        authorization: adminAuth,
        method: "POST",
        name: "Project repo",
        params: { pid: testProject?._id },
        body: { oid: memberOid },
      });
    });

    it("Creates repository", async () => {
      await repositoryHandler(ctx);

      expect(ctx.res).toBe(undefined);

      // expect project to have a repository
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.repositoryUrl?.startsWith("http")).toBe(true);
    });

    it("Adds user", async () => {
      ctx.req.method = "PATCH";
      await memberHandler(ctx);
      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(memberOid)).toBe(true);
      expect(proj?.owners.includes(memberOid)).toBe(false);

      // expect user to be in members group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Removes user", async () => {
      ctx.req.method = "DELETE";
      await memberHandler(ctx);

      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(memberOid)).toBe(false);
      expect(proj?.owners.includes(memberOid)).toBe(false);

      // expect user to be removed from members group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Invites user", async () => {
      ctx.req.method = "PATCH";
      ctx.req.body.oid = cypressOid;
      await memberHandler(ctx);
      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(cypressOid)).toBe(true);
      expect(proj?.owners.includes(cypressOid)).toBe(false);

      // expect user to be in members group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Removes user's invitation", async () => {
      ctx.req.method = "DELETE";
      ctx.req.body.oid = cypressOid;
      await memberHandler(ctx);

      // expect project to have member
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.members.includes(cypressOid)).toBe(false);
      expect(proj?.owners.includes(cypressOid)).toBe(false);

      // expect user to be removed from members group
      const res = await waitForProjectConstellation(ctx, proj!);
      expect(res).toBe(true);
    });

    it("Deletes repository", async () => {
      ctx.req.method = "DELETE";
      await repositoryHandler(ctx);
      // expect project to not have a repository
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.repositoryUrl).toBeFalsy();
    });
  });

  describe("Project workspace", () => {
    const ctx = getCtx({ name: "Project workspace" });

    it("Creates workspace", async () => {
      await workspaceQueueHandler(ctx, {
        pid: testProject?._id,
        oid: ownerOid,
        workspaceType: WorkspaceType.SECURED,
        aiUsage: false,
      });

      // expect project to have a workspace
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.workspaceUrl?.startsWith("http")).toBe(true);
    });

    it("Deletes workspace", async () => {
      await workspaceDeletionQueueHandler(ctx, { pid: testProject?._id, oid: ownerOid });

      // expect project to not have a workspace
      const proj = await ProjectModel.findById(testProject._id);
      expect(proj?.workspaceUrl).toBeFalsy();
    });
  });

  describe("Project roles and entitlements", () => {
    const ctx = getCtx({
      name: "Project roles and entitlements",
      method: "POST",
      authorization: global.adminJwt,
    });

    beforeAll(() => {
      ctx.req.params = { pid: testProject?._id };
    });

    it("Adds entitlement, role and IAM role", async () => {
      ctx.req.body = [
        {
          entitlements: ["A-Darwin"],
          roles: ["All active ECB users"],
          iamRoles: ["VLAB_ESCB-Employee"],
        },
      ];
      await roleAndEntitlementsHandler(ctx);

      expect(ctx.res).toBe(undefined);
      const proj = await ProjectModel.findById(ctx.req.params.pid);
      expect(
        proj?.rolesAndEntitlements[0]?.entitlements?.includes(ctx.req.body[0].entitlements[0]),
      ).toBe(true);
      expect(
        proj?.rolesAndEntitlements[0]?.roles
          ?.map(({ roleName }) => roleName)
          .includes(ctx.req.body[0].roles[0]),
      ).toBe(true);
      expect(
        proj?.rolesAndEntitlements[0]?.iamRoles
          ?.map(({ roleName }) => roleName)
          .includes(ctx.req.body[0].iamRoles[0]),
      ).toBe(true);
    });
  });
});
