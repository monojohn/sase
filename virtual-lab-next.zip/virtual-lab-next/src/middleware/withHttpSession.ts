import { jwtDecode } from "jwt-decode";
import type { FullSession, HttpTriggerMwWithoutParams, MlSession } from "../../@types/types";
import GraphService from "../services/graphService/graphService";

export type Session = {
  upn: string;
  oid: string;
  name: string;
  workspaceName?: string;
  sessionId?: string;
};

export type StartingSession = {
  upn?: string;
  oid?: string;
  name?: string;
  workspaceName?: string;
  sessionId?: string;
};

const isMlSession = (session: FullSession | MlSession): session is MlSession =>
  "xms_mirid" in session;

export const withHttpSession: HttpTriggerMwWithoutParams = (handler) => async (ctx) => {
  const startingSession: StartingSession = {};
  const authHeader = ctx?.req?.headers?.authorization;

  if (!authHeader) {
    ctx.log("No authorization header defined", { headers: ctx?.req?.headers });
    ctx.res = { status: 401, body: { message: "No session in authorization header" } };
    return;
  }

  // decode session and assign data
  const decodedSession = jwtDecode<FullSession | MlSession>(authHeader);
  startingSession.oid = decodedSession.oid;

  if (!startingSession.oid) {
    ctx.res = { status: 401, body: { message: "Invalid session" } };
    return;
  }

  // ML sessions don't have a UPN
  if (isMlSession(decodedSession)) {
    startingSession.upn = "ML Session";

    startingSession.workspaceName = decodedSession.xms_mirid
      .split("/")
      .find((item) => item.startsWith("mlw-"));

    ctx.log("ML session detected", decodedSession);
  } else {
    startingSession.upn = decodedSession.upn;
    startingSession.name = decodedSession.name;
    startingSession.sessionId = decodedSession.sid;

    // if upn is still not present (i.e. Guest users don't have UPN in session)
    if (startingSession.oid && !startingSession.upn) {
      // Get user from Graph and assign data
      const { userPrincipalName } = await GraphService.getUserProps(ctx, startingSession.oid, [
        "userPrincipalName",
      ]);

      startingSession.upn = userPrincipalName;
    }

    // if fetching the UPN failed at any stage, prevent request from going through
    if (!startingSession.upn) {
      ctx.res = {
        status: 401,
        body: { message: `Failed to fetch UPN for ${startingSession.oid}` },
      };
      return;
    }
  }

  ctx.session = {
    name: startingSession.name ?? "ML Session",
    oid: decodedSession.oid,
    upn: startingSession.upn,
    workspaceName: startingSession.workspaceName,
    sessionId: startingSession.sessionId,
  };

  ctx.log(`Session found`, { oid: ctx.session.oid });
  return handler(ctx);
};
