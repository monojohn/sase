import { jest } from "@jest/globals";
import jwt from "jsonwebtoken";
import { HttpTrigger } from "../../@types/types";
import { getCtx } from "../../jest/helpers";
import GraphService from "../services/graphService/graphService";
import { withHttpSession } from "./withHttpSession";

describe("withHttpSession", () => {
  beforeAll(() => {
    jest.spyOn(GraphService, "getUserProps").mockImplementation(async () => ({}) as any);
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserProps").mockRestore();
  });

  describe("Error cases", () => {
    it("Returns 401 when no auth header is passed", async () => {
      const ctx = getCtx({ name: "withHttpSession", authorization: "" });
      const handler = jest.fn();
      const cb = withHttpSession(handler);
      await cb(ctx);

      expect(ctx.res).toEqual({
        status: 401,
        body: { message: "No session in authorization header" },
      });
    });

    it("Returns 401 when no OID is not present in decoded session", async () => {
      const authorization = jwt.sign({ upn: "upn", name: "name" }, "secret");
      const ctx = getCtx({ name: "withHttpSession", authorization });

      const handler = jest.fn<HttpTrigger<{ rsp: string }>>();
      const cb = withHttpSession(handler);

      await cb(ctx);

      expect(ctx.res).toEqual({
        status: 401,
        body: { message: "Invalid session" },
      });
    });

    it("Returns 401 when UPN fetching fails", async () => {
      const authorization = jwt.sign({ oid: "oid", name: "name" }, "secret");
      const ctx = getCtx({ name: "withHttpSession", authorization });

      const handler = jest.fn<HttpTrigger<{ rsp: string }>>();
      const cb = withHttpSession(handler);

      await cb(ctx);

      expect(ctx.res).toEqual({
        status: 401,
        body: { message: "Failed to fetch UPN for oid" },
      });
    });
  });

  describe("Success cases", () => {
    it("Adds user session when decode is successful", async () => {
      const authorization = jwt.sign({ upn: "upn", oid: "oid", name: "name" }, "secret");
      const ctx = getCtx({ name: "withHttpSession", authorization });

      const handler = jest.fn<HttpTrigger<{ rsp: string }>>();
      const cb = withHttpSession(handler);

      await cb(ctx);
      // expect session to have been injected
      expect(handler).toHaveBeenCalledWith({
        ...ctx,
        session: {
          upn: "upn",
          oid: "oid",
          name: "name",
          workspaceName: undefined,
        },
      });
    });

    it("Adds ML session when decode is successful", async () => {
      const authorization = jwt.sign({ oid: "oid", name: "name", xms_mirid: "/mlw-ws" }, "secret");
      const ctx = getCtx({ name: "withHttpSession", authorization });

      const handler = jest.fn<HttpTrigger<{ rsp: string }>>();
      const cb = withHttpSession(handler);

      await cb(ctx);
      // expect session to have been injected
      expect(handler).toHaveBeenCalledWith({
        ...ctx,
        session: {
          oid: "oid",
          upn: "ML Session",
          name: "ML Session",
          workspaceName: "mlw-ws",
        },
      });
    });
  });
});
