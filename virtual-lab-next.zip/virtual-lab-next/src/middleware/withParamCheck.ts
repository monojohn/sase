import { Context } from "@azure/functions";
import { MainHandler } from "../../@types/types";
import SlackService from "../services/slackService";
import { ERRORS } from "../utils/errors";

const getMissingParams = <T>(expectedProps: string[], actualProps: T) => {
  const missingKeys: (keyof T)[] = [];

  // for each required prop
  for (let index = 0; index < expectedProps.length; index++) {
    const key = expectedProps[index] as keyof T;
    // if it wasn't received
    if (!actualProps[key]) {
      // store it in error array
      missingKeys.push(key);
    }
  }

  return missingKeys;
};

export const withParamCheck =
  <T>(functionName: string, expectedProps: string[], handler: MainHandler<T>) =>
  async (ctx: Context, actualProps: T) => {
    const missingParams = getMissingParams(expectedProps, actualProps);

    ctx.log({ expectedProps, actualProps });

    // if there are any missing keys
    if (missingParams.length > 0) {
      const error = `Missing parameter(s) in ${functionName}:\n${missingParams.join("\n")}`;

      ctx.log(error);

      // log it
      await SlackService.logError(ctx, new Error(error));

      // and throw and error
      throw new Error(`${ERRORS.MISSING_PARAMS} | ${error}`);
    }

    // otherwise, run the code as usual
    return handler(ctx, actualProps);
  };
