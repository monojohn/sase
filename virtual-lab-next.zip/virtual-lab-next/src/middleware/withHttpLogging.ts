/* eslint-disable @typescript-eslint/unbound-method, @typescript-eslint/no-unsafe-assignment */

import { Context as AzureContext, Logger as AzureLog } from "@azure/functions";
import winston from "winston";
import type { Context, CronTriggerMw, HttpTriggerMwWithoutParams } from "../../@types/types";
import CreateLogger from "../utils/datadog";

function isString(val: unknown): val is string {
  return typeof val === "string";
}

const useChildLogger =
  (ctx: AzureContext, method: winston.LeveledLogMethod, logger: (...args: unknown[]) => void) =>
  (...args: unknown[]) => {
    const argCopy = [...args];
    const { invocationId } = ctx;
    if (isString(argCopy[0])) {
      // inject invocationId when needed
      if (!argCopy[0]?.startsWith(invocationId)) {
        // eslint-disable-next-line no-param-reassign
        argCopy[0] = `${invocationId} | ${argCopy[0]}`;
      }
    } else {
      // Use invocation as the first log param otherwise
      argCopy.unshift(invocationId);
    }
    logger?.(...argCopy); // optional to make test mocks easier
    // can't use argCopy as is when passing metadata
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument, @typescript-eslint/no-explicit-any
    method(argCopy as any, { invocationId });
  };

type Inject = <T>(ctx: Context<T> | AzureContext) => void;

export const injectDatadogLogger: Inject = (ctx) => {
  // create a child logger for this request which always adds the invocation Id to all logs
  const logger = CreateLogger(ctx.executionContext.functionName);
  const childLogger = logger.child({ invocationId: ctx.invocationId });

  // override all log levels to use child logger
  const customLog = useChildLogger(ctx, childLogger.info, ctx.log) as AzureLog;
  customLog.info = useChildLogger(ctx, childLogger.info, ctx.log.info);
  customLog.warn = useChildLogger(ctx, childLogger.warn, ctx.log.warn);
  customLog.error = useChildLogger(ctx, childLogger.error, ctx.log.error);
  customLog.verbose = useChildLogger(ctx, childLogger.verbose, ctx.log.verbose);

  ctx.log = customLog;
};

export const withHttpLogging: HttpTriggerMwWithoutParams = (handler) => (ctx) => {
  injectDatadogLogger(ctx);

  const {
    req: { method, url, params, body },
  } = ctx;

  ctx.log(`Request received for ${method} ${url}\n`, { params, body });

  return handler(ctx);
};

export const withCronLogging: CronTriggerMw = (handler) => (ctx, timer) => {
  injectDatadogLogger(ctx);

  return handler(ctx, timer);
};
