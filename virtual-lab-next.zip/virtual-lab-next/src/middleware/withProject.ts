import { HttpTriggerMwWithoutParams } from "../../@types/types";
import { Project } from "../services/dbConnector/models/project";
import ProjectModel from "../services/dbConnector/models/projectModel";

export const withProject: HttpTriggerMwWithoutParams = (handler) => async (ctx) => {
  const id = ctx.req.params.pid;

  let project: Project | null = null;
  if (id) {
    // search only for string values
    project = await ProjectModel.findById(id).lean();
  }

  if (!project) {
    ctx.log(`Project with id ${id} does not exist, returning 404`);
    ctx.res = { status: 404, body: { message: `Project '${id}' not found` } };
    return;
  }

  ctx.project = project;

  // otherwise, run the code as usual
  return handler(ctx);
};
