/* eslint-disable @typescript-eslint/no-unsafe-call */

import { Context as AzureContext } from "@azure/functions";
import { jest } from "@jest/globals";
import { Context } from "../../@types/types";
import { getCtx } from "../../jest/helpers";
import { withHttpLogging } from "./withHttpLogging";

describe("withHttpLogging", () => {
  const log = jest.fn();
  let ctx: Context<unknown>;

  beforeEach(() => {
    log.mockReset();
    ctx = getCtx({ name: "withHttpLogging", log });
  });

  it("Logs request info at the start", async () => {
    const handler = () => {};
    const cb = withHttpLogging(handler);
    await cb(ctx);

    expect(log).toHaveBeenCalledTimes(1);
    expect(log).toHaveBeenCalledWith(`withHttpLogging | Request received for GET url\n`, {
      body: {},
      params: {},
    });
  });

  it("Add invocation id to all logs", async () => {
    const log1 = `log1`;
    const log2 = { log2: "log2" };
    const log3 = [{ prop: "log3" }];

    const handler = (context: AzureContext) => {
      context.log(log1);
      context.log(log2);
      context.log(log3);
    };

    const cb = withHttpLogging(handler);
    await cb(ctx);

    expect(log).toHaveBeenCalledTimes(4);
    expect(log).toHaveBeenNthCalledWith(1, `${ctx.invocationId} | Request received for GET url\n`, {
      body: {},
      params: {},
    });
    expect(log).toHaveBeenNthCalledWith(2, `${ctx.invocationId} | ${log1}`);
    expect(log).toHaveBeenNthCalledWith(3, ctx.invocationId, log2);
    expect(log).toHaveBeenNthCalledWith(4, ctx.invocationId, log3);
  });

  it("Works without session", async () => {
    const handler = () => {};
    const ctxCopy = { ...ctx, session: undefined as any };

    const cb = withHttpLogging(handler);
    await cb(ctxCopy);
    const message = `message`;
    const expectedLog = `${ctx.invocationId} | ${message}`;

    ctxCopy.log(message);

    expect(log).toHaveBeenCalledTimes(2);
    expect(log).toHaveBeenNthCalledWith(1, `${ctx.invocationId} | Request received for GET url\n`, {
      body: {},
      params: {},
    });

    expect(log).toHaveBeenNthCalledWith(2, expectedLog);
  });
});
