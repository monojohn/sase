import { HttpTriggerMw } from "../../@types/types";
import SlackService from "../services/slackService";

const getMissingParams = <T>(expectedProps: string[], actualProps: T) => {
  // early return to prevent abuse
  if (!actualProps) {
    return expectedProps;
  }

  const missingKeys: (keyof T)[] = [];

  // for each required prop
  for (let index = 0; index < expectedProps.length; index++) {
    const key = expectedProps[index] as keyof T;
    // if it wasn't received
    if (!actualProps[key]) {
      // store it in error array
      missingKeys.push(key);
    }
  }

  return missingKeys;
};

export const withHttpParamCheck: HttpTriggerMw<string[]> =
  (handler, expectedProps) => async (ctx) => {
    const missingParams = getMissingParams(expectedProps, ctx.req.body);

    // if there are any missing keys
    if (missingParams.length > 0) {
      const message = `Missing parameter(s):\n${missingParams.join("\n")}`;
      const error = new Error(message);

      // log it
      ctx.log(message);
      await SlackService.logError(ctx, error);

      // and return an error
      ctx.res = { status: 400, body: { message } };
      return;
    }

    // otherwise, run the code as usual
    return handler(ctx);
  };
