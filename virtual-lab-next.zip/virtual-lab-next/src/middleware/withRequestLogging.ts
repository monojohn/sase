import type { Context } from "@azure/functions";
import type { MainHandler } from "../../@types/types";
import { injectDatadogLogger } from "./withHttpLogging";

export const withRequestLogging =
  <T>(name: string, handler: MainHandler<T>) =>
  (ctx: Context, props: T) => {
    injectDatadogLogger(ctx);

    ctx.log(`Request received for ${name}`);
    return handler(ctx, props);
  };
