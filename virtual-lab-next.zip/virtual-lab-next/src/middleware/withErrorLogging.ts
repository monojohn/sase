import type { CronTriggerMw, HttpTriggerMwWithoutParams } from "../../@types/types";
import SlackService from "../services/slackService";

export const withErrorLogging: HttpTriggerMwWithoutParams = (handler) => async (ctx) => {
  try {
    await handler(ctx);
    // status can be a function
    let status = ctx.res?.status as number;
    if (typeof status !== "number") {
      // default to 200 if no code is present
      status = 200;
    }

    if (
      // log non-200's
      status !== 200 &&
      // except 201's
      status !== 201 &&
      // except 401's
      status !== 401 &&
      // except 404's for HEAD requests
      !(status === 404 && ctx.req.method === "HEAD")
    ) {
      const body = ctx.res?.body as { message?: string; error?: string };
      const error = body?.error ?? body?.message ?? "No response defined";
      await SlackService.logError(ctx, new Error(error));
    }
  } catch (err) {
    const error = err as Error;
    ctx.log("Error processing request", error);
    await SlackService.logError(ctx, error);
    ctx.res = {
      status: 500,
      body: {
        message: "Error processing request.",
        error: error.message,
      },
    };
  }
};

export const withCronErrorLogging: CronTriggerMw = (handler) => async (ctx, timer) => {
  try {
    await handler(ctx, timer);
  } catch (err) {
    const error = err as Error;
    ctx.log(error);
    // log cron error to slack
    await SlackService.logError(ctx, error);
  }
};
