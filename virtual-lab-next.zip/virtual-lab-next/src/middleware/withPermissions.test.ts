import { jest } from "@jest/globals";
import { getCtx } from "../../jest/helpers";
import GraphService from "../services/graphService/graphService";
import { withMemberPermissions, withOwnerPermissions } from "./withPermissions";

const ctx = getCtx({ name: "withPermissions", project: { owners: [], members: [] }, session: {} });

describe("withPermissions", () => {
  beforeEach(() => {
    ctx.res = undefined;
  });

  afterAll(() => {
    jest.spyOn(GraphService, "getUserGroupsInfo").mockRestore();
  });

  describe("withReadPermissions", () => {
    it("Returns a 403 if no read permissions are present", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
        isAdmin: false,
        isNonEscb: false,
        isVlUser: true,
      }));

      const handler = jest.fn();
      const cb = withMemberPermissions(handler);

      await cb(ctx);

      expect(ctx.res.status).toBe(403);
    });

    it("Calls the handler when permissions exist", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
        isAdmin: true,
        isNonEscb: false,
        isVlUser: true,
      }));

      const handler = jest.fn();
      const cb = withMemberPermissions(handler);

      await cb(ctx);

      expect(ctx.res).toBe(undefined);
      expect(handler).toHaveBeenCalled();
    });
  });

  describe("withWritePermissions", () => {
    it("Returns a 403 if no write permissions are present", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
        isAdmin: false,
        isNonEscb: false,
        isVlUser: true,
      }));

      const handler = jest.fn();
      const cb = withOwnerPermissions(handler);

      await cb(ctx);

      expect(ctx.res.status).toBe(403);
    });

    it("Calls the handler when permissions exist", async () => {
      jest.spyOn(GraphService, "getUserGroupsInfo").mockImplementation(async () => ({
        isAdmin: true,
        isNonEscb: false,
        isVlUser: true,
      }));

      const handler = jest.fn();
      const cb = withOwnerPermissions(handler);

      await cb(ctx);

      expect(ctx.res).toBe(undefined);
      expect(handler).toHaveBeenCalled();
    });
  });
});
