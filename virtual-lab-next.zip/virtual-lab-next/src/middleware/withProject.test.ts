import { jest } from "@jest/globals";
import { createTestProject, genId, getCtx } from "../../jest/helpers";
import { withProject } from "./withProject";

const ctx = getCtx({ name: "withProject" });

describe("withProject", () => {
  beforeEach(() => {
    ctx.res = undefined;
  });

  it("Returns a 404 if non-string id is sent", async () => {
    const cb = withProject(jest.fn());

    await cb(ctx);
    expect(ctx.res.status).toBe(404);
  });

  it("Returns a 404 if no project is found", async () => {
    ctx.req.params.pid = genId();
    const cb = withProject(jest.fn());

    await cb(ctx);

    expect(ctx.res.status).toBe(404);
  });

  it("Sends the project to the handler when the project exists", async () => {
    const project = await createTestProject();

    const cb = withProject(jest.fn());
    const pid = project._id.toString();
    ctx.req.params = { pid };

    await cb(ctx);

    expect(ctx.res).toBe(undefined);
    expect(ctx.project?.name).toBe(project.name);
  });
});
