import { Context } from "@azure/functions";
import { jest } from "@jest/globals";
import { getCtx } from "../../jest/helpers";
import SlackService from "../services/slackService";
import { withErrorLogging } from "./withErrorLogging";

const ctx = getCtx({ name: "withErrorLogging" });

describe("withErrorLogging", () => {
  it("Calls the handler", async () => {
    const handler = jest.fn();
    const cb = withErrorLogging(handler);

    await cb(ctx);

    expect(handler).toHaveBeenCalled();
  });

  it("Logs an error & sets status to 500", async () => {
    const handler = () => {
      throw new Error(`Mock error`);
    };

    const cb = withErrorLogging(handler);
    await cb(ctx);

    expect(ctx.res.status).toBe(500);
  });

  it("Doesn't log and error for 404 HEAD requests", async () => {
    const subCtx = getCtx({ name: "withErrorLogging", method: "HEAD" });
    const slackMock = jest.fn(async () => void 0);
    jest.spyOn(SlackService, "logError").mockImplementationOnce(slackMock);

    const handler = (handlerCtx: Context) => {
      // eslint-disable-next-line no-param-reassign
      handlerCtx.res = { status: 404 };
    };

    const cb = withErrorLogging(handler);
    await cb(subCtx);

    expect(subCtx.res).toEqual({ status: 404 });
    expect(slackMock).toHaveBeenCalledTimes(0);
  });
});
