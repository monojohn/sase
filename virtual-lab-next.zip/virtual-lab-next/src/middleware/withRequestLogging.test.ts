import { Context } from "@azure/functions";
import { jest } from "@jest/globals";
import { withRequestLogging } from "./withRequestLogging";

describe("withLogging", () => {
  const log: any = jest.fn();
  const invocationId = "invocationId";

  const context: Context = {
    log,
    invocationId,
    executionContext: {
      functionName: "mock-fn",
    },
  } as any;

  it("Calls context.log on invocation", async () => {
    const name = "unit-test";
    const handler = withRequestLogging<any>(name, async () => true);
    await handler(context, { a: 1 });
    expect(log).toHaveBeenCalledWith(`${invocationId} | Request received for unit-test`);
  });
});
