import { Context as AzureContext } from "@azure/functions";
import { HttpTriggerMwWithoutParams, UserPermissions } from "../../@types/types";
import { AccessibilityLevel } from "../services/dbConnector/enums";
import { Project } from "../services/dbConnector/models/project";
import GraphService from "../services/graphService/graphService";

export type Permissions = {
  isOwnerOrAdmin: boolean;
  isOwner: boolean;
  isAdmin: boolean;
};

export const getUserPermissions = async (ctx: AzureContext, oid: string, project: Project) => {
  const [isMember, isOwner] = [project?.members?.includes(oid), project?.owners?.includes(oid)];

  const userGroupsInfo = await GraphService.getUserGroupsInfo(ctx, oid);
  const { isAdmin, isNonEscb, isVlUser } = userGroupsInfo;

  return {
    isOwnerOrAdmin: isOwner || isAdmin,
    isUserNonEscb: isNonEscb,
    isMember,
    isOwner,
    isAdmin,
    isVlUser,
  } as UserPermissions;
};

/**
 * Injects permissions without enforcing them
 */
export const withPermissions: HttpTriggerMwWithoutParams = (handler) => async (ctx) => {
  const { oid } = ctx.session;
  ctx.permissions = await getUserPermissions(ctx, oid, ctx.project);

  // check if user is part of the VL users, VL guests or VL admins groups
  if (!ctx.permissions.isVlUser) {
    ctx.res = {
      status: 403,
      body: {
        message: `User ${oid} does not have VL general access`,
      },
    };
    return;
  }

  // otherwise, run the code as usual
  return handler(ctx);
};

export const canUserViewProject = (project: Project, permissions: UserPermissions) => {
  const { isOwnerOrAdmin, isMember, isUserNonEscb } = permissions;
  const isProjectPubliclyVisible =
    project.accessibilityLevel === AccessibilityLevel.Public ||
    project.accessibilityLevel === AccessibilityLevel.Protected;

  const userIsInProject = isOwnerOrAdmin || isMember;
  const userCanSeeProject = isProjectPubliclyVisible && !isUserNonEscb;

  return userIsInProject || userCanSeeProject;
};

export const withViewPermissions: HttpTriggerMwWithoutParams = (handler) =>
  withPermissions((ctx) => {
    const { project, session } = ctx;
    if (!canUserViewProject(project, ctx.permissions)) {
      ctx.res = {
        status: 403,
        body: {
          message: `User ${session.oid} does not have permissions to access project ${project._id}`,
        },
      };
      return;
    }

    // otherwise, run the code as usual
    return handler(ctx);
  });

export const withMemberPermissions: HttpTriggerMwWithoutParams = (handler) =>
  withPermissions((ctx) => {
    const { project, session } = ctx;
    const { isOwnerOrAdmin, isMember } = ctx.permissions;

    if (!isOwnerOrAdmin && !isMember) {
      ctx.res = {
        status: 403,
        body: {
          message: `User ${session.oid} does not have permissions to access project ${project._id}`,
        },
      };
      return;
    }

    // otherwise, run the code as usual
    return handler(ctx);
  });

export const withOwnerPermissions: HttpTriggerMwWithoutParams = (handler) =>
  withPermissions((ctx) => {
    const { session, project } = ctx;
    const { oid } = session;

    if (!ctx.permissions.isOwnerOrAdmin) {
      ctx.res = {
        status: 403,
        body: { message: `User ${oid} does not have permissions for project ${project._id}` },
      };
      return;
    }

    // run the code as usual
    return handler(ctx);
  });

export const withAdminPermissions: HttpTriggerMwWithoutParams = (handler) =>
  withPermissions((ctx) => {
    const { session } = ctx;
    const { oid } = session;

    if (!ctx.permissions.isAdmin) {
      ctx.res = {
        status: 403,
        body: { message: `User ${oid} does not have required permissions` },
      };
      return;
    }

    // run the code as usual
    return handler(ctx);
  });

export const withAdminBlock: HttpTriggerMwWithoutParams = (handler) => async (ctx) => {
  let { isAdmin } = ctx.permissions ?? {};

  // use previous check when possible
  if (typeof isAdmin !== "boolean") {
    const userGroupsInfo = await GraphService.getUserGroupsInfo(ctx, ctx.session.oid);
    isAdmin = userGroupsInfo.isAdmin;
  }

  if (isAdmin) {
    ctx.res = {
      status: 403,
      body: { message: `SA accounts cannot take this action` },
    };
    return;
  }

  // run the code as usual
  return handler(ctx);
};
