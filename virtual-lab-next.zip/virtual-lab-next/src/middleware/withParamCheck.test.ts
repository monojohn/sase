import { getCtx } from "../../jest/helpers";
import { withParamCheck } from "./withParamCheck";

describe("withParamCheck", () => {
  const ctx = getCtx();

  it("handles a missing object", async () => {
    const handler: any = () => true;
    const callback = withParamCheck("unit-test", [], handler);
    expect(await callback(ctx, undefined)).toBe(true);
  });

  it("handles no required props with an empty object", async () => {
    const handler: any = () => true;
    const callback = withParamCheck("unit-test", [], handler);
    expect(await callback(ctx, {})).toBe(true);
  });

  it("handles required props with an correct object", async () => {
    const handler: any = () => true;
    const callback = withParamCheck("unit-test", ["foo"], handler);
    expect(await callback(ctx, { foo: "bar" })).toBe(true);
  });

  it("handles multiple required props with bad object", async () => {
    const handler: any = () => true;
    const callback = withParamCheck("unit-test", ["foo", "bar"], handler);

    await expect(() => callback(ctx, {})).rejects.toMatchObject({
      message: "400 | Missing parameter(s) in unit-test:\nfoo\nbar",
    });
  });
});
