import baseConfig from "./jest.config";

// For a detailed explanation regarding each configuration property, visit:
// https://jestjs.io/docs/en/configuration.html

export default {
  ...baseConfig,
  testTimeout: 10 * 60 * 1000, // timeout in milliseconds
  reporters: [
    "default",
    [
      "jest-sonar",
      {
        outputDirectory: "./coverage",
        outputName: "sonar.xml",
        // reportedFilePath: "absolute",
      },
    ],
  ],
  // remove default ignore
  testPathIgnorePatterns: [],
};
