// For a detailed explanation regarding each configuration property, visit:
// https://jestjs.io/docs/en/configuration.html

export default {
  testTimeout: 60 * 10 * 1000, // timeout in milliseconds
  coverageDirectory: "coverage",

  coverageReporters: ["json", "lcov", "html"],
  collectCoverageFrom: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "!./src/**/*.{d.ts}",
    "!**/node_modules/**",
    "!**/vendor/**",
  ],
  setupFiles: ["<rootDir>/jest.setup.ts"],
  // ignore integration tests by default
  // NOTE: formatters can mess up the regex, it MUST have the slashes: ["<rootDir>/.*\.int\.test\.ts$"]
  testPathIgnorePatterns: ["<rootDir>/src/*/.*\\.int.test.ts$"],

  setupFilesAfterEnv: ["<rootDir>/jest/setup.ts"], // for DB teardown

  extensionsToTreatAsEsm: [".ts"],
  moduleNameMapper: {
    "^(\\.{1,2}/.*)\\.js$": "$1",
  },
  transform: {
    "^.+\\.tsx?$": ["ts-jest", { useESM: true }],
  },
  reporters: [
    "default",
    [
      "jest-sonar",
      {
        outputDirectory: "./coverage",
        outputName: "sonar.xml",
      },
    ],
  ],
};

declare global {
  // See: https://stackoverflow.com/a/68328575/12292636
  var adminJwt: string;
  var vidmanteJwt: string;
  var robertaJwt: string;
}
