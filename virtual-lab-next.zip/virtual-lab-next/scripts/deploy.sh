#!/bin/bash

# process args
while getopts f:t:d:e:p: flag; do
    case "${flag}" in
    f) fullDeployment=true ;;
    d) dir=${OPTARG} ;;
    e) environment=${OPTARG} ;;
    p) private=true ;;
    esac
done

# check service prefix
# default to test environment
if [ -z "$environment" ]; then
    echo "environment not set, defaulting to test"
    environment="test"
fi

echo "Log in to Azure"
identity=$(az login --identity  --object-id $AZURE_USERNAME)
RUNTIME="node"
OS_TYPE="Windows"

if ! [[ -x "$(command -v jq)" ]]; then
    echo "Please install [jq] before continuing -> https://stedolan.github.io/jq/download/.  Aborting."
    exit 1
fi
echo $identity | jq -r '.[0].id'

deployFn() {
    echo "Deploying $1"
    echo "Check if Azure functionapp $1 exists in $AZURE_RESOURCE_GROUP"
    if az functionapp config show -n $1 -g $AZURE_RESOURCE_GROUP &>/dev/null; then
        echo "Azure function $1 exists"
        echo "Deploy code"
        func azure functionapp publish $1 --javascript
        echo "Setting function environment variables"
        az functionapp config appsettings set --name $1 --resource-group $AZURE_RESOURCE_GROUP --settings \
        "AUTHORITY=$AUTHORITY" \
        "AZURE_CLIENT_ID=$AZURE_CLIENT_ID" \
        "AZURE_PRIVATE_KEY=$AZURE_PRIVATE_KEY" \
        "AZURE_THUMBPRINT=$AZURE_THUMBPRINT" \
        "AZURE_CR_RESOURCE_GROUP=$AZURE_CR_RESOURCE_GROUP" \
        "AZURE_RESOURCE_GROUP=$AZURE_RESOURCE_GROUP" \
        "AZURE_TENANT=$AZURE_TENANT" \
        "AZURE_TENANT_ID=$AZURE_TENANT_ID" \
        "AZURE_USERNAME=$AZURE_USERNAME" \
        "FLOWMAILER_ACCOUNT_ID=$FLOWMAILER_ACCOUNT_ID" \
        "FLOWMAILER_CLIENT_ID=$FLOWMAILER_CLIENT_ID" \
        "FLOWMAILER_CLIENT_SECRET=$FLOWMAILER_CLIENT_SECRET" \
        "FLOWMAILER_EMAIL_SENDER=$FLOWMAILER_EMAIL_SENDER" \
        "FLOWMAILER_EMAIL_REPLY_TO=$FLOWMAILER_EMAIL_REPLY_TO" \
        "FLOWMAILER_SMTP_PASS=$FLOWMAILER_SMTP_PASS" \
        "FLOWMAILER_SMTP_USER=$FLOWMAILER_SMTP_USER" \
        "GIT_REPOSITORY_TOKEN=$GIT_REPOSITORY_TOKEN" \
        "HUBSITE_ID=$HUBSITE_ID" \
        "STORAGE_ACCOUNT=$STORAGE_ACCOUNT" \
        "SUBSCRIPTION_ID=$SUBSCRIPTION_ID" \
        "GROUP_ACCOUNT_TYPE=$GROUP_ACCOUNT_TYPE" \
        "GROUP_SERVICE=$GROUP_SERVICE" \
        "APP_INSTANCE=$APP_INSTANCE" \
        "IGAM_KEY=$IGAM_KEY" \
        "IGAM_ENDPOINT=$IGAM_ENDPOINT" \
        "IGAM_CERT=$IGAM_CERT" \
        "VL_ADMINS_GROUP_ID=$VL_ADMINS_GROUP_ID" \
        "VL_MEMBERS_GROUP_ID=$VL_MEMBERS_GROUP_ID" \
        "VL_GUESTS_GROUP_ID=$VL_GUESTS_GROUP_ID" \
        "CONTRIBUTOR_ROLE_ID=$CONTRIBUTOR_ROLE_ID" \
        "CUSTOM_MEMBER_ROLE_ID=$CUSTOM_MEMBER_ROLE_ID" \
        "INFRA_CLIENT_ID=$INFRA_CLIENT_ID" \
        "INFRA_CERTIFICATE=$INFRA_CERTIFICATE" \
        "HUBSITE_NAME=$HUBSITE_NAME" \
        "FF_USE_PLANNER=$FF_USE_PLANNER" \
        "FF_USE_PROJECT_ACTIVITY_TYPE=$FF_USE_PROJECT_ACTIVITY_TYPE" \
        "SLACK_WEBHOOK_URL=$SLACK_WEBHOOK_URL" \
        "WEBSITE_NODE_DEFAULT_VERSION=~22" \
        "DATADOG_API_KEY=$DATADOG_API_KEY" \
        "DATAD0G_APP_KEY=$DATAD0G_APP_KEY" \
        "DD_SITE=$DD_SITE" \
        "DD_SERVICE=$DD_SERVICE" \
        "DD_LOGS_INJECTION=$DD_LOGS_INJECTION" \
        "ML_BUDGET_EMAIL=$ML_BUDGET_EMAIL" \
        "KUBECONFIG=$KUBECONFIG" \
        "MONGO_URL=$MONGO_URL" \
        "IAM_CLIENT_ID=$IAM_CLIENT_ID" \
        "IAM_CLIENT_SECRET=$IAM_CLIENT_SECRET" \
        "ENVIRONMENT=$ENVIRONMENT" \
        "DEVO_SECRET_ACCESS_KEY=$DEVO_SECRET_ACCESS_KEY" \
        "NODE_OPTIONS=$NODE_OPTIONS"
    else
        echo "$1 does not exist, breaking"
        exit 1
    fi
}

# go to dist folder
cd dist

# needed for private functions
echo "10.136.4.175 func-test-virtuallab-private.scm.azurewebsites.net" >> /etc/hosts
echo "10.136.4.176 func-test-virtuallab-cron-private.scm.azurewebsites.net" >> /etc/hosts
echo "10.140.10.178 func-stg-virtuallab-private.scm.azurewebsites.net" >> /etc/hosts
echo "10.140.10.179 func-stg-virtuallab-cron-private.scm.azurewebsites.net" >> /etc/hosts

# if we're doing a single deployment
if [ ! -z "$dir" ]; then
    target="func-$environment-$dir"
    echo "Running single deployment for $target in $dir"
    cd $dir
    deployFn $target
else
    if [ ! -z "$private" ]; then
        cd virtuallab
        deployFn "func-$environment-virtuallab-private"
        cd ..
        cd virtuallab-cron
        deployFn "func-$environment-virtuallab-cron-private"


    elif [ ! -z "$fullDeployment" ]; then
        echo "Running full deployment"

        # get all directories in /dist without the trailing slash
        folders=$(ls -d */ | sed 's#/##')

        # for each directory in /dist
        for dir in $folders; do
            
            cd $dir
            deployFn "func-$environment-$dir"
            cd ..
        done
    else
        echo "dir ($dir) and fullDeployment (${fullDeployment}) do not exist, breaking"
        exit 1
    fi
fi
