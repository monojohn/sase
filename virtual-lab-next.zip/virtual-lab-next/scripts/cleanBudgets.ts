import "dotenv/config";

import EntitlementService from "../src/services/igamService/entitlementsService";
import { GROUP_TEAM_PREFIX } from "../src/utils/config";
import BudgetService from "./../src/services/budgetService/budgetService";
import { askUser } from "./helpers/askQuestion";

const ctx = console as any;

const script = async () => {
  const budgetsToDelete: string[] = [];

  // get all budgets
  const budgetService = new BudgetService(ctx);
  const budgets = await budgetService.getBudgets();

  // for each budget
  for (const budget of budgets) {
    const budgetName = budget.name;

    if (!budgetName?.startsWith(GROUP_TEAM_PREFIX)) {
      // ignore budgets which don't start with TEAM_VLB
      break;
    }

    // get group from IGAM
    const [group] = await EntitlementService.get(ctx, budgetName);
    // if the group does not exist
    if (!group) {
      // add it to list
      budgetsToDelete.push(budgetName);
    }
  }

  console.log(budgetsToDelete, `Found ${budgetsToDelete.length} budgets to delete`);
  // ask user if budgets should be delete
  if (budgetsToDelete.length > 0 && (await askUser("Delete budgets?"))) {
    for (const budgetName of budgetsToDelete) {
      console.log(`Deleting budget ${budgetName}`);
      await budgetService.deleteBudget(ctx, budgetName);
    }
  }
};

script();
