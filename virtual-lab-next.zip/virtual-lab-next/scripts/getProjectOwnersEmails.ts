import "dotenv/config";

import ProjectModel from "../src/services/dbConnector/models/projectModel";
import { chunkArray } from "../src/utils/chunkArray";
import GraphService from "../src/services/graphService/graphService";

const ctx = console as any;

const getEmailsOfProjectOwners = async () => {
  const errors: string[] = [];
  const allEmails: string[] = [];

  const projects = await ProjectModel.find();
  const projectChunks = chunkArray(projects);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const emails = await GraphService.getGroupOwnersEmails(ctx, project.name);
        allEmails.push(...emails);
      }),
    );
    for (const promiseResult of settled) {
      if (promiseResult.status === "rejected") {
        errors.push(promiseResult.reason);
      }
    }
  }
  console.log(Array.from(new Set(allEmails)).join("\n"));
  console.log(errors);
};

getEmailsOfProjectOwners();
