import "dotenv/config.js";
import SpFolderService from "../src/services/sharepointService/spFolderService";
import XLSX from "xlsx";
import GraphService from "../src/services/graphService/graphService";
import { VL_GUESTS_GROUP_ID, VL_MEMBERS_GROUP_ID } from "../src/utils/config";
import { getEmailOfUser } from "../src/utils/helpers";
import { readExcelFile } from "../src/features/export/helpers";

const ctx = console as any;
const updateExportedFiles = async () => {
  // get users
  const [ecbUsers, guestUsers] = await Promise.all([
    GraphService.getGroupUsers(ctx, VL_MEMBERS_GROUP_ID, [
      "id",
      "mail",
      "otherMails",
      "identities",
    ]),
    GraphService.getGroupUsers(ctx, VL_GUESTS_GROUP_ID, ["id", "mail", "otherMails", "identities"]),
  ]);
  const allUsers = [...ecbUsers, ...guestUsers];

  // get files
  const folderName = "User logs";
  const files = await SpFolderService.getFiles(ctx, folderName);

  await Promise.all(
    files.map(async (file) => {
      // get file data
      const buffer = await SpFolderService.downloadFile(ctx, file.ServerRelativeUrl);
      const data = readExcelFile(buffer);
      const updatedFile = data.map((row, index) => {
        const updatedRow = [...row];
        let value = "";
        if (index === 0) {
          // header row should contain "Email"
          value = "Email";
        } else {
          // rest of rows email of user
          const user = allUsers.find(({ id }) => id === row[0]);
          value = user ? getEmailOfUser(user) : "";
        }
        updatedRow.splice(6, 0, value);
        return updatedRow;
      });

      // create new file
      const sheet = XLSX.utils.aoa_to_sheet(updatedFile);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, sheet, "User Logs");

      // upload new file with the same name
      await SpFolderService.uploadFile(ctx, workbook, folderName, file.Name);
    }),
  );
};

updateExportedFiles();
