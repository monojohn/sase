import "dotenv/config";

import fs from "node:fs";
import XLSX from "xlsx";
import { Project } from "../src/services/dbConnector/models/project";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import { chunkArray } from "../src/utils/chunkArray";
import SpFolderService from "../src/services/sharepointService/spFolderService";
import { shouldFileBeIgnored } from "../src/features/fileExpiration/helpers";
import { IFileInfo } from "@pnp/sp/files/types";
import { wait, withRetry } from "../src/utils/helpers";

XLSX.set_fs(fs);

const ctx = console as any;
type FilesMap = Record<string, IFileInfo[]>;

const getProjectsFiles = async () => {
  const projects = await ProjectModel.find();
  const chunks = chunkArray(projects);
  const filesDetails: FilesMap = {};
  const errors: string[] = [];

  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        await withRetry(
          async () => {
            await wait(2);
            const files = await getFilesOfProject(project);
            filesDetails[project.name] = files;
          },
          ctx,
          10,
        );
      }),
    );
    for (const [index, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(chunk[index].name);
      }
    }
  }
  console.log(errors);

  return exportToExcel(filesDetails);
};

const getFilesOfProject = async (project: Project) => {
  const { teamGroupId } = project;
  if (!teamGroupId) {
    // broken project, return empty array
    return [];
  }

  // get files
  const site = await GraphService.getSiteById(ctx, teamGroupId);
  const projectFiles = await SpFolderService.getProjectFiles(ctx, site.name);

  // return only user files
  return projectFiles.filter((file) => !shouldFileBeIgnored(project, file));
};

const exportToExcel = async (filesDetails: FilesMap) => {
  const filesObject: Record<string, string>[] = [];

  // build sheet data
  for (const projectName of Object.keys(filesDetails)) {
    const files = filesDetails[projectName];
    for (const file of files) {
      filesObject.push({
        "Project name": projectName,
        "File name": file.Name,
      });
    }
  }

  // create workbook and save
  const workbook = XLSX.utils.book_new();
  const filesSheet = XLSX.utils.json_to_sheet(filesObject);
  XLSX.utils.book_append_sheet(workbook, filesSheet, "User Details");
  XLSX.writeFile(workbook, "scripts/projectFiles.xlsx");
};

getProjectsFiles();
