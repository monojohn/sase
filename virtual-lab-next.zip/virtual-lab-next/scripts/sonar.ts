import "dotenv/config";
import { execSync, spawn } from "child_process";
import { SONAR_HOST_URL, SONAR_TOKEN } from "../src/utils/config";

const projectKey = "virtual-lab_azure-functions_virtual-lab_AYCzIc8SPpMuYjBLC4M5";
const branch = execSync("git rev-parse --abbrev-ref HEAD").toString().trim();

// run scan in sonarqube
const scanner = spawn(
  "npx",
  [
    "sonar-scanner",
    `-Dsonar.host.url=${SONAR_HOST_URL}`,
    `-Dsonar.token=${SONAR_TOKEN}`,
    `-Dsonar.branch.name=${branch}`,
  ],
  { stdio: "inherit", shell: true },
);

scanner.on("exit", async (code) => {
  if (code !== 0) {
    process.exit(code ?? 1);
  }

  console.log("Scan completed. Fetching results from SonarQube...");

  try {
    const metrics = [
      "coverage",
      "new_coverage",
      "bugs",
      "new_bugs",
      "vulnerabilities",
      "new_vulnerabilities",
      "code_smells",
      "new_code_smells",
    ].join(",");

    const metricsUrl = `${SONAR_HOST_URL}/api/measures/component?component=${projectKey}&metricKeys=${metrics}&branch=${branch}`;

    const metricsResp = await fetch(metricsUrl, {
      headers: {
        Authorization: `Basic ${Buffer.from(SONAR_TOKEN + ":").toString("base64")}`,
      },
    });

    if (!metricsResp.ok) throw new Error(`SonarQube API error: ${metricsResp.statusText}`);
    const metricsData = await metricsResp.json();

    const issuesUrl = `${SONAR_HOST_URL}/api/issues/search?componentKeys=${projectKey}&branch=${branch}&ps=100&statuses=OPEN`;
    const issuesResp = await fetch(issuesUrl, {
      headers: {
        Authorization: `Basic ${Buffer.from(SONAR_TOKEN + ":").toString("base64")}`,
      },
    });

    if (!issuesResp.ok) throw new Error(`SonarQube API error: ${issuesResp.statusText}`);
    const issuesData = await issuesResp.json();

    console.log(issuesData.issues);
    console.log(`\nIssues found: ${issuesData.total}`);

    console.log("\nMetrics:");
    console.log(metricsData.component.measures);
  } catch (err) {
    console.error("Failed to fetch results:", err);
  }
});
