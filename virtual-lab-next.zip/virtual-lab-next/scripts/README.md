# /src/scripts

Scripts are great if you want to test something out without deploying or run 1-time jobs for business like getting the emails of project owners.

To run a script, use `ts-node ./scripts/<scrip-name>.ts`

## Naming

Scripts which start with `test` like `test.my-script.ts` are git ignored for ease of use.
