/* eslint-disable no-console, consistent-return */

import { KeyVaultManagementClient } from "@azure/arm-keyvault";
import { Workspace } from "@azure/arm-machinelearning";
import { StorageManagementClient } from "@azure/arm-storage";
import { Context } from "@azure/functions";
import moment from "moment";
import { ActionType } from "../../../src/features/userActions/enums";
import FavoriteProjectModel from "../../../src/services/dbConnector/models/favoriteProjectModel";
import OwnershipInviteModel from "../../../src/services/dbConnector/models/ownershipInviteModel";
import ProjectModel from "../../../src/services/dbConnector/models/projectModel";
import UserActionModel from "../../../src/services/dbConnector/models/userActionModel";
import RepositoryService from "../../../src/services/repositoryService/repositoryService";
import EntitlementsService from "../../../src/services/igamService/entitlementsService";
import MachineLearningService from "../../../src/services/machineLearningService/machineLearningService";
import ProjectDeletionService from "../../../src/services/projectService/projectDeletionService";
import { chunkArray } from "../../../src/utils/chunkArray";
import { AZURE_RESOURCE_GROUP, SUBSCRIPTION_ID } from "../../../src/utils/config";
import { Project } from "./../../../src/services/dbConnector/models/project.d";
import { getIdOfAllVlGroups } from "./helpers";
import { wait, withRetry } from "../../../src/utils/helpers";
import { Repository } from "../../../src/services/repositoryService/types";
import { updateProject } from "../../../src/services/repositoryService/helpers";
import IgamRequestModel from "../../../src/services/dbConnector/models/igamRequestModel";
import { ProjectStatus, RequestStatus, RequestType } from "../../../src/services/dbConnector/enums";
import JoinProjectRequestModel from "../../../src/services/dbConnector/models/joinProjectRequestModel";

const ctx = console as unknown as Context;

const CleanupService = {
  async clean(readOnly: boolean) {
    const projects = await ProjectModel.find();

    await CleanupService.cleanGroups(readOnly, projects);
    await CleanupService.cleanMlWorkspaces(readOnly, projects);
    await CleanupService.cleanStorageAccounts(readOnly, projects);
    await CleanupService.cleanKeyVaults(readOnly, projects);
    await CleanupService.cleanRepositories(readOnly, projects);
    await CleanupService.cleanAwaitingOwners(readOnly, projects);
    await CleanupService.cleanJoinRequests(readOnly, projects);
    await CleanupService.cleanFavorites(readOnly, projects);
    await CleanupService.cleanUserActions(readOnly);
    await CleanupService.cleanRejectedProjectCreationRequests(readOnly);
    await CleanupService.cleanOldProjects(readOnly, projects);
  },

  async cleanFavorites(readOnly: boolean, projects: Project[]) {
    console.log("\n\n--- Favorites ---");

    // get project ids
    const existingProjectsPids = projects.map((project) => project?._id.toString());

    // find all favs for missing projects
    const favorites = await FavoriteProjectModel.find();
    const badFavorites = favorites.filter(({ pid }) => !existingProjectsPids.includes(pid));

    const percentage = (badFavorites.length / favorites.length) * 100;
    console.log(
      `Found ${badFavorites.length} bad favorites out of ${favorites.length} (${percentage}%)`,
    );

    if (!readOnly) {
      console.log(`Deleting ${badFavorites.length} favorites`, badFavorites);
      const badFavoritesIds = badFavorites.map(({ _id }) => _id);
      await FavoriteProjectModel.deleteMany({ _id: { $in: badFavoritesIds } }).lean();
    }
  },

  async cleanAwaitingOwners(readOnly: boolean, projects: Project[]) {
    console.log("\n\n--- Awaiting owners ---");

    // get project ids
    const existingProjectsPids = projects.map((project) => project?._id.toString());

    // find all items with missing projects
    const awaitingOwners = await OwnershipInviteModel.find();
    const badInvites = awaitingOwners.filter(({ pid }) => !existingProjectsPids.includes(pid));

    const percentage = (badInvites.length / awaitingOwners.length) * 100;
    console.log(
      `Found ${badInvites.length} bad ownership invitations out of ${awaitingOwners.length} (${percentage}%)`,
    );

    if (!readOnly) {
      console.log(`Deleting ${badInvites.length} ownership invitations`, badInvites);
      const badInvitesIds = badInvites.map(({ _id }) => _id);
      await OwnershipInviteModel.deleteMany({ _id: { $in: badInvitesIds } }).lean();
    }
  },

  async cleanJoinRequests(readOnly: boolean, projects: Project[]) {
    console.log("\n\n--- Join requests ---");

    // get project ids
    const existingProjectsPids = projects.map((project) => project?._id.toString());

    // find all items with missing projects
    const joinRequests = await JoinProjectRequestModel.find();
    const badRequests = joinRequests.filter(({ pid }) => !existingProjectsPids.includes(pid));

    const percentage = (badRequests.length / joinRequests.length) * 100;
    console.log(
      `Found ${badRequests.length} bad join requests out of ${joinRequests.length} (${percentage}%)`,
    );

    if (!readOnly) {
      console.log(`Deleting ${badRequests.length} join request`, badRequests);
      const badRequestIds = badRequests.map(({ _id }) => _id);
      await JoinProjectRequestModel.deleteMany({ _id: { $in: badRequestIds } }).lean();
    }
  },

  async cleanGroups(readOnly: boolean, projects: Project[]) {
    console.log("\n\n--- Azure Groups ---");
    // get all groups with our prefixes
    const groups = await getIdOfAllVlGroups(ctx);

    const allGroupIds = Object.keys(groups);
    const brokenProjects: Project[] = [];
    const goodProjectId: string[] = [];
    // for each project
    for (let index = 0; index < projects.length; index++) {
      const proj = projects[index];
      if (
        // skip projects that were rejected / expired / closed / awaiting approval / being created
        ![
          ProjectStatus.ApprovalClosed,
          ProjectStatus.ApprovalExpired,
          ProjectStatus.ApprovalRejected,
          ProjectStatus.AwaitingApproval,
          ProjectStatus.BeingCreated,
        ].includes(proj.status) &&
        //  if 1+ of the groups is not on the groups list
        (!groups[proj.membersGroupId] ||
          !groups[proj.ownersGroupId] ||
          !groups[proj.teamGroupId] ||
          // remove unit test projects too
          proj.name.startsWith("VL Proj Creation UT"))
      ) {
        brokenProjects.push(proj);
        // delete any existing groups
      } else {
        // otherwise,
        // remove it from the groups list
        delete groups[proj.membersGroupId];
        delete groups[proj.ownersGroupId];
        delete groups[proj.teamGroupId];

        goodProjectId.push(proj.membersGroupId, proj.ownersGroupId, proj.teamGroupId);
      }
    }

    let groupIdsToDelete = Object.keys(groups);

    console.log(`Number of groups to delete: ${groupIdsToDelete.length}`);
    console.log(`Number of good groups: ${goodProjectId.length}`);

    // find all groups which don't belong to a 'good' project
    for (let index = 0; index < groupIdsToDelete.length; index++) {
      const group = groups[groupIdsToDelete[index]];

      if (goodProjectId.includes(group?.id)) {
        // if group has a project
        // remove it from the list
        delete groups[group.id];
      } else if (!group) {
        console.log(`Bad group at index (${index})`);
      } else {
        console.log(`${group?.displayName} is bad`);
      }
    }

    console.log(
      `${brokenProjects.length} out of ${projects.length} projects (~${Math.round(
        (brokenProjects.length / projects.length) * 100,
      )}%) have missing groups.`,
    );

    console.log(
      `${groupIdsToDelete.length} out of ${allGroupIds.length} (~${Math.round(
        (groupIdsToDelete.length / allGroupIds.length) * 100,
      )}%) groups don't have a project.`,
    );

    if (brokenProjects.length >= projects.length / 2) {
      return console.log(`Over 50% of projects are broken, are you sure?`);
    }

    for (let index = 0; index < brokenProjects.length; index++) {
      const { _id, name } = brokenProjects[index];
      if (readOnly) {
        console.log(`Would delete ${_id}: ${name} from list`);
        continue;
      }

      console.log(`Deleting ${_id}: ${name} from list`);
      await ProjectModel.deleteOne({ _id });
    }

    const errors: string[] = [];
    groupIdsToDelete = Object.keys(groups);
    if (!readOnly) {
      // delete all remaining groups in the list since they don't belong to any project
      for (let index = 0; index < groupIdsToDelete.length; index++) {
        const group = groups[groupIdsToDelete[index]];
        const entId = await EntitlementsService.getEntitlementsId(ctx, group.displayName);

        if (!entId) {
          console.log(`${group.displayName} does not have a matching entId, skipping`);
          continue;
        }

        console.log(`Deleting ${group.displayName}: ${entId}`);
        await EntitlementsService.delete(ctx, entId).catch((e: Error) => {
          console.log(`Failed to delete ${entId}`);
          errors.push(`${errors.length + 1}: ${entId} - ${group.displayName} | ${e.message}`);
        });
      }
    }

    // shows erors if any
    if (errors.length > 0) {
      console.log(errors.join("\n"));
    }
  },

  async cleanRepositories(readOnly: boolean, allProjects: Project[]) {
    const projectsWithRepos = allProjects.filter(({ repositoryUrl }) =>
      repositoryUrl?.startsWith("http"),
    );

    // get url of all repository groups
    const urlsInList = projectsWithRepos.map(({ repositoryUrl }) => repositoryUrl);

    const projectsUrls: string[] = [];
    const orphanProjects: Repository[] = [];
    const repositoryGroups = await RepositoryService.getAllRepositoryGroups();

    for (let index = 0; index < repositoryGroups.length; index++) {
      const repositoryGroup = repositoryGroups[index];
      const url = repositoryGroup.web_url;

      if (!url || !urlsInList.includes(url)) {
        const repositories = await RepositoryService.getRepositories(repositoryGroup.id);
        const unmarkedRepositories = repositories.filter(
          ({ name }) => !name.includes(RepositoryService.deletionPhrases[0]),
        );
        if (unmarkedRepositories.length) {
          orphanProjects.push(...unmarkedRepositories);
        }
      } else {
        projectsUrls.push(url);
      }
    }

    const missingUrls: string[] = [];
    const projectsWithBadUrls: Project[] = [];
    const projectWithBadStateUrl: string[] = [];

    // Find projects with a broken workspace url
    for (let index = 0; index < urlsInList.length; index++) {
      const projectUrl = urlsInList[index];
      if (projectUrl.indexOf("http") !== 0) {
        projectWithBadStateUrl.push(projectUrl);
        projectsWithBadUrls.push(projectsWithRepos[index]);
      } else if (!projectsUrls.includes(projectUrl)) {
        missingUrls.push(projectUrl);
      }
    }

    console.log("\n\n--- Repos ---");

    console.log(
      `${urlsInList.length} out of ${allProjects.length} (~${Math.round(
        (urlsInList.length / allProjects.length) * 100,
      )}%) projects have repository groups`,
    );

    console.log(
      `${orphanProjects.length} out of ${repositoryGroups.length} (~${Math.round(
        (orphanProjects.length / repositoryGroups.length) * 100,
      )}%) repository groups don't have an associated project`,
    );

    console.log(
      `${missingUrls.length} out of ${projectsWithRepos.length} (~${Math.round(
        (missingUrls.length / projectsWithRepos.length) * 100,
      )}%) projects have broken repository groups urls`,
    );

    console.log(
      `${projectWithBadStateUrl.length} out of ${projectsWithRepos.length} (~${Math.round(
        (projectWithBadStateUrl.length / projectsWithRepos.length) * 100,
      )}%) projects have repository groups locked in an intermediate stage`,
    );

    const pids = projectsWithBadUrls.map(({ _id }) => _id);

    if (readOnly) {
      console.log(`Would update ${pids.length} projects`);
    } else {
      await ProjectModel.updateMany({ _id: { $in: pids } }, { $set: { repositoryUrl: null } });
    }

    // mark repository groups for deletion
    await Promise.all(
      orphanProjects.map(async ({ id, name }) => {
        if (readOnly) {
          return console.log(`Would mark repository ${name} for deletion`);
        }
        await updateProject(id, `${name} ${RepositoryService.deletionPhrases[0]}`);
      }),
    );
  },

  async cleanStorageAccounts(readOnly: boolean, projects: Project[]) {
    const credentials = MachineLearningService.connect();
    const client = new StorageManagementClient(credentials, SUBSCRIPTION_ID);
    const storageAccounts = await MachineLearningService.getAllResources(
      client.storageAccounts.list(),
    );

    const projectnames = projects.map(({ name }) => name);
    // return storage accounts without projects
    const orphanStorageAccounts = storageAccounts.filter(
      // doesn't have a project
      ({ tags }) =>
        // has a project tag
        tags!.project &&
        // but the tag doesn't match a project
        !projectnames.includes(tags!.project),
    );

    const storageAccountNames = orphanStorageAccounts.map(({ name }) => name);
    console.log(
      `Found ${orphanStorageAccounts.length} storage accounts without a project`,
      storageAccountNames,
    );

    if (!readOnly) {
      for (let index = 0; index < storageAccountNames.length; index++) {
        const name = storageAccountNames[index];
        ctx.log(`Deleting ${name}`);
        await client.storageAccounts.delete(AZURE_RESOURCE_GROUP, name!);
      }
    }
  },

  async cleanKeyVaults(readOnly: boolean, projects: Project[]) {
    const credentials = MachineLearningService.connect();
    const client = new KeyVaultManagementClient(credentials, SUBSCRIPTION_ID);

    const keyVaults = await MachineLearningService.getAllResources(client.vaults.list());

    const projectnames = projects.map(({ name }) => name);
    const orphanKeyVaults = keyVaults.filter(
      // does't match a project
      ({ tags }) =>
        // has a project tag
        tags!.project &&
        // but the tag doesn't match a project
        !projectnames.includes(tags!.project),
    );
    const keyVaultNames = orphanKeyVaults.map(({ name }) => name);
    console.log(`Found ${orphanKeyVaults.length} key vaults without a project`, keyVaultNames);

    if (!readOnly) {
      for (let index = 0; index < keyVaultNames.length; index++) {
        const name = keyVaultNames[index];
        ctx.log(`Deleting ${name}`);
        await client.vaults.delete(AZURE_RESOURCE_GROUP, name!);
      }
    }
  },

  async cleanMlWorkspaces(readOnly: boolean, allProjects: Project[]) {
    console.log("\n\n--- ML Workspaces ---");
    const projects = allProjects.filter(({ workspaceUrl }) => workspaceUrl?.startsWith("http"));
    const projectsMlwUrl = projects.map(({ workspaceUrl }) => workspaceUrl);

    // get url of all ML Workspaces
    const workspaces: Workspace[] = [];
    const workspacesUrl: string[] = [];
    const orphanMlW: Workspace[] = [];
    const projectsWithBadUrls: Project[] = [];
    const workspaceList = MachineLearningService.getAllWorkspaces() as {
      next: () => Promise<{ value: Workspace }>;
    };

    let { value: workspace } = await workspaceList.next();

    // for each workspace
    while (workspace) {
      // generate url from name
      const url = MachineLearningService.getWorkspaceUrlByName(workspace.name!);
      // add to list of all workspaces
      workspaces.push(workspace);
      // keep url for later use
      workspacesUrl.push(url);
      // if MLW's url is not in any project
      // and workspace is not being deleted or created
      // and it starts with "mlw-" because we have some other workspaces created for AI Studio
      if (
        !projectsMlwUrl.includes(url) &&
        workspace.provisioningState === "Succeeded" &&
        workspace.name!.startsWith("mlw-")
      ) {
        // add it to orphan list
        orphanMlW.push(workspace);
      }

      // get next value and restarts
      const { value } = await workspaceList.next();
      workspace = value;
    }

    const projectsWithMissingML: Project[] = [];
    const projectWithBadStateMlwUrl: string[] = [];
    // Find projects with a broken workspace url
    for (let index = 0; index < projectsMlwUrl.length; index++) {
      const projectMlwUrl = projectsMlwUrl[index];
      if (projectMlwUrl.indexOf("http") !== 0) {
        projectWithBadStateMlwUrl.push(projectMlwUrl);
        projectsWithBadUrls.push(projects[index]);
      } else if (!workspacesUrl.includes(projectMlwUrl)) {
        projectsWithMissingML.push(projects[index]);
      }
    }

    console.log(
      `${projectsMlwUrl.length} out of ${allProjects.length} (~${Math.round(
        (projectsMlwUrl.length / allProjects.length) * 100,
      )}%) projects have ML workspaces`,
    );

    console.log(
      `${orphanMlW.length} out of ${workspaces.length} (~${Math.round(
        (orphanMlW.length / workspaces.length) * 100,
      )}%) ML Workspaces don't have an associated project`,
    );

    console.log(
      `${projectsWithMissingML.length} out of ${projects.length} (~${Math.round(
        (projectsWithMissingML.length / projects.length) * 100,
      )}%) projects have broken workspace urls`,
    );

    console.log(
      `${projectWithBadStateMlwUrl.length} out of ${projects.length} (~${Math.round(
        (projectWithBadStateMlwUrl.length / projects.length) * 100,
      )}%) projects have ML workspaces locked in an intermediate stage`,
    );

    console.log(
      `Orphan workspaces:`,
      orphanMlW.map(({ name }) => name),
    );

    const projectsWithBrokenWs = [...projectsWithBadUrls, ...projectsWithMissingML];
    const pids = projectsWithBrokenWs.map(({ _id }) => _id);

    if (readOnly) {
      console.log(`Would update workspaces of`, pids);
    } else {
      await ProjectModel.updateMany(
        { _id: { $in: pids } },
        {
          $set: {
            workspaceUrl: null,
            workspaceType: null,
            permissionsChangedDate: null,
            workspaceExploratoryJustification: null,
            rolesAndEntitlements: [],
            aiUsage: null,
            aiModels: null,
            openAiConnection: null,
            ecbContact: null,
            aiUseCaseId: null,
            gdpr: null,
            aiAct: null,
            businessRisk: null,
          },
        },
      );
    }

    // delete ML workspaces
    const credentials = MachineLearningService.connect();
    await Promise.all(
      orphanMlW.map((ws) => {
        if (readOnly) {
          return console.log(`Would delete ML workspace for ${ws.tags!.project}`);
        }
        return MachineLearningService.deleteWorkspace(ctx, credentials, ws.tags!.project);
      }),
    );
  },

  async cleanUserActions(readOnly: boolean) {
    console.log("\n\n--- User actions ---");

    // get delete action of projects
    const actions = await UserActionModel.find({
      // createdAt: { $gt: createdAtMax },
      action: ActionType.DELETE_PROJECT,
    });

    // delete actions of projects which have been deleted over 92 days ago
    const oldActions = actions.filter(
      ({ createdAt }) => moment().diff(moment(createdAt), "days") > 92,
    );

    await withRetry(
      async () => {
        // get unique pids
        const pids = Array.from(oldActions.map(({ pid }) => pid));

        if (readOnly) {
          const actionsToDelete = await UserActionModel.find({ pid: { $in: pids } });
          console.log(`Would delete ${actionsToDelete.length} actions`);
        } else {
          console.log(`Deleting actions for projects`, pids);
          await wait(1);
          await UserActionModel.deleteMany({ pid: { $in: pids } }).lean();
        }
      },
      ctx,
      5,
    );
  },

  async cleanRejectedProjectCreationRequests(readOnly: boolean) {
    console.log("\n\n--- Rejected project creation requests ---");

    // get project creation requests which weren't approved
    const requests = await IgamRequestModel.find({
      requestType: RequestType.PROJECT_CREATION,
      requestStatus: {
        $in: [RequestStatus.CLOSED, RequestStatus.REJECTED, RequestStatus.EXPIRED],
      },
    });

    // delete requests and associated projects that weren't approved for 3 months
    const oldRequests = requests.filter(
      ({ updatedAt }) => moment().diff(moment(updatedAt), "days") > 92,
    );

    await withRetry(
      async () => {
        const pids = oldRequests.map(({ pid }) => pid); // ids of projects
        const requestIds = oldRequests.map(({ _id }) => _id); // ids of requests

        if (readOnly) {
          const requestsToDelete = await IgamRequestModel.find({ _id: { $in: requestIds } });
          const projectsToDelete = await ProjectModel.find({ _id: { $in: pids } });
          console.log(`Would delete ${requestsToDelete.length} actions`);
          console.log(
            `Would delete projects ${projectsToDelete.map(({ name }) => name).join(", ")}`,
          );
        } else {
          console.log(`Deleting project creation requests`, requestIds);
          await wait(1);
          await IgamRequestModel.deleteMany({ _id: { $in: requestIds } });

          console.log(`Deleting projects`, pids);
          await wait(1);
          await ProjectModel.deleteMany({ _id: { $in: pids } });
        }
      },
      ctx,
      5,
    );
  },

  async cleanOldProjects(readOnly: boolean, projects: Project[]) {
    console.log("\n\n--- Old projects ---");
    if (process.env.AZURE_TENANT === "ecbprod") {
      throw new Error(`This script should only run on DEV environment`);
    }

    const oldProjects = projects.filter(
      (project) =>
        moment().diff(moment(project.updatedAt), "days") > 61 &&
        !project.name.includes("Integration project") &&
        project.status === ProjectStatus.Active,
    );

    if (oldProjects.length === 0) {
      return console.log("There are no projects older than 2 months");
    }

    let errors: string[] = [];
    const chunks = chunkArray(oldProjects);
    for (let index = 0; index < chunks.length; index++) {
      const chunk = chunks[index];
      const results = await Promise.allSettled(
        chunk.map(async (project) => {
          if (readOnly) {
            return console.log(`Would delete project ${project.name}`);
          }
          await ProjectDeletionService.deleteProject(ctx, project);
        }),
      );

      errors = [
        ...errors,
        ...(results.filter(({ status }) => status === "rejected") as PromiseRejectedResult[]).map(
          ({ reason }) => reason,
        ),
      ];
    }

    if (errors.length > 0) {
      console.log(`-----Projects that failed at deletion-----`);
      console.log(errors.join("\n"));
    }
  },
};

export default CleanupService;
