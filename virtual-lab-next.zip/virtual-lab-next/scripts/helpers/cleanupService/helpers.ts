import { Context } from "@azure/functions";
import GraphService from "../../../src/services/graphService/graphService";
import { GraphGroup } from "../../../src/services/graphService/types";
import { ENV, GROUP_SEC_PREFIX, GROUP_TEAM_PREFIX } from "../../../src/utils/config";

// Sacred groups must never be deleted
const sacredGroups = [
  "e565a689-2af8-49e3-9748-3c9c09de90ad", // TEAM_VLB-VirtualLab
];

export const getIdOfAllVlGroups = async (ctx: Context) => {
  const [sec, team] = await Promise.all([
    GraphService.searchGroups(ctx, `${GROUP_SEC_PREFIX}`),
    GraphService.searchGroups(ctx, `${GROUP_TEAM_PREFIX}`),
  ]);

  return [...sec, ...team].reduce(
    (acc, group) => {
      // Exclude sacred groups from results
      if (
        !sacredGroups.includes(group.id) &&
        // staging groups are picked up on prod as they have the same preffix
        ((ENV === "prod" && !group.displayName.startsWith("TEAM_VLB-STG-")) || ENV !== "prod")
        // only include member and owner groups for now
        // && (group.displayName.toLocaleLowerCase().indexOf("-members") ===
        //   group.displayName.length + 1 - "-members".length ||
        //   group.displayName.toLocaleLowerCase().indexOf("-owners") ===
        //     group.displayName.length + 1 - "-owners".length)
      ) {
        acc[group.id] = group;
      }

      return acc;
    },
    {} as Record<string, GraphGroup>,
  );
};
