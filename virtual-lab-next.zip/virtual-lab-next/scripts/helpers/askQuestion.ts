import readline from "readline";

/**
 * Asks user for confirmation before continuing. A negative answer exits the process
 *
 * @param question
 * @param yesAnswers
 * @returns
 */
export const askConfirmation = (question: string, yesAnswers: string[] = ["yes", "y"]) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise<string>((resolve) => {
    rl.question(`${question} (${yesAnswers.join(" / ")})`, (ans: string) => {
      rl.close();
      if (!yesAnswers.includes(ans?.toLocaleLowerCase())) {
        // eslint-disable-next-line no-console
        console.log(`User answered '${ans}', stopping`);
        process.exit(0);
      }
      resolve(ans);
    });
  });
};

/**
 * Asks user for confirmation before continuing.
 * Either answer continues execution by returning true / false
 *
 * @param question
 * @param yesAnswers
 * @returns
 */
export const askUser = (question: string, yesAnswers: string[] = ["yes", "y"]) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise<boolean>((resolve) => {
    rl.question(`${question} (${yesAnswers.join(" / ")})`, (ans: string) => {
      rl.close();
      return resolve(yesAnswers.includes(ans?.toLocaleLowerCase()));
    });
  });
};
