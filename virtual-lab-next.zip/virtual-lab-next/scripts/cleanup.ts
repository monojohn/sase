import "dotenv/config";

import MongoConnector from "../src/services/dbConnector/mongoDb";
import { askConfirmation } from "./helpers/askQuestion";
import CleanupService from "./helpers/cleanupService/cleanupService";

export const args = process.argv.slice(2);

async function runCleanup(deleteMode: boolean) {
  if (deleteMode) {
    await askConfirmation("The script is running in delete mode, are you sure?", ["yes", "y"]);
  }

  return CleanupService.clean(!deleteMode);
}

runCleanup(args[0] === "--delete")
  .catch((e) => {
    console.log("Cleanup failed", e);
    process.exit(1);
  })
  .then(() => MongoConnector.disconnect());
