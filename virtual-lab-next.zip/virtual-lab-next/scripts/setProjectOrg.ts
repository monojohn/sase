import "dotenv/config.js";
import ProjectModel from "../src/services/dbConnector/models/projectModel.js";
import { Project } from "../src/services/dbConnector/models/project.js";
import EntitlementsService from "../src/services/igamService/entitlementsService.js";

const ctx = console as any;
const saveProjectOrg = async (project: Project) => {
  ctx.log(`Saving org for ${project.name}`);
  const org = await EntitlementsService.getProjectOrg(ctx, project.name);

  ctx.log(`Setting org ${org} for ${project.name}`);
  await ProjectModel.findOneAndUpdate(
    { _id: project._id },
    {
      $set: {
        org,
      },
    },
  );
};

const saveOrgs = async () => {
  const projects = await ProjectModel.find({
    org: null,
  });
  const errors: string[] = [];

  for (const project of projects) {
    try {
      await saveProjectOrg(project);
    } catch (e) {
      errors.push(`Failed for ${project.name}: ${e}`);
    }
  }

  ctx.log(errors);
};

saveOrgs();
