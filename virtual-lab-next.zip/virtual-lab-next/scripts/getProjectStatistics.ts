import "dotenv/config";

import { AccessibilityLevel } from "../src/services/dbConnector/enums";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import { GROUP_TEAM_PREFIX } from "../src/utils/config";
import MetricsService from "../src/services/metricsService/metricsService";

const ctx = console as any;

const getProjectStatistics = async () => {
  if (!GROUP_TEAM_PREFIX) {
    throw new Error(`GROUP_TEAM_PREFIX not set, received '${GROUP_TEAM_PREFIX}'`);
  }
  const groupsUsers = await MetricsService.getUsersByGroups(ctx, GROUP_TEAM_PREFIX, ["mail"], true);

  // get all users from the result
  let allUsers: string[] = [];
  for (const groupUsers of groupsUsers) {
    allUsers = allUsers.concat(
      groupUsers
        .map((user) => user.mail)
        .filter((mail) => mail && !mail.includes("@cloud.ecb.int")),
    );
  }

  // count occurrences in users membership
  const userOccurrences = allUsers.reduce(
    (acc, index) => ((acc[index] = ++acc[index] || 1), acc),
    {} as Record<string, number>,
  );
  const uniqueUsers: any[] = Object.entries(userOccurrences).map((user) => {
    return { mail: user[0], count: user[1] };
  });

  // filter by users with at least one project and sort the list
  console.log("\n\n\n");
  for (const user of uniqueUsers
    .filter((user) => user.count > 1)
    .sort((a, b) => {
      return b.count - a.count;
    })) {
    console.log(`${user.mail} is part of ${user.count} groups`);
  }

  console.log(
    `\n\nFound ${uniqueUsers.length} unique users with ${allUsers.length} membership count\n`,
  );
  console.log(`A user is part of ${allUsers.length / uniqueUsers.length} projects on average\n`);

  const projects = await ProjectModel.find({});

  const privateProjects = projects.filter(
    ({ accessibilityLevel }) => accessibilityLevel === AccessibilityLevel.Private,
  ).length;

  const protectedProjects = projects.filter(
    ({ accessibilityLevel }) => accessibilityLevel === AccessibilityLevel.Protected,
  ).length;

  console.log(`Number of projects: ${projects.length}`);
  console.log(`Number of private projects: ${privateProjects}`);
  console.log(`Number of protected projects: ${protectedProjects}`);
};

getProjectStatistics();
