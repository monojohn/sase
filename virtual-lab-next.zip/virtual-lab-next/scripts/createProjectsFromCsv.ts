import "dotenv/config";

import { Context } from "@azure/functions";
import fs from "node:fs";
import Readline from "readline";
import { createProject } from "../src/features/projectCreation/projectCreation";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
} from "../src/services/dbConnector/enums";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import ProjectDeletionService from "../src/services/projectService/projectDeletionService";
import { AZURE_TENANT } from "../src/utils/config";
import { getTeamGroupName, wait } from "../src/utils/helpers";
import { askConfirmation } from "./helpers/askQuestion";
import ProjectService from "../src/services/projectService/projectService";
import { ProjectCreationType } from "../src/services/projectService/enums";

const isProd = AZURE_TENANT !== "ecbdevenv";
const tagId = isProd
  ? "de95da13-0cb1-4377-ac8b-f59c79706044"
  : "08f65dea-9301-48e2-8b9b-a7ac13a7bc97";
const ctx = console as unknown as Context;
const [filePath] = process.argv.slice(2);

type CreateProjectEntry = {
  projectName: string;
  description: string;
  dataSensitivityLevel: DataSensitivityLevel;
  confidentialityLevel: ConfidentialityLevel;
  accessibilityLevel: AccessibilityLevel;
  tags: string[];
  ownerUpn: string;
  membersUpn: string[];
};

const projectData: CreateProjectEntry[] = [];

if (!filePath) {
  ctx.log(`Error: invalid file path: '${filePath}'. Make sure you send a second argument`);
  process.exit(1);
}

const readStream = Readline.createInterface({
  input: fs.createReadStream(filePath),
});

readStream.on("line", handleLine);
readStream.on("close", handleEnd);

function isValidLine(lineSplit: string[]) {
  if (lineSplit.length < 8) {
    console.log(`line has <8 splits`, lineSplit);

    return false;
  }

  for (let index = 1; index < 6; index++) {
    if (lineSplit[index].length === 0) {
      console.log(`${lineSplit[index]} has length 0`, index, lineSplit);

      return false;
    }
  }

  return true;
}

let count = 0;
let hasStarted = false;
const startLineQueue = 'Enter your projects here:"';

/**
 * This function CANNOT be async
 */
function handleLine(line: string) {
  count++;

  if (!hasStarted) {
    const index = line.indexOf(startLineQueue);
    if (index < 0) {
      console.log(`ignoring line ${count}`);
      return;
    }
    line = line.split(startLineQueue)[1];
    hasStarted = true;
  }

  const lineSplit = line.split(",");
  if (!isValidLine(lineSplit)) {
    console.log(`Ignoring line ${count}`);
    return;
  }

  const [
    _, // ignore useless line in the excel file
    projectName,
    description,
    dataSensitivityLevel,
    confidentiality,
    accessibility,
    strOwnerUpn,
    strMembersUpn,
    tags,
  ] = lineSplit;

  projectData.push({
    projectName: projectName.trim(),
    description: description.trim(),
    dataSensitivityLevel: dataSensitivityLevel.trim() as DataSensitivityLevel,
    confidentialityLevel: confidentiality.trim() as ConfidentialityLevel,
    accessibilityLevel: accessibility.trim() as AccessibilityLevel,
    tags: tags.split(";").map((tag) => tag.trim()),
    ownerUpn: strOwnerUpn,
    membersUpn: strMembersUpn
      .split(";")
      .map((upn) => upn.trim())
      .filter((upn) => upn),
  });
}

const batchSize = 4;

/**
 * When file reading ends, create 1 project at a time
 */
async function handleEnd() {
  await askConfirmation(
    `Will create ${projectData.length} project in ${isProd ? "PRODUCTION" : "Test"}, continue?`,
  );

  // create 1 projects at a time so IGAM doesn't fall over
  for (let index = 0; index < projectData.length; index += batchSize) {
    const promises: Promise<unknown>[] = [];

    console.log(`\n\nNext up: ${index + 1} / ${projectData.length}\n\n`);

    // wait so user can cancel between runs
    await wait(5);

    for (let t = 0; t < batchSize; t++) {
      // const data = projectData[index + t];
      promises.push(
        (async (data) => {
          const { projectName, ownerUpn, membersUpn } = data;

          const graphOwner = await GraphService.getUserProps(ctx, ownerUpn, [
            "id",
            "department",
            "displayName",
            "userType",
            "userPrincipalName",
          ]);
          const graphMembers = await GraphService.getUsersProps(ctx, membersUpn, ["id"]);
          const ownerOid = graphOwner.id;
          const memberOids = graphMembers.map(({ id }) => id);

          const existingTeamGroups = await GraphService.getGroupByName(
            ctx,
            getTeamGroupName(projectName),
          );
          if (existingTeamGroups && existingTeamGroups.length > 0) {
            console.log(
              `Project ${existingTeamGroups[0].displayName} (${projectName}) already exists in Projects list, skipping`,
            );
            return;
          }

          console.log(`Creating project ${index + 1} / ${projectData.length}: ${data.projectName}`);
          // add entry to DB
          const name = projectName.trim();

          const project = await ProjectModel.create({
            name,
            description: "description",
            dataSensitivityLevel: data.dataSensitivityLevel,
            confidentialityLevel: data.confidentialityLevel,
            accessibilityLevel: data.accessibilityLevel,
            tags: data.tags,
            members: memberOids,
            owners: [ownerOid],
          });

          // create project
          try {
            await createProject(
              ctx,
              {
                owner: ownerOid,
                project,
                addAllOwners: true,
                projectCreationType: ProjectCreationType.NO_APPROVAL,
              },
              graphOwner,
            );
          } catch (e) {
            ctx.log(`Error in project creation, cleaning up`, { e });
            await ProjectDeletionService.handleCreationFailure(ctx, {
              id: project._id,
              name: projectName,
            });
          }

          for (const member of graphMembers) {
            await ProjectService.addUser(ctx, project, member.id, false);
          }
        })(projectData[index + t]),
      );
    }

    await Promise.all(promises);
  }
}
