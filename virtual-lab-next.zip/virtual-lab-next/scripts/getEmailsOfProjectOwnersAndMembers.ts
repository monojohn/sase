import "dotenv/config";

import { GROUP_SEC_PREFIX } from "../src/utils/config";
import { getEmailOfUser } from "../src/utils/helpers";
import MetricsService from "../src/services/metricsService/metricsService";

const ctx = console as any;

const getEmailsOfProjectOwnersAndMembers = async () => {
  if (!GROUP_SEC_PREFIX) {
    throw new Error(`GROUP_SEC_PREFIX not set, received '${GROUP_SEC_PREFIX}'`);
  }
  const groupsUsers = await MetricsService.getUsersByGroups(ctx, GROUP_SEC_PREFIX, [
    "userType",
    "mail",
    "otherMails",
    "identities",
  ]);

  // remove duplicates
  const uniqueEmails: string[] = [];
  for (const groupUsers of groupsUsers) {
    for (const user of groupUsers) {
      // get alt email of user
      const email = getEmailOfUser(user);
      // if user is not in map
      if (
        // email is set
        email &&
        // not a guest account
        user.userType !== "Guest" &&
        // not a dup
        !uniqueEmails.includes(email) &&
        // and not a technical account
        !email.split("@")[1].includes("cloud.ecb.int")
      ) {
        // add them in
        uniqueEmails.push(email);
      }
    }
  }

  console.log(`\n\nFound ${uniqueEmails.length} unique members and owners\n`);
  console.log(uniqueEmails.join("; ") + ";");
};

getEmailsOfProjectOwnersAndMembers();
