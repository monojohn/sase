import "dotenv/config";

import { GROUP_TEAM_PREFIX } from "../src/utils/config";
import BudgetService from "./../src/services/budgetService/budgetService";

const ctx = console as any;

const cleanupDuplicateBudgets = async () => {
  const budgetService = new BudgetService(ctx);
  const budgets = await budgetService.getBudgets();
  const budgetsToCheck = budgets.filter(({ name }) => name?.startsWith(GROUP_TEAM_PREFIX));
  const budgetNames = budgetsToCheck.map(({ name }) => name);
  const duplicateBudgets = budgetNames.filter((item, index) => budgetNames.indexOf(item) !== index);
  for (const budget of budgetNames) {
    console.log(budget);
  }

  console.log("--------");
  for (const budget of duplicateBudgets) {
    console.log(budget);
    await budgetService.deleteBudget(ctx, budget);
  }
};

const updateBudgets = async () => {
  const budgetService = new BudgetService(ctx);
  const budgets = await budgetService.getBudgets();
  // get budgets which don't have the 4th alert at 150%
  const budgetsToUpdate = budgets.filter(
    ({ name, properties }) =>
      name?.startsWith(GROUP_TEAM_PREFIX) && Object.keys(properties.notifications).length < 4,
  );
  for (const budget of budgetsToUpdate) {
    await budgetService.updateBudget(
      budget.properties.filter.tags.values[0],
      budget.properties.timePeriod.startDate,
    );
  }
  console.log(budgetsToUpdate.length);
};

cleanupDuplicateBudgets();
updateBudgets();
