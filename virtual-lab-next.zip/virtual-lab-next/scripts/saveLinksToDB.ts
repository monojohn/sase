import "dotenv/config.js";
import GraphService from "../src/services/graphService/graphService.js";
import SharePointService from "../src/services/sharepointService/sharepointService.js";
import ProjectModel from "../src/services/dbConnector/models/projectModel.js";
import { Project } from "../src/services/dbConnector/models/project.js";

const ctx = console as any;
const savelinks = async (project: Project) => {
  ctx.log(`Saving links for ${project.name}`);
  const { name: siteName } = await GraphService.getSiteById(ctx, project.teamGroupId);

  const quickLaunch = SharePointService.getQuickLaunch(siteName);
  const quickLaunchItems = await quickLaunch();

  const plannerTab = quickLaunchItems.find(({ Title }) => Title === "Task Planner");
  const teamsTab = quickLaunchItems.find(({ Title }) => Title === "MS Teams");
  if (!plannerTab || !teamsTab) {
    throw new Error(`Missing at least one of the tabs for project ${project.name}`);
  }

  await ProjectModel.findOneAndUpdate(
    { _id: project._id },
    {
      $set: {
        plannerUrl: plannerTab.Url,
        teamsUrl: teamsTab.Url,
      },
    },
  );
};

const saveLinksToDB = async () => {
  const projects = await ProjectModel.find({
    $or: [{ plannerUrl: null }, { teamsUrl: null }],
  });
  const errors: string[] = [];

  for (const project of projects) {
    try {
      await savelinks(project);
    } catch (e) {
      errors.push(`Failed for ${project.name}: ${e}`);
    }
  }

  ctx.log(errors);
};

saveLinksToDB();
