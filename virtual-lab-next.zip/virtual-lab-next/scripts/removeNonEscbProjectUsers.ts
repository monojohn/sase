import "dotenv/config";
import DataGovernanceNotificationService from "../src/features/dataGovernance/dataGovernanceNotificationService";
import DataGovernanceService from "../src/features/dataGovernance/dataGovernanceService";
import GraphService from "../src/services/graphService/graphService";
import { removeUserFromProject } from "../src/services/projectService/projectModificationService/removeUser";
import { ENV } from "../src/utils/config";
import { askConfirmation, askUser } from "./helpers/askQuestion";
import { getEmailOfUser } from "../src/utils/helpers";

const ctx = console as any;

async function runCleanup() {
  await askConfirmation(`This script is possibly destructive and running in ${ENV}. continue?`);

  const projectsToNotify = await DataGovernanceService.getProjectsToNotify(ctx, new Date());
  console.log(`Found ${projectsToNotify.length} projects to cleanup`);

  for (let index = 0; index < projectsToNotify.length; index++) {
    const project = projectsToNotify[index];

    if (await askUser(`Remove members of project #${project._id} - ${project.name}?`)) {
      const members = await GraphService.getGroupUsers(ctx, project.membersGroupId, [
        "userPrincipalName",
        "mail",
        "userType",
        "otherMails",
        "displayName",
        "identities",
      ]);

      if (members.length === 0) {
        console.log(`Project #${project._id} ${project.name} has no members to remove, skipping`);
        continue;
      }

      const membersString = members
        .map((user) => `[${user.userType}]: ${user.userPrincipalName} (${user.displayName})`)
        .join("\n");

      const question = `Remove ${members.length} members of project #${project._id} - ${project.name}?\n ${membersString}`;

      if (await askUser(question)) {
        await Promise.all(
          members.map(async (user) => {
            await removeUserFromProject(ctx, project, user.userPrincipalName);
            await DataGovernanceNotificationService.sendMemberRemovalEmail(
              ctx,
              project,
              getEmailOfUser(user),
            );
          }),
        );
        console.log(`Removed members of project #${project._id}`);
      } else {
        console.log(`skipping project #${project._id}`);
      }
    }
  }
}

runCleanup().catch((e) => {
  console.log("Member removal failed", e);
  process.exit(1);
});
