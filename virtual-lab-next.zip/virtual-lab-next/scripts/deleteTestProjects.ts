import "dotenv/config";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import ProjectDeletionService from "../src/services/projectService/projectDeletionService";

const ctx = {
  executionContext: {
    functionName: "file-cron",
  },
  log: console.log,
} as any;

const deleteTestProjects = async () => {
  const projects = await ProjectModel.find({
    name: /^integration proj.*/i,
  });

  for (let index = 0; index < projects.length; index++) {
    const project = projects[index];
    ctx.log(`Deleting ${index + 1}/${projects.length} ${project.name}`);
    try {
      await ProjectDeletionService.handleCreationFailure(ctx, {
        id: project._id,
        name: project.name,
      });
      ctx.log(project.name);
    } catch (e) {
      ctx.log(`Error deleting ${project.name}`, e);
    }
  }
};

deleteTestProjects();
