import "dotenv/config";

import { GROUP_TEAM_PREFIX } from "../src/utils/config";
import MetricsService from "../src/services/metricsService/metricsService";

const ctx = console as any;

const getUserDetails = async () => {
  if (!GROUP_TEAM_PREFIX) {
    throw new Error(`GROUP_TEAM_PREFIX not set, received '${GROUP_TEAM_PREFIX}'`);
  }
  const groupsUsers = await MetricsService.getUsersByGroups(
    ctx,
    GROUP_TEAM_PREFIX,
    ["userType", "mailNickname", "givenName", "surname", "userPrincipalName", "mail"],
    true,
  );

  // get all users from the result
  let allUsers: any[] = [];
  for (const groupUsers of groupsUsers) {
    allUsers = allUsers
      .concat(groupUsers)
      .filter(
        ({ userType, mail }) => userType !== "Guest" && mail && !mail.includes("@cloud.ecb.int"),
      );
  }

  // get unique values
  const uniqueUsers = Array.from(new Set(allUsers.map((a) => a.mail))).map((mail) => {
    return allUsers.find((user) => user.mail === mail);
  });

  console.log(`\n\nFound ${uniqueUsers.length} unique users\n`);
  for (const user of uniqueUsers) {
    console.log(
      `${user.mailNickname},${user.givenName},${user.surname},${user.userPrincipalName},${user.mail}`,
    );
  }
};

getUserDetails();
