import GraphService from "../../src/services/graphService/graphService";

const ctx = console as any;

const fileHeader = `import { GraphUser } from "@/services/graphService";

export const mockUsers: GraphUser[] = `;

export const createUserMock = async () => {
  let users = await GraphService.searchUsers(ctx, "", true);

  const jsonString = `${fileHeader}${JSON.stringify(users, null, 2)}`;

  // replace with variables
  return jsonString
    .replaceAll('"accessibilityLevel": "Public"', '"accessibilityLevel": AccessibilityLevel.Public')
    .replaceAll(
      '"accessibilityLevel": "Private"',
      '"accessibilityLevel": AccessibilityLevel.Private',
    )
    .replaceAll(
      '"accessibilityLevel": "Protected"',
      '"accessibilityLevel": AccessibilityLevel.Protected',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-PUBLIC"',
      '"confidentialityLevel": ConfidentialityLevel.PUBLIC',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-UNRESTRICTED"',
      '"confidentialityLevel": ConfidentialityLevel.UNRESTRICTED',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-RESTRICTED"',
      '"confidentialityLevel": ConfidentialityLevel.RESTRICTED',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-CONFIDENTIAL"',
      '"confidentialityLevel": ConfidentialityLevel.CONFIDENTIAL',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-SECRET"',
      '"confidentialityLevel": ConfidentialityLevel.SECRET',
    );
};
