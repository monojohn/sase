import ProjectModel from "../../src/services/dbConnector/models/projectModel";

const fileHeader = `import { AccessibilityLevel, ConfidentialityLevel } from "@/types/enums";
import { ProjectStructure } from "@/types/types";

export const mockProjects: ProjectStructure[] = `;

export const createProjectsMock = async () => {
  let projects = await ProjectModel.find(
    // get all non-cypress projects
    { name: { $not: /cypress/ } },
    {},
    {
      lean: true,
      projection: {
        __v: 0, // omit field
      },
    },
  );

  const jsonString = `${fileHeader}${JSON.stringify(projects, null, 2)}`;

  // replace with variables
  return jsonString
    .replaceAll('"accessibilityLevel": "Public"', '"accessibilityLevel": AccessibilityLevel.Public')
    .replaceAll(
      '"accessibilityLevel": "Private"',
      '"accessibilityLevel": AccessibilityLevel.Private',
    )
    .replaceAll(
      '"accessibilityLevel": "Protected"',
      '"accessibilityLevel": AccessibilityLevel.Protected',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-PUBLIC"',
      '"confidentialityLevel": ConfidentialityLevel.PUBLIC',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-UNRESTRICTED"',
      '"confidentialityLevel": ConfidentialityLevel.UNRESTRICTED',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-RESTRICTED"',
      '"confidentialityLevel": ConfidentialityLevel.RESTRICTED',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-CONFIDENTIAL"',
      '"confidentialityLevel": ConfidentialityLevel.CONFIDENTIAL',
    )
    .replaceAll(
      '"confidentialityLevel": "ECB-SECRET"',
      '"confidentialityLevel": ConfidentialityLevel.SECRET',
    );
};
