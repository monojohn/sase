import "dotenv/config";

import fs from "node:fs";
import path, { dirname } from "path";
import { fileURLToPath } from "node:url";
import MongoConnector from "../../src/services/dbConnector/mongoDb";
import { createProjectsMock } from "./createProjectsMock";
import { createUserMock } from "./createUserMock";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const vlUiDir = "../../../virtual-lab-ui/src/mocks";
const vlUiPath = path.resolve(__dirname, vlUiDir);

const downloadDestination = fs.existsSync(vlUiPath) ? vlUiPath : path.resolve(__dirname, "./mocks");
const fileComment = `/**
 * This file is auto generated. any changes will be lost on the next update
 */\n\n`;

/**
 * Creates Mock files for the FE to use.
 *
 * Tries to create files in /virtual-lab-ui/mocks if the directory exists, otherwise they are created in ./mocks
 */
export const script = async () => {
  // create projects mock
  const projectsMockFile = path.resolve(downloadDestination, "./projects.ts");
  const projectsMock = await createProjectsMock();
  fs.writeFileSync(projectsMockFile, `${fileComment}${projectsMock}`);

  // create user mock
  const userMockFile = path.resolve(downloadDestination, "./users.ts");
  const userMock = await createUserMock();
  fs.writeFileSync(userMockFile, `${fileComment}${userMock}`);
};

script()
  .catch((e) => {
    console.log(e);
  })
  .then(() => {
    return MongoConnector.disconnect();
  });
