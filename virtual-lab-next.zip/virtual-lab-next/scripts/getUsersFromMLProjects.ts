import "dotenv/config";

import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import { GraphUser } from "../src/services/graphService/types";
import { chunkArray } from "../src/utils/chunkArray";
import { isTechnicalAccount } from "../src/utils/isTechnicalAccount";

const ctx = console as any;

type User = Pick<GraphUser, "id" | "mail" | "displayName" | "userType">;
type UserMap = Record<string, User>;

const getUserDetails = async () => {
  const errors: string[] = [];

  const allUsers: UserMap = {};
  const usersWithMLProjects: UserMap = {};

  const projects = await ProjectModel.find();
  const projectChunks = chunkArray(projects);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const team = await GraphService.getGroupMemberUsers(ctx, project.teamGroupId, [
          "id",
          "mail",
          "displayName",
          "userType",
        ]);
        // for each member
        for (const user of team.filter(({ displayName }) => !isTechnicalAccount(displayName))) {
          // if project has an ML workspace
          if (project.workspaceUrl) {
            // add them to map
            usersWithMLProjects[user.id] = user;
          }

          // add user to allUsers map
          allUsers[user.id] = user;
        }
      }),
    );
    for (const promiseResult of settled) {
      if (promiseResult.status === "rejected") {
        errors.push(promiseResult.reason);
      }
    }
  }
  console.log("-----ECB Users with ML projects---------");
  for (const id of Object.keys(usersWithMLProjects)) {
    console.log(`${usersWithMLProjects[id].mail} - ${usersWithMLProjects[id].displayName}`);
  }
  console.log("-----------ECB Users-------------");
  for (const id of Object.keys(allUsers)) {
    console.log(`${allUsers[id].mail} - ${allUsers[id].displayName}`);
  }
  console.log(errors);
};

getUserDetails();
