import "dotenv/config";
import fs from "node:fs";
import path from "path";
import { fileURLToPath } from "node:url";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import { chunkArray } from "../src/utils/chunkArray";
import GraphService from "../src/services/graphService/graphService";

const ctx = console as any;

const dirname = path.dirname(fileURLToPath(import.meta.url));

// Utility function to convert data to CSV and write it to a file
const writeDataToCsv = <T extends Record<string, string>>(data: T[], fileName: string) => {
  if (data.length === 0) {
    console.log("No data to write.");
    return;
  }

  // Get the keys from the first object to create the CSV headers
  const headers = Object.keys(data[0]);

  const headersForOutput = headers.join(",");
  const dataForOutput = data
    .map((row) => headers.map((header) => row[header]).join(","))
    .join("\n");

  // Define the path where the CSV will be saved
  const filePath = path.resolve(dirname, fileName);

  // Write the CSV content to a file
  fs.writeFileSync(filePath, `${headersForOutput}\n${dataForOutput}`, { encoding: "utf8" });

  console.log(`CSV file has been written to ${filePath}`);
};

const getOpenAIUseCasesUserNames = async () => {
  const data: {
    projectName: string;
    owners: string;
    members: string;
    openAiUseCaseId: string;
  }[] = [];

  const projects = await ProjectModel.find();
  const projectsWithOpenAiUseCase = projects.filter((project) => project.aiUseCaseId);
  console.log(
    `Counting: ${projects.length} projects out of which: ${projectsWithOpenAiUseCase.length} have an Open AI use case`,
  );

  const projectChunks = chunkArray(projectsWithOpenAiUseCase);

  for (const projectChunk of projectChunks) {
    await Promise.all(
      projectChunk.map(async (project) => {
        const [members, owners] = await Promise.all([
          // Can not use "displayName", because it contains ',' and thus breaks '.csv' format
          GraphService.getGroupUsers(ctx, project.membersGroupId, ["givenName", "surname"]),
          GraphService.getGroupUsers(ctx, project.ownersGroupId, ["givenName", "surname"]),
        ]);

        const memberNames = members.map((member) => `${member.givenName} ${member.surname}`);
        const ownerNames = owners.map((owner) => `${owner.givenName} ${owner.surname}`);

        data.push({
          projectName: project.name,
          openAiUseCaseId: project.aiUseCaseId ?? "",
          owners: ownerNames.join(" and "),
          members: memberNames.join(" and "),
        });
      }),
    );
  }

  // Resolve the path dynamically based on the current file's location
  const filePath = path.resolve(dirname, "..", "projects.csv");

  writeDataToCsv(data, filePath);
};

getOpenAIUseCasesUserNames();
