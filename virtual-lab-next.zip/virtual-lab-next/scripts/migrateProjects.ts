import "dotenv/config.js";
import GraphService from "../src/services/graphService/graphService.js";
import { FILES_PAGE_URL, ML_PROJECT_SPACE_PAGE_URL } from "../src/utils/config.js";
import ProjectModel from "../src/services/dbConnector/models/projectModel.js";
import { Project } from "../src/services/dbConnector/models/project.js";
import SpClient from "../src/utils/sharepointClient.js";
import { withRetry } from "../src/utils/helpers.js";

const ctx = console as any;
const errors: string[] = [];
const migrateProject = async (project: Project) => {
  ctx.log(`Checking ${project.name}`);
  const { name: siteName } = await GraphService.getSiteById(ctx, project.teamGroupId);

  const client = SpClient.getClient(siteName);

  const webInfo = await client.web.select("QuickLaunchEnabled")();
  if (!webInfo.QuickLaunchEnabled) {
    console.log(`Already migrated project ${project.name}, skipping`);
    return;
  }

  const promises = [
    withRetry(
      () =>
        client.web
          .getFileByServerRelativePath(`/sites/${siteName}/${ML_PROJECT_SPACE_PAGE_URL}`)
          .delete(),
      ctx,
      5,
    ),
    withRetry(
      () => client.web.getFileByServerRelativePath(`/sites/${siteName}/${FILES_PAGE_URL}`).delete(),
      ctx,
      5,
    ),
    withRetry(
      () =>
        client.web.getFileByServerRelativePath(`/sites/${siteName}/SitePages/Home.aspx`).delete(),
      ctx,
      5,
    ),
  ];

  const result = await Promise.allSettled(promises);
  for (const promiseResult of result) {
    if (promiseResult.status === "rejected") {
      errors.push(`Failed to cleanup "${project.name}": ${promiseResult.reason}`);
    }
  }

  // disable navigation
  await client.web.update({
    QuickLaunchEnabled: false,
  });
  const list = await client.web.lists
    .getByTitle("Documents")
    .select("RootFolder/ServerRelativeUrl")
    .expand("RootFolder")();

  // set files as home page
  await client.web.rootFolder.update({
    WelcomePage: list.RootFolder.ServerRelativeUrl.split("/").slice(-1)[0],
  });
};

const migrateProjects = async () => {
  const projects = await ProjectModel.find();

  for (const project of projects) {
    try {
      await migrateProject(project);
      ctx.log("\n");
    } catch (e) {
      errors.push(`Failed for ${project.name}: ${e}`);
    }
  }

  ctx.log(errors);
};

migrateProjects();
