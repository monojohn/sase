import "dotenv/config.js";
import GraphService from "../src/services/graphService/graphService.js";
import SharePointService from "../src/services/sharepointService/sharepointService.js";
import { AZURE_TENANT_ID } from "../src/utils/config.js";
import { withRetry } from "../src/utils/helpers.js";
import ProjectModel from "../src/services/dbConnector/models/projectModel.js";
import { Project } from "../src/services/dbConnector/models/project.js";

const ctx = console as any;
const updatePlannerTab = async (project: Project) => {
  ctx.log(`Checking ${project.name}`);
  const { name: siteName } = await GraphService.getSiteById(ctx, project.teamGroupId);

  const quickLaunch = SharePointService.getQuickLaunch(siteName);
  const quickLaunchItems = await quickLaunch();

  const plannerTab = quickLaunchItems.find(({ Title }) => Title === "Task Planner");
  if (!plannerTab) {
    ctx.log(`No planner tab for project ${project.name}`);
    return;
  }

  if (plannerTab.Url.includes("planner.cloud.microsoft/webui/plan")) {
    ctx.log(`Planner for ${project.name} has already been updated, skipping`);
    return;
  }

  const planId = plannerTab.Url.split("planId=")[1];
  const plannerUrl = `https://planner.cloud.microsoft/webui/plan/${planId}/view/board?tid=${AZURE_TENANT_ID}`;
  ctx.log(`Updating planner url to ${plannerUrl}`);

  await withRetry(() => quickLaunch.getById(plannerTab.Id).update({ Url: plannerUrl }), ctx, 5);
};

const updateAllPlannerLinks = async () => {
  const projects = await ProjectModel.find();
  const errors: string[] = [];

  for (const project of projects) {
    try {
      await updatePlannerTab(project);
      ctx.log("\n");
    } catch (e) {
      errors.push(`Failed for ${project.name}: ${e}`);
    }
  }

  ctx.log(errors);
};

updateAllPlannerLinks();
