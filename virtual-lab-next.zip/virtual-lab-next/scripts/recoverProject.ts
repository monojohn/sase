import "dotenv/config";

import { Context } from "@azure/functions";
import { createContent } from "../src/features/projectCreation/helpers";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
} from "../src/services/dbConnector/enums";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import RepositoryService from "../src/services/repositoryService/repositoryService";
import GraphService from "../src/services/graphService/graphService";
import EntitlementsService from "../src/services/igamService/entitlementsService";
import MachineLearningService from "../src/services/machineLearningService/machineLearningService";
import SharePointService from "../src/services/sharepointService/sharepointService";
import { getMembersGroupName, getOwnersGroupName, getTeamGroupName } from "../src/utils/helpers";
import { askConfirmation } from "./helpers/askQuestion";
import { Project } from "../src/services/dbConnector/models/project";
import { VL_ORG } from "../src/utils/config";

export const args = process.argv.slice(2);

type ProjectGroups = {
  teamGroupId: string;
  teamGroupName: string;
  ownersGroupId: string;
  membersGroupId: string;
  ownersGroupName: string;
  membersGroupName: string;
};

const silentCtx = { log: () => {} } as unknown as Context;
const ctx = console as unknown as Context;

async function recoverProject(projectName: string, groupOwners: string, groupMembers: string) {
  const [teamGroupName, ownersGroupName, membersGroupName] = [
    getTeamGroupName(projectName),
    getOwnersGroupName(projectName),
    getMembersGroupName(projectName),
  ];

  const [teamGroupId, ownersGroupId, membersGroupId] = await Promise.all([
    GraphService.getGroupIdByName(silentCtx, teamGroupName),
    GraphService.getGroupIdByName(silentCtx, ownersGroupName),
    GraphService.getGroupIdByName(silentCtx, membersGroupName),
  ]);

  const groupData = {
    teamGroupId,
    teamGroupName,
    ownersGroupName,
    membersGroupName,
    ownersGroupId,
    membersGroupId,
  };

  const project = await createProjectEntry(groupData);
  await createGroups(groupData, groupOwners, groupMembers, project);

  await askConfirmation(`Proceed with project content recovery?`);
  return createContent(ctx, {
    ...groupData,
    itemId: 0,
    title: projectName,
    type: project.accessibilityLevel || "Public",
  });
}

async function createGroups(
  props: ProjectGroups,
  groupOwners: string,
  groupMembers: string,
  project: Project,
) {
  const { ownersGroupName, membersGroupName, teamGroupId, ownersGroupId, membersGroupId } = props;

  if (!teamGroupId || !ownersGroupId || !membersGroupId) {
    if (!teamGroupId) {
      console.log(`Team group is missing, recreate it before continuing`);
      process.exit(1);
    }

    console.log(`Some groups don't exist, creating them.`, {
      teamGroupId: teamGroupId,
      ownersGroupId: ownersGroupId,
      membersGroupId: membersGroupId,
    });

    const ownersNames = groupOwners.split(" ");
    const owners = await GraphService.getUsersProps(ctx, ownersNames, ["department", "userType"]);
    const ecbOwners = owners.filter(({ userType }) => userType === "Member");
    let department: string;
    if (ecbOwners.length) {
      department = ecbOwners[0].department;
    } else {
      department = VL_ORG;
    }

    const promises: Promise<unknown>[] = [];
    if (!membersGroupId) {
      console.log(`Creating group ${membersGroupName} with members:\n${groupMembers}`);

      await askConfirmation(`Proceed with member group creation?`);

      promises.push(
        EntitlementsService.create(ctx, {
          owner: department,
          displayName: membersGroupName,
          description: " - ",
          members: groupMembers.split(" ").map((accountName) => ({
            action: "add",
            accountName,
          })),
          entType: "AAD-Group",
          classification: project.confidentialityLevel,
        }),
      );
    }
    if (!ownersGroupId) {
      if (!groupOwners) {
        throw new Error(
          `when the owners group does not exist, a list of owners must be passed as the 2nd parameter`,
        );
      }

      console.log(`Creating group ${ownersGroupName} with members:\n${groupOwners}`);

      await askConfirmation(`Proceed with owner group creation?`);

      promises.push(
        EntitlementsService.create(ctx, {
          owner: department,
          displayName: ownersGroupName,
          description: " - ",
          members: groupOwners.split(" ").map((accountName) => ({
            action: "add",
            accountName,
          })),
          entType: "AAD-Group",
          classification: project.confidentialityLevel,
        }),
      );
    }

    await Promise.all([promises]);

    // created groups
    console.log(`Groups created, wait a bit and run this script again.`);

    process.exit(0);
  }
}

async function createProjectEntry(props: ProjectGroups) {
  const { teamGroupId, teamGroupName, ownersGroupId, membersGroupId } = props;

  const existingProject = await ProjectModel.findOne({ name: projectName });

  if (existingProject) {
    console.log(`A project with this name already exists, skipping creation`);
    return existingProject;
  }

  const [isPublic, spSite, graphOwners, graphMembers, mlWorkspace, repositoryGroup] =
    await Promise.all([
      SharePointService.isProjectPublic(teamGroupName),
      GraphService.getSiteById(ctx, teamGroupId),
      GraphService.getGroupUsers(ctx, ownersGroupId, ["id"]),
      GraphService.getGroupUsers(ctx, membersGroupId, ["id"]),
      MachineLearningService.getWorkspaceByProjectName(projectName),
      RepositoryService.getRepositoryGroup(ctx, projectName),
    ]);

  const members = graphMembers.map(({ id }) => id);
  const owners = graphOwners.map(({ id }) => id);

  const name = projectName.trim();
  const projectData = {
    name,
    description: "",
    dataSensitivityLevel: isPublic ? DataSensitivityLevel.No : DataSensitivityLevel.CSI,
    confidentialityLevel: isPublic ? ConfidentialityLevel.PUBLIC : ConfidentialityLevel.RESTRICTED,
    accessibilityLevel: isPublic ? AccessibilityLevel.Public : AccessibilityLevel.Private,
    tags: [],
    members,
    owners,
    siteId: spSite.id,
    url: spSite.webUrl,
    workspaceUrl: mlWorkspace?.name
      ? MachineLearningService.getWorkspaceUrlByName(mlWorkspace.name)
      : undefined,
    repositoryUrl: repositoryGroup?.web_url || undefined,
  };

  console.log(projectData);
  await askConfirmation(`Proceed?`);

  return ProjectModel.create(projectData);
}

if (args.length > 3) {
  console.log(`Too many arguments passed, did you forget to use "?`);
  process.exit(1);
}

const [projectName, owners, members] = args;
recoverProject(projectName, owners, members);
