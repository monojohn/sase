import "dotenv/config";

import GraphService from "../src/services/graphService/graphService";
import { VL_GUESTS_GROUP_ID } from "../src/utils/config";
import { isTechnicalAccount } from "../src/utils/isTechnicalAccount";

const ctx = console as any;

// users from our team have to be excluded
const vlTeamMembers: string[] = [
  "Vidmante.Vaitone.external@ecb.europa.eu",
  "Rosanne.Baars.external@ecb.europa.eu",
  "Afonso.Martins_Vaz@ecb.europa.eu",
  "nicolas.schroeders@ecb.europa.eu",
  "Hendrik.Brakemeier@ecb.europa.eu",
  "Maria.Frantzi@ecb.europa.eu",
  "Alexandre.Januario@ecb.europa.eu",
  "Adrien.Dutfoy@ecb.europa.eu",
  "Christophe.Muller@ecb.europa.eu",
  "Roberta.Popescu.external@ecb.europa.eu",
  "Sophia_Luisa_Luca.Janzen.external@ecb.europa.eu",
];

const ecbAddress = "@ecb.europa.eu";

const getUserDetails = async () => {
  if (!VL_GUESTS_GROUP_ID) {
    throw new Error(`VL_GUESTS_GROUP_ID not set, received '${VL_GUESTS_GROUP_ID}'`);
  }

  // get all guest users
  const guestUsers = await GraphService.getGroupUsers(ctx, VL_GUESTS_GROUP_ID, [
    "otherMails",
    "displayName",
  ]);

  // get guest users who have an ECB email address and exclude our team
  const ecbUsersWithIamAccount = guestUsers.filter(
    ({ otherMails, displayName }) =>
      !isTechnicalAccount(displayName) &&
      otherMails.find((mail) => mail.includes(ecbAddress) && !vlTeamMembers.includes(mail)),
  );

  for (const { otherMails } of ecbUsersWithIamAccount) {
    // log their ECB email address
    console.log(otherMails.find((mail) => mail.includes(ecbAddress)));
  }
};

getUserDetails();
