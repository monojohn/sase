import "dotenv/config.js";
import ProjectModel from "../src/services/dbConnector/models/projectModel";

const ctx = console as any;

const migrateUseCases = async () => {
  const projects = await ProjectModel.find().populate("openAiUseCase").lean();
  const projectsWithOpenAiUseCase = projects.filter(
    (project) => project.openAiUseCase && !project.aiUseCaseId,
  );

  for (const project of projectsWithOpenAiUseCase) {
    if (!project.openAiUseCase?.useCaseId) {
      ctx.log(`Missing use case id for project ${project.name}`);
      continue;
    }
    ctx.log(`Setting aiUseCaseId for ${project.name} as ${project.openAiUseCase.useCaseId}`);
    await ProjectModel.updateOne(
      { _id: project._id },
      { $set: { aiUseCaseId: project.openAiUseCase.useCaseId, aiUsage: true } },
    );
  }
};

migrateUseCases();
