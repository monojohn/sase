import "dotenv/config";

import { KeyVaultManagementClient } from "@azure/arm-keyvault";
import { StorageManagementClient } from "@azure/arm-storage";
import MachineLearningService from "../src/services/machineLearningService/machineLearningService";
import { AZURE_RESOURCE_GROUP, SUBSCRIPTION_ID } from "../src/utils/config";
import { enableStorageAccountLogging } from "../src/services/machineLearningService/helpers";

async function updateKeyVaults() {
  const credentials = MachineLearningService.connect();
  const client = new KeyVaultManagementClient(credentials, SUBSCRIPTION_ID);

  const keyVaults = await MachineLearningService.getAllResources(client.vaults.list());

  const settled = await Promise.allSettled(
    keyVaults.map(async (keyVault) => {
      console.log(`Checking key vault settings for project ${keyVault.tags!.project}`);
      // getting the keyvault is necessary as the list does not give us "properties"
      const keyVaultWithProperties = await client.vaults.get(AZURE_RESOURCE_GROUP, keyVault.name!);
      if (
        !keyVaultWithProperties.properties.enablePurgeProtection ||
        !keyVaultWithProperties.properties.enableSoftDelete
      ) {
        console.log(`Updating key vault for project ${keyVault.tags!.project}`);
        return client.vaults.update(AZURE_RESOURCE_GROUP, keyVault.name!, {
          properties: {
            enablePurgeProtection: true,
            enableSoftDelete: true,
          },
        });
      }
    }),
  );
  // preserve errors
  return (settled.filter(({ status }) => status === "rejected") as PromiseRejectedResult[]).map(
    ({ reason }) => reason,
  );
}

async function updateStorageAccounts() {
  const credentials = MachineLearningService.connect();
  const client = new StorageManagementClient(credentials, SUBSCRIPTION_ID);
  const storageAccounts = await MachineLearningService.getAllResources(
    client.storageAccounts.list(),
  );

  const settled = await Promise.allSettled(
    storageAccounts.map(async (storageAccount) => {
      console.log(`Checking storage account for project ${storageAccount.tags?.project}`);

      if (!storageAccount.tags?.Backup) {
        console.log(`Setting backup tag disabled for storage account ${storageAccount.name}`);
        await client.storageAccounts.update(AZURE_RESOURCE_GROUP, storageAccount.name!, {
          tags: { ...storageAccount.tags, Backup: "disabled" },
        });
      }

      if (storageAccount.allowBlobPublicAccess === true) {
        console.log(`Disabling blob public access for storage account ${storageAccount.name}`);
        await client.storageAccounts.update(AZURE_RESOURCE_GROUP, storageAccount.name!, {
          allowBlobPublicAccess: false,
        });
      }

      if (storageAccount.minimumTlsVersion !== "TLS1_2") {
        console.log(`Updating storage account TLS for project ${storageAccount.tags!.project}`);
        await client.storageAccounts.update(AZURE_RESOURCE_GROUP, storageAccount.name!, {
          minimumTlsVersion: "TLS1_2",
        });
      }

      const blob = await client.blobServices.getServiceProperties(
        AZURE_RESOURCE_GROUP,
        storageAccount.name!,
      );
      if (!blob.deleteRetentionPolicy?.enabled) {
        console.log(`Enabling soft delete for storage account ${storageAccount.name}`);
        await client.blobServices.setServiceProperties(AZURE_RESOURCE_GROUP, storageAccount.name!, {
          deleteRetentionPolicy: {
            enabled: true,
            days: 7,
          },
        });
      }
    }),
  );
  // preserve errors
  return (settled.filter(({ status }) => status === "rejected") as PromiseRejectedResult[]).map(
    ({ reason }) => reason,
  );
}

async function setStorageAccountLogging() {
  const credentials = MachineLearningService.connect();
  const client = new StorageManagementClient(credentials, SUBSCRIPTION_ID);
  const storageAccounts = await MachineLearningService.getAllResources(
    client.storageAccounts.list(),
  );

  const settled = await Promise.allSettled(
    storageAccounts.map(async (storageAccount) => {
      console.log(`Enabling logging for storage account ${storageAccount.name}`);
      await enableStorageAccountLogging(storageAccount.name!);
    }),
  );
  // preserve errors
  return (settled.filter(({ status }) => status === "rejected") as PromiseRejectedResult[]).map(
    ({ reason }) => reason,
  );
}

async function updateMLResources() {
  // update key vault recoverability
  const keyVaultErrors = await updateKeyVaults();

  // update storage accounts
  const storageAccountsErrors = await updateStorageAccounts();

  // enable logging for storage accounts
  const loggingErrors = await setStorageAccountLogging();

  console.log(keyVaultErrors);
  console.log(storageAccountsErrors);
  console.log(loggingErrors);
}

updateMLResources();
