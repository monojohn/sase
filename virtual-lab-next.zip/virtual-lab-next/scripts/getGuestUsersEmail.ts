import "dotenv/config";

import GraphService from "../src/services/graphService/graphService";
import { getEmailOfUser } from "../src/utils/helpers";

const ctx = console as any;
const getEmailsOfGuestUsers = async () => {
  const [vlGroup] = await GraphService.searchGroups(console as any, "TEAM_VLB-VirtualLab");

  // filtering on userType is not supported at the moment
  const users = await GraphService.getGroupUsers(ctx, vlGroup.id, [
    "userType",
    "mail",
    "otherMails",
    "identities",
  ]);

  const guestUsersEmail = users
    .filter(({ userType }) => userType === "Guest")
    .map((user) => {
      return getEmailOfUser(user);
    });

  console.log(`\n\nFound ${guestUsersEmail.length} user emails:\n`);

  console.log(guestUsersEmail.join("; ") + ";");
};

getEmailsOfGuestUsers();
