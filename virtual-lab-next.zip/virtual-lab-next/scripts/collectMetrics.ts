import "dotenv/config";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import { UserType } from "../src/services/graphService/types";
import MetricsService from "../src/services/metricsService/metricsService";

const labels: Record<UserType, string> = {
  Guest: "NCA Users",
  Member: "ECB Users",
};

const isUrl = (str?: string | null) => str?.startsWith("http");
const ctx = console as any;

const collectMetrics = async () => {
  const [users, projects] = await Promise.all([
    MetricsService.getAllVlUsers(ctx),
    ProjectModel.find(),
  ]);

  const guests = MetricsService.filterUsersByType(users, "Guest");
  const uniqueDomains = MetricsService.getUniqueDomains(guests);

  const [projectsWithMlWorkspaces, projectsWithRepos, projectsWithBoth, projectsWithEither] = [
    projects.filter(({ workspaceUrl }) => isUrl(workspaceUrl)),
    projects.filter(({ repositoryUrl }) => isUrl(repositoryUrl)),
    projects.filter(
      ({ repositoryUrl, workspaceUrl }) => isUrl(repositoryUrl) && isUrl(workspaceUrl),
    ),
    projects.filter(
      ({ repositoryUrl, workspaceUrl }) => isUrl(repositoryUrl) || isUrl(workspaceUrl),
    ),
  ];

  console.log(
    `\nThere's a total of ${projects.length} projects and ${users.length} users in Virtual Lab\n`,
  );

  for (const type of MetricsService.getUserTypes(users)) {
    console.log(
      `${MetricsService.filterUsersByType(users, type).length} are ${type}s (${labels[type]})`,
    );
  }

  console.log(`\nGuest users come from ${uniqueDomains.length} unique domains: `, uniqueDomains);

  console.log(
    `\n${projectsWithEither.length} / ${projects.length} (~${Math.ceil(
      (projectsWithEither.length / projects.length) * 100,
    )}%) projects have either a ML Workspace or a repo`,
  );

  console.log(
    `${projectsWithMlWorkspaces.length} / ${projects.length} (~${Math.ceil(
      (projectsWithMlWorkspaces.length / projects.length) * 100,
    )}%) projects have ML Workspaces`,
  );

  console.log(
    `${projectsWithRepos.length} / ${projects.length} (~${Math.ceil(
      (projectsWithRepos.length / projects.length) * 100,
    )}%) projects have DevOp Repos`,
  );

  console.log(
    `${projectsWithBoth.length} / ${projects.length} (~${Math.ceil(
      (projectsWithBoth.length / projects.length) * 100,
    )}%) projects have both an ML Workspace and a repo`,
  );
};

collectMetrics();
