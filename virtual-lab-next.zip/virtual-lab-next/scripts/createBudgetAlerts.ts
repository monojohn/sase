import "dotenv/config";

import axios, { AxiosError } from "axios";
import moment from "moment";
import BudgetService from "../src/services/budgetService/budgetService";
import ArmService from "../src/utils/armService";
import { ML_BUDGET_EMAIL, SUBSCRIPTION_ID } from "../src/utils/config";

const ctx = console as any;
const budgetService = new BudgetService(ctx);

const configs = {
  sandbox: {
    name: "vl-sb-alert",
    filter: undefined,
    budget: 1000,
    accName: "",
  },
  devenv: {
    name: "vl-devenv-alert",
    filter: undefined,
    budget: 4900,
    accName: "ECBDEVENV-VLB-ASG-SEC-VirtualLab-Admin",
  },
  prod: {
    name: "vl-prod-alert",
    filter: undefined,
    budget: 53400,
    accName: "ECBPROD-VLB-ASG-SEC-VirtualLab-Admin",
  },
  prod_infra: {
    name: "vl-prod-infra-alert",
    filter: {
      tags: {
        name: "project",
        operator: "In",
        values: ["", null],
      },
    },
    budget: 3100,
    accName: "ECBPROD-VLB-ASG-SEC-VirtualLab-Admin",
  },
};

const deleteBudget = async (name: string) => {
  await budgetService.deleteBudget(ctx, name);
};

const script = async () => {
  const { name, filter, budget } = configs.prod_infra;
  // return await deleteBudget(name)

  const { token } = await ArmService.get(ctx);
  ctx.log("Creating ML Budget");
  const url = `https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/providers/Microsoft.Consumption/budgets/${name}?api-version=2021-10-01`;
  const { data } = await axios.put(url, getRequestBody(budget, name, filter), {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  console.log(data);
};

script().catch((e) => {
  const err = e as AxiosError<{ error: {} }>;
  console.log("top level error:", err.response?.data);
});

const startOfMonth = moment.utc().startOf("month").toDate().toUTCString();
const getRequestBody = (amount: number, name: string, filter: any) => {
  return {
    name,
    eTag: null,
    properties: {
      category: "Cost",
      amount,
      timeGrain: "Monthly",
      timePeriod: {
        startDate: startOfMonth,
        endDate: "Sat, 31 Dec 2050 00:00:00 GMT",
      },
      notifications: {
        Actual_GreaterThan_70_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 70,
          contactEmails: [ML_BUDGET_EMAIL],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
        Actual_GreaterThan_90_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 90,
          contactEmails: [ML_BUDGET_EMAIL],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
        Actual_GreaterThan_100_Percent: {
          enabled: true,
          operator: "GreaterThan",
          threshold: 100,
          contactEmails: [ML_BUDGET_EMAIL],
          contactRoles: [],
          contactGroups: [],
          thresholdType: "Actual",
          locale: null,
        },
      },
      filter,
    },
  };
};
