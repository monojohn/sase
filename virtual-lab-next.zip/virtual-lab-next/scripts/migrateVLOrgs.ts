import "dotenv/config.js";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import EntitlementsService from "../src/services/igamService/entitlementsService";

const ctx = console as any;

const migrateOrgs = async () => {
  const projects = await ProjectModel.find();

  for (const project of projects.filter(({ org }) => org === "ORG-VIRTUALLAB-TEAM(CI587574)")) {
    console.log(project);
    await EntitlementsService.updateOrg(
      ctx,
      [project.teamGroupName, project.ownersGroupName, project.membersGroupName],
      "Virtual Lab Custom 1(CI587574)",
      false,
    );
  }

  for (const project of projects.filter(({ org }) => org === "ORG-VIRTUALLAB-TEAM2(CI587574)")) {
    console.log(project);
    await EntitlementsService.updateOrg(
      ctx,
      [project.teamGroupName, project.ownersGroupName, project.membersGroupName],
      "Virtual Lab Custom 2(CI587574)",
      false,
    );
  }

  for (const project of projects.filter(({ org }) => org === "ORG-VIRTUALLAB-TEAM3(CI587574)")) {
    console.log(project);
    await EntitlementsService.updateOrg(
      ctx,
      [project.teamGroupName, project.ownersGroupName, project.membersGroupName],
      "Virtual Lab Custom 3(CI587574)",
      false,
    );
  }

  console.log("Migrated all projects");
};

migrateOrgs();
