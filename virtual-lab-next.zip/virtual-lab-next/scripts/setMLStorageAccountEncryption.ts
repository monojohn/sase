import "dotenv/config";

import { filterValidWorkspaces } from "../src/features/machineLearningTagging/helpers";
import MachineLearningService from "../src/services/machineLearningService/machineLearningService";
import {
  AZURE_RESOURCE_GROUP,
  AZURE_TENANT_ID,
  STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID,
  STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME,
  SUBSCRIPTION_ID,
} from "../src/utils/config";

import { KeyVaultManagementClient } from "@azure/arm-keyvault";
import { Workspace } from "@azure/arm-machinelearning";
import { StorageManagementClient } from "@azure/arm-storage";
import { ClientCertificateCredential } from "@azure/identity";
import { chunkArray } from "../src/utils/chunkArray";

const ctx = console as any;

async function setEncription(
  workspace: Workspace,
  credentials: ClientCertificateCredential,
  storageClient: StorageManagementClient,
  keyVaultClient: KeyVaultManagementClient,
) {
  if (!workspace.storageAccount || !workspace.keyVault) {
    throw new Error(`No storage account or key vault for ${workspace.tags?.project}`);
  }

  const storageAccountSplit = workspace.storageAccount.split("/");
  const storageAccountName = storageAccountSplit.at(-1)!;
  const storageAccount = await storageClient.storageAccounts.getProperties(
    AZURE_RESOURCE_GROUP,
    storageAccountName,
  );

  if (storageAccount.encryption?.keySource === "Microsoft.Keyvault") {
    return;
  }

  // update encryption if it's not already CMK
  console.log(`Updating encryption for project ${workspace.tags?.project}`);

  const split = workspace.keyVault.split("/");
  const keyVaultName = split.at(-1)!;
  const keyVaultKeyName = `kvk-${keyVaultName.slice(3)}`;

  const vault = await keyVaultClient.vaults.get(AZURE_RESOURCE_GROUP, keyVaultName);
  const policies = vault.properties.accessPolicies || [];

  // update key vault
  await keyVaultClient.vaults.update(AZURE_RESOURCE_GROUP, keyVaultName, {
    properties: {
      accessPolicies: [
        ...policies,
        {
          tenantId: AZURE_TENANT_ID,
          permissions: {
            keys: ["unwrapKey", "wrapKey", "get"],
          },
          objectId: STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_ID,
        },
      ],
      enabledForDiskEncryption: true,
    },
  });

  // create key vault key
  await MachineLearningService.createKeyVaultKey(
    ctx,
    credentials,
    SUBSCRIPTION_ID,
    AZURE_RESOURCE_GROUP,
    keyVaultName,
    keyVaultKeyName,
    workspace.tags!,
  );

  const identity = `/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${STORAGE_ACCOUNT_CMK_MANAGED_IDENTITY_NAME}`;

  // update storage account
  await storageClient.storageAccounts.update(AZURE_RESOURCE_GROUP, storageAccountName, {
    identity: {
      type: "UserAssigned",
      userAssignedIdentities: {
        [`${identity}` as string]: {},
      },
    },
    encryption: {
      encryptionIdentity: {
        encryptionUserAssignedIdentity: identity,
      },
      keySource: "Microsoft.Keyvault",
      services: {
        file: {
          enabled: true,
        },
        blob: {
          enabled: true,
        },
        queue: {
          enabled: true,
        },
        table: {
          enabled: true,
        },
      },
      keyVaultProperties: {
        keyName: keyVaultKeyName,
        keyVaultUri: vault.properties.vaultUri,
      },
    },
  });
}

async function setStorageAccountsEncryption() {
  const workspaces = await MachineLearningService.getAllProjects();
  const validWorkspaces = await filterValidWorkspaces(ctx, workspaces);

  const credentials = MachineLearningService.connect();
  const storageClient = new StorageManagementClient(credentials, SUBSCRIPTION_ID);
  const keyVaultClient = new KeyVaultManagementClient(credentials, SUBSCRIPTION_ID);

  const errors: string[] = [];

  const workspaceChunks = chunkArray(validWorkspaces);
  for (let index = 0; index < workspaceChunks.length; index++) {
    const chunk = workspaceChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (workspace) => {
        await setEncription(workspace, credentials, storageClient, keyVaultClient);
      }),
    );
    for (const [index, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(`${chunk[index].tags!.project} failed with error: ${promiseResult.reason}`);
      }
    }
  }

  console.log(errors);
}

setStorageAccountsEncryption();
