import "dotenv/config";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import { Project } from "../src/services/dbConnector/models/project";
import EntitlementsService from "../src/services/igamService/entitlementsService";
import { getOrgName, getTeamGroupName } from "../src/utils/helpers";
import { ORG_PREFIX, VL_ORG } from "../src/utils/config";
import GraphService from "../src/services/graphService/graphService";
import { ProjectStatus } from "../src/services/dbConnector/enums";
import OrgService from "../src/services/igamService/orgService";

const ctx = console as any;
const args = process.argv.slice(2);

async function setProjectOrg(project: Project, readOnly: boolean) {
  const entitlement = await EntitlementsService.get(ctx, getTeamGroupName(project.name));
  const projectOrgName = getOrgName(project.name);
  const { owner } = entitlement[0];

  if (owner !== `${projectOrgName}(${VL_ORG})` && owner !== VL_ORG) {
    // project has been updated or is new
    return;
  }

  const {
    owners: projectOwners,
    teamGroupName,
    ownersGroupName,
    membersGroupName,
    name,
    ownersGroupId,
  } = project;

  const owners = await GraphService.getGroupUsers(ctx, ownersGroupId, [
    "department",
    "userType",
    "id",
  ]);
  const ecbOwners = owners.filter(({ userType }) => userType === "Member");

  // if there are any ECB owners, pick the first one from them. otherwise, the first one of all
  const firstOwnerId =
    projectOwners.find((ownerId) => ecbOwners.map(({ id }) => id).includes(ownerId)) ||
    projectOwners[0];

  const firstOwner = owners.find(({ id }) => id === firstOwnerId);
  if (!firstOwner) {
    throw new Error(`Missing first owner for ${name}`);
  }
  const department = await GraphService.getUserDepartment(ctx, firstOwner);

  if (readOnly) {
    ctx.log(`Would set entitlement owner for project ${name} to ${department}`);
    ctx.log(`Would delete org ${getOrgName(name)}`);
  } else {
    // set new entitlement owner
    ctx.log(`Setting entitlement owner for project ${name} to ${department}`);
    await EntitlementsService.updateOrg(
      ctx,
      [teamGroupName, ownersGroupName, membersGroupName],
      department,
      false,
    );

    // delete project org
    ctx.log(`Deleting org ${getOrgName(name)}`);
    await OrgService.deleteByName(ctx, getOrgName(name));
  }
}

async function updateProjectOrgs(readOnly: boolean) {
  const projects = await ProjectModel.find({ status: ProjectStatus.Active });
  const errors: string[] = [];

  // step 1: set entitlement orgs (owners) and delete project orgs
  for (const project of projects) {
    try {
      await setProjectOrg(project, readOnly);
    } catch (e) {
      errors.push(`Error for ${project.name} ${e}`);
    }
  }

  // step 2: check leftover orgs
  const orgs = await OrgService.search(ctx, `orgName eq ${ORG_PREFIX}*`);
  const invalidOrgs = orgs.filter(
    (org) =>
      // it's not used by a project - which shouldn't happen after the step above
      !projects.some(({ name }) => org.orgName.startsWith(getOrgName(name))) &&
      // it's not one of our orgs 2173 = VL org, 30869 = VL team org
      !["2173", "30869"].includes(org.id),
  );

  for (const org of invalidOrgs) {
    if (readOnly) {
      ctx.log(`Would delete org ${org.orgName}`);
    } else {
      ctx.log(`Deleting org ${org.orgName}`);
      try {
        await OrgService.delete(ctx, org.id);
      } catch (e) {
        errors.push(`Error for ${org.orgName} ${e}`);
      }
    }
  }

  ctx.log(errors);
}

updateProjectOrgs(args[0] !== "--update");
