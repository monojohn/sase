import "dotenv/config";

import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import { GraphUser } from "../src/services/graphService/types";
import { chunkArray } from "../src/utils/chunkArray";
import { GROUP_TEAM_PREFIX } from "../src/utils/config";
import { isTechnicalAccount } from "../src/utils/isTechnicalAccount";
import MetricsService from "../src/services/metricsService/metricsService";

const ctx = console as any;

type User = Pick<GraphUser, "id" | "mail" | "displayName" | "userType" | "department">;
type UserMap = Record<string, { user: User; projects: string[] }>;

const getUserDetails = async () => {
  const errors: string[] = [];

  const usersWithProjects: UserMap = {};
  const projects = await ProjectModel.find();
  const projectChunks = chunkArray(projects);
  for (let index = 0; index < projectChunks.length; index++) {
    const chunk = projectChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const team = await GraphService.getGroupMemberUsers(ctx, project.teamGroupId, [
          "id",
          "userType",
          "department",
          "displayName",
          "mail",
        ]);

        for (const member of team.filter(({ displayName }) => !isTechnicalAccount(displayName))) {
          if (!usersWithProjects[member.id]) {
            usersWithProjects[member.id] = {
              user: member,
              projects: [],
            };
          }
          usersWithProjects[member.id].projects.push(project.name);
        }
      }),
    );
    for (const promiseResult of settled) {
      if (promiseResult.status === "rejected") {
        errors.push(promiseResult.reason);
      }
    }
  }

  // count users in each department
  // get projects that users are part of from each department
  const departmentsDistribution = Object.keys(usersWithProjects).reduce(
    (acc, id) => {
      const userDetails = usersWithProjects[id];
      const department = userDetails.user.department;
      // start at count 0 and empty array for projects if it does not exist
      if (!acc[department]) {
        acc[department] = {
          users: [],
          projects: [],
        };
      }
      // increment and add projects
      acc[department] = {
        users: Array.from(new Set([...acc[department].users, userDetails.user.displayName])),
        projects: Array.from(new Set([...acc[department].projects, ...userDetails.projects])),
      };
      return acc;
    },
    {} as { [department: string]: { users: string[]; projects: string[] } },
  );

  return {
    errors,
    departmentsDistribution,
  };
};

const getGuestsPerInstitution = async () => {
  if (!GROUP_TEAM_PREFIX) {
    throw new Error(`GROUP_TEAM_PREFIX not set, received '${GROUP_TEAM_PREFIX}'`);
  }
  const groupsUsers = await MetricsService.getUsersByGroups(
    ctx,
    GROUP_TEAM_PREFIX,
    ["userType", "mail", "department", "id", "displayName", "otherMails"],
    true,
  );
  // get guest users
  const guestUsers = groupsUsers
    .flat(1)
    .filter(
      ({ userType, displayName }) => userType === "Guest" && !isTechnicalAccount(displayName),
    );

  // get unique emails
  const uniqueEmails = [...new Set(guestUsers.map((a) => a.mail))];
  // get unique users from emails
  const uniqueUsers = uniqueEmails.map((email) => guestUsers.find((user) => user.mail === email)!);

  // count users in each institution
  const institutionsCount = uniqueUsers.reduce(
    (acc, { otherMails }) => {
      const institutionCode = GraphService.getInstitutionOfUser(otherMails);
      // start at count 0 if it does not exist

      if (!institutionCode) {
        return acc;
      }

      if (!acc[institutionCode]) {
        acc[institutionCode] = 0;
      }

      // increment
      acc[institutionCode] += 1;
      return acc;
    },
    {} as { [institutionCode: string]: number },
  );

  return institutionsCount;
};

const getDepartments = async () => {
  const { errors, departmentsDistribution } = await getUserDetails();
  const institutionsCount = await getGuestsPerInstitution();
  console.log("-------- Users distribution per department ----------");
  for (const department of Object.keys(departmentsDistribution)) {
    console.log(`${department} - ${departmentsDistribution[department].users.join(", ")}`);
  }

  console.log("-------- Projects distribution per department ----------");
  for (const department of Object.keys(departmentsDistribution)) {
    console.log(`${department} - ${departmentsDistribution[department].projects.join(", ")}`);
  }

  console.log("Department name,User count,Projects count");
  for (const department of Object.keys(departmentsDistribution)) {
    console.log(
      [
        department,
        departmentsDistribution[department].users.length,
        departmentsDistribution[department].projects.length,
      ].join(","),
    );
  }

  if (errors.length) {
    console.log(errors);
  }

  console.log("-------- Institutions ----------");

  console.log(
    `Found ${Object.keys(institutionsCount).length} institutions with the following distribution:`,
  );
  console.log("Institution name,User count");
  for (const institution of Object.keys(institutionsCount)) {
    console.log([institution, institutionsCount[institution]].join(","));
  }
};

getDepartments();
