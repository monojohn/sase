import "dotenv/config";
import IamAuth from "../src/services/iamService/iamAuth";
import IamService from "../src/services/iamService/iamService";

const ctx = console as any;

const script = async () => {
  const token = await IamAuth.getToken();
  const data = await IamService.getRoles(ctx, "VLAB_ESCB-Employee");
  console.log(data);
};

script();
