import "dotenv/config";
import { MlWhitelistItem } from "../src/features/mlWhitelist/types";
import MlWhitelistModel from "../src/services/dbConnector/models/mlWhitelistModel";
import MongoConnector from "../src/services/dbConnector/mongoDb";

export const script = async () => {
  const { url, description } = {
    url: "kalafioras.eu.3ml.com.test",
    description: "just aa funny test to check the flow",
  } as MlWhitelistItem;

  await MlWhitelistModel.findOneAndUpdate(
    { url },
    { $set: { url, description } },
    { upsert: true },
  );
};

script()
  .catch((e) => {
    console.log(e);
  })
  .then(() => {
    return MongoConnector.disconnect();
  });
