import "dotenv/config";

import BackupService from "../../src/services/backupService/backupService";
import MongoConnector from "../../src/services/dbConnector/mongoDb";
import { ENV } from "../../src/utils/config";
import { askConfirmation } from "../helpers/askQuestion";

export const args = process.argv.slice(2);

const script = async (fileName: string) => {
  await askConfirmation(`This will delete the "${fileName}" file in ${ENV}. Continue?`);

  await BackupService.delete([fileName]);
  console.log(`${fileName} deleted`);
};

script(args[0])
  .catch((e) => {
    console.log("Cleanup failed", e);
    process.exit(1);
  })
  .then(() => MongoConnector.disconnect());
