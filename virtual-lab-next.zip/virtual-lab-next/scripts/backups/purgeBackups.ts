import "dotenv/config";

import BackupService from "../../src/services/backupService/backupService";
import MongoConnector from "../../src/services/dbConnector/mongoDb";
import { ENV } from "../../src/utils/config";
import { askConfirmation } from "../helpers/askQuestion";

export const args = process.argv.slice(2);

const script = async () => {
  await askConfirmation(`This will delete all backups for ${ENV}. Continue?`);

  const files = await BackupService.listFiles();
  const fileNames = files.map(({ name }) => name);
  await BackupService.delete(fileNames);
};

script()
  .catch((e) => {
    console.log("Cleanup failed", e);
    process.exit(1);
  })
  .then(() => MongoConnector.disconnect());
