import "dotenv/config";
import MongoConnector from "../../src/services/dbConnector/mongoDb";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import path, { dirname } from "node:path";
import UserActionModel from "../../src/services/dbConnector/models/userActionModel";
import { fetchCollectionInChunks, wait } from "../../src/utils/helpers";
import { UserAction } from "../../src/services/dbConnector/models/userAction";

const fileName = "userActions.json";
const collectionName = UserActionModel;

const ctx = console as any;

const __dirname = dirname(fileURLToPath(import.meta.url));
const pathName = `./downloads/${fileName}`;

const script = async () => {
  // a new type may need to be defined based on the format of the JSON file so it can be properly parsed
  type ExtendedUserAction = UserAction & {
    createdAt: { $date: string };
    updatedAt: { $date: string };
    _id: { $oid: string };
  };

  const file = fs.readFileSync(path.resolve(__dirname, pathName), "utf8");
  const newData: ExtendedUserAction[] = JSON.parse(file);

  // get the current collection data
  const currentData = await fetchCollectionInChunks(collectionName, {});
  const existingIds = currentData.map(({ _id }) => _id.toString());

  // get data that needs to be inserted
  const dataToInsert = newData.filter(({ _id }) => !existingIds.includes(_id.$oid.toString()));
  ctx.log(`${dataToInsert.length} records to insert`);

  for (const doc of dataToInsert) {
    // parse the data so it can be uploaded to the collection
    const updatedDoc = {
      ...doc,
      createdAt: doc.createdAt.$date ? doc.createdAt.$date : doc.createdAt,
      updatedAt: doc.updatedAt.$date ? doc.updatedAt.$date : doc.updatedAt,
      _id: doc._id.$oid ? doc._id.$oid : doc._id,
    };
    ctx.log(updatedDoc);
    await collectionName.insertMany([updatedDoc]);
    // the wait time can be updated based on results to not run into the too many requests error
    await wait(0.1);
  }
};

script()
  .catch((err) => {
    console.error(err);
  })
  .then(() => {
    MongoConnector.disconnect();
    console.log("done");
  });
