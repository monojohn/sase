import "dotenv/config";

import fs from "node:fs";
import path, { dirname } from "path";
import { fileURLToPath } from "node:url";
import BackupService from "../../src/services/backupService/backupService";

const ctx = console as any;

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

type ModelEntry = {
  _id: string;
};

type CompassEntry = {
  _id: {
    $oid: string;
  };
};

/**
 * Downloads and attempts to format a file from Azure storage.
 * If formatting fails, the raw copy is put to file
 *
 * @param fileName the file name to download
 */
export const downloadBackup = async (fileName: string) => {
  const fileAsString = await BackupService.getFile(ctx, fileName);

  // format file
  console.log(`Formatting file`);
  let formattedFile = fileAsString;
  try {
    const entries = JSON.parse(fileAsString) as ModelEntry[];

    // add $oid so it's easy to insert into Compass
    const compassEntries = entries.map((entry) => {
      return {
        ...entry,
        ...{ _id: { $oid: entry._id } },
      } as CompassEntry;
    });

    formattedFile = JSON.stringify(compassEntries, null, 2);
  } catch (e) {
    console.log(`Failed to format file, saving unformatted version`);
  }

  const downloadDirectory = path.resolve(__dirname, `./downloads`);
  // create dir if not present
  if (!fs.existsSync(downloadDirectory)) {
    console.log(`Creating "${downloadDirectory} dir"`);
    fs.mkdirSync(downloadDirectory);
  }

  // create / overwrite file
  const filename = `${fileName}.json`;
  console.log(`Creating file ${filename}`);
  const filePath = path.resolve(downloadDirectory, filename);
  fs.writeFileSync(filePath, formattedFile);
};
