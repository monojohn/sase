import "dotenv/config";
import BackupService from "../../src/services/backupService/backupService";
import MongoConnector from "../../src/services/dbConnector/mongoDb";

const ctx = console as any;

const script = async () => {
  await BackupService.backupDb(ctx);
};

script()
  .catch((err) => {
    console.error(err);
  })
  .then(() => {
    MongoConnector.disconnect();
    console.log("done");
  });
