import "dotenv/config";

import BackupService from "../../src/services/backupService/backupService";
import MongoConnector from "../../src/services/dbConnector/mongoDb";

const args = process.argv.slice(2);

async function script(prefix?: string) {
  const files = await BackupService.listFiles(prefix?.trim());
  console.log(`Found ${files.length} backups`);

  for (let index = 0; index < files.length; index++) {
    const { name, properties } = files[index];

    console.log(`${name} | ${properties.contentLength} bytes`);
  }
  console.log(
    `Note: The size above accounts will be ~33% larger than the JSON output due to Base64 encoding.`,
  );
}

script(args[0])
  .catch((e) => {
    console.log(e);
    process.exit(1);
  })
  .then(() => MongoConnector.disconnect());
