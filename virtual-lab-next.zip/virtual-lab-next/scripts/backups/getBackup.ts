import "dotenv/config";

import BackupService from "../../src/services/backupService/backupService";
import MongoConnector from "../../src/services/dbConnector/mongoDb";
import { askConfirmation } from "../helpers/askQuestion";
import { downloadBackup } from "./helpers";

export const args = process.argv.slice(2);

export const script = async (prefix: string = "") => {
  if (!prefix) {
    await askConfirmation(`No prefix provided, all backups will be downloaded. Continue?`);
    console.log(`Downloading all files`);
  } else {
    console.log(`Downloading all files starting with ${prefix}`);
  }

  const files = await BackupService.listFiles(prefix);

  if (files.length === 0) {
    let message = "";
    if (prefix) {
      message = `No file found for the prefix "${prefix}". Make sure you don't have any typos`;
    } else {
      message = "No files found";
    }
    return console.log(message);
  }

  for (let index = 0; index < files.length; index++) {
    const file = files[index];
    const fileName = file.name;

    try {
      await downloadBackup(fileName);
    } catch (e) {
      console.log(`Failed to download ${fileName}`);
      console.log(e);
    }
  }
};

script(args[0])
  .catch((e) => {
    console.log(e);
    process.exit(1);
  })
  .then(() => MongoConnector.disconnect());
