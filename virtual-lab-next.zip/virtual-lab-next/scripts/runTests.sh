#!/bin/bash

# get secrets and passwords from key vault 
az login --identity  --object-id $AZURE_USERNAME
flowmailerClientSecret=$(az keyvault secret show -n flowmailer-client-secret --vault-name kv-test-virtuallab)
flowmailerSmtpPass=$(az keyvault secret show -n flowmailer-smtp-pass --vault-name kv-test-virtuallab)
igamCert=$(az keyvault secret show -n igam-cert --vault-name kv-test-virtuallab)
igamKey=$(az keyvault secret show -n igam-key --vault-name kv-test-virtuallab)
infraCertificate=$(az keyvault secret show -n infra-certificate --vault-name kv-test-virtuallab)
azurePrivateKey=$(az keyvault secret show -n azure-private-key --vault-name kv-test-virtuallab)
sofaToken=$(az keyvault secret show -n sofa-token --vault-name kv-test-virtuallab)

# set env variables
FLOWMAILER_CLIENT_SECRET=$(echo $flowmailerClientSecret | jq .value | tr -d \")
FLOWMAILER_SMTP_PASS=$(echo $flowmailerSmtpPass | jq .value | tr -d \")
IGAM_CERT=$(echo $igamCert | jq .value | tr -d \" | sed s/\\\\n/n/g)
IGAM_KEY=$(echo $igamKey | jq .value | tr -d \" | sed s/\\\\n/n/g)
INFRA_CERTIFICATE=$(echo $infraCertificate | jq .value | tr -d \" | sed s/\\\\n/n/g)
AZURE_PRIVATE_KEY=$(echo $azurePrivateKey | jq .value | tr -d \" | sed s/\\\\n/n/g)
GIT_REPOSITORY_TOKEN=$(echo $sofaToken | jq .value | tr -d \")

# pull latest code changes
git config user.email "vl@ecb.europa.eu"
git config user.name "vl-bot"
git remote remove gitlab_origin || true # needed because at a second run, the add command fails
git remote add gitlab_origin https://oauth2:$GIT_TOKEN@gitlab.sofa.dev/$CI_PROJECT_PATH.git
git pull gitlab_origin $CI_COMMIT_BRANCH

# run tests
yarn test:cov

# push new coverage
git add .
git commit -m "update tests coverage"
git push gitlab_origin HEAD:$CI_COMMIT_BRANCH -o ci.skip