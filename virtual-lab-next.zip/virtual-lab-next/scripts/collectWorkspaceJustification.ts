import "dotenv/config";

import fs from "node:fs";
import path, { dirname } from "path";
import { fileURLToPath } from "node:url";

import ProjectModel from "../src/services/dbConnector/models/projectModel";
import MongoConnector from "../src/services/dbConnector/mongoDb";

const SCRIPT_FILENAME = fileURLToPath(import.meta.url);
const SCRIPTS_DIRNAME = dirname(SCRIPT_FILENAME);

const collectWorkspaceJustification = async () => {
  const projects = await ProjectModel.find({ workspaceUrl: { $ne: null } });

  const mappedProjets = projects.map((project) => {
    const { name, workspaceUrl, workspaceType, workspaceExploratoryJustification } = project;

    return {
      name,
      url: workspaceUrl,
      type: workspaceType,
      ...(workspaceType === "Exploratory" && {
        workspaceExploratoryJustification,
      }),
    };
  });

  const exportDir = path.resolve(SCRIPTS_DIRNAME, `./`);
  const exportFile = path.resolve(exportDir, "workspace-justification.json");
  fs.writeFileSync(exportFile, JSON.stringify(mappedProjets, null, 2));
};

collectWorkspaceJustification()
  .catch((e) => {
    console.log(e);
  })
  .then(() => {
    return MongoConnector.disconnect();
  });
