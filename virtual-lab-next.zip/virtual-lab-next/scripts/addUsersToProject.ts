import "dotenv/config";

import { Project } from "../src/services/dbConnector/models/project";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import ProjectService from "../src/services/projectService/projectService";

const ctx = {
  log: console.log,
} as any;

const MEMBERS: string[] = [];
const OWNERS: string[] = [];

async function addUser(
  emailOrUpn: string,
  project: Project,
  existingUpns: string[],
  failed: string[],
  duplicates: string[],
  isAddingOwner: boolean,
) {
  const users = await GraphService.getUserByAltEmail(ctx, emailOrUpn);
  let user = users.find(
    // find first non-sa account
    ({ userPrincipalName }) => !userPrincipalName.startsWith("sa"),
  );

  if (!user) {
    // try to get user by upn
    try {
      user = await GraphService.getUser(ctx, emailOrUpn);
    } catch (e) {
      // ignore errors, graph throws on 404s
    }
  }

  if (!user?.userPrincipalName) {
    const err = `User with email ${emailOrUpn} not found`;
    console.log(err);
    failed.push(err);
    return err;
  }

  const { userPrincipalName } = user;
  if (existingUpns.includes(userPrincipalName.toLocaleLowerCase())) {
    const err = `User with email ${emailOrUpn} and upn ${userPrincipalName} is already in project`;
    console.log(err);
    duplicates.push(err);
    return err;
  }

  console.log(`Adding member ${emailOrUpn}`);
  await ProjectService.addUser(ctx, project, userPrincipalName, isAddingOwner);
}

async function addUsersToProject(pid: string, members: string[], owners: string[]) {
  const project = await ProjectModel.findById(pid);

  if (!project) {
    throw new Error(`Project ${pid} not found`);
  }

  console.log(`Adding ${members.length} members to project ${project.name}`);
  console.log(`Adding ${owners.length} owners to project ${project.name}`);

  console.log("Getting existing owners and members");
  const existingUsers = await GraphService.getGroupUsers(ctx, project.teamGroupId, [
    "id",
    "userPrincipalName",
  ]);

  console.log(`${existingUsers.length} existing users`);
  const existingUpns = existingUsers.map(({ userPrincipalName }) =>
    userPrincipalName.toLocaleLowerCase(),
  );

  const failed = [] as any[];
  const duplicates = [] as any[];
  for (const member of members) {
    await addUser(member, project, existingUpns, failed, duplicates, false);
  }

  for (const owner of owners) {
    console.log(`Adding owner ${owner}`);
    await addUser(owner, project, existingUpns, failed, duplicates, true);
  }

  console.log(`There were ${failed.length} errors`, failed);
  console.log(`There were ${duplicates.length} duplicate users`, duplicates);
}

addUsersToProject("572", MEMBERS, OWNERS);
