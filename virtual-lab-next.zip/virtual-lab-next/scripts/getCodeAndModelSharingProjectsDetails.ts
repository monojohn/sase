import "dotenv/config";
import { Project } from "../src/services/dbConnector/models/project";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import { chunkArray } from "../src/utils/chunkArray";
import { getTeamGroupName } from "../src/utils/helpers";

const ctx = console as any;
const mlProjects: any[] = [];
const gitProjects: any[] = [];
const mlAndGitProjects: any[] = [];

const getCodeAndModelSharingProjectsDetails = async () => {
  const projects = await ProjectModel.find();
  const chunks = chunkArray(
    projects.filter((project) => project.workspaceUrl || project.repositoryUrl),
  );

  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    await Promise.all(
      chunk.map(async (project) => {
        await getProjectDetails(project);
      }),
    );
  }

  console.log("Projects with ML workspace");
  console.log(mlProjects);
  console.log("Projects with Git repository");
  console.log(gitProjects);
  console.log("Projects with ML workspace and Git repository");
  console.log(mlAndGitProjects);
};

const getProjectDetails = async (project: Project) => {
  const teamGroupName = getTeamGroupName(project.name);
  const teamGroupId = await GraphService.getGroupIdByName(ctx, teamGroupName);
  const projectMembers = await GraphService.getGroupUsers(ctx, teamGroupId, [
    "userType",
    "mail",
    "department",
  ]);

  // get non-technical members as they are relevant for members count
  const nonTechincalMembers = projectMembers.filter(
    ({ mail }) => mail && !mail.includes("@cloud.ecb.int"),
  );

  // get ECB users for getting their departments
  const ecbUsers = nonTechincalMembers.filter(({ userType }) => userType !== "Guest");

  var departments = ecbUsers.reduce(
    (acc, user) => {
      if (!acc[user.department]) {
        acc[user.department] = 0;
      }
      acc[user.department] += 1;
      return acc;
    },
    {} as { [department: string]: number },
  );

  const projectDetails = {
    name: project.name,
    description: project.description,
    tags: project.tags,
    membersCount: nonTechincalMembers.length,
    departments,
  };

  if (project.workspaceUrl && project.repositoryUrl) {
    mlAndGitProjects.push(projectDetails);
  } else if (project.workspaceUrl) {
    mlProjects.push(projectDetails);
  } else if (project.repositoryUrl) {
    gitProjects.push(projectDetails);
  }
};

getCodeAndModelSharingProjectsDetails();
