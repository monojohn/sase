import { GetObjectCommand, ListObjectsV2Command, S3Client } from "@aws-sdk/client-s3";
import { AssumeRoleCommand, STSClient } from "@aws-sdk/client-sts";

import {
  DEVO_ACCESS_KEY_ID,
  DEVO_BUCKET,
  DEVO_ENDPOINT,
  DEVO_REGION,
  DEVO_ROLE_ARN,
  DEVO_SECRET_ACCESS_KEY,
  ENV,
  IS_PROD,
} from "../src/utils/config";
import { v4 as uuidv4 } from "uuid";
import fs from "node:fs";

const ctx = console as any;

const downloadDevoFiles = async () => {
  // sts client
  const stsClient = new STSClient({
    region: DEVO_REGION,
    endpoint: DEVO_ENDPOINT,
    credentials: { accessKeyId: DEVO_ACCESS_KEY_ID, secretAccessKey: DEVO_SECRET_ACCESS_KEY },
  });
  const assumeRole = await stsClient.send(
    new AssumeRoleCommand({
      RoleArn: DEVO_ROLE_ARN,
      RoleSessionName: uuidv4(),
      DurationSeconds: 3600,
    }),
  );

  const creds = assumeRole.Credentials;
  if (!creds?.AccessKeyId || !creds?.SecretAccessKey) {
    const message = "Missing credentials from assuming role";
    ctx.log(message);
    throw new Error(message);
  }

  // s3 client
  const s3 = new S3Client({
    region: DEVO_REGION,
    credentials: {
      accessKeyId: creds.AccessKeyId,
      secretAccessKey: creds.SecretAccessKey,
      sessionToken: creds.SessionToken,
    },
  });

  const tableNamePrefix = IS_PROD ? "" : `${ENV.toLowerCase()}_`;
  const tableNames = ["user_metadata", "project_to_user", "project_logs", "token_consumption"];
  for (const tableName of tableNames) {
    const list = await s3.send(
      new ListObjectsV2Command({
        Bucket: DEVO_BUCKET,
        Prefix: `prj_vlab/db/${tableNamePrefix}${tableName}`,
      }),
    );

    if (!list.Contents) {
      return;
    }

    let index = 0;

    for (const obj of list.Contents.filter(({ Key }) => Key?.includes(".parquet"))) {
      const getCmd = new GetObjectCommand({
        Bucket: DEVO_BUCKET,
        Key: obj.Key,
      });

      const response = await s3.send(getCmd);
      const bytes = await response.Body?.transformToByteArray();
      await fs.promises.writeFile(`./data/${tableName}_${index}.parquet`, Buffer.from(bytes!));
      index += 1;
    }
  }
};

downloadDevoFiles();
