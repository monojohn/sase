import "dotenv/config.js";
import moment from "moment";
import { OpenAIUsage } from "../src/services/dbConnector/models/OpenAIUsage";
import { enrichOpenAiUsage, findOpenAiUsage } from "../src/utils/openAIUsage";
import DevoService from "../src/services/devoService/devoService";
import { wait } from "../src/utils/helpers";
const ctx = console as any;

const monthsToExport = [
  "2025-02",
  "2025-03",
  "2025-04",
  "2025-05",
  "2025-06",
  "2025-07",
  "2025-08",
  "2025-09",
  "2025-10",
  "2025-11",
  "2025-12",
  "2026-01",
] as OpenAIUsage["month"][];

const loadDevoData = async () => {
  for (const month of monthsToExport) {
    const metrics = await findOpenAiUsage(month);

    const timestamp = moment(`${month}-01`).toDate();
    console.log(timestamp);

    const enrichedMetrics = enrichOpenAiUsage(metrics, timestamp);

    try {
      await DevoService.uploadData(ctx, enrichedMetrics, "token_consumption");
    } catch (e) {
      console.log(e);
    }

    await wait(1);
  }
};

loadDevoData();
