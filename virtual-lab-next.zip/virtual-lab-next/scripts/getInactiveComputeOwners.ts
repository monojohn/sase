import "dotenv/config";
import moment from "moment";
import { Project } from "../src/services/dbConnector/models/project";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import MachineLearningService from "../src/services/machineLearningService/machineLearningService";
import { chunkArray } from "../src/utils/chunkArray";

const ctx = console as any;
const times = {
  cpu: 16,
  gpu: 1,
};

async function getInactiveComputesFromWorkspace(project: Project) {
  const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
  if (!workspace) {
    return [];
  }

  const computes = await MachineLearningService.getComputes(ctx, workspace.name!);

  const toEmail: string[] = [];
  await Promise.all(
    computes
      .filter(({ properties }) => properties.computeType === "ComputeInstance")
      .map(async (compute) => {
        const computeType = MachineLearningService.isComputeInstanceGPU(compute) ? "gpu" : "cpu";
        const { userId } = compute.properties.properties.createdBy;

        const daysOfInactivity = moment().diff(moment(compute.properties.modifiedOn), "days");

        if (daysOfInactivity >= times[computeType]) {
          const userEmail = await GraphService.getUserEmail(ctx, userId);
          toEmail.push(userEmail);
        }
      }),
  );

  return toEmail;
}

async function getOwnersOfInactiveComputeInstances() {
  const errors: string[] = [];

  const projects = await ProjectModel.find();
  const projectsWithMLWorkspaces = projects.filter(({ workspaceUrl }) =>
    workspaceUrl?.startsWith("http"),
  );

  const projectsChunks = chunkArray(projectsWithMLWorkspaces);

  let owners: string[] = [];

  for (let index = 0; index < projectsChunks.length; index++) {
    const chunk = projectsChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const ownersToEmail = await getInactiveComputesFromWorkspace(project);
        owners = Array.from(new Set([...owners, ...ownersToEmail]));
      }),
    );

    // preserve errors
    for (const [index, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(`${chunk[index].name} failed with ${promiseResult.reason}`);
      }
    }
  }

  if (errors.length > 0) {
    console.log(errors);
  }

  console.log("----------------");
  console.log(owners.join("\n"));
}

getOwnersOfInactiveComputeInstances();
