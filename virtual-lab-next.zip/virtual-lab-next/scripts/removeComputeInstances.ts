import "dotenv/config";

import { Project } from "../src/services/dbConnector/models/project";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import MachineLearningService from "../src/services/machineLearningService/machineLearningService";
import { chunkArray } from "../src/utils/chunkArray";
import { askConfirmation } from "./helpers/askQuestion";
import { getEmailOfUser } from "../src/utils/helpers";

const ctx = console as any;

const excludedMLWorkspaces = ["mlw-athenamodeldevelopment0a8d", "mlw-timeseriesforecastingusij35c"];

async function deleteComputesFromWorkspace(readOnly: boolean, project: Project) {
  const workspace = await MachineLearningService.getWorkspaceByProjectName(project.name);
  if (!workspace || excludedMLWorkspaces.includes(workspace.name!)) {
    return;
  }
  const computesData = await MachineLearningService.getComputes(ctx, workspace.name!);
  const incompliantComputes = computesData.filter(
    (compute) => new Date(compute.properties.createdOn) < new Date("2023-04-26T23:00:00"),
  );

  if (incompliantComputes.length === 0) {
    return;
  }
  const owners = await GraphService.getGroupUsers(ctx, project.ownersGroupId, [
    "mail",
    "otherMails",
    "identities",
  ]);
  const ownersEmails = owners.map((owner) => getEmailOfUser(owner));

  if (readOnly) {
    return {
      computes: incompliantComputes.map(
        (compute) =>
          `Would delete compute ${compute.name}/${workspace.name!} for project ${
            project.name
          } --- last used on ${compute.properties.modifiedOn}`,
      ),
      owners: ownersEmails,
    };
  }

  incompliantComputes.map(async (compute) => {
    console.log(`Deleting compute ${compute.name} for project ${project.name}`);
    await MachineLearningService.deleteCompute(ctx, workspace.name!, compute.name);
  });

  return {
    computes: incompliantComputes.map(
      (compute) => `Trigegred deletion of compute ${compute.name} for project ${project.name}`,
    ),
    owners: ownersEmails,
  };
}

async function deleteComputeInstances(readOnly: boolean) {
  const errors: string[] = [];

  const projects = await ProjectModel.find();
  const projectsWithMLWorkspaces = projects.filter(({ workspaceUrl }) =>
    workspaceUrl?.startsWith("http"),
  );

  const projectsChunks = chunkArray(projectsWithMLWorkspaces);

  let incompliantComputes: string[] = [];
  let owners: string[] = [];

  for (let index = 0; index < projectsChunks.length; index++) {
    const chunk = projectsChunks[index];
    const settled = await Promise.allSettled(
      chunk.map(async (project) => {
        const computeDetails = await deleteComputesFromWorkspace(readOnly, project);
        if (computeDetails) {
          incompliantComputes = [...incompliantComputes, ...computeDetails.computes];
          owners = Array.from(new Set([...owners, ...computeDetails.owners]));
        }
      }),
    );

    // preserve errors
    for (const [index, promiseResult] of settled.entries()) {
      if (promiseResult.status === "rejected") {
        errors.push(`${chunk[index].name} failed with ${promiseResult.reason}`);
      }
    }
  }

  if (errors.length > 0) {
    console.log(errors);
  }
  console.log(incompliantComputes.join("\n"));
  console.log(`Total number of incompliant resources: ${incompliantComputes.length}`);

  console.log("----------------");
  console.log(owners.join("\n"));
}

export const args = process.argv.slice(2);

async function deleteComputes(deleteMode: boolean) {
  if (deleteMode) {
    await askConfirmation("The script is running in delete mode, are you sure?", ["yes", "y"]);
  }

  return deleteComputeInstances(!deleteMode);
}

deleteComputes(args[0] === "--delete").catch((e) => {
  console.log("Compute deletion failed", e);
  process.exit(1);
});
