import { HttpRequest, Context as MsContext, Timer } from "@azure/functions";
import { Session } from "../src/middleware/withHttpSession";
import { Project } from "../src/services/dbConnector/models/project";

type Props = {
  params?: Record<string, unknown>;
  body?: Record<string, unknown>;
};

export type MainHandler<T> = (context: MsContext, props: T) => Promise<boolean | void>;

export type UserPermissions = {
  isOwnerOrAdmin: boolean;
  isUserNonEscb: boolean;
  isMember: boolean;
  isOwner: boolean;
  isAdmin: boolean;
  isVlUser: boolean;
};

export type Context<Props> = MsContext & {
  session: Session;
  project: Project;
  permissions: UserPermissions;
  req: Omit<HttpRequest, keyof Props> & Props;
  actionId: number | string;
};

export type HttpTrigger<Props = {}> = (ctx: Context<Props>) => Promise<unknown> | unknown;

export type WithSession<T> = T & {
  upn?: string;
  oid?: string;
};

/**
 * Middleware type. Accepts a handler and a config and returns the executing handler
 */
export type HttpTriggerMw<K> = <T>(handler: HttpTrigger<T>, props: K) => HttpTrigger<T>;

/**
 * Middleware type. Accepts a handler returns the executing handler
 */
export type HttpTriggerMwWithoutParams = <T>(handler: HttpTrigger<T>) => HttpTrigger<T>;

export type HttpTriggerProps<P> = P & { session: Session };

export type CronTrigger = (ctx: MsContext, timer: Timer) => Promise<void>;

export interface CronTriggerMw {
  (handler: CronTrigger): CronTrigger;
}

export type FullSession = {
  aud: string;
  iss: string; // "https://sts.windows.net/f4e69ed8-b558-4494-a61a-031b535160c5/",
  iat: number; // 1645540748,
  nbf: number; // 1645540748,
  exp: number; // 1645544992,
  acr: string; // "1",
  aio: string;
  amr: string[]; // [ "pwd" ],
  appid: string;
  appidacr: string; // "0",
  family_name: string; //  "Santos",
  given_name: string; // "Martinho",
  ipaddr: string; // "195.128.0.90",
  name: string; // "Santos, Martinho (External)",
  oid: string;
  onprem_sid: string;
  rh: string;
  scp: string; //  "user_impersonation",
  sub: string;
  sid: string; // session id
  tid: string;
  unique_name: string; //  "Martinho.Santos@tadnet.eu",
  upn?: string; //  "Martinho.Santos@tadnet.eu" NOTE: NOT present for guest users
  uti: string;
  ver: string; //  "1.0"
};

export type MlSession = {
  aud: string; // "https://storage.azure.com/",
  iss: string; // "https://sts.windows.net/f4e69ed8-b558-4494-a61a-031b535160c5/",
  iat: number; // 1672849237,
  nbf: number; // 1672849237,
  exp: number; // 1672935937,
  aio: string; // "E2ZgYJBZxLZd55gQz62z/XrfltfzAgA=",
  appid: string; // "ddff0531-898b-4436-a918-fac9d6f3ce72",
  appidacr: string; // "2",
  idp: string; // "https://sts.windows.net/f4e69ed8-b558-4494-a61a-031b535160c5/",
  oid: string; // "c6e452a0-8302-4427-8879-baa3a7714e23",
  rh: string; // "0.AAAA2J7m9Fi1lESmGgMbU1FgxYGmBuTU86hCkLbCsClJevE5AAA.",
  sub: string; // "c6e452a0-8302-4427-8879-baa3a7714e23",
  tid: string; // "f4e69ed8-b558-4494-a61a-031b535160c5",
  uti: string; // "KRcguQ5Rk0aRaQgOf34gCQ",
  ver: string; // "1.0",
  xms_mirid: string; // "/subscriptions/231020c2-5e29-4ec6-8e69-c879b0c4ba0b/resourcegroups/rg-VLTest/providers/Microsoft.MachineLearningServices/workspaces/mlw-mbstestentorgdc3e/onlineEndpoints/managed-endpoint-01041543656448"
};
