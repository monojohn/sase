import MongoConnector from "../src/services/dbConnector/mongoDb";
import { MongoMemoryServer } from "mongodb-memory-server";

let mongoServer: MongoMemoryServer;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  process.env.MONGO_URL = mongoServer.getUri();
});

afterAll(async () => {
  // close DB connection after tests
  await MongoConnector.disconnect();
  if (mongoServer) {
    await mongoServer.stop();
  }
});
