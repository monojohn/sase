import { HttpMethod } from "@azure/functions";
import jwt from "jsonwebtoken";
import { Session } from "../src/middleware/withHttpSession";
import {
  AccessibilityLevel,
  ConfidentialityLevel,
  DataSensitivityLevel,
  ProjectStatus,
} from "../src/services/dbConnector/enums";
import { Project } from "../src/services/dbConnector/models/project";
import ProjectModel from "../src/services/dbConnector/models/projectModel";
import GraphService from "../src/services/graphService/graphService";
import {
  GROUP_MEMBERS_SUFFIX,
  GROUP_OWNERS_SUFFIX,
  GROUP_SEC_PREFIX,
  GROUP_TEAM_PREFIX,
} from "../src/utils/config";
import { getTeamGroupName } from "../src/utils/helpers";
import crypto from "node:crypto";

const ctx: any = console;

const usedIds: string[] = [];
/**
 * Generates a weak unique id for use in tests
 *
 * @returns string id
 */
export const genId = () => {
  // we may get duplicates fairly often so we use a map to avoid them
  let id = "";
  do {
    id = genString(24);
  } while (usedIds.includes(id));

  usedIds.push(id);

  return id;
};

/**
 * Generates a string with length 'length'
 *
 * @param length
 * @returns string
 */
export const genString = (length = 500) => {
  let id = `${crypto.getRandomValues(new Uint32Array(24))[0]}`;
  while (id.length < length) {
    id = `${id}${crypto.getRandomValues(new Uint32Array(24))[0]}`;
  }

  return id.substring(0, length);
};

/**
 * Creates a test project with reasonable defaults
 *
 * @param props Partial project
 * @returns
 */
export const createTestProject = async (props: Partial<Project> = {}) => {
  const {
    name = `UT project ${genId()}`,
    description = "description",
    url = "url",
    owners = [],
    members = [],
    accessibilityLevel = AccessibilityLevel.Public,
    confidentialityLevel = ConfidentialityLevel.PUBLIC,
    dataSensitivityLevel = DataSensitivityLevel.No,
    ...rest
  } = props;

  return ProjectModel.create({
    url,
    name,
    owners,
    members,
    description,
    accessibilityLevel,
    confidentialityLevel,
    dataSensitivityLevel,
    status: ProjectStatus.Active,
    ...rest,
  });
};

export const getIntegrationProjects = async () => {
  const baseTeamName = getTeamGroupName("Integration project");
  const baseSecGroupName = baseTeamName.replace(GROUP_TEAM_PREFIX, GROUP_SEC_PREFIX);
  const [teamGroups, securityGroups] = await Promise.all([
    GraphService.searchGroups(ctx, baseTeamName),
    GraphService.searchGroups(ctx, baseSecGroupName),
  ]);

  const [ownerGroups, memberGroups] = [
    securityGroups.filter(({ displayName }) => displayName.includes(GROUP_OWNERS_SUFFIX)),
    securityGroups.filter(({ displayName }) => displayName.includes(GROUP_MEMBERS_SUFFIX)),
  ];

  const teamGroupNames = teamGroups.map(({ displayName }) => displayName);

  const existingProjects = await ProjectModel.find({
    teamGroupName: { $in: teamGroupNames },
    status: ProjectStatus.Active,
  });

  // filter out projects without security groups
  const validGroups = teamGroups.filter(({ displayName }) => {
    const baseGroupName = displayName.replace(GROUP_TEAM_PREFIX, "");

    const [ownerGroup, memberGroup] = [
      ownerGroups.find((group) => group.displayName.includes(baseGroupName)),
      memberGroups.find((group) => group.displayName.includes(baseGroupName)),
    ];

    return ownerGroup && memberGroup;
  });

  const groupsWithoutProject = validGroups.filter(
    ({ displayName }) =>
      !existingProjects.some(({ teamGroupName }) => teamGroupName === displayName),
  );

  const projectsToCreate = await Promise.all(
    groupsWithoutProject.map(async (group) => {
      const teamGroupName = group.displayName;
      const teamGroupId = group.id;
      const baseGroupName = teamGroupName.replace(GROUP_TEAM_PREFIX, "");
      const projectName = baseGroupName.replaceAll("_", " ");

      // get other groups
      const [ownerGroup, memberGroup] = [
        ownerGroups.find((group) => group.displayName.includes(baseGroupName)),
        memberGroups.find((group) => group.displayName.includes(baseGroupName)),
      ];

      if (!ownerGroup || !memberGroup) {
        throw new Error(`Owner / member oup not found for ${baseGroupName}`);
      }

      const [owners, members] = await Promise.all([
        GraphService.getGroupUsers(ctx, ownerGroup.id, ["id"]),
        GraphService.getGroupUsers(ctx, memberGroup.id, ["id"]),
      ]);

      return {
        name: projectName,
        teamGroupId,
        ownersGroupId: ownerGroup.id,
        membersGroupId: memberGroup.id,
        description: "description",
        owners: owners.map(({ id }) => id),
        members: members.map(({ id }) => id),
        dataSensitivityLevel: DataSensitivityLevel.No,
        accessibilityLevel: AccessibilityLevel.Public,
        confidentialityLevel: ConfidentialityLevel.PUBLIC,
        url: await GraphService.getSiteUrl(ctx, teamGroupId),
        siteId: await GraphService.getSiteId(ctx, teamGroupId),
        status: ProjectStatus.Active as string,
      } as Partial<Project>;
    }),
  );

  const extraProjects = await ProjectModel.create(projectsToCreate);

  return [...existingProjects, ...extraProjects];
};

type TestContext = {
  method?: HttpMethod;
  name: string;
  url?: string;
  log?: any;
  authorization?: string;
  params?: Record<string, any>;
  body?: Record<string, any>;
  project?: Partial<Project>;
  session?: Partial<Session>;
};

export const getCtx = (props: TestContext = { name: "" }) => {
  const authOid = genId();

  const {
    name,
    session,
    method = "GET",
    url = "url",
    authorization = jwt.sign({ upn: "upn", oid: authOid, sid: "session-id" }, "secret"),
    project = {},
    params = {},
    body = {},
    log = ctx.log,
  } = props;

  return {
    req: { method, url, headers: { authorization }, params, body },
    executionContext: { functionName: name },
    invocationId: name,
    log,
    authOid,
    project,
    session,
  } as any;
};
