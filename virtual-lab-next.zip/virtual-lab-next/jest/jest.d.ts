declare global {
  // See: https://stackoverflow.com/a/68328575/12292636
  var adminJwt: string;

  var vidmanteOid: string;
  var vidmanteJwt: string;

  var robertaOid: string;
  var robertaJwt: string;

  var cypressOid: string;
  var cypressJwt: string;

  /**
   * Receives real emails
   */
  var testEmail: string;

  var __MONGO_URL__: string;
}

export {};
