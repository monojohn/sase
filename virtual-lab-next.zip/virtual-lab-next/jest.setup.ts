import "dotenv/config.js";

import fetch from "cross-fetch";
import jwt from "jsonwebtoken";

// ensure tests are not running in prod
if (process.env.AZURE_TENANT === "ecbprod") {
  throw new Error(`Tests must be executed in devEnv`);
}

// required for graph tests
global.fetch = fetch;

process.env.IS_JEST = "true";
process.env.DISABLE_SLACK = "true";
process.env.DATADOG_API_KEY = "fakeapiKey";

// used for integration tests
process.env.TEST_USER_VIDMANTE = "vidmante.vaitone.external@tadnet.eu";
process.env.TEST_USER_ROBERTA = "roberta.popescu.external@tadnet.eu";
process.env.TEST_USER_CYPRESS = "cypresstestuser@test.cloud.ecb.int";
process.env.TEST_USER_ADMIN = "sa_popesco_7470d6ef-528b-46f5-a52f-5729aa3f0d45@test.cloud.ecb.int";

global.adminJwt = jwt.sign(
  { upn: process.env.TEST_USER_ADMIN, oid: "7470d6ef-528b-46f5-a52f-5729aa3f0d45" },
  "secret",
);

global.vidmanteOid = "1d4a57dd-2c6c-4309-b9cb-d404d53476e0";
global.vidmanteJwt = jwt.sign(
  { upn: process.env.TEST_USER_VIDMANTE, oid: "1d4a57dd-2c6c-4309-b9cb-d404d53476e0" },
  "secret",
);

global.robertaOid = "202eb6a9-e030-474c-ab26-5864a99b7a52";
global.robertaJwt = jwt.sign(
  { upn: process.env.TEST_USER_ROBERTA, oid: global.robertaOid },
  "secret",
);

global.cypressOid = "994cc5bf-6e54-4f6c-b0dc-7db518d0067c";
global.cypressJwt = jwt.sign(
  { upn: process.env.TEST_USER_CYPRESS, oid: global.cypressOid },
  "secret",
);

// use a real email to test layout
global.testEmail = "unit-test-email@asdasdasdasdasd.com";
