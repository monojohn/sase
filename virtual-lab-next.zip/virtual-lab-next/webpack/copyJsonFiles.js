import fs from "node:fs";
import path, { dirname } from "path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));

const getDirectories = (source) =>
  fs
    .readdirSync(source, { withFileTypes: true })
    .filter((dirent) => dirent.isDirectory())
    .map((dirent) => dirent.name);

const functionsPath = path.resolve(__dirname, "../dist");
const functions = getDirectories(functionsPath);

// go through each route
for (let index = 0; index < functions.length; index++) {
  const route = functions[index];
  const routePath = path.resolve(__dirname, `../src/functions/${route}`);
  const functionFilesAndDirs = fs.readdirSync(routePath);

  const hasHostJsonFile = functionFilesAndDirs.includes("host.json");
  const hasFunctionJsonFile = functionFilesAndDirs.includes("function.json");

  // each route MUST have a function.json OR a host.json file
  if (!hasHostJsonFile && !hasFunctionJsonFile) {
    throw new Error(
      `[WARNING] Skipping ${route}: Required file missing: function.json or host.json`,
    );
  }

  // copy host.json to root of dist
  if (hasHostJsonFile) {
    const [originHostFile, destinationHostFile] = [
      path.resolve(__dirname, `../src/functions/${route}/host.json`),
      path.resolve(__dirname, `../dist/${route}/host.json`),
    ];
    console.log(`Copying ${originHostFile} to ${destinationHostFile}`);
    fs.copyFileSync(originHostFile, destinationHostFile);
  }

  let originFuncFile = "";
  let destinationFuncPath = "";
  let destinationFuncFile = "";

  if (hasFunctionJsonFile) {
    // copy function.json to <fn-name>/main/function.json
    [originFuncFile, destinationFuncPath, destinationFuncFile] = [
      path.resolve(__dirname, `../src/functions/${route}/function.json`),
      path.resolve(__dirname, `../dist/${route}/main/`),
      path.resolve(__dirname, `../dist/${route}/main/function.json`),
    ];

    fs.mkdirSync(destinationFuncPath, { recursive: true });
    console.log(`Copying ${originFuncFile} to ${destinationFuncFile}`);
    fs.copyFileSync(originFuncFile, destinationFuncFile);
  } else {
    // if function file is not present, scan for sub dirs
    for (const fileOrDir of functionFilesAndDirs) {
      const dirPath = path.resolve(routePath, fileOrDir);
      if (!fs.lstatSync(dirPath).isDirectory()) {
        // skip files
        continue;
      }

      console.log(`Getting items in ${dirPath}`);
      const dirItems = fs.readdirSync(dirPath);
      // ignore directories without function.json files
      if (!dirItems.includes("function.json")) {
        console.log(`ignoring ${dirPath}: no function.json file`);
        continue;
      }

      [originFuncFile, destinationFuncPath, destinationFuncFile] = [
        path.resolve(dirPath, `./function.json`),
        path.resolve(__dirname, `../dist/${route}/${fileOrDir}/`),
        path.resolve(__dirname, `../dist/${route}/${fileOrDir}/function.json`),
      ];

      // and copy each function.json found
      fs.mkdirSync(destinationFuncPath, { recursive: true });
      console.log(`Copying ${originFuncFile} to ${destinationFuncFile}`);
      fs.copyFileSync(originFuncFile, destinationFuncFile);
    }
  }
}
