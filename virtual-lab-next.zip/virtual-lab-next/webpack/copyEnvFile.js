import fs from "node:fs";
import path, { dirname } from "path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));

const getDirectories = (source) =>
  fs
    .readdirSync(source, { withFileTypes: true })
    .filter((dirent) => dirent.isDirectory())
    .map((dirent) => dirent.name);

const funcDistPath = path.resolve(__dirname, "../dist");
const azureFunctions = getDirectories(funcDistPath);
const envFilePath = path.resolve(__dirname, "../.env");

const envFileContents = fs.readFileSync(envFilePath, {
  encoding: "utf-8",
});

const asJson = envToJson(envFileContents);

// go through each route
for (let index = 0; index < azureFunctions.length; index++) {
  const azureFunction = azureFunctions[index];

  const destinationFile = path.resolve(__dirname, `../dist/${azureFunction}/local.settings.json`);

  console.log(`Writing local.settings.json to ${azureFunction}`);
  fs.writeFileSync(destinationFile, asJson);
}

function envToJson(envString = "") {
  const lines = envString.replace(/\r/gi, "").split("\n");
  const output = {};
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index].trim();

    // ignore commented and empty lines
    if (line.indexOf("#") === 0 || line.indexOf("/") === 0 || line.length === 0) {
      continue;
    }

    const [key, ...value] = line.split("=");
    // replace \\n in cert strings with \n for compatibility with Azure
    output[key] = value.join("=").replace(/\\n/gi, "\n");
  }

  return JSON.stringify(
    {
      IsEncrypted: false,
      Values: {
        AzureWebJobsStorage: "UseDevelopmentStorage=true",
        FUNCTIONS_WORKER_RUNTIME: "node",
        ...output,
      },
    },
    null,
    2,
  );
}
