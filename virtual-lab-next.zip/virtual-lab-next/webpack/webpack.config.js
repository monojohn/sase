import fs from "node:fs";
import { createRequire } from "node:module";
import path, { dirname } from "path";
import { fileURLToPath } from "node:url";
import webpack from "webpack";
import { BundleAnalyzerPlugin } from "webpack-bundle-analyzer";

const require = createRequire(import.meta.url);
const __dirname = dirname(fileURLToPath(import.meta.url));

const getEntryFilePath = (dir) => {
  console.log(`Getting items in ${dir}`);
  const dirItems = fs.readdirSync(dir);

  // for windows paths
  let dirSplit = dir.split("\\");
  if (dirSplit[0].length === dir.length) {
    // support unix file paths
    dirSplit = dir.split("/");
  }

  const expectedFileName = dirSplit.at(-1);

  // find first ts file which has the same name as the folder
  let entryFile = dirItems.find(
    (fileName) =>
      fileName.startsWith(expectedFileName) &&
      fileName.endsWith(".ts") &&
      !fileName.endsWith("test.ts"),
  );

  if (!entryFile) {
    throw new Error(`'${expectedFileName}' entry file not found for ${dir}`);
  }

  return path.resolve(__dirname, `${dir}/${entryFile}`);
};

/**
 * Get entry point of folder
 *
 * @param {string[]} funcNames - Names of sub directories to build
 * @returns
 */
const getEntryPoints = (funcNames) => {
  const azureFunctions = funcNames || fs.readdirSync(path.resolve(__dirname, "../src/functions/"));
  const buildEntries = {};

  for (const azureFunctionDir of azureFunctions) {
    // get files and directories inside top directory
    const azureFunctionDirPath = path.resolve(__dirname, `../src/functions/${azureFunctionDir}`);

    if (!fs.lstatSync(azureFunctionDirPath).isDirectory()) {
      // ignore files in functions directory
      continue;
    }

    const filesAndDirs = fs.readdirSync(azureFunctionDirPath);

    // expect a top level host.json file
    if (!filesAndDirs.includes("host.json")) {
      throw new Error(`host.json file missing in ${azureFunctionDir}`);
    }

    // if there is a top level function
    if (filesAndDirs.includes("function.json")) {
      buildEntries[`${azureFunctionDir}/index`] = getEntryFilePath(azureFunctionDirPath);
    } else {
      // if functions are in a sub directory
      for (const fileOrDirectory of filesAndDirs) {
        const dirPath = path.resolve(
          __dirname,
          `../src/functions/${azureFunctionDir}/${fileOrDirectory}`,
        );

        if (!fs.lstatSync(dirPath).isDirectory()) {
          // skip files
          continue;
        }

        const dirItems = fs.readdirSync(dirPath);
        // ignore directories without function.json files
        if (!dirItems.includes("function.json")) {
          console.log(`ignoring ${dirPath}: no function.json file`);
          continue;
        }

        buildEntries[`${azureFunctionDir}/${fileOrDirectory}/index`] = getEntryFilePath(dirPath);
      }
    }
  }

  console.log(buildEntries);

  return buildEntries;
};

export default (env) => {
  const func = env.func;
  const useMetrics = !!env.metrics;

  const functionsPath = path.resolve(__dirname, "../src/functions");
  const functions = func ? [func] : fs.readdirSync(functionsPath);

  // for each of the directories, get the first ts file found
  const entries = getEntryPoints(functions);
  const plugins = [];
  if (useMetrics) {
    plugins.push(
      new BundleAnalyzerPlugin({
        analyzerMode: "static",
        openAnalyzer: true,
      }),
    );
  }
  console.log({ entries });

  return {
    mode: "production",
    target: "node22.19",
    entry: entries,
    output: {
      path: path.resolve(__dirname, "../dist"),
      library: { type: "commonjs2" },
      clean: true,
    },
    module: {
      rules: [
        {
          test: /\.ts(x)?$/,
          loader: "ts-loader",
          exclude: /(node_modules)/,
        },
      ],
    },

    optimization: {
      minimize: false,
      // NOTE: Not minimizing code for now
      // node-fetch breaks with minification due to this issue:
      // https://github.com/node-fetch/node-fetch/issues/784
      // minimizer: [
      //   new TerserPlugin({
      //     // cache: true,
      //     parallel: true,
      //     terserOptions: {
      //       // https://github.com/webpack-contrib/terser-webpack-plugin#terseroptions
      //       mangle: false,
      //       sourceMap: true,
      //       compress: false,
      //       keep_classnames: /AbortSignal/,
      //       keep_fnames: /AbortSignal/,
      //       output: {
      //         beautify: true,
      //         indent_level: 1,
      //       },
      //     },
      //   }),
      // ],
    },
    plugins: [...plugins, new webpack.ContextReplacementPlugin(/moment[\/\\]locale$/, /en/)],
    resolve: {
      extensions: [".ts", ".tsx", ".js"],
      extensionAlias: {
        ".js": [".ts", ".js"],
        ".mjs": [".mts", ".mjs"],
      },
      fallback: {
        https: require.resolve("https"),
      },
    },
  };
};
