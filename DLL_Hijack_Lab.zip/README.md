# DLL Hijacking Lab (Safe & Benign)

This lab gives you:
- A **vulnerable app** that calls `LoadLibrary("testme.dll")` without a full path.
- A **benign DLL payload** that pops a message box when loaded.
- Build scripts for **MSVC (cl)** and **MinGW (gcc)**.
- Quick test steps with ProcMon.

> Use in a lab folder only. Do not target system apps. This is for learning/testing.

---

## Contents

```
DLL_Hijack_Lab/
  src/
    vuln_app.c       # vulnerable app
    testdll.c        # benign DLL payload (MessageBox)
  build_msvc.bat     # build both with MSVC
  build_mingw.bat    # build both with MinGW-w64 (gcc)
  run_test.ps1       # helper to run the test scenario
  README.md          # this file
```

---

## Prereqs

### Option A: MSVC (Visual Studio Build Tools)
- Install **Visual Studio 2022 Build Tools** with the *Desktop development with C++* workload.
- Open **x64 Native Tools Command Prompt for VS**.

### Option B: MinGW-w64 (GCC)
- Install **MinGW-w64** and add its `bin` folder to **PATH**.
- Verify `gcc --version` works.

---

## Build

### MSVC
```
build_msvc.bat
```
Outputs:
- `vuln_app.exe`
- `testdll.dll`

### MinGW
```
build_mingw.bat
```
Outputs:
- `vuln_app.exe`
- `testdll.dll`

---

## Run the hijack test

1) Place both outputs in the **same folder** (they will be in the repo root after build).  
2) **Rename** `testdll.dll` to **`testme.dll`** (the name the app looks for).
3) Run the app:
```
.uln_app.exe
```
If the DLL gets loaded, a **MessageBox** will pop. Close it and the app will continue/exit.

> To see the search-order in action with ProcMon:
> - Filter: `Operation is Load Image` + `Path ends with .dll` + `Process Name is vuln_app.exe`
> - You will see attempts to load `testme.dll` from the working directory and then fallback locations.

---

## Clean up

- Delete the renamed `testme.dll` after testing.
- Keep `testdll.dll` as your benign payload for other tests.

---

## Notes

- The vulnerable app is intentionally unsafe and should **never** be used in production.
- On modern Windows, **Safe DLL Search Mode** is enabled by default; this demo is still valid because the app requests a DLL by **name** without an absolute path.
