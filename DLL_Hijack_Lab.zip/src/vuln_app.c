#include <windows.h>
#include <stdio.h>

int main(void) {
    printf("[vuln_app] Attempting to load testme.dll via LoadLibraryA(\"testme.dll\")...\n");
    HMODULE h = LoadLibraryA("testme.dll"); // intentionally unsafe: no full path
    if (h == NULL) {
        DWORD err = GetLastError();
        printf("[vuln_app] LoadLibrary failed. GetLastError() = %lu\n", err);
        printf("[vuln_app] Tip: rename testdll.dll to testme.dll and place it next to vuln_app.exe\n");
        return 1;
    } else {
        printf("[vuln_app] DLL loaded! Now FreeLibrary and exit.\n");
        FreeLibrary(h);
        return 0;
    }
}
