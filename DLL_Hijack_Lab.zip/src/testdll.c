#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
    if (fdwReason == DLL_PROCESS_ATTACH) {
        MessageBoxA(NULL, "Benign DLL loaded via hijack test!", "DLL Hijacking Lab", MB_OK | MB_ICONINFORMATION);
    }
    return TRUE;
}
