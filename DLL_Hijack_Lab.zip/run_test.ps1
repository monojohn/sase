# Runs the demo: renames testdll.dll -> testme.dll and launches vuln_app.exe
param(
  [switch]$KeepName  # if set, won't rename the DLL (advanced usage)
)

$exe = Join-Path $PSScriptRoot "vuln_app.exe"
$dll = Join-Path $PSScriptRoot "testdll.dll"
$target = Join-Path $PSScriptRoot "testme.dll"

if (!(Test-Path $exe)) { Write-Error "vuln_app.exe not found. Build first."; exit 1 }
if (!(Test-Path $dll)) { Write-Error "testdll.dll not found. Build first."; exit 1 }

if (-not $KeepName) {
  Copy-Item -Path $dll -Destination $target -Force
  Write-Host "[*] Copied testdll.dll to testme.dll"
} else {
  Write-Host "[*] Using testdll.dll without rename"
}

Write-Host "[*] Launching vuln_app.exe ..."
Start-Process -FilePath $exe -NoNewWindow -Wait

Write-Host "[*] Done. Cleaning up copied DLL..."
if (Test-Path $target) { Remove-Item $target -Force }
